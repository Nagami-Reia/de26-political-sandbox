"""Bundle this plugin and its evidence; exclude caches and scenario reports."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED


def build(output):
    root=Path(__file__).resolve().parent
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    files=sorted(p for p in root.rglob("*") if p.is_file() and p.suffix not in {".pyc",".zip"}
                 and not set(p.relative_to(root).parts)&{"__pycache__","output","outputs",".git"} and p.name!=".DS_Store")
    manifest={str(p.relative_to(root)):sha256(p.read_bytes()).hexdigest() for p in files}
    with ZipFile(output,"w",ZIP_DEFLATED) as archive:
        for path in files:archive.write(path,"hakoniwa_polling/"+str(path.relative_to(root)))
        archive.writestr("package_manifest.json",json.dumps({"schema_version":"sha256-files-1","package":"hakoniwa_polling","sha256":manifest},ensure_ascii=False,indent=2))
    return {"archive":str(output),"bytes":output.stat().st_size,"files":len(files),"sha256":sha256(output.read_bytes()).hexdigest()}


if __name__ == "__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--output",type=Path,default=Path("hakoniwa_polling_plugin_v1.zip"))
    print(json.dumps(build(parser.parse_args().output),ensure_ascii=False))
