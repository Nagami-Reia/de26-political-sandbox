"""Plugin calendar-time measurement; not a proprietary pollster model.

The latent trajectory is piecewise constant between timestamped observations.
The trailing fieldwork window averages time, never event counts. We make no
claim that this uniform window reproduces actual respondents' interview times.
"""
from datetime import datetime, timedelta, timezone
import math

from .model import normalize


def instant(value):
    dt = datetime.fromisoformat(value) if isinstance(value, str) else value
    if dt.tzinfo is None:
        raise ValueError("Polling observation timestamps require an explicit UTC offset")
    return dt.astimezone(timezone.utc)


def publication_round(probabilities, grid=.5):
    """Largest-remainder rounding of a complete composition, preserving 100%."""
    if not math.isfinite(grid) or grid <= 0 or not math.isclose(100/grid, round(100/grid)):
        raise ValueError("Grid must divide 100 into whole publication units")
    p = normalize(probabilities)
    units = round(100/grid)
    exact = [v*units for v in p]
    counts = [math.floor(v) for v in exact]
    # Stable party-order tie break is recorded policy, not random measurement.
    order = sorted(range(len(p)), key=lambda j: (-(exact[j]-counts[j]), j))
    for j in order[:units-sum(counts)]:
        counts[j] += 1
    return [v*grid for v in counts]


class FieldworkObserver:
    def __init__(self, parties, window_minutes=4320, publication_grid=.5):
        self.parties = tuple(parties)
        if not self.parties or len(set(self.parties)) != len(self.parties):
            raise ValueError("Nonempty unique, complete party universe required")
        if not math.isfinite(window_minutes) or window_minutes <= 0:
            raise ValueError("Positive finite fieldwork window required")
        publication_round([1]*len(self.parties), publication_grid)
        self.window = timedelta(minutes=window_minutes)
        self.grid = publication_grid
        self.history = []

    def observe(self, timestamp, latent_percent):
        now = instant(timestamp)
        p = normalize(latent_percent)
        if len(p) != len(self.parties):
            raise ValueError("Full party vector required, including Other")
        if self.history and now < self.history[-1][0]:
            raise ValueError("Polling observation time cannot run backwards")
        if self.history and now == self.history[-1][0]:
            self.history[-1] = (now, p)
        else:
            self.history.append((now, p))
        desired_start = now-self.window
        start = max(desired_start, self.history[0][0])
        seconds = (now-start).total_seconds()
        sums = [0.0]*len(p)
        for (at, value), (until, _) in zip(self.history, self.history[1:]):
            span = max(0.0, (min(until, now)-max(at, start)).total_seconds())
            for j, v in enumerate(value):
                sums[j] += span*v
        mean = [v/seconds for v in sums] if seconds else p
        # Keep the boundary predecessor plus the window, not the whole run.
        before = [j for j, (at, _) in enumerate(self.history) if at <= desired_start]
        if before:
            self.history = self.history[before[-1]:]
        return {"parties":list(self.parties), "latent_percent":[v*100 for v in p],
                "fieldwork_mean_percent":[v*100 for v in mean],
                "published_model_percent":publication_round(mean, self.grid),
                "fieldwork_start":start.isoformat(), "fieldwork_end":now.isoformat(),
                "coverage_fraction":min(1.0, seconds/self.window.total_seconds()),
                "evidence_status":"SIMULATION_MEASUREMENT_ASSUMPTION",
                "method":"uniform_time_window_complete_composition_largest_remainder",
                "actual_survey":False, "sampling_error_model":None}
