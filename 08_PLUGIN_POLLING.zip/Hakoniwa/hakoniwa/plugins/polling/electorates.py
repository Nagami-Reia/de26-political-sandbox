"""Rebuild evidence-backed 2025 Bundestag anchors, never synthetic Landtag polls.

Representative election counts identify age × recorded-sex × state choices.
District correlations do NOT identify individual income/occupation effects.
"""
import argparse
import csv
from datetime import date
from hashlib import sha256
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent/"data/electorates"
STATES = dict(zip(("SH","HH","NI","HB","NW","HE","RP","BW","BY","SL","BE","BB","MV","SN","ST","TH"),
                 ("Schleswig-Holstein","Hamburg","Niedersachsen","Bremen","Nordrhein-Westfalen","Hessen",
                  "Rheinland-Pfalz","Baden-Württemberg","Bayern","Saarland","Berlin","Brandenburg",
                  "Mecklenburg-Vorpommern","Sachsen","Sachsen-Anhalt","Thüringen")))
AGES = {"2001-2007":"18–24", "1991-2000":"25–34", "1981-1990":"35–44",
        "1966-1980":"45–59", "1956-1965":"60–69", "<=1955":"70+"}
AGE_PARTS = {"2001-2007":("2005-2007","2001-2004"),"1991-2000":("1996-2000","1991-1995"),
             "1981-1990":("1986-1990","1981-1985"),"1966-1980":("1976-1980","1966-1975"),
             "1956-1965":("1956-1965",),"<=1955":("<=1955",)}
PARTIES = ("Union","SPD","Grüne","FDP","AfD","Linke","BSW","Freie Wähler","Other")
CSV_URLS = {
    "btw25_rws_bst2.csv":"https://www.bundeswahlleiterin.de/dam/jcr/de1bf90b-ae2e-43d6-8974-0a1e0a0a72e3/btw25_rws_bst2.csv",
    "btw25_rws_bw2.csv":"https://www.bundeswahlleiterin.de/dam/jcr/677acfc3-fc2b-4614-aaaf-aab9a1ad05ce/btw25_rws_bw2.csv",
    "btw2025_strukturdaten.csv":"https://www.bundeswahlleiterin.de/dam/jcr/181f9e38-38db-4f64-991c-8141dfa0f2cb/btw2025_strukturdaten.csv",
    "btw25_kerg2.csv":"https://www.bundeswahlleiterin.de/dam/jcr/f49a47a1-735b-4e9b-b4e1-4c73cad2292e/btw25_kerg2.csv"}
FEATURES = {"density_2023_log1p":8,"non_german_citizens_2023_pct":7,
            "disposable_income_2021_eur":35,"gdp_2021_eur_per_capita":36,
            "manufacturing_employment_2023_pct":39,"sgb_ii_aug_2024_per_1000":43,
            "unemployment_nov_2024_pct":46,"school_leavers_university_entrance_2022_pct":32}


def number(value):
    if value in (None,"","-",".","/","x"): return None
    return float(value.replace(",","."))


def read_csv(path):
    lines = Path(path).read_text(encoding="utf-8-sig").splitlines()
    start = next(i for i,line in enumerate(lines) if line.startswith(("Land;","Wahlart;")))
    rows=[r for r in csv.DictReader(lines[start:],delimiter=";") if r.get("Land") or r.get("Wahlart")]
    if any(None in row or any(v is None for v in row.values()) for row in rows):
        raise ValueError("Truncated or malformed source CSV: "+str(path))
    return rows


def party_counts(row):
    out={p:number(row[col]) for p,col in {"SPD":"SPD","Grüne":"GRÜNE","FDP":"FDP","AfD":"AfD",
         "Linke":"Die Linke","BSW":"dar. BSW","Freie Wähler":"dar. FREIE WÄHLER"}.items()}
    # Empty CDU in Bavaria / CSU elsewhere means not standing, not a measured 0.
    union=[number(row[p]) for p in ("CDU","CSU") if number(row[p]) is not None]
    out["Union"] = sum(union) if union else None
    other=number(row["Sonstige"])
    out["Other"] = None if other is None else other-sum(out[p] or 0 for p in ("BSW","Freie Wähler"))
    if any(v is not None and v < -2 for v in out.values()):
        raise ValueError("Negative residual Other: overlapping categories")
    return {p:max(0,v) if v is not None else None for p,v in out.items()}


def weighted_correlation(points):
    # Exploratory effect size, not a significance or prediction claim.
    points=[(x,y,w) for x,y,w in points if x is not None and y is not None and w > 0]
    if len(points)<8: return {"n_districts":len(points),"r":None,"reason":"fewer_than_8_districts"}
    total=sum(w for _,_,w in points)
    mx=sum(x*w for x,_,w in points)/total
    my=sum(y*w for _,y,w in points)/total
    xx=sum(w*(x-mx)**2 for x,_,w in points)
    yy=sum(w*(y-my)**2 for _,y,w in points)
    r=sum(w*(x-mx)*(y-my) for x,y,w in points)/math.sqrt(xx*yy) if xx*yy else None
    return {"n_districts":len(points),"r":r,"unit":"district_ecological_association_not_individual_effect",
            "uncertainty":None,"multiplicity_adjusted":False}


def ecology(raw):
    structure=read_csv(raw/"btw2025_strukturdaten.csv")
    columns=list(structure[0])
    districts={int(r["Wahlkreis-Nr."]):r for r in structure if r["Wahlkreis-Nr."].isdigit() and 1<=int(r["Wahlkreis-Nr."])<=299}
    vote={}
    for r in read_csv(raw/"btw25_kerg2.csv"):
        if r["Gebietsart"] != "Wahlkreis" or r["Stimme"] != "2": continue
        key=int(r["Gebietsnummer"])
        record=vote.setdefault(key,{"parties":{}})
        if r["Gruppenname"] == "Gültige": record["valid"]=number(r["Anzahl"])
        if r["Gruppenart"] == "Partei": record["parties"][r["Gruppenname"]]=number(r["Anzahl"])
    if set(vote) != set(range(1,300)) or set(districts) != set(range(1,300)):
        raise ValueError("Complete results and structure must cover all 299 constituencies")
    table=[]
    for key,r in sorted(districts.items()):
        v=vote[key]; counts=v["parties"]; valid=v["valid"]
        named={"Union":(counts.get("CDU") or 0)+(counts.get("CSU") or 0),"SPD":counts.get("SPD"),
               "Grüne":counts.get("GRÜNE"),"FDP":counts.get("FDP"),"AfD":counts.get("AfD"),
               "Linke":counts.get("Die Linke"),"BSW":counts.get("BSW"),"Freie Wähler":counts.get("FREIE WÄHLER")}
        named["Other"]=valid-sum(v for v in named.values() if v is not None)
        features={key:number(r[columns[index]]) for key,index in FEATURES.items()}
        if features["density_2023_log1p"] is not None: features["density_2023_log1p"]=math.log1p(features["density_2023_log1p"])
        table.append({"district":key,"state":r["Land"],"valid":valid,"features":features,
                      "shares":{p:100*v/valid if v is not None else None for p,v in named.items()}})
    bystate={}
    for state in STATES.values():
        subset=[r for r in table if r["state"] == state]
        bystate[state]={p:{f:weighted_correlation([(r["features"][f],r["shares"][p],r["valid"]) for r in subset]) for f in FEATURES} for p in PARTIES}
    return {"source_labels":{f:columns[i] for f,i in FEATURES.items()},"within_state":bystate,
            "districts":table,"warning":"Exploratory spatial associations; no individual income, education, immigration or employment voting effect is inferred"}


def build(root=ROOT):
    root=Path(root); raw=root/"raw"
    votes=[r for r in read_csv(raw/"btw25_rws_bst2.csv") if r["Erst-/Zweitstimme"] == "2"]
    turnout={(r["Land"],r["Geschlecht"],r["Geburtsjahresgruppe"]):r for r in read_csv(raw/"btw25_rws_bw2.csv")}
    regions={}
    for state,name in {"Bund":"Deutschland",**STATES}.items():
        records=[r for r in votes if r["Land"] == state]
        total=next(r for r in records if r["Geschlecht"] == r["Geburtsjahresgruppe"] == "Summe")
        totals=party_counts(total); valid=number(total["Summe"])-number(total["Ungültig"])
        groups=[]
        for r in records:
            sex,age=r["Geschlecht"],r["Geburtsjahresgruppe"]
            if age != "Summe" and age not in AGES: raise ValueError("Unknown age cohort "+age)
            if sex != "Summe" and sex not in ("m|d|o","w"): raise ValueError("Unknown recorded-sex category")
            n=number(r["Summe"])-number(r["Ungültig"]); counts=party_counts(r)
            parts=AGE_PARTS.get(age,("Summe",))
            tr=[turnout[(state,sex,a)] for a in parts]
            eligible=sum(number(x["Wahlberechtigte"]) for x in tr)
            participants=sum(number(x["Wähler/-innen"]) for x in tr)
            groups.append({"sex":sex,"cohort":age,"age_2025":AGES.get(age,"all"),"valid_votes_weighted":n,
                "eligible_weighted":eligible,"participants_weighted":participants,"turnout":participants/eligible,
                "counts":counts,"support_percent":{p:100*c/n if c is not None else None for p,c in counts.items()},
                "party_electorate_composition_percent":{p:100*c/totals[p] if c is not None and totals[p] else None for p,c in counts.items()}})
        parties={}
        for p in PARTIES:
            share=100*totals[p]/valid if totals[p] is not None else None
            ages=[g for g in groups if g["sex"] == "Summe" and g["cohort"] != "Summe" and g["support_percent"][p] is not None]
            top=max(ages,key=lambda g:g["support_percent"][p]) if ages else None
            contribution=max(ages,key=lambda g:g["counts"][p]) if ages else None
            sexes={g["sex"]:g["support_percent"][p] for g in groups if g["sex"] != "Summe" and g["cohort"] == "Summe"}
            parties[p]={"state_2025_vote_percent":share,"highest_support_age":top["age_2025"] if top else None,
                "highest_support_percent":top["support_percent"][p] if top else None,
                "largest_electorate_contributor_age":contribution["age_2025"] if contribution else None,
                "sex_support_percent":sexes,"representation_by_age":{g["age_2025"]:g["support_percent"][p]/share if share else None for g in ages},
                "standing_party":"CSU" if p == "Union" and state == "BY" else "CDU" if p == "Union" and state != "Bund" else p}
        regions[state]={"name":name,"valid_votes_weighted":valid,"parties":parties,"groups":groups}
    source_notes={name:{"url":url,"sha256":sha256((raw/name).read_bytes()).hexdigest(),"retrieved":"2026-10-22",
                 "attribution":"Die Bundeswahlleiterin / Statistisches Bundesamt 2025; structure employment and labour data: Bundesagentur für Arbeit",
                 "license":"Datenlizenz Deutschland – Namensnennung – Version 2.0","license_url":"https://www.govdata.de/dl-de/by-2-0"}
                 for name,url in CSV_URLS.items()}
    atlas={"schema_version":"electorate-atlas-1.0","election":"BUNDESTAG_2025_SECOND_VOTE","event_date":"2025-02-23",
           "available_from":"2025-06-23","evidence_status":"OBSERVED_REPRESENTATIVE_ELECTION_STATISTICS",
           "source_notes":source_notes,"regions":regions,"ecology":ecology(raw),
           "notes":["Weighted representative counts, not exact exhaustive age-specific vote counts; integer calibration rounding remains",
                    "m|d|o includes male, divers and no recorded sex; not an exclusively male group",
                    "BSW and Freie Wähler are subsets of raw Sonstige and have been subtracted from residual Other",
                    "Age labels are age at 2025 election, not age reclassified in 2026",
                    "State demographics anchor Bundestag choices, not state-election choices or current immutable voter floors",
                    "Support P(party|group) differs from electorate composition P(group|party)",
                    "No identified individual occupation, religion, income or policy-event elasticities"]}
    root.mkdir(parents=True,exist_ok=True)
    (root/"atlas_2025.json").write_text(json.dumps(atlas,ensure_ascii=False,indent=2,allow_nan=False)+"\n")
    return atlas


class ElectorateAtlas:
    def __init__(self,path=ROOT/"atlas_2025.json"):
        self.data=json.loads(Path(path).read_text())

    def state(self,code,*,as_of,target="BUNDESTAG_2025_SECOND_VOTE"):
        if target != self.data["election"]:
            raise ValueError("Atlas identifies historical Bundestag votes, not current Landtag intentions")
        if date.fromisoformat(as_of)<date.fromisoformat(self.data["available_from"]):
            raise ValueError("Representative statistics were not public at this cutoff")
        return {"evidence_status":self.data["evidence_status"],"event_date":self.data["event_date"],
                "available_from":self.data["available_from"],**self.data["regions"][code]}


def report(atlas):
    lines=["# 16州×党派基本盘证据册（2025联邦议会二票）","",
           "这是历史投票结构，不是2026州议会民调，也不是铁票下限。年龄为2025投票时年龄。最高组内支持率≠最大选票来源组。",
           "m|d|o包含男性、divers和无性别登记者。下表差值为该组减女性。所有数值由官方代表性选举统计重算，存在校准取整。","",
           "[官方统计及方法](https://www.bundeswahlleiterin.de/bundestagswahlen/2025/ergebnisse/repraesentative-wahlstatistik.html)",""]
    for state in STATES:
        r=atlas["regions"][state]
        lines += ["## "+r["name"],"","|党派|州二票%|支持率最高年龄|该组支持率%|选票贡献最大年龄|m/d/o−女 pp|","|---|---:|---|---:|---|---:|"]
        for p,data in r["parties"].items():
            if data["state_2025_vote_percent"] is None: continue
            sx=data["sex_support_percent"]
            delta=sx.get("m|d|o")-sx.get("w") if sx.get("m|d|o") is not None and sx.get("w") is not None else None
            lines.append(f'|{data["standing_party"]}|{data["state_2025_vote_percent"]:.3f}|{data["highest_support_age"]}|{data["highest_support_percent"]:.3f}|{data["largest_electorate_contributor_age"]}|{delta:.3f}|' if delta is not None else f'|{p}|{data["state_2025_vote_percent"]:.3f}|未报告|—|—|—|')
        lines += ["","地区结构关联另存JSON：州内至少8个选区才计算加权相关；未做显著性或多重比较校正，不用于推断个人投票，也不参与事件民调增减。",""]
    lines += ["## 尚未识别","","各州的职业×收入×教育联合投票画像、宗教和价值坐标、稳定基本盘与游离选民比例、政策事件因果弹性均未从这些表中识别。需要带权个体调查及更多波次，不能靠给州总量贴标签补齐。"]
    return "\n".join(lines)+"\n"


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--report",default="outputs/polling_2026_10_22/electorate_profiles.md")
    args=parser.parse_args(); atlas=build()
    path=Path(args.report); path.parent.mkdir(parents=True,exist_ok=True); path.write_text(report(atlas))
    print(json.dumps({"regions":len(atlas["regions"]),"state_party_profiles":len(STATES)*len(PARTIES),"report":str(path)},ensure_ascii=False))


if __name__ == "__main__":main()
