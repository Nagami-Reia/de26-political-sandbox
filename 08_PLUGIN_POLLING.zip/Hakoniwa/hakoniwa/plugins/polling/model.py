"""Dependency-free production inference; frozen reference fitting stays separate.

CLR corrections describe published polls relative to past-poll consensus, not
causal changes in objective voter preferences. Never mutate the world here.
"""
from __future__ import annotations

from datetime import date
from hashlib import sha256
import json
import math
from pathlib import Path

BUNDLE = Path(__file__).resolve().parent/"data/calibration/polling_consolidated_v1"
STATE_ALIASES = {"BW":"Baden-Württemberg", "BY":"Bayern", "BE":"Berlin", "BB":"Brandenburg",
                 "HB":"Bremen", "HH":"Hamburg", "HE":"Hessen", "MV":"Mecklenburg-Vorpommern",
                 "NI":"Niedersachsen", "NW":"Nordrhein-Westfalen (NRW)", "NRW":"Nordrhein-Westfalen (NRW)",
                 "RP":"Rheinland-Pfalz", "SL":"Saarland", "SN":"Sachsen", "ST":"Sachsen-Anhalt",
                 "LSA":"Sachsen-Anhalt", "SH":"Schleswig-Holstein", "TH":"Thüringen",
                 "Nordrhein-Westfalen":"Nordrhein-Westfalen (NRW)"}


def finite_vector(values):
    result = [float(v) for v in values]
    if not result or not all(math.isfinite(v) for v in result):
        raise ValueError("Expected nonempty finite numeric vector")
    return result


def normalize(values):
    values = finite_vector(values)
    if min(values) < 0 or sum(values) <= 0:
        raise ValueError("Invalid composition")
    peak = max(values)
    scaled = [v/peak for v in values]
    total = sum(scaled)
    return [v/total for v in scaled]


def softmax(values):
    values = finite_vector(values)
    peak = max(values)
    return normalize([math.exp(v-peak) for v in values])


def clr(values, floor=.0025):
    p = normalize(values)
    z = [math.log(max(v, floor)) for v in p]
    center = sum(z)/len(z)
    return [v-center for v in z]


def dynamic_choice(baseline_probability, delta_distance, delta_competence,
                   delta_leader, delta_tactical, temperature=1.0):
    p = normalize(baseline_probability)
    vectors = [finite_vector(v) for v in (delta_distance, delta_competence, delta_leader, delta_tactical)]
    if any(len(v) != len(p) for v in vectors) or not math.isfinite(temperature) or temperature <= 0:
        raise ValueError("Mismatched party vectors or invalid temperature")
    # Preserve explicitly unavailable alternatives; zero is not an undecided bucket.
    available = [j for j,v in enumerate(p) if v > 0]
    utility = [math.log(p[j])+(-vectors[0][j]+sum(v[j] for v in vectors[1:]))/temperature for j in available]
    chosen = softmax(utility)
    result = [0.0]*len(p)
    for j,v in zip(available,chosen): result[j] = v
    return result


def aggregate_groups(population_mass, participation_probability, decided_probability, conditional_party_probability):
    n,t,d = [finite_vector(v) for v in (population_mass,participation_probability,decided_probability)]
    q = [finite_vector(row) for row in conditional_party_probability]
    if len(n) != len(t) or len(n) != len(d) or len(q) != len(n) or min(n) < 0:
        raise ValueError("Mismatched/invalid population groups")
    if any(not 0 <= v <= 1 for v in t+d) or any(min(row)<0 or not math.isclose(sum(row),1,abs_tol=1e-8) for row in q):
        raise ValueError("Invalid participation/decided/choice probabilities")
    if len({len(row) for row in q}) != 1:
        raise ValueError("Mismatched party dimensions")
    weights = [a*b*c for a,b,c in zip(n,t,d)]
    denominator = sum(weights)
    if denominator <= 0:
        raise ValueError("No decided participants")
    return {"conditional_party_probability": [sum(w*row[j] for w,row in zip(weights,q))/denominator for j in range(len(q[0]))],
            "eligible_mass":sum(n), "participant_mass":sum(a*b for a,b in zip(n,t)),
            "decided_participant_mass":denominator,
            "undecided_participant_mass":sum(a*b*(1-c) for a,b,c in zip(n,t,d)),
            "nonparticipant_mass":sum(a*(1-b) for a,b in zip(n,t))}


def federal_correction(context, params):
    correction=finite_vector(params["alpha"])
    house=params["house"].get(context["series"])
    if house is not None:
        correction=[a+b for a,b in zip(correction,finite_vector(house))]
    if params["kind"].startswith("rank") or params["kind"] == "full":
        x,mu,scale=[finite_vector(v) for v in (context["dynamic_features"],params["means"],params["scale"])]
        if len(x) != len(mu) or len(scale) != len(mu) or min(scale) <= 0:
            raise ValueError("Incorrect dynamic feature dimensions/scales")
        z=[(a-b)/s for a,b,s in zip(x,mu,scale)]
        correction=[c+params["center"][j]+sum(v*params["coefficients"][k][j] for k,v in enumerate(z))
                    for j,c in enumerate(correction)]
    return correction


class PollingModel:
    def __init__(self, root=BUNDLE):
        self.root = Path(root)
        self.spec = json.loads((self.root/"model_spec.json").read_text())

    def verify(self):
        manifest = json.loads((self.root/"manifest.json").read_text())
        failed = []
        for name,digest in manifest["sha256"].items():
            path = (self.root/name).resolve()
            if not path.is_relative_to(self.root.resolve()) or not path.is_file() or sha256(path.read_bytes()).hexdigest() != digest:
                failed.append(name)
        if failed: raise ValueError("Reference manifest mismatch: "+repr(failed))
        example = json.loads((self.root/"examples/national_long.json").read_text())
        prediction = self.predict(example)
        if max(abs(a-b) for a,b in zip(prediction["predicted_percent"], example["expected_prediction_percent"])) > 1e-9:
            raise ValueError("Exported coefficient replay differs")
        return {"valid":True,"files_checked":len(manifest["sha256"]),"reference_replay":"passed",
                "world_effects_estimated":False,"demographic_causality_identified":False}

    def predict(self, context):
        name = context["model"]
        cfg = self.spec["fitted_models"][name]
        params = json.loads((self.root/cfg["parameters"]).read_text())
        if context["party_order"] != params["parties"]:
            raise ValueError("Exact party order required; BSW cannot silently move between Other and named category")
        target = date.fromisoformat(context.get("target_date",context.get("published","")))
        latest = date.fromisoformat(context["latest_predictor_date"])
        if latest >= target:
            raise ValueError("Predictors must have been published strictly before target date")
        fit_until = date(2025,12,31)
        if target <= fit_until:
            raise ValueError("These parameters were refitted through 2025; cannot use them as historical out-of-sample parameters")
        base = clr(context["baseline_percent"])
        if len(base) != len(params["parties"]): raise ValueError("Incorrect baseline size")
        warnings = ["Publication estimate, not objective world support or a causal policy effect",
                    "2026 is a reused rolling holdout, not a new blind evaluation"]
        series = context["series"]
        if name.startswith("federal"):
            house = params["house"].get(series)
            if house is None: warnings.append("Unseen series: zero relative house correction")
            correction = federal_correction(context,params)
        else:
            if context.get("target") != "LANDTAG_VOTE_INTENTION":
                raise ValueError("State model predicts Landtag intentions, not Bundestag intentions within a state")
            state = STATE_ALIASES.get(context["state"],context["state"])
            momentum = finite_vector(context["national_momentum_clr"])
            residual = finite_vector(context["previous_state_residual_clr"])
            if len(momentum) != len(base) or len(residual) != len(base): raise ValueError("Incorrect state feature sizes")
            gap = float(context["log_gap"])
            if not math.isfinite(gap) or gap < 0: raise ValueError("Invalid log gap")
            correction=[]
            for j,m in enumerate(params["models"]):
                c=m["coefficients"]
                if "state:"+state not in c: raise ValueError("Unknown state")
                raw=[momentum[j],residual[j],gap]
                standardized=[(v-mu)/sd for v,mu,sd in zip(raw,m["dynamic_standardization_mean"],m["dynamic_standardization_sd"])]
                value=c["national_party_offset"]+c["state:"+state]+c.get("institute:"+series,0)
                value+=sum(c[key]*v for key,v in zip(("national_momentum","previous_state_residual","log_gap"),standardized))
                correction.append(value)
            if "institute:"+series not in params["models"][0]["coefficients"]:
                warnings.append("Unseen state series: zero relative institute correction")
        result=[100*v for v in softmax([a+b for a,b in zip(base,correction)])]
        return {"model":name,"target":cfg["target"],"party_order":params["parties"],"predicted_percent":result,
                "status":"MODEL_ESTIMATE_OF_PUBLISHED_POLL_NOT_WORLD_TRUTH", "target_date":target.isoformat(),
                "latest_predictor_date":latest.isoformat(),"parameter_fit_until":fit_until.isoformat(),
                "warnings":sorted(set(warnings)),"prediction_interval":None}


class BlendedPublicationModel:
    """Experimental validation-selected model; requires explicit recent-series data.

    A research artifact is supplied deliberately; it never silently becomes the
    simulation's default electorate response or a pollster's true methodology.
    """
    def __init__(self, parameters):
        self.params=json.loads(Path(parameters).read_text())

    def predict(self, context):
        params=self.params
        if context["party_order"] != params["parties"]:
            raise ValueError("Exact party order required")
        target=date.fromisoformat(context["target_date"])
        latest=date.fromisoformat(context["latest_predictor_date"])
        if latest>=target or target<=date.fromisoformat(params["fit_until"]):
            raise ValueError("Future leakage or historical refit leakage")
        baseline=normalize(context["baseline_percent"])
        if len(baseline) != len(params["parties"]): raise ValueError("Wrong baseline size")
        old_date=date.fromisoformat(context["previous_series_date"]) if context.get("previous_series_date") else None
        if old_date and old_date>latest: raise ValueError("Prior series date exceeds latest predictor date")
        fresh=old_date is not None and 0<(target-old_date).days<=120
        persistence=normalize(context["previous_series_percent"]) if fresh else baseline
        if len(persistence) != len(baseline): raise ValueError("Wrong previous-series size")
        model=params["model"]
        predicted=softmax([a+b for a,b in zip(clr(baseline),federal_correction(context,model))]) if model else baseline
        weight=float(params["model_weight"])
        if not math.isfinite(weight) or not 0<=weight<=1: raise ValueError("Invalid blend weight")
        result=[100*(weight*a+(1-weight)*b) for a,b in zip(predicted,persistence)]
        return {"target":"PUBLISHED_BUNDESTAG_VOTE_INTENTION","party_order":params["parties"],
                "predicted_percent":result,"model_weight":weight,"persistence_available":fresh,
                "target_date":target.isoformat(),"latest_predictor_date":latest.isoformat(),
                "status":"EXPERIMENTAL_NEXT_RELEASE_MODEL_NOT_WORLD_TRUTH","prediction_interval":None,
                "warnings":["Validation-selected; reused 2026 test, no fresh confirmation",
                            "No identified causal policy response; do not mutate world support"]}
