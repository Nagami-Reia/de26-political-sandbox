"""Audited extraction of the supplied October 2026 PDF; national crosstabs only.

Coordinate fixture is tied to a checksum and visually verified page. No OCR or
LLM-generated numbers. Unprinted/dash cells remain unknown, not invented zero.
"""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import shutil

from .electorates import ROOT

EXPECTED_SHA256 = "2d0e5db596a5931998d9b49d4604e0699dfd7c53d0b7288e327d76642d982b0c"
ARTICLE_URL = "https://yougov.com/de-de/artikel/55780-yougov-sonntagsfrage-afd-bleibt-vorn-union-weiter-im-tief-fast-jeder-zweite-sieht-vorurteile-gegenuber-juden-als-problem-in-deutschland"
PDF_URL = "https://ygo-assets-websites-editorial-emea.yougov.net/documents/YouGov_Sonntagsfrage_Oktober_2026.pdf"
COLUMNS = ["total"]+["recall_2025:"+p for p in ("SPD","Union","Grüne","AfD","FDP","Linke","BSW","Other")]+[
    "sex:male","sex:female","age:18-29","age:30-39","age:40-49","age:50-59","age:60-69","age:70+",
    "education:low","education:middle","education:high","region:West","region:East",
    "settlement:urban","settlement:suburban","settlement:rural"]
PARTIES = ("Union","AfD","SPD","Grüne","Linke","FDP","BSW","Other")


def extract(path):
    import pdfplumber
    path=Path(path)
    digest=sha256(path.read_bytes()).hexdigest()
    if digest != EXPECTED_SHA256:
        raise ValueError("PDF changed: coordinate extraction requires renewed visual verification")
    with pdfplumber.open(path) as doc:
        lines=doc.pages[0].crop((138,130,720,188)).extract_text(x_tolerance=.5,y_tolerance=1).splitlines()
        method=doc.pages[2].extract_text()
    if len(lines) != 11 or any(len(line.split()) != len(COLUMNS) for line in lines):
        raise ValueError("Unexpected table geometry; manual verification needed")
    bases=[{key:int(value) for key,value in zip(COLUMNS,line.split())} for line in lines[:2]]
    values={party:{key:None if token == "-" else int(token.removesuffix("%"))
                  for key,token in zip(COLUMNS,line.split())} for party,line in zip(PARTIES,lines[2:10])}
    if {p:values[p]["total"] for p in PARTIES} != dict(zip(PARTIES,(18,28,14,16,10,5,3,6))):
        raise ValueError("Visually verified totals do not match extraction")
    groups={key:{"base_brutto_as_printed":bases[0][key],"unweighted_base_netto":bases[1][key],
                 "support_percent":{p:values[p][key] for p in PARTIES},
                 "rounded_column_sum":sum(values[p][key] or 0 for p in PARTIES),
                 "small_unweighted_base_warning":bases[1][key]<100} for key in COLUMNS}
    return {"schema_version":"poll-crosstabs-1.0","source_id":"user_yougov_2026_10",
            "source_path":"raw/yougov_2026_10.pdf","sha256":digest,"source_page":1,"method_page":3,
            "primary_article_url":ARTICLE_URL,"primary_pdf_url":PDF_URL,"primary_cross_check_date":"2026-10-22",
            "field_start":"2026-10-16","field_end":"2026-10-19",
            "publication_date":"2026-10-19","database_publication_date":"2026-10-20","dawum_id":"4355","received_at":"2026-10-22",
            "available_from":"2026-10-20","availability_policy":"Conservative later calendar date retained; original article date and DAWUM date differ; exact public-release timestamp unknown",
            "target":"BUNDESTAG_VOTE_INTENTION","geography":"DE","sample_size_all_respondents":2202,
            "conditional_population":"eligible respondents declaring a current party choice",
            "groups":groups,"method_text":method,"effective_sample_size":None,"sampling_design":"quota_online_panel_not_probability_sample",
            "turnout_weighting":"stated likelihood of voting 0..1, as described on page 3",
            "warnings":["State quotas are sampling margins, not state-level party-intention crosstabs",
                        "Source article dated Oct 19; frozen database records Oct 20; neither source date silently rewritten in calibration history",
                        "Recall columns condition on current party declarers; not complete 2025 electorate retention or voter flows",
                        "Brutto label is preserved; not used as effective sample size or equivalent to 2202/1773",
                        "Integer rounding remains; unprinted dash is null rather than asserted exact zero",
                        "Age bins differ from official 2025 election statistics; no direct age-bin change inferred",
                        "No design effects or effective N: no fabricated simple-random-sample margins of error",
                        "Only party-choice table imported; prejudice questions are not treated as inferred personality coordinates"]}


def build(path,root=ROOT):
    payload=extract(path)
    root=Path(root); (root/"raw").mkdir(parents=True,exist_ok=True)
    destination=root/"raw/yougov_2026_10.pdf"
    if Path(path).resolve() != destination.resolve():
        if destination.exists() and sha256(destination.read_bytes()).hexdigest() != payload["sha256"]:
            raise ValueError("Existing raw PDF differs; refusing overwrite")
        shutil.copyfile(path,destination)
    (root/"yougov_2026_10.json").write_text(json.dumps(payload,ensure_ascii=False,indent=2,allow_nan=False)+"\n")
    return payload


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("pdf",nargs="?",default=str(ROOT/"raw/yougov_2026_10.pdf"))
    p=build(parser.parse_args().pdf)
    print(json.dumps({"source_id":p["source_id"],"groups":len(p["groups"]),"national":p["groups"]["total"]},ensure_ascii=False))


if __name__ == "__main__":main()
