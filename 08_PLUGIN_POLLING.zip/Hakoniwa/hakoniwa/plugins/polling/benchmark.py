"""Validation-selected shrinkage toward a strong same-series persistence baseline.

No held-out values select weights. The already supplied 2026 test is reused,
not a fresh blind test. This runner does not execute the vendor's write paths.
"""
import argparse
from datetime import date
import importlib.util
import json
from pathlib import Path

from .model import BUNDLE, PollingModel


def run(output):
    import numpy as np
    PollingModel().verify()
    spec = importlib.util.spec_from_file_location("polling_reference_fit", BUNDLE/"polling_fit/fit_framework.py")
    fit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(fit)
    source = [json.loads(line) for line in (BUNDLE/"polling_research/data/federal_polls_2017_2026.jsonl").read_text().splitlines()]
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    results = {}
    for bsw, name in ((False,"federal_long"), (True,"federal_bsw")):
        rows, parties, excluded = fit.prepare(source, bsw)
        train_end = date(2024 if bsw else 2023,12,31).toordinal()
        refit_end = date(2025,12,31).toordinal()
        candidates = []
        for tau in (7,14,28,56):
            data = fit.features(rows, tau)
            train, val, test = data["day"]<=train_end, (data["day"]>train_end)&(data["day"]<=refit_end), data["day"]>refit_end
            assert all(m["latest_predictor_date"] < m["published"] for m in data["meta"])
            for kind in ("consensus","house","rank1","rank2","rank3","rank4","full"):
                for lam in ((1,10,100) if kind.startswith("rank") or kind == "full" else (10,)):
                    model_pred = fit.softmax(data["B"]) if kind == "consensus" else fit.predict(data,fit.fit(data,train,kind,lam))
                    for weight in (0.0,.25,.5,.75,1.0):
                        pred = weight*model_pred+(1-weight)*data["last"]
                        score = fit.metrics(data,pred,val)
                        candidates.append({"kind":kind,"tau":tau,"lambda":lam,"model_weight":weight,"validation":score})
        # Tie rule prefers persistence / fewer corrections, not optimistic test results.
        selected = min(candidates, key=lambda x:(x["validation"]["institute_macro_rmse_pp"],x["model_weight"],x["tau"],x["kind"],x["lambda"]))
        data = fit.features(rows, selected["tau"])
        train, val, test = data["day"]<=train_end, (data["day"]>train_end)&(data["day"]<=refit_end), data["day"]>refit_end
        model = None if selected["kind"] == "consensus" else fit.fit(data,~test,selected["kind"],selected["lambda"])
        model_pred = fit.softmax(data["B"]) if model is None else fit.predict(data,model)
        pred = selected["model_weight"]*model_pred+(1-selected["model_weight"])*data["last"]
        # Paired month-block uncertainty describes this reused test only.
        months = sorted({m["published"][:7] for m,t in zip(data["meta"],test) if t})
        blocks = {m:np.array([i for i,(meta,t) in enumerate(zip(data["meta"],test)) if t and meta["published"].startswith(m)]) for m in months}
        rng = np.random.default_rng(20261022)
        differences=[]
        for _ in range(2000):
            ix=np.concatenate([blocks[m] for m in rng.choice(months,len(months),replace=True)])
            differences.append(float(np.sqrt(np.mean((100*(pred[ix]-data["P"][ix]))**2))-np.sqrt(np.mean((100*(data["last"][ix]-data["P"][ix]))**2))))
        result={"parties":parties,"excluded":excluded,"selected":selected,
                "selection":"pre-2026 validation equal-institute macro RMSE; test never used to select",
                "test_use":"reused 2026 rolling next-release holdout, not independent confirmation",
                "train_end":date.fromordinal(train_end).isoformat(),"parameter_fit_until":"2025-12-31",
                "validation_n":int(val.sum()),"test_n":int(test.sum()),
                "test":fit.metrics(data,pred,test),"persistence_test":fit.metrics(data,data["last"],test),
                "selected_minus_persistence_test_rmse_month_block_95":np.quantile(differences,[.025,.975]).tolist(),
                "bootstrap_warning":"Few calendar-month blocks; conditional descriptive interval, not forecast coverage",
                "sampling_intervals_calibrated":False,"causal_response_identified":False,
                "candidate_count":len(candidates),"deployment":"research_only_pending_fresh_out_of_time_validation"}
        results[name]=result
        fit.dump(output/(name+"_parameters.json"),{"parties":parties,"tau_days":selected["tau"],
                 "model_weight":selected["model_weight"],"fit_until":"2025-12-31","model":model})
        fit.dump(output/(name+"_predictions.json"),{"parties":parties,"predictions":[{**data["meta"][i],
            "actual_percent":100*data["P"][i],"prediction_percent":100*pred[i],"persistence_percent":100*data["last"][i]}
            for i in np.flatnonzero(test)]})
        print(name, json.dumps(result,ensure_ascii=False),flush=True)
    fit.dump(output/"benchmark.json",results)
    return results


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",default="outputs/polling_2026_10_22/benchmark")
    run(parser.parse_args().output)


if __name__ == "__main__":main()
