"""Reproducible descriptive reverse analysis; estimates are NOT pollster weights.
Dependencies: numpy, pandas, openpyxl. Public data cutoff: 2026-10-22.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'data'
def write(name,data):
 (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False))
def clean(v):
 if isinstance(v,dict):return {k:clean(x) for k,x in v.items()}
 if isinstance(v,list):return [clean(x) for x in v]
 if isinstance(v,(np.integer,)):return int(v)
 if isinstance(v,(np.floating,float)):return None if not np.isfinite(v) else float(v)
 return v
def jsonl(name,rows):
 (OUT/name).write_text(''.join(json.dumps(clean(r),ensure_ascii=False,allow_nan=False)+'\n' for r in rows))

d=json.loads((ROOT/'raw/dawum.json').read_text())
polls=[]
for sid,s in d['Surveys'].items():
 if s['Parliament_ID']!='0' or not ('2017-01-01'<=s['Date']<='2026-10-22'):continue
 start=s['Survey_Period']['Date_Start'];end=s['Survey_Period']['Date_End']
 results={d['Parties'][k]['Shortcut']:v for k,v in s['Results'].items()}
 polls.append({'id':sid,'published':s['Date'],'field_start':start,'field_end':end,
  'institute':d['Institutes'][s['Institute_ID']]['Name'],
  'mode':d['Methods'][s['Method_ID']]['Name'],'n_reported':int(s['Surveyed_Persons']) if s['Surveyed_Persons'].isdigit() else None,
  'n_basis':'as reported by DAWUM; not harmonized across institutes',
  'commissioner':d['Taskers'][s['Tasker_ID']]['Name'],
  'results':results,'source_url':'https://api.dawum.de/',
  'sum_published':sum(results.values()),'status':'OBSERVED_PUBLISHED_AGGREGATE'})
polls.sort(key=lambda r:(r['published'],r['id']))
jsonl('federal_polls_2017_2026.jsonl',polls)
rows=[]
for p in polls:
 mid=pd.Timestamp(p['field_start'])+(pd.Timestamp(p['field_end'])-pd.Timestamp(p['field_start']))/2
 for party,v in p['results'].items():
  rows.append({**{k:p[k] for k in ['id','published','field_start','field_end','institute','mode','n_reported']},'mid':mid,'party':party,'value':v})
df=pd.DataFrame(rows)
df=df[df.published>='2024-01-01'].copy()
df['series']=df['institute']
df.loc[df.institute=='INSA','series']='INSA / '+df.loc[df.institute=='INSA','mode']
major=['INSA','YouGov','Forsa','Forschungsgruppe Wahlen','Infratest dimap','Allensbach','Ipsos','Verian (Emnid)','GMS']
df=df[df.institute.isin(major)].copy()
summaries=[]
for series,group in df.groupby('series'):
 p=group.drop_duplicates('id').sort_values('published')
 dur=(pd.to_datetime(p.field_end)-pd.to_datetime(p.field_start)).dt.days+1
 lag=(pd.to_datetime(p.published)-pd.to_datetime(p.field_end)).dt.days
 vals=group.value.to_numpy()
 summaries.append({'series':series,'polls':len(p),'start':p.published.min(),'end':p.published.max(),
  'n_reported_median':float(p.n_reported.median()),'field_days_inclusive_median':float(dur.median()),
  'publication_lag_days_median':float(lag.median()),
  'published_values_noninteger_share':float(np.mean(np.abs(vals-np.round(vals))>1e-8)),
  'n_warning':'unharmonized bases; not an effective sample size',
  'grid_warning':'observed support grid; does not prove internal rounding algorithm'})
write('series_diagnostics_2024_2026.json',summaries)

# Retrospective peer contrasts. Each peer institute contributes one mean, so
# high-frequency publishers do not dominate. Exclude the entire target institute.
# Symmetric field-midpoint windows use future reports: NEVER a live forecast.
contrasts=[]
for window in [4,7,10]:
 for r in df.itertuples():
  if r.institute not in ['INSA','YouGov','Forsa','Forschungsgruppe Wahlen','Infratest dimap','Allensbach']:continue
  eligible=df[(df.party==r.party)&(df.institute!=r.institute)&((df.mid-r.mid).abs()<=pd.Timedelta(days=window))]
  means=eligible.groupby('institute').value.mean()
  if len(means)<3:continue
  contrasts.append({'id':r.id,'series':r.series,'party':r.party,'published':r.published,'window_days':window,
   'peer_institutes':len(means),'value':r.value,'peer_mean':float(means.mean()),'contrast_pp':float(r.value-means.mean())})
jsonl('peer_contrasts.jsonl',contrasts)
c=pd.DataFrame(contrasts)
stats=[]
for (window,series,party,period),g in c.assign(period=np.where(c.published<'2026-01-01','2024-2025','2026')).groupby(['window_days','series','party','period']):
 stats.append({'window_days':int(window),'series':series,'party':party,'period':period,'n_polls':len(g),
  'mean_contrast_pp':round(float(g.contrast_pp.mean()),3),'median_contrast_pp':round(float(g.contrast_pp.median()),3),
  'q25_pp':round(float(g.contrast_pp.quantile(.25)),3),'q75_pp':round(float(g.contrast_pp.quantile(.75)),3),
  'interpretation':'retrospective peer contrast; not bias to truth, not proprietary weighting'})
write('peer_contrast_summary.json',stats)

def read_fgw(name):
 raw=pd.read_excel(ROOT/'raw'/name,header=None,sheet_name='Tabelle1')
 names=[str(x).strip() for x in raw.iloc[7,2:]]
 out=[]
 for row in raw.iloc[9:].itertuples(index=False,name=None):
  if not isinstance(row[1],(pd.Timestamp,__import__('datetime').datetime)):continue
  date=pd.Timestamp(row[1]).strftime('%Y-%m-%d')
  if date>'2026-10-22':continue
  for party,val in zip(names,row[2:]):
   if pd.notna(val) and isinstance(val,(float,int)):
    out.append({'date':date,'party':party,'value':float(val)})
 return pd.DataFrame(out)
m=read_fgw('fgw_mood.xlsx');p=read_fgw('fgw_projection.xlsx')
pair=m.merge(p,on=['date','party'],suffixes=('_mood','_projection')).sort_values(['party','date'])
pair['difference_pp']=pair.value_projection-pair.value_mood
pair['previous_projection']=pair.groupby('party').value_projection.shift(1)
jsonl('fgw_paired_1991_2026.jsonl',pair.to_dict('records'))
fit=[]
for party,g in pair[pair.date>='2024-01-01'].groupby('party'):
 g=g.dropna();train=g[g.date<'2026-01-01'];test=g[g.date>='2026-01-01']
 if len(train)<12 or len(test)<4:continue
 # Transparent surrogate: P[t] = a + b*M[t] + c*P[t-1]. No constraint that
 # these coefficients are actual individual weights. One-step holdout uses
 # previous observed P; no future target used in fitting.
 X=np.column_stack([np.ones(len(train)),train.value_mood,train.previous_projection]);y=train.value_projection.to_numpy()
 coeff=np.linalg.lstsq(X,y,rcond=None)[0]
 Xt=np.column_stack([np.ones(len(test)),test.value_mood,test.previous_projection])
 static_coeff=np.linalg.lstsq(X[:,:2],y,rcond=None)[0]
 rmse=lambda a,b:float(np.sqrt(np.mean((np.asarray(a)-np.asarray(b))**2)))
 fit.append({'party':party,'n_train':len(train),'n_test':len(test),'train':'2024-2025','test':'2026',
  'mean_projection_minus_mood_2024_2026':round(float(g.difference_pp.mean()),3),
  'intercept':round(float(coeff[0]),4),'current_mood_coefficient':round(float(coeff[1]),4),
  'previous_projection_coefficient':round(float(coeff[2]),4),
  'design_condition_number':round(float(np.linalg.cond(X)),2),
  'test_rmse_surrogate_pp':round(rmse(test.value_projection,Xt@coeff),3),
  'test_rmse_static_affine_mood_pp':round(rmse(test.value_projection,Xt[:,:2]@static_coeff),3),
  'test_rmse_current_mood_pp':round(rmse(test.value_projection,test.value_mood),3),
  'test_rmse_previous_projection_pp':round(rmse(test.value_projection,test.previous_projection),3),
  'status':'EXPLORATORY_SURROGATE_NOT_IDENTIFIED_INSTITUTE_MODEL'})
write('fgw_surrogate_holdout.json',fit)
write('coverage.json',{'dawum_metadata':d['Database'],'federal_polls':len(polls),'range':[polls[0]['published'],polls[-1]['published']],
 'polls_2024_2026':len({r['id'] for r in rows if r['published']>='2024-01-01'}),
 'fgw_paired_cells':len(pair),'fgw_paired_dates':pair.date.nunique(),
 'fgw_paired_range':[pair.date.min(),pair.date.max()],
 'validation':{'duplicate_poll_ids':len(polls)-len({p['id'] for p in polls}),
  'future_polls':sum(p['published']>'2026-10-22' for p in polls),
  'published_share_sum_not_100':sum(abs(p['sum_published']-100)>.01 for p in polls),
  'note':'Published rounding discrepancies preserved, not silently normalized.'}})
print(json.dumps({'coverage':json.loads((OUT/'coverage.json').read_text()),'diagnostics':summaries,'fgw_fit':fit},ensure_ascii=False,indent=2))
