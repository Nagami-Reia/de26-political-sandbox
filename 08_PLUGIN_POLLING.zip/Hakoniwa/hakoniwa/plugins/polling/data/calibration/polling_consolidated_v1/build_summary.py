"""Consolidate previous completed work without re-estimating models."""
from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parent
def load(p):return json.loads((R/p).read_text())
def write(p,obj):(R/p).write_text(json.dumps(obj,ensure_ascii=False,indent=2))
spec={
 'schema_version':'hakoniwa-polling-research-1.0','as_of':'2026-10-22','integrated_into_original_hakoniwa':False,
 'symbols':{'g':'elector group','s':'state','p':'party','i':'survey institute/product/mode','t':'time','N':'eligible population mass','tau':'participation probability','d':'decided-party-choice probability','q':'conditional party choice probability','S':'aggregate party share','A':'party affinity score'},
 'units':{'internal_probability':'0..1','reported_share':'percent 0..100','errors':'percentage points','fitted_coefficients':'centered log ratio / relative logit','time':'calendar days'},
 'status_vocabulary':{'CONCEPTUAL':'proposed structure, not calibrated','FITTED':'estimated from training data','VALIDATION_SELECTED':'chosen using an earlier validation period','CONVENTION':'fixed for computation/identification','UNIDENTIFIED':'current data cannot identify it','OBSERVED':'published external data'},
 'conceptual_pipeline':[
  {'id':'affinity_2d','status':'CONCEPTUAL','expression':'A[g,p,t0] = f_p(social_position[g], value_orientation[g])','candidate':'party-specific quadratic [1,s,v,s^2,s*v,v^2]','coefficients':None,'implementation':'model.affinity_2d','requires':'joint group profiles and repeated group-party choice/affinity measurements'},
  {'id':'baseline_choice','status':'CONCEPTUAL','expression':'pi0[g,:] = softmax(A[g,:])'},
  {'id':'dynamic_3d','status':'CONCEPTUAL','axes':['economic_distribution','social_cultural_orientation','institutional_trust'],'expression':'D[g,p,t] = sum_k w[g,k,t] * (x[g,k,t]-perceived_party_position[g,p,k,t])^2','coordinates':None,'salience_weights':None,'warning':'axes are hypotheses; no empirical semantic identification from aggregate shares'},
  {'id':'dynamic_choice','status':'CONCEPTUAL','expression':'q[g,p,t] proportional to pi0[g,p]*exp((-delta_D+delta_competence+delta_leader+delta_tactical)/temperature[g])','implementation':'model.dynamic_choice','rule':'Use changes relative to baseline; do not count the same affinity twice'},
  {'id':'aggregate','status':'CONCEPTUAL','expression':'S[p,t] = sum_g N[g]*tau[g]*d[g]*q[g,p,t] / sum_g N[g]*tau[g]*d[g]','implementation':'model.aggregate_groups','rule':'undecided and abstention are separate from Other; conditional on decided participants'},
  {'id':'survey_observation','status':'PARTIALLY_SPECIFIED','expression':'published[i,p,t] = publication_grid(institute_measurement(fieldwork_average(S), response_selection, weighting, projection))','individual_weights':None,'rule':'observe world state; do not treat a release prediction as objective world truth'}],
 'fitted_models':{
  'federal_long':{'status':'VALIDATION_SELECTED','target':'BUNDESTAG_VOTE_INTENTION_PUBLICATION','selected':'house','expression':'softmax(CLR(past_consensus)+alpha_party+house_series_party)','parameters':'polling_fit/results/long/house_parameters.json','summary':'polling_fit/results/long/summary.json','decay_time_constant_days':14,'party_rule':'six core parties + Other; BSW included in Other'},
  'federal_bsw':{'status':'VALIDATION_SELECTED','target':'BUNDESTAG_VOTE_INTENTION_PUBLICATION','selected':'rank1','expression':'softmax(CLR(past_consensus)+alpha_party+house_series_party+rank1_dynamic_correction)','parameters':'polling_fit/results/bsw/rank1_parameters.json','summary':'polling_fit/results/bsw/summary.json','decay_time_constant_days':14,'party_rule':'BSW separate; data begins 2024'},
  'state_landtag':{'status':'VALIDATION_SELECTED','target':'LANDTAG_VOTE_INTENTION','selected':'state_house_dynamic','expression':'softmax(CLR(past_national_consensus)+alpha_party+state_party_intercept+house_series_party+party_dynamic_slopes*state_context)','parameters':'polling_fit/results/states/state_house_dynamic_parameters.json','summary':'polling_fit/results/states/summary.json','state_party_intercepts':True,'independent_state_party_slopes':False,'warning':'Landtag outcomes; not state-level Bundestag intentions'}},
 'conventions':{'temperature_scale':{'value':1,'status':'CONVENTION'},'zero_replacement_pp':{'value':.25,'status':'CONVENTION'},'national_house_shrinkage_pseudo_observations':{'value':20,'status':'CONVENTION'},'historical_expiry_days':120},
 'validation_selected_penalties':{'state_intercept':10,'state_institute':50,'state_dynamic':10,'bsw_ridge':100,'note':'valid only under these scripts loss, feature scaling and target transforms'},
 'unidentified':{'socioeconomic_value_surface':None,'semantic_three_dimensional_positions':None,'group_event_causal_effects':None,'proprietary_pollster_weights':None,'state_bundestag_offsets':None},
 'interpretation_rules':['Latent correction rank 2/3 does not identify social/economic/cultural dimensions','A CLR coefficient is not a percentage-point increment','Do not choose a model by looking at 2026 test errors','2026 evaluation uses earlier observed 2026 publications; not open-loop scenario simulation','State coefficients are partially pooled and may include election-type/candidate/organization effects','All positive party probabilities jointly normalize','Actual surveys and model estimates must keep distinct evidence labels']}
write('model_spec.json',spec)
results={}
for name,folder in [('federal_long','long'),('federal_bsw','bsw'),('state_landtag','states')]:
 d=load('polling_fit/results/'+folder+'/summary.json')
 results[name]={'selected_on_validation':d['selected_by_validation'],'sample_split':{k:d[k] for k in ['n_train','n_validation','n_test']},
  'test_metrics':[{'model':c['kind'],'rmse_pp':c['test']['rmse_pp']} for c in d['configs']],
  'test_target':'published poll shares, normalized to sum to 100'}
results['key_conclusions']=['State-party intercepts improve over a national-only baseline','The strongest state persistence baseline nearly matches the fitted state model','Two-to-three correction-rank improvement is small','Demographic 2D surfaces and semantic 3D coordinates remain unestimated']
write('results_index.json',results)
coverage=load('polling_research/data/coverage.json');state=load('polling_fit/results/states/summary.json')
write('data_catalog.json',{'federal_polls':{'path':'polling_research/data/federal_polls_2017_2026.jsonl','n':2687,'range':coverage['range'],'kind':'OBSERVED_PUBLISHED_AGGREGATE'},
 'all_jurisdictions_source':{'path':'polling_research/raw/dawum.json','state_polls_since_2017':state['n_source_state_polls'],'state_retained_for_fit':state['n_retained'],'license':'ODC-ODbL 1.0','publisher':'dawum.de','author':'Philipp Guttmann'},
 'fgw_pairs':{'path':'polling_research/data/fgw_paired_1991_2026.jsonl','dates':coverage['fgw_paired_dates'],'party_date_cells':coverage['fgw_paired_cells'],'source':'Forschungsgruppe Wahlen: Politbarometer'},
 'sources':'polling_research/data/sources.json','fetch_manifest':'polling_research/data/source_manifest.json','prior_peer_comparisons':'polling_research/data/peer_contrast_summary.json','pollster_evidence':'polling_research/data/pollster_profiles_evidence.json'})
(R/'README_zh.md').write_text('''# 箱庭民调研究：统一说明与程序入口

截至2026-10-22。本包整理当前已经完成的民调资料、函数框架、拟合参数和检验结果。未接入原箱庭仓库。

## 从这里读

- `model_spec.json`：全部符号、公式、层级、证据状态及参数路径。
- `results_index.json`：全国、BSW单列、州议会三个版本的样本数与误差。
- `data_catalog.json`：历史数据、来源、许可与覆盖范围。
- `polling_fit/REPORT_zh.md`：详细拟合方法与局限。
- `model.py`：统一的可执行函数及命令行入口。

## 目前完整的概念链条

二维社会处境/价值画像 → 党派基础亲近度 → 三维位置及事件引起的选择变化 → 各群体选择与参与意愿汇总 → 机构调查、加权、投影与发布。

前半段的实质画像参数尚未估计。已拟合的是后半段可从总量数据识别的机构修正、历史动态与州党偏差。概念函数需要显式提供参数，缺参数时会报错。

`affinity_2d` 提供一个六项二次多项式候选，尚未证明它优于其他曲面。`dynamic_choice` 使用相对基准的变化量。`aggregate_groups` 保留参与概率与已决定概率，避免把未决定都归入其他党。

## 实际结果

长期全国模型使用2017—2023训练、2024—2025选参、2026测试。验证选中机构×党派修正，测试RMSE 0.908pp；同机构上一期基准为0.789pp。不能省略这个更强基准。

BSW单列模型使用2024训练、2025选参、2026测试。验证选中一维动态修正，测试RMSE 0.760pp，同系列上一期为0.776pp。二维0.752、三维0.746，差距小。

州议会模型中，全国趋势基准6.461pp，州党截距2.976pp，加入机构与历史动态1.814pp；上次州民调基准1.859pp。新模型相对这个强基准的提升尚不稳健。

全国源数据2687次；州级源数据1248次，其中1109次进入州级拟合。FGW两套官方历史表配对599个日期。不同任务有缺失过滤及热身，不能把所有样本数简单相加当成一次训练。

## 可运行命令

依赖 Python 3 + numpy。复现拟合图另需 matplotlib。数据读取不需要联网。

```bash
python model.py summary
python model.py verify
python model.py predict examples/national_long.json
```

`predict` 接受显式上下文与导出的拟合参数。它预测机构发布结果，无法凭一个政策事件自动生成真实民意。历史示例来自2026留出记录，使用的上下文均早于目标发布日期。

需要重跑时，从包根目录执行：

```bash
python polling_fit/fit_framework.py --input polling_research/data/federal_polls_2017_2026.jsonl
python polling_fit/fit_states.py
python polling_fit/check_fit.py
```

重新拟合会改变参数文件，原包校验值随后失效属于预期现象；可运行 `python build_summary.py` 重建汇总与校验清单。

## 参数与边界

党派、机构、州党参数分别保存，单位为CLR/logit，需经过softmax才能得到百分比。州模型的动态斜率目前按党派共享，州党截距部分收缩。数据不足时不独立填满全部州党斜率。

14天是验证选择的历史指数衰减时间常数，20是固定的机构收缩约定，θ=1是尺度约定。它们没有相同的证据地位，也不是机构公开的保密计算系数。

二维/三维在拟合结果里指统计修正秩，不能解释成已经发现了经济、文化和信任三条政治轴。

本包未解决事件因果效应、人口联合分布、未决定者流动和开放循环模拟。州议会意向与各州联邦选举意向有不同目标定义。

## 资料更正

重读直接下载的YouGov 2026年10月原PDF后，未加权投票意向人数为1773，与文章一致。早期提到的“正文与附表人数冲突”已撤回；本包不带该错误判断的旧说明。

## 来源与许可

DAWUM数据及派生数据库部分遵循ODC Open Database License 1.0，署名dawum.de、Philipp Guttmann。来源 https://api.dawum.de/ ，许可 https://opendatacommons.org/licenses/odbl/1-0/ 。

FGW表格引用为 Forschungsgruppe Wahlen: Politbarometer，并注明逐期日期；原始使用说明保留在表内。其他来源网址见sources.json。
''')
hashes={}
for p in sorted(R.rglob('*')):
 if p.is_file() and p.name!='manifest.json' and '__pycache__' not in p.parts:
  hashes[str(p.relative_to(R))]=hashlib.sha256(p.read_bytes()).hexdigest()
write('manifest.json',{'schema_version':'sha256-files-1','sha256':hashes})
archive=R.parent/'Hakoniwa_Polling_Consolidated_v1.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(R.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:z.write(p,p.relative_to(R))
print(archive)
