"""Chronological calibration of aggregate layers in the proposed framework.
Not identification of demographic coordinates, private pollster weights, or
causal event effects. Requires numpy/scipy, Python >=3.10.
Run: python fit_framework.py --input ../polling_research/data/federal_polls_2017_2026.jsonl
"""
import argparse
from collections import Counter,defaultdict
from datetime import date,timedelta
import hashlib,json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
def clr(p):
 z=np.log(np.maximum(p,1e-12));return z-z.mean(axis=-1,keepdims=True)
def softmax(z):
 a=np.exp(z-np.max(z,axis=-1,keepdims=True));return a/a.sum(axis=-1,keepdims=True)
def dump(path,obj):
 def clean(o):
  if isinstance(o,np.ndarray):return clean(o.tolist())
  if isinstance(o,(np.integer,)):return int(o)
  if isinstance(o,(np.floating,float)):return float(o) if np.isfinite(o) else None
  if isinstance(o,dict):return {k:clean(v) for k,v in o.items()}
  if isinstance(o,(tuple,list)):return [clean(v) for v in o]
  return o
 path.write_text(json.dumps(clean(obj),ensure_ascii=False,indent=2,allow_nan=False))

def prepare(source,bsw=False):
 parties=['CDU/CSU','SPD','Grüne','FDP','Linke','AfD']+(['BSW'] if bsw else [])+['Other']
 out=[];excluded=Counter()
 for r in source:
  if bsw and r['published']<'2024-01-01':continue
  if any(p not in r['results'] for p in parties[:-1]):excluded['missing_named_party']+=1;continue
  raw=np.array([r['results'][p] for p in parties[:-1]]+[sum(v for p,v in r['results'].items() if p not in parties[:-1])],float)
  if (raw<0).any() or raw.sum()<=0:excluded['invalid_composition']+=1;continue
  # 0.25pp is a numerical zero replacement, not a pseudo-respondent count.
  smoothed=np.maximum(raw,.25);smoothed=smoothed/smoothed.sum()
  out.append({**r,'day':date.fromisoformat(r['published']).toordinal(),'p':raw/raw.sum(),'z':clr(smoothed),
   'series':r['institute']+' / '+r['mode']})
 out.sort(key=lambda r:(r['day'],r['id']))
 return out,parties,dict(excluded)

def features(rows,tau):
 """All observations published on target date excluded, regardless of row order.
 Each institute receives equal total weight across its modes. No sample-size
 weighting because n definitions differ. Max age 120 days, explicit expiry.
 """
 byday=defaultdict(list)
 for r in rows:byday[r['day']].append(r)
 latest={};own={};records=[];contexts=[];meta=[];Y=[];base=[];last=[]
 prior_context=[]
 for day,group in sorted(byday.items()):
  available={k:v for k,v in latest.items() if day-v['day']<=120}
  if len({v['institute'] for v in available.values()})>=3:
   inst=defaultdict(list)
   for v in available.values():inst[v['institute']].append(v)
   inst_means=[];inst_weights=[]
   for values in inst.values():
    w=np.array([np.exp(-(day-v['day'])/tau) for v in values]);ps=np.stack([v['p'] for v in values])
    inst_means.append(np.average(ps,axis=0,weights=w));inst_weights.append(float(w.max()))
   b=np.average(inst_means,axis=0,weights=inst_weights);b=b/b.sum();bz=clr(np.maximum(b,.0025))
   # Previous consensus must have existed at least 14 days before target.
   previous=next((v for d,v in reversed(prior_context) if d<=day-14),bz)
   momentum=bz-previous
   for r in group:
    old=own.get(r['series']);age=day-old['day'] if old else 121
    innovation=old.get('innovation',np.zeros_like(bz)) if old else np.zeros_like(bz)
    if age>120:innovation=np.zeros_like(bz)
    duration=(date.fromisoformat(r['field_end'])-date.fromisoformat(r['field_start'])).days+1
    lag=(date.fromisoformat(r['published'])-date.fromisoformat(r['field_end'])).days
    x=np.r_[momentum,innovation,np.log1p(min(age,121)),duration,lag,float(old is None or age>120)]
    records.append(r);Y.append(r['z']);base.append(bz);last.append(old['p'] if old and age<=120 else b)
    contexts.append(x);meta.append({'id':r['id'],'published':r['published'],'series':r['series'],'institute':r['institute'],
      'latest_predictor_date':date.fromordinal(max(v['day'] for v in available.values())).isoformat(),
      'field_start':r['field_start'],'field_end':r['field_end']})
   prior_context.append((day,bz))
   for r in group:r['innovation']=r['z']-bz
  for r in group:latest[r['series']]=r;own[r['series']]=r
 return {'rows':records,'meta':meta,'X':np.stack(contexts),'Y':np.stack(Y),'B':np.stack(base),'last':np.stack(last),
   'P':np.stack([r['p'] for r in records]),'day':np.array([r['day'] for r in records]),'tau':tau}

def fit(data,mask,kind,lam=10):
 R=data['Y'][mask]-data['B'][mask];n,k=R.shape
 alpha=R.mean(axis=0)
 house={}
 if kind!='offset':
  labels=[r['series'] for r,m in zip(data['rows'],mask) if m]
  for label in sorted(set(labels)):
   ix=np.array([s==label for s in labels]);count=int(ix.sum())
   # Fixed shrinkage prior strength 20 observations. Sensitivity checked separately.
   house[label]=(R[ix]-alpha).sum(axis=0)/(count+20)
  H=np.stack([house[s] for s in labels]);E=R-alpha-H
 else:E=R-alpha
 means=data['X'][mask].mean(axis=0);scale=data['X'][mask].std(axis=0);scale[scale<1e-8]=1
 coefs=np.zeros((data['X'].shape[1],k));basis=np.eye(k);center=np.zeros(k)
 if kind.startswith('rank') or kind=='full':
  center=E.mean(axis=0)
  _,sing,V=np.linalg.svd(E-center,full_matrices=False)
  rank=k-1 if kind=='full' else int(kind[4:])
  basis=V[:rank].T
  X=(data['X'][mask]-means)/scale
  coefs=np.linalg.solve(X.T@X+lam*np.eye(X.shape[1]),X.T@(E-center))@basis@basis.T
 return {'kind':kind,'lambda':lam,'alpha':alpha,'house':house,'means':means,'scale':scale,'coefficients':coefs,'basis':basis,'center':center,
   'feature_names':['momentum_clr_'+str(i) for i in range(k)]+['previous_series_innovation_clr_'+str(i) for i in range(k)]+['log1p_days_since_series','field_days_inclusive','release_lag_days','no_recent_same_series']}
def predict(data,model):
 R=np.tile(model['alpha'],(len(data['rows']),1))
 if model['kind']!='offset':R+=np.stack([model['house'].get(r['series'],np.zeros(R.shape[1])) for r in data['rows']])
 if model['kind'].startswith('rank') or model['kind']=='full':
  R+=model['center']+(data['X']-model['means'])/model['scale']@model['coefficients']
 return softmax(data['B']+R)
def metrics(data,pred,mask):
 e=100*(pred[mask]-data['P'][mask]);ins=np.array([r['institute'] for r in data['rows']])[mask]
 return {'n_polls':int(mask.sum()),'rmse_pp':float(np.sqrt(np.mean(e*e))),'mae_pp':float(np.abs(e).mean()),
   'institute_macro_rmse_pp':float(np.mean([np.sqrt(np.mean(e[ins==i]**2)) for i in sorted(set(ins))])),
   'party_rmse_pp':np.sqrt(np.mean(e*e,axis=0)).tolist()}

def run(source,bsw=False):
 rows,parties,excluded=prepare(source,bsw)
 train_end='2024-12-31' if bsw else '2023-12-31'
 val_start='2025-01-01' if bsw else '2024-01-01'
 datasets={tau:features(rows,tau) for tau in [7,14,28,56]}
 first=next(iter(datasets.values()));days=first['day']
 train=days<=date.fromisoformat(train_end).toordinal()
 val=(days>=date.fromisoformat(val_start).toordinal())&(days<date(2026,1,1).toordinal())
 test=days>=date(2026,1,1).toordinal();refit=~test
 assert all(d['meta']==first['meta'] for d in datasets.values())
 assert all(m['latest_predictor_date']<m['published'] for m in first['meta'])
 configs=[]
 for kind in ['consensus','offset','house','rank1','rank2','rank3','rank4','full']:
  options=[]
  for tau,data in datasets.items():
   for lam in ([1,10,100] if kind.startswith('rank') or kind=='full' else [10]):
    pred=softmax(data['B']) if kind=='consensus' else predict(data,fit(data,train,kind,lam))
    score=metrics(data,pred,val)
    options.append((score['institute_macro_rmse_pp'],tau,lam,score))
  _,tau,lam,score=min(options,key=lambda x:x[:3])
  data=datasets[tau]
  model=None if kind=='consensus' else fit(data,refit,kind,lam)
  pred=softmax(data['B']) if kind=='consensus' else predict(data,model)
  configs.append({'kind':kind,'tau_days':tau,'ridge_lambda':None if kind in ['consensus','offset','house'] else lam,
   'validation':score,'test':metrics(data,pred,test)})
  if model is not None:dump(ROOT/'results'/('bsw' if bsw else 'long')/(kind+'_parameters.json'),{'parties':parties,'tau_days':tau,**model})
 # Pure persistence reference, no hyperparameter selected.
 configs.append({'kind':'same_series_last','tau_days':None,'ridge_lambda':None,
   'validation':metrics(first,first['last'],val),'test':metrics(first,first['last'],test)})
 selected=min(configs[:-1],key=lambda x:x['validation']['institute_macro_rmse_pp'])
 data=datasets[selected['tau_days']]
 final_model=None if selected['kind']=='consensus' else fit(data,refit,selected['kind'],selected['ridge_lambda'] or 10)
 pred=softmax(data['B']) if final_model is None else predict(data,final_model)
 # Paired calendar-month bootstrap on TEST only for diagnostics, never selection.
 consensus_config=next(x for x in configs if x['kind']=='consensus')
 cons=softmax(datasets[consensus_config['tau_days']]['B'])
 indices=np.flatnonzero(test);months=sorted(set(m['published'][:7] for m,t in zip(data['meta'],test) if t))
 bymonth={m:np.array([i for i in indices if data['meta'][i]['published'].startswith(m)]) for m in months}
 rng=np.random.default_rng(20261022);diffs=[]
 for _ in range(2000):
  ix=np.concatenate([bymonth[m] for m in rng.choice(months,len(months),replace=True)])
  diffs.append(float(np.sqrt(np.mean((100*(pred[ix]-data['P'][ix]))**2))-np.sqrt(np.mean((100*(cons[ix]-data['P'][ix]))**2))))
 predictions=[]
 for i in indices:
  predictions.append({**data['meta'][i],'actual_normalized_percent':(100*data['P'][i]).tolist(),
   'prediction_percent':(100*pred[i]).tolist(),'consensus_prediction_percent':(100*cons[i]).tolist()})
 folder=ROOT/'results'/('bsw' if bsw else 'long')
 dump(folder/'predictions_2026.json',{'parties':parties,'predictions':predictions})
 summary={'parties':parties,'source_polls':len(source),'retained_polls_before_warmup':len(rows),'excluded':excluded,
   'train_end':train_end,'validation_start':val_start,'validation_end':'2025-12-31','test_start':'2026-01-01',
   'n_train':int(train.sum()),'n_validation':int(val.sum()),'n_test':int(test.sum()),
   'selection_metric':'validation equal-institute mean RMSE; NOT test error',
   'configs':configs,'selected_by_validation':selected['kind'],
   'test_selected_minus_consensus_rmse_month_block_bootstrap_95':np.quantile(diffs,[.025,.975]),
   'bootstrap_note':'conditional diagnostic, only 10 calendar-month blocks; not population confidence',
   'test_use':'rolling next-release prediction using previous observed publications; not open-loop forecast',
   'zero_replacement_pp':.25,'house_shrinkage_observations':20,
   'identifiable':['aggregate relative series offsets','reduced-rank corrections to previous-release consensus'],
   'not_identified':['social-position/value coordinates','group-specific affinity surfaces','economic/cultural/trust coordinates','causal event sensitivities','individual pollster weights','utility temperature separately from utility scale']}
 dump(folder/'summary.json',summary)
 print(('BSW' if bsw else 'LONG'),json.dumps({'selected':selected['kind'],'n_train':int(train.sum()),'n_validation':int(val.sum()),'n_test':int(test.sum())},ensure_ascii=False),flush=True)
 return summary

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--input',type=Path,required=True);args=parser.parse_args()
 for sub in ['long','bsw']:(ROOT/'results'/sub).mkdir(parents=True,exist_ok=True)
 source=[json.loads(l) for l in args.input.read_text().splitlines()]
 dump(ROOT/'results/input_provenance.json',{'path':str(args.input),'sha256':hashlib.sha256(args.input.read_bytes()).hexdigest(),'n':len(source),'source':'https://api.dawum.de/','data_license':'ODC-ODbL 1.0, dawum.de, Philipp Guttmann'})
 run(source,False);run(source,True)
