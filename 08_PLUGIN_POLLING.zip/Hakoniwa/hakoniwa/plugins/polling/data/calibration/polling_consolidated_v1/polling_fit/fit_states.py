"""Partially pooled state-party intercepts for LANDTAG vote intentions.
National Bundestag polls are predictors, not interchangeable targets.
Regularization identifies a shrinkage convention, not causal constants.
"""
import json
from pathlib import Path
from collections import defaultdict,Counter
from datetime import date
import numpy as np
from fit_framework import clr,softmax,dump,prepare,features

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results/states';OUT.mkdir(parents=True,exist_ok=True)
raw=json.loads((ROOT.parent/'polling_research/raw/dawum.json').read_text())
federal=[json.loads(l) for l in (ROOT.parent/'polling_research/data/federal_polls_2017_2026.jsonl').read_text().splitlines()]
fed,parties,_=prepare(federal)
national=features(fed,14)
fed_context=[(r['day'],r['p'],r['institute'],r['series']) for r in fed]
state_rows=[];excluded=Counter()
for sid,s in raw['Surveys'].items():
 if s['Parliament_ID'] in ['0','17'] or not ('2017-01-01'<=s['Date']<='2026-10-22'):continue
 result={raw['Parties'][k]['Shortcut']:v for k,v in s['Results'].items()}
 result['CDU/CSU']=sum(result.get(k,0) for k in ['CDU/CSU','CDU','CSU'])
 if any(p not in result for p in parties[:-1]):excluded['missing_named_party']+=1;continue
 values=np.array([result[p] for p in parties[:-1]]+[sum(v for p,v in result.items() if p not in parties[:-1]+['CDU','CSU'])],float)
 if values.sum()<=0:continue
 state_rows.append({'id':sid,'day':date.fromisoformat(s['Date']).toordinal(),'published':s['Date'],
  'state':raw['Parliaments'][s['Parliament_ID']]['Shortcut'],
  'institute':raw['Institutes'][s['Institute_ID']]['Name']+' / '+raw['Methods'][s['Method_ID']]['Name'],
  'p':values/values.sum(),'z':clr(np.maximum(values,.25)/np.maximum(values,.25).sum()),
  'target':'LANDTAG_VOTE_INTENTION','field_start':s['Survey_Period']['Date_Start'],'field_end':s['Survey_Period']['Date_End']})
state_rows.sort(key=lambda r:(r['day'],r['id']))
byday=defaultdict(list)
for r in state_rows:byday[r['day']].append(r)
records=[];own={};context_history=[]
for day,group in sorted(byday.items()):
 # Cut by publication, STRICTLY before state release date, no same-day leakage.
 available=[r for r in fed if 0<day-r['day']<=120]
 latest={r['series']:r for r in available}
 if len({r['institute'] for r in latest.values()})<3:continue
 inst=defaultdict(list)
 for r in latest.values():inst[r['institute']].append(r)
 means=[];weights=[]
 for vs in inst.values():
  w=np.array([np.exp(-(day-r['day'])/14) for r in vs]);means.append(np.average(np.stack([r['p'] for r in vs]),axis=0,weights=w));weights.append(w.max())
 bp=np.average(means,axis=0,weights=weights);bz=clr(np.maximum(bp,.0025))
 prev=next((z for d,z in reversed(context_history) if d<=day-14),bz)
 for r in group:
  old=own.get(r['state']);age=day-old['day'] if old else 731
  innovation=old['z']-old['baseline_z'] if old and age<=730 else np.zeros(len(parties))
  records.append({**r,'baseline_z':bz,'momentum':bz-prev,'previous_state_residual':innovation,
   'log_gap':np.log1p(min(age,731)),'baseline_p':bp,
   'persistence_p':old['p'] if old and age<=730 else bp,
   'latest_predictor_date':max(x['published'] for x in latest.values())})
 context_history.append((day,bz))
 for r in group:own[r['state']]={**r,'baseline_z':bz}

states=sorted(set(r['state'] for r in records));insts=sorted(set(r['institute'] for r in records))
P=np.stack([r['p'] for r in records]);Z=np.stack([r['z'] for r in records]);B=np.stack([r['baseline_z'] for r in records]);Y=Z-B
dates=np.array([r['day'] for r in records]);tr=dates<date(2024,1,1).toordinal();va=(dates>=date(2024,1,1).toordinal())&(dates<date(2026,1,1).toordinal());te=dates>=date(2026,1,1).toordinal()
S=np.array([[float(r['state']==s) for s in states] for r in records]);H=np.array([[float(r['institute']==i) for i in insts] for r in records])
def score(pred,mask):
 e=100*(pred[mask]-P[mask]);labels=np.array([r['state'] for r in records])[mask]
 return {'n':int(mask.sum()),'rmse_pp':float(np.sqrt(np.mean(e*e))),
  'state_macro_rmse_pp':float(np.mean([np.sqrt(np.mean(e[labels==s]**2)) for s in set(labels)]))}

def fit(mask,kind,ls=20,li=50,ld=100):
 models=[];predz=np.zeros_like(Y)
 for j,party in enumerate(parties):
  # Party-specific slopes on same-party national momentum/state persistence.
  dyn=np.array([[r['momentum'][j],r['previous_state_residual'][j],r['log_gap']] for r in records])
  mean=dyn[mask].mean(0);std=dyn[mask].std(0);std[std<1e-8]=1;dyn=(dyn-mean)/std
  blocks=[np.ones((len(records),1))];pen=[0.0];names=['national_party_offset']
  if kind!='global_offset':blocks.append(S);pen.extend([ls]*len(states));names.extend('state:'+s for s in states)
  if kind in ['state_house','state_house_dynamic']:blocks.append(H);pen.extend([li]*len(insts));names.extend('institute:'+s for s in insts)
  if kind=='state_house_dynamic':blocks.append(dyn);pen.extend([ld]*3);names.extend(['national_momentum','previous_state_residual','log_gap'])
  X=np.column_stack(blocks);coef=np.linalg.solve(X[mask].T@X[mask]+np.diag(pen),X[mask].T@Y[mask,j]);predz[:,j]=X@coef
  models.append({'party':party,'coefficients':dict(zip(names,coef.tolist())),'dynamic_standardization_mean':mean,'dynamic_standardization_sd':std})
 return softmax(B+predz),models

configs=[]
for kind in ['global_offset','state','state_house','state_house_dynamic']:
 options=[]
 for ls in ([20] if kind=='global_offset' else [2,10,50,200]):
  for li in ([10,50] if 'house' in kind else [50]):
   for ld in ([10,100] if 'dynamic' in kind else [100]):
    pred,_=fit(tr,kind,ls,li,ld);v=score(pred,va);options.append((v['state_macro_rmse_pp'],ls,li,ld,v))
 _,ls,li,ld,v=min(options,key=lambda x:x[:4]);pred,models=fit(~te,kind,ls,li,ld)
 configs.append({'kind':kind,'state_penalty':ls,'institute_penalty':li,'dynamic_penalty':ld,'validation':v,'test':score(pred,te)})
 dump(OUT/(kind+'_parameters.json'),{'parties':parties,'models':models,'target':'LANDTAG_VOTE_INTENTION','coefficients_are':'CLR/logit-scale relative corrections, not percentage points'})
for kind,pred in [('national_only',softmax(B)),('state_last',np.stack([r['persistence_p'] for r in records]))]:configs.append({'kind':kind,'validation':score(pred,va),'test':score(pred,te)})
chosen=min(configs,key=lambda x:x['validation']['state_macro_rmse_pp']);kind=chosen['kind']
if kind=='national_only':pred=softmax(B)
elif kind=='state_last':pred=np.stack([r['persistence_p'] for r in records])
else:pred,_=fit(~te,kind,chosen['state_penalty'],chosen['institute_penalty'],chosen['dynamic_penalty'])
state_summary=[]
for s in states:
 mask=np.array([r['state']==s for r in records]);test=mask&te
 state_summary.append({'state':s,'training_through_2025':int((mask&~te).sum()),'test_2026':int(test.sum()),
  'selected_test_rmse_pp':score(pred,test)['rmse_pp'] if test.any() else None,
  'low_data_warning':int((mask&~te).sum())<30})
dump(OUT/'summary.json',{'n_source_state_polls':sum(s['Parliament_ID'] not in ['0','17'] and s['Date']>='2017-01-01' for s in raw['Surveys'].values()),
 'n_retained':len(records),'n_train':int(tr.sum()),'n_validation':int(va.sum()),'n_test':int(te.sum()),'excluded':dict(excluded),'parties':parties,
 'configs':configs,'selected_by_validation':kind,'states':state_summary,
 'constraints':['Not a Bundesland Bundestag-intention estimate','CSU and CDU aligned as Union only for cross-region model; state labels retained','Other includes local parties and BSW; not substantively identical across states','Partial pooling penalty is a modelling convention selected on validation','No invented state demographic constants','No test-based tuning','Latest-state baseline can be up to 730 days old','Rolling next-publication prediction, not open-loop simulation']})
dump(OUT/'predictions_2026.json',{'parties':parties,'selected':kind,'rows':[{'id':r['id'],'state':r['state'],'published':r['published'],'latest_predictor_date':r['latest_predictor_date'],'actual_normalized_percent':100*P[i],'predicted_percent':100*pred[i],'persistence_percent':100*r['persistence_p']} for i,r in enumerate(records) if te[i]]})
# Compare the selected model to the serious persistence benchmark, resampling
# entire states to avoid pretending all releases are independent observations.
rng=np.random.default_rng(20261022);test_states=sorted({r['state'] for i,r in enumerate(records) if te[i]})
groups={s:np.array([i for i,r in enumerate(records) if te[i] and r['state']==s]) for s in test_states}
persist=np.stack([r['persistence_p'] for r in records]);diff=[]
for _ in range(2000):
 ix=np.concatenate([groups[s] for s in rng.choice(test_states,len(test_states),replace=True)])
 diff.append(float(np.sqrt(np.mean((100*(pred[ix]-P[ix]))**2))-np.sqrt(np.mean((100*(persist[ix]-P[ix]))**2))))
dump(OUT/'persistence_comparison_uncertainty.json',{'test_states':len(test_states),'rmse_difference_selected_minus_persistence_95_state_block':np.quantile(diff,[.025,.975]),'note':'Conditional small-block bootstrap diagnostic; not population confidence. Negative favours selected model.'})
print(json.dumps({'configs':configs,'selected':kind,'counts':[int(tr.sum()),int(va.sum()),int(te.sum())]},ensure_ascii=False),flush=True)
