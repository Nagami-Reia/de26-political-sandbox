"""Checks of probability constraints, chronological access and fit isolation."""
import copy,json
from pathlib import Path
import numpy as np
from fit_framework import prepare,features,fit,predict,dump
R=Path(__file__).resolve().parent
source=[json.loads(l) for l in (R.parent/'polling_research/data/federal_polls_2017_2026.jsonl').read_text().splitlines()]
rows,_,_=prepare(copy.deepcopy(source));a=features(rows,14)
train=np.array([r['published']<'2024-01-01' for r in a['rows']])
m=fit(a,train,'rank3',100);p=predict(a,m)
assert np.isfinite(p).all() and np.allclose(p.sum(1),1) and (p>=0).all()
assert all(r['latest_predictor_date']<r['published'] for r in a['meta'])
b=copy.deepcopy(a);b['Y'][~train]=b['Y'][~train]+100*np.arange(b['Y'].shape[1])
n=fit(b,train,'rank3',100)
assert np.allclose(m['coefficients'],n['coefficients']) and np.allclose(m['basis']@m['basis'].T,n['basis']@n['basis'].T)
# Mutate future raw targets. Earlier decision-time contexts must be identical.
future=copy.deepcopy(source)
for r in future:
 if r['published']>='2026-07-01':r['results']['CDU/CSU']=80
r2,_,_=prepare(future);b=features(r2,14)
assert a['meta']==b['meta']
past=np.array([r['published']<'2026-07-01' for r in a['meta']])
assert np.allclose(a['X'][past],b['X'][past]) and np.allclose(a['B'][past],b['B'][past])
state=json.loads((R/'results/states/predictions_2026.json').read_text())
for row in state['rows']:
 assert row['latest_predictor_date']<row['published']
 assert abs(sum(row['predicted_percent'])-100)<1e-8
 assert row['state']
dump(R/'results/checks.json',{'passed':['nonnegative finite compositional predictions sum to one','same-day and future publications excluded from target predictors','held-out targets do not change training coefficients or factor subspace','mutating future source values does not change earlier contexts','state predictions sum to 100 and use earlier national releases'],
 'not_established':['open-loop scenario validity','demographic causal identification','future generalization beyond the 2026 holdout','calibrated prediction intervals']})
print('5 substantive checks passed')
