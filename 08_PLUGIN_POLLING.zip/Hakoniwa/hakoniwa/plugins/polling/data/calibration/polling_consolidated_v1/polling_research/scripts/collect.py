"""Public polling source collector. Cache responses, retain hashes and provenance.
Run from polling_research with Python 3 (stdlib only). No authentication required.
"""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
BASE = 'https://www.forschungsgruppe.de/Umfragen/Politbarometer/Langzeitentwicklung_-_Themen_im_Ueberblick/Politik_I/'
SOURCES = {
 'dawum.json':'https://api.dawum.de/',
 'insa.html':'https://www.wahlrecht.de/umfragen/insa.htm',
 'yougov.html':'https://www.wahlrecht.de/umfragen/yougov.htm',
 'insa_methods.html':'https://www.insa-consulere.de/leistungen/',
 'yougov_faq.html':'https://yougov.com/de-de/geschaeft/sektoren/politik/wahlforschung',
 'fgw_methods.html':'https://www.forschungsgruppe.de/Rund_um_die_Meinungsforschung/Methodik_Politbarometer/',
 'fgw_faq.html':'https://www.forschungsgruppe.de/FAQ/',
 'fgw_projection.xlsx':BASE+'1_Projektion.xlsx',
 'fgw_mood.xlsx':BASE+'2_Stimmung.xlsx',
 'fgw_no_intention.xlsx':BASE+'3_Keine_Wahl_1.xlsx',
 'yougov_2026_10.pdf':'https://ygo-assets-websites-editorial-emea.yougov.net/documents/YouGov_Sonntagsfrage_Oktober_2026.pdf',
 'yougov_2025_05.pdf':'https://ygo-assets-websites-editorial-emea.yougov.net/documents/YouGov_Sonntagsfrage_KW19_2025_Ergebnisse.pdf',
 'yougov_2024_08.pdf':'https://ygo-assets-websites-editorial-emea.yougov.net/documents/YouGov_Sonntagsfrage_August2024.pdf',
 'forsa_methods.html':'https://www.forsa.de/dialog-mit-forsa/',
 'dimap_2021_08.pdf':'https://www.infratest-dimap.de/fileadmin/user_upload/DT2108_Bericht.pdf',
}
def fetch(item):
 name,url=item
 path=ROOT/'raw'/name
 try:
  if not path.exists():
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Political-methods-research/1.0'}),timeout=35) as r:
    data=r.read()
   path.write_bytes(data)
  data=path.read_bytes()
  return {'file':name,'url':url,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'status':'OK','accessed_date':'2026-10-22'}
 except Exception as e:return {'file':name,'url':url,'status':'ERROR','error':str(e)}
if __name__=='__main__':
 (ROOT/'raw').mkdir(exist_ok=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: rows=list(pool.map(fetch,SOURCES.items()))
 (ROOT/'data'/'source_manifest.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
 for row in rows: print(row['file'],row['status'],row.get('bytes',row.get('error')))
