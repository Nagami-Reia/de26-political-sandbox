"""Unified interfaces for the polling research package.
Fitted models predict published aggregate poll results. The conceptual helpers
require supplied parameters and never fill unestimated social coefficients.
Run: python model.py summary | verify | predict examples/national_long.json
"""
import argparse,hashlib,json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
def read(path):return json.loads(Path(path).read_text())
def softmax(x):
 x=np.asarray(x,float)
 if not np.isfinite(x).all():raise ValueError('Nonfinite utility')
 z=np.exp(x-x.max());return z/z.sum()
def simplex(values):
 p=np.asarray(values,float)
 if p.ndim!=1 or not np.isfinite(p).all() or (p<0).any() or p.sum()<=0:raise ValueError('Invalid probability/share vector')
 return p/p.sum()
def clr(values,floor=.0025):
 z=np.log(np.maximum(simplex(values),floor));return z-z.mean()

def affinity_2d(social_position,value_orientation,coefficients):
 """PROPOSED polynomial candidate, NOT fitted from aggregate poll data.
 coefficients: party x [1,s,v,s^2,s*v,v^2], externally supplied.
 """
 if coefficients is None:raise ValueError('Two-dimensional affinity coefficients are unestimated')
 s,v=float(social_position),float(value_orientation)
 c=np.asarray(coefficients,float)
 if c.ndim!=2 or c.shape[1]!=6 or not np.isfinite(c).all():raise ValueError('Expected finite party-by-6 coefficients')
 return c@np.array([1,s,v,s*s,s*v,v*v])

def dynamic_choice(baseline_probability,delta_distance,delta_competence,delta_leader,delta_tactical,temperature):
 """CONCEPTUAL: baseline * exp(delta utility / temperature).
 Distance must be a change from the baseline to avoid counting affinity twice.
 """
 p=simplex(baseline_probability)
 if not np.isfinite(temperature) or temperature<=0:raise ValueError('Positive temperature required')
 a=[np.asarray(x,float) for x in [delta_distance,delta_competence,delta_leader,delta_tactical]]
 if any(x.shape!=p.shape for x in a):raise ValueError('Mismatched party vectors')
 return softmax(np.log(np.maximum(p,1e-12))+(-a[0]+a[1]+a[2]+a[3])/temperature)

def aggregate_groups(population_mass,participation_probability,decided_probability,conditional_party_probability):
 """CONCEPTUAL aggregation among decided participants; undecided not Other."""
 n,t,d=[np.asarray(x,float) for x in [population_mass,participation_probability,decided_probability]]
 q=np.asarray(conditional_party_probability,float)
 if n.ndim!=1 or n.shape!=t.shape or n.shape!=d.shape or q.ndim!=2 or q.shape[0]!=len(n):raise ValueError('Mismatched group dimensions')
 if not all(np.isfinite(x).all() for x in [n,t,d,q]) or (n<0).any() or (q<0).any():raise ValueError('Invalid group values')
 if (t<0).any() or (t>1).any() or (d<0).any() or (d>1).any() or not np.allclose(q.sum(1),1):raise ValueError('Invalid probability')
 w=n*t*d
 if w.sum()<=0:raise ValueError('No decided participants')
 return (w[:,None]*q).sum(0)/w.sum()

def fitted_prediction(context):
 """Apply exported, already-fitted coefficients to explicit context only."""
 scope=context['model'];cfg=read(ROOT/'model_spec.json')['fitted_models'][scope]
 params=read(ROOT/cfg['parameters']);base=clr(context['baseline_percent'])
 if len(base)!=len(params['parties']):raise ValueError('Party order mismatch')
 if context.get('party_order')!=params['parties']:raise ValueError('Explicit matching party_order required')
 warnings=[]
 if scope in ['federal_long','federal_bsw']:
  correction=np.asarray(params['alpha'],float)
  series=context['series'];house=params['house']
  if series in house:correction=correction+np.asarray(house[series])
  else:warnings.append('Unseen series: shrunk institution correction is zero')
  if params['kind'].startswith('rank') or params['kind']=='full':
   x=np.asarray(context['dynamic_features'],float);mu=np.asarray(params['means']);sd=np.asarray(params['scale'])
   if x.shape!=mu.shape:raise ValueError('Incorrect dynamic_features size/order')
   correction=correction+np.asarray(params['center'])+((x-mu)/sd)@np.asarray(params['coefficients'])
 else:
  if context['target']!='LANDTAG_VOTE_INTENTION':raise ValueError('State parameters apply only to Landtag intentions')
  correction=[]
  for j,m in enumerate(params['models']):
   c=m['coefficients'];statekey='state:'+context['state']
   if statekey not in c:raise ValueError('Unknown state')
   value=c['national_party_offset']+c[statekey]
   inst='institute:'+context['series'];value+=c.get(inst,0)
   if inst not in c:warnings.append('Unseen state survey series: zero institution correction')
   raw=np.array([context['national_momentum_clr'][j],context['previous_state_residual_clr'][j],context['log_gap']])
   z=(raw-np.array(m['dynamic_standardization_mean']))/np.array(m['dynamic_standardization_sd'])
   value+=sum(c[name]*z[k] for k,name in enumerate(['national_momentum','previous_state_residual','log_gap']))
   correction.append(value)
  correction=np.array(correction)
 result=100*softmax(base+correction)
 return {'model':scope,'target':cfg['target'],'party_order':params['parties'],'predicted_percent':result.tolist(),
  'status':'MODEL_ESTIMATE_OF_PUBLISHED_POLL_NOT_WORLD_TRUTH','warnings':sorted(set(warnings))}

def main():
 parser=argparse.ArgumentParser();parser.add_argument('command',choices=['summary','verify','predict']);parser.add_argument('context',nargs='?');args=parser.parse_args()
 if args.command=='summary':print(json.dumps(read(ROOT/'results_index.json'),ensure_ascii=False,indent=2))
 elif args.command=='predict':
  if not args.context:parser.error('predict requires a JSON context')
  print(json.dumps(fitted_prediction(read(args.context)),ensure_ascii=False,indent=2))
 else:
  manifest=read(ROOT/'manifest.json');fail=[]
  for p,h in manifest['sha256'].items():
   f=ROOT/p
   if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=h:fail.append(p)
  if fail:raise RuntimeError('Manifest mismatch: '+repr(fail))
  example=read(ROOT/'examples/national_long.json');result=fitted_prediction(example)
  if not np.allclose(result['predicted_percent'],example['expected_prediction_percent'],atol=1e-9):raise RuntimeError('Exported inference differs from fitted holdout output')
  if abs(sum(result['predicted_percent'])-100)>1e-8:raise RuntimeError('Probability normalization failure')
  print(json.dumps({'valid':True,'files_checked':len(manifest['sha256']),'historical_parameter_replay':'passed','conceptual_parameters':'remain unestimated'},ensure_ascii=False))
if __name__=='__main__':main()
