"""POLLING: voter response first, survey measurement second.

Pure model/evidence APIs are standalone. Hakoniwa world hooks load lazily.
"""
from .model import PollingModel, BlendedPublicationModel, aggregate_groups, dynamic_choice, softmax, normalize
from .party_response import (PartyResponseModel, predict_union, predict_spd, predict_gruene,
    predict_fdp, predict_linke, predict_afd, predict_bsw, predict_other)
from .observation import FieldworkObserver

__all__=["PollingModel","BlendedPublicationModel","aggregate_groups","dynamic_choice","softmax","normalize",
    "PartyResponseModel","predict_union","predict_spd","predict_gruene","predict_fdp","predict_linke",
    "predict_afd","predict_bsw","predict_other","FieldworkObserver"]


def __getattr__(name):
    if name in {"RealtimePollingTracker","PollSeriesSpec"}:
        from .tracker import RealtimePollingTracker, PollSeriesSpec
        return {"RealtimePollingTracker":RealtimePollingTracker,"PollSeriesSpec":PollSeriesSpec}[name]
    if name == "PollingPlugin":
        from .service import PollingPlugin
        return PollingPlugin
    raise AttributeError(name)
