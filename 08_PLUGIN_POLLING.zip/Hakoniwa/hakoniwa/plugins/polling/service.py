"""Single Hakoniwa event hook: electorate reaction → world support → measurement."""
from copy import deepcopy
from datetime import datetime
import json
from pathlib import Path

from .party_response import PartyResponseModel, PARTIES
from .tracker import RealtimePollingTracker


class PollingPlugin(RealtimePollingTracker):
    def __init__(self,run_id,environment_id,specs,start_timestamp,*,bindings,
                 response_request=None,response_by_event_id=None,window_minutes=4320,publication_grid=.5,
                 timestamp_by_event_id=None):
        if set(bindings) != set(PARTIES) or len(set(bindings.values())) != len(PARTIES):
            raise ValueError("POLLING requires all eight party bindings including Other")
        self.bindings=dict(bindings)
        super().__init__(run_id,environment_id,specs,start_timestamp,timestamp_by_event_id,
            composition_groups=({"key":"DE_complete_party_vote_intention","variables":[bindings[p] for p in PARTIES],
                "complete_party_universe":True,"window_minutes":window_minutes,"publication_grid":publication_grid},))
        self.response_model=PartyResponseModel()
        self.base_request=deepcopy(response_request or {})
        if self.base_request.get("events"):
            raise ValueError("Queue realized node responses separately; baseline request must not contain future events")
        self.response_by_event_id=deepcopy(response_by_event_id or {})
        self.realized_events=[]; self.voter_response_history=[]
        self._baseline_ready=False; self._last_composition=None; self._recorded_ids=set()

    def _composition(self,state):return {p:state.variables[v].value for p,v in self.bindings.items()}

    def record_baseline(self,state):
        if self._baseline_ready:raise ValueError("POLLING baseline already recorded")
        at=self.start.date().isoformat()
        if "calibration" not in self.base_request:
            self.base_request["calibration"]={"source_id":"scenario_initial_world_composition",
                "available_from":at,"target":"BUNDESTAG_VOTE_INTENTION","party_percent":self._composition(state)}
        request={**self.base_request,"as_of":at,"events":[]}
        result=self.response_model.predict(request)
        self.response_model.settle_into_world(result,state,self.bindings,acknowledge_conditional_model=True)
        self._last_composition=self._composition(state)
        self.voter_response_history.append({"event_id":"baseline","timestamp":self.start.isoformat(),
            "stage":"ELECTORATE_AGGREGATION_BEFORE_MEASUREMENT","result":result})
        self._baseline_ready=True
        super().record_baseline(state)

    def record(self,state,*,event_id,actor,action,event_kind,resource_changes=None):
        if not self._baseline_ready:raise ValueError("Record POLLING baseline before events")
        if event_id in self._recorded_ids:raise ValueError("Duplicate node measurement: "+event_id)
        if any(abs(self._composition(state)[p]-self._last_composition[p])>1e-7 for p in PARTIES):
            raise ValueError("Support changed outside voter-response plugin; do not combine legacy direct deltas with POLLING mode")
        timestamp=self.timestamp_by_event_id.get(event_id,self._timestamp(self.telemetry.next_step))
        current=datetime.fromisoformat(timestamp)
        if current<datetime.fromisoformat(self.voter_response_history[-1]["timestamp"]):raise ValueError("Polling time cannot run backwards")
        configured=self.response_by_event_id.get(event_id)
        incoming=(resource_changes or {}).get("electorate_response")
        if configured is not None and incoming is not None:raise ValueError("Ambiguous duplicate response payload")
        response=deepcopy(incoming if incoming is not None else configured)
        if response and "by_action" in response:
            if action not in response["by_action"]:raise ValueError("Missing realized-action voter-response assumption")
            response=response["by_action"][action]
        if response:
            response={**response,"id":event_id,"date":current.date().isoformat()}
        candidate_events=self.realized_events+([response] if response else [])
        request={**self.base_request,"as_of":current.date().isoformat(),"events":candidate_events,
                 "response_assumptions_acknowledged":True}
        result=self.response_model.predict(request)
        before=dict(self._last_composition)
        self.response_model.settle_into_world(result,state,self.bindings,acknowledge_conditional_model=True)
        self.realized_events=candidate_events
        self._last_composition=self._composition(state)
        self.voter_response_history.append({"event_id":event_id,"timestamp":timestamp,
            "stage":"ELECTORATE_RESPONSE_BEFORE_MEASUREMENT","new_group_signal":response,
            "response_status":"EXPLICIT_CONDITIONAL_RESPONSE" if response else "NO_NEW_GROUP_RESPONSE_EVIDENCE",
            "node_delta_pp":{p:self._last_composition[p]-before[p] for p in PARTIES},"result":result})
        step=super().record(state,event_id=event_id,actor=actor,action=action,event_kind=event_kind,resource_changes=resource_changes)
        self._recorded_ids.add(event_id)
        return step

    def to_dict(self):
        payload=super().to_dict()
        payload["polling_plugin"]={"id":"hakoniwa.polling","version":"1.0.0",
            "pipeline":["event_and_narrative","group_perception_and_participation","coupled_party_choice",
                        "aggregate_world_support","fieldwork_measurement","publication_and_node_trace"],
            "contract":"Voter reaction precedes polling; polling never generates voter reaction",
            "voter_response_history":self.voter_response_history}
        return payload

    def export(self,output):
        from .reporting import render_payload
        output=Path(output); output.mkdir(parents=True,exist_ok=True)
        full=self.to_dict()
        compact={key:value for key,value in full.items() if key not in {"polling_plugin","composition_measurements"}}
        (output/"full_trace.json").write_text(json.dumps(full,ensure_ascii=False,indent=2,allow_nan=False)+"\n")
        (output/"report_trace.json").write_text(json.dumps(compact,ensure_ascii=False,allow_nan=False)+"\n")
        render_payload(compact,output/"report.html")
        return {"report":str(output/"report.html"),"full_trace":str(output/"full_trace.json")}
