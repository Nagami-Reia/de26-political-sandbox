"""Synthetic integration check, not a real political prediction. Uses original core."""
import argparse
from pathlib import Path

from ..service import PollingPlugin
from ..party_response import PARTIES
from ..tracker import PollSeriesSpec
from ....political_state import PoliticalState, StateVariable


def run(output):
    initial=dict(zip(PARTIES,(18,14,16,5,10,28,3,6)))
    world=PoliticalState({p:StateVariable(p,v) for p,v in initial.items()},{},{})
    specs=tuple(PollSeriesSpec(p,p,"electorate","vote_intention","DE") for p in PARTIES)
    plugin=PollingPlugin("polling-plugin-integration-demo","synthetic-not-real",specs,"2026-10-22T00:00:00+02:00",
        bindings={p:p for p in PARTIES},window_minutes=120,
        timestamp_by_event_id={"n1":"2026-10-22T01:00:00+02:00","n2":"2026-10-22T02:00:00+02:00","n3":"2026-10-22T04:00:00+02:00"})
    plugin.record_baseline(world)
    response={"evidence_status":"SIMULATION_ASSUMPTION","source_notes":["Artificial utility shock for pipeline verification only"],
        "group_changes":[{"selector":{"cohorts":["<=1955"]},"party_signals":{"Union":{"delta_competence":-.1}}}]}
    plugin.record(world,event_id="n1",actor="world",action="interpreted_news",event_kind="group_perception",
        resource_changes={"electorate_response":response})
    plugin.record(world,event_id="n2",actor="world",action="no_new_evidence",event_kind="decision")
    plugin.record(world,event_id="n3",actor="world",action="observation",event_kind="time_passed")
    return plugin.export(output)


if __name__ == "__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--output",type=Path,default=Path("outputs/polling_2026_10_22/node_stream_demo"))
    print(run(parser.parse_args().output))
