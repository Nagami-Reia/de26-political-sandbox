"""Narrative cognition becomes electorate signals, never prewritten poll points."""
import math
from .party_response import AXES, PARTIES, bounded


def legacy_support_effects(deltas,bindings,gains,cap):
    """Isolated compatibility mapping; not the calibrated electorate model."""
    effects={}
    for target,delta in deltas.items():
        variable=bindings.get(target)
        if variable is not None:
            change=delta*gains.get(target,0)
            effects[variable]=effects.get(variable,0)+max(-cap,min(cap,change))
    return effects


class NarrativeVoterBridge:
    def __init__(self,config):
        if config.get("status") != "SIMULATION_ASSUMPTION" or not config.get("rationale"):
            raise ValueError("Narrative-to-voter coefficients need an explicit assumption and rationale")
        if type(config.get("delay_minutes")) is not int or config["delay_minutes"]<1:
            raise ValueError("Positive perception/response delay required")
        if not config.get("audience_selectors") or not config.get("frame_party_signals"):
            raise ValueError("Explicit audience mapping and frame-to-party utility signals required")
        if config.get("overlap_policy") != "explicit_additive_assumption":
            raise ValueError("Declare how overlapping audiences are combined; do not imply an observed joint distribution")
        for frame,parties in config["frame_party_signals"].items():
            if set(parties)-set(PARTIES):raise ValueError("Unknown frame party")
            for p,signal in parties.items():
                if set(signal)-set(AXES):raise ValueError("Unknown utility dimension")
                for axis,value in signal.items():bounded(value,-1,1,frame+":"+p+":"+axis)
        self.config=config

    def build_event(self,outcome):
        changes=[]
        for audience in outcome.audience_results:
            selector=self.config["audience_selectors"].get(audience.audience)
            if selector is None:raise ValueError("Narrative audience has no electorate mapping: "+audience.audience)
            signals={}
            for frame,share in audience.frame_shares.items():
                for party,components in self.config["frame_party_signals"].get(frame,{}).items():
                    row=signals.setdefault(party,{})
                    for axis,value in components.items():row[axis]=row.get(axis,0)+share*audience.response_strength*value
            changes.append({"selector":selector,"party_signals":signals})
        return {"evidence_status":"SIMULATION_ASSUMPTION","source_notes":[self.config["rationale"],
            "Narrative interpretation and attention precede group utility; no fixed polling-point reward.",
            "Overlapping audience effects explicitly additive; not an observed demographic joint."],"group_changes":changes}
