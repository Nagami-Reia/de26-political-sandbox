"""Standalone plugin CLI; pure inference needs only Python's standard library."""
import argparse
from datetime import date
import json
from pathlib import Path

from .model import PollingModel, BlendedPublicationModel
from .party_response import PartyResponseModel, PARTIES
from .electorates import ElectorateAtlas, ROOT


def display(value):
    if isinstance(value,float):return round(value,3)
    if isinstance(value,dict):return {key:display(v) for key,v in value.items()}
    if isinstance(value,list):return [display(v) for v in value]
    return value


def main(argv=None):
    parser=argparse.ArgumentParser(prog="polling",description="Voter response → aggregate support → survey measurement. Not validated causal forecasting.")
    parser.add_argument("operation",choices=("verify","response","predict","electorate","crosstabs"))
    parser.add_argument("--request",type=Path)
    parser.add_argument("--party",choices=PARTIES)
    parser.add_argument("--state")
    parser.add_argument("--as-of")
    parser.add_argument("--experimental-parameters",type=Path)
    parser.add_argument("--pretty",action="store_true")
    parser.add_argument("--output",type=Path,help="write full-precision JSON without passing it through an LLM")
    args=parser.parse_args(argv)
    try:
        if args.operation == "verify": result=PollingModel().verify()
        elif args.operation in {"response","predict"}:
            if not args.request:raise ValueError("--request is required")
            request=json.loads(args.request.read_text())
            if args.operation == "response":
                model=PartyResponseModel(); result=model.functions()[args.party](request) if args.party else model.predict(request)
            else: result=(BlendedPublicationModel(args.experimental_parameters) if args.experimental_parameters else PollingModel()).predict(request)
        elif args.operation == "electorate":
            if not args.state or not args.as_of: raise ValueError("--state and --as-of are required")
            result=ElectorateAtlas().state(args.state,as_of=args.as_of)
        else:
            if not args.as_of:raise ValueError("--as-of is required")
            result=json.loads((ROOT/"yougov_2026_10.json").read_text())
            if date.fromisoformat(args.as_of)<date.fromisoformat(result["available_from"]):raise ValueError("Future source unavailable at cutoff")
        text=json.dumps(result,ensure_ascii=False,indent=2 if args.pretty else None,allow_nan=False)
        if args.output:
            args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(text+"\n")
            print(json.dumps({"saved":str(args.output)},ensure_ascii=False))
        else:print(json.dumps(display(result),ensure_ascii=False,indent=2 if args.pretty else None,allow_nan=False))
        return 0
    except (ValueError,KeyError,OSError) as exc:
        print(json.dumps({"error":str(exc)},ensure_ascii=False));return 2


if __name__ == "__main__":raise SystemExit(main())
