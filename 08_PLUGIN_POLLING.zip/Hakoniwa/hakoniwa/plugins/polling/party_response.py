"""Party-specific, coupled electorate response functions.

Each party has its own state × age × recorded-sex electorate and optional
response weights. All functions share one softmax denominator: no party can
gain support without another party losing conditional share. Response weights
are explicit assumptions until individual longitudinal evidence identifies them.
"""
from datetime import date
import json
import math
from pathlib import Path

from .electorates import ElectorateAtlas, ROOT, STATES
from .model import dynamic_choice, normalize

PARTIES=("Union","SPD","Grüne","FDP","Linke","AfD","BSW","Other")
AXES=("delta_distance","delta_competence","delta_leader","delta_tactical")
SELECTORS=("states","cohorts","sexes")


def bounded(value,lower,upper,name):
    value=float(value)
    if not math.isfinite(value) or not lower<=value<=upper:
        raise ValueError(f"{name} must be finite within {lower}..{upper}")
    return value


def rake_party_marginal(probabilities, weights, target, tolerance=1e-10):
    """Minimum-KL intercept calibration to ONE supplied national party margin.

    Conditional cell distributions remain model estimates; the calibration does
    not turn national polling into observed state or age-specific polling.
    """
    target=normalize(target); total=sum(weights)
    q=[list(row) for row in probabilities]
    for step in range(20000):
        margin=[sum(w*row[j] for w,row in zip(weights,q))/total for j in range(len(target))]
        if max(abs(a-b) for a,b in zip(margin,target)) < tolerance:
            return q,step
        if any(t>0 and p==0 for t,p in zip(target,margin)):
            raise ValueError("Target requires an unavailable party")
        ratio=[t/p if p else 0 for t,p in zip(target,margin)]
        q=[normalize([v*r for v,r in zip(row,ratio)]) for row in q]
    raise ValueError("National calibration did not converge")


class PartyResponseModel:
    def __init__(self,atlas=None):
        self.atlas=atlas or ElectorateAtlas()

    def _groups(self,as_of):
        groups=[]
        for state in STATES:
            region=self.atlas.state(state,as_of=as_of)
            for g in region["groups"]:
                if g["sex"] == "Summe" or g["cohort"] == "Summe": continue
                counts=[g["counts"][p] for p in PARTIES[:-1]]+[sum(g["counts"][p] or 0 for p in ("Other","Freie Wähler"))]
                if any(v is None for v in counts):
                    raise ValueError("Missing historical choice cell; cannot invent a party probability")
                groups.append({"id":f'{state}:{g["sex"]}:{g["cohort"]}',"state":state,"sex":g["sex"],
                    "cohort":g["cohort"],"age_at_2025_election":g["age_2025"],
                    "eligible_mass":g["eligible_weighted"],"turnout":g["turnout"],
                    "valid_ballot_probability":g["valid_votes_weighted"]/g["participants_weighted"],
                    "decided":1.0,"q":normalize(counts)})
        return groups

    def functions(self):
        return {p:PartyResponseFunction(self,p) for p in PARTIES}

    def predict(self,request):
        as_of=request["as_of"]; date.fromisoformat(as_of)
        if request.get("target","BUNDESTAG_VOTE_INTENTION") != "BUNDESTAG_VOTE_INTENTION":
            raise ValueError("These demographic anchors cannot be silently used as Landtag voting functions")
        groups=self._groups(as_of)
        baseline_q=[g["q"] for g in groups]
        baseline_weights=[g["eligible_mass"]*g["turnout"]*g["valid_ballot_probability"] for g in groups]
        calibration=request.get("calibration")
        calibration_note=None
        if calibration:
            if calibration == "yougov_2026_10":
                source=json.loads((ROOT/"yougov_2026_10.json").read_text())
                calibration={"source_id":source["source_id"],"available_from":source["available_from"],
                    "target":"BUNDESTAG_VOTE_INTENTION","party_percent":source["groups"]["total"]["support_percent"]}
            if calibration["target"] != "BUNDESTAG_VOTE_INTENTION" or date.fromisoformat(calibration["available_from"])>date.fromisoformat(as_of):
                raise ValueError("Wrong election target or future calibration source")
            if not calibration.get("source_id") or set(calibration["party_percent"]) != set(PARTIES):
                raise ValueError("Sourced complete national party composition required")
            baseline_q,iterations=rake_party_marginal(baseline_q,baseline_weights,[calibration["party_percent"][p] for p in PARTIES])
            calibration_note={"source_id":calibration["source_id"],"available_from":calibration["available_from"],"iterations":iterations,
                "target_as_printed_percent":calibration["party_percent"],
                "target_normalization":"complete supplied composition normalized once; integer poll rounding remains",
                "method":"minimum_KL_national_party_intercept_raking",
                "warning":"Derived state/cell estimates are NOT observed state/cell polling; 2025 population and turnout structure held fixed by assumption"}
        events=request.get("events",[])
        if events and request.get("response_assumptions_acknowledged") is not True:
            raise ValueError("Event response coefficients are not identified: explicitly acknowledge simulation assumptions")
        temperature=bounded(request.get("temperature",1),1e-6,1,"temperature")
        rules=request.get("party_weights",{})
        if set(rules)-set(PARTIES): raise ValueError("Unknown party weight key")
        weights={}
        for p in PARTIES:
            unknown=set(rules.get(p,{}))-set(AXES)
            if unknown: raise ValueError("Unknown response axis: "+repr(unknown))
            weights[p]={axis:bounded(rules.get(p,{}).get(axis,1),0,1,f"{p}:{axis}") for axis in AXES}
        deltas=[{p:{axis:0.0 for axis in AXES} for p in PARTIES} for _ in groups]
        turnout=[g["turnout"] for g in groups]; decided=[g["decided"] for g in groups]
        event_trace=[]; seen=set()
        for event in events:
            if not event.get("id") or event["id"] in seen: raise ValueError("Event IDs must be nonempty and unique; no repeated-event double counting")
            seen.add(event["id"])
            if event.get("evidence_status") != "SIMULATION_ASSUMPTION" or not event.get("source_notes"):
                raise ValueError("Group response assignments require SIMULATION_ASSUMPTION and source_notes")
            if event.get("date") and date.fromisoformat(event["date"])>date.fromisoformat(as_of):
                raise ValueError("Event lies after the requested simulation date")
            affected=set()
            for change in event.get("group_changes",[]):
                selector=change.get("selector",{})
                if set(selector)-set(SELECTORS): raise ValueError("Unsupported group selector; education and income joints are not identified")
                domains={"states":set(STATES),"cohorts":{g["cohort"] for g in groups},"sexes":{"m|d|o","w"}}
                for key,values in selector.items():
                    if not isinstance(values,list) or not values or not set(values).issubset(domains[key]):
                        raise ValueError("Unknown or empty selector values: "+key)
                signals=change.get("party_signals",{})
                if set(signals)-set(PARTIES): raise ValueError("Unknown party signal")
                for p,signal in signals.items():
                    if set(signal)-set(AXES): raise ValueError("Unknown utility axis")
                    for axis,v in signal.items(): bounded(v,-1,1,axis)
                dt=bounded(change.get("turnout_delta",0),-1,1,"turnout_delta")
                dd=bounded(change.get("decided_delta",0),-1,1,"decided_delta")
                matched=[]
                for i,g in enumerate(groups):
                    if any(g[field] not in selector[key] for key,field in (("states","state"),("cohorts","cohort"),("sexes","sex")) if key in selector): continue
                    matched.append(g["id"]); affected.add(g["id"])
                    # Reject unbounded probability inputs rather than silently clip them.
                    turnout[i]=bounded(turnout[i]+dt,0,1,"updated_turnout")
                    decided[i]=bounded(decided[i]+dd,0,1,"updated_decided")
                    for p,signal in signals.items():
                        for axis,v in signal.items(): deltas[i][p][axis]+=float(v)
                if not matched: raise ValueError("Group change matched no known cells")
            event_trace.append({"id":event["id"],"affected_groups":sorted(affected),"source_notes":event["source_notes"],
                "evidence_status":"SIMULATION_ASSUMPTION"})
        final_q=[]; utility_trace=[]
        for i,g in enumerate(groups):
            components=[[deltas[i][p][axis]*weights[p][axis] for p in PARTIES] for axis in AXES]
            final_q.append(dynamic_choice(baseline_q[i],*components,temperature=temperature))
            utility_trace.append({p:sum((-1 if axis=="delta_distance" else 1)*deltas[i][p][axis]*weights[p][axis] for axis in AXES)/temperature for p in PARTIES})
        after_weights=[g["eligible_mass"]*t*d*g["valid_ballot_probability"] for g,t,d in zip(groups,turnout,decided)]
        def aggregate(indices,cell_q,cell_weights):
            total=sum(cell_weights[i] for i in indices)
            if total<=0: raise ValueError("No decided valid participants in an electorate")
            return [100*sum(cell_weights[i]*cell_q[i][j] for i in indices)/total for j in range(len(PARTIES))]
        all_indices=list(range(len(groups)))
        national_before=aggregate(all_indices,baseline_q,baseline_weights)
        national_after=aggregate(all_indices,final_q,after_weights)
        states={}
        for state in STATES:
            ix=[i for i,g in enumerate(groups) if g["state"]==state]
            before,after=aggregate(ix,baseline_q,baseline_weights),aggregate(ix,final_q,after_weights)
            states[state]={"before_percent":dict(zip(PARTIES,before)),"after_percent":dict(zip(PARTIES,after)),
                           "delta_pp":{p:b-a for p,a,b in zip(PARTIES,before,after)},"status":"MODELLED_BUNDESTAG_INTENTION_WITHIN_STATE_NOT_LANDTAG_POLL"}
        party_results={}
        for j,p in enumerate(PARTIES):
            original_mass=sum(w*q[j] for w,q in zip(baseline_weights,baseline_q))
            shares=[w*q[j]/original_mass if original_mass else 0 for w,q in zip(baseline_weights,baseline_q)]
            age_mix={age:sum(s for s,g in zip(shares,groups) if g["cohort"]==age) for age in sorted({g["cohort"] for g in groups})}
            state_mix={state:sum(s for s,g in zip(shares,groups) if g["state"]==state) for state in STATES}
            # Local derivative wrt a uniform own-party competence shock at baseline.
            derivative=100*sum(w*q[j]*(1-q[j])*weights[p]["delta_competence"]/temperature for w,q in zip(baseline_weights,baseline_q))/sum(baseline_weights)
            party_results[p]={"function_id":"predict_"+{"Union":"union","SPD":"spd","Grüne":"gruene","FDP":"fdp","Linke":"linke","AfD":"afd","BSW":"bsw","Other":"other"}[p],
                "before_percent":national_before[j],"after_percent":national_after[j],"delta_pp":national_after[j]-national_before[j],
                "party_electorate_age_composition":age_mix,"party_electorate_state_composition":state_mix,
                "response_weights":weights[p],"local_own_competence_slope_pp_per_utility_unit":derivative,
                "slope_status":"mathematical_derivative_of_assumed_model_not_empirical_causal_elasticity",
                "states":{state:{key:states[state][key][p] for key in ("before_percent","after_percent","delta_pp")} for state in STATES}}
        result={"schema_version":"party-response-functions-1.0","as_of":as_of,"target":"BUNDESTAG_VOTE_INTENTION",
                "status":"CONDITIONAL_SIMULATION_PROJECTION_NOT_VALIDATED_EVENT_CAUSAL_FORECAST","party_order":list(PARTIES),
                "calibration":calibration_note,"parties":party_results,"states":states,"event_trace":event_trace,
                "normalization":"all parties jointly normalized within each group, then population/turnout/decided/valid-ballot weighted",
                "coefficient_status":"unit-scale neutral defaults or explicit user weights; NOT fitted party-specific causal coefficients",
                "fixed_structure_assumptions":["2025 eligible population/cohorts and valid-ballot rates retained","baseline decided probability 1.000 is bookkeeping, not measured current undecided rate",
                    "Other includes Freie Wähler; aggregate bucket has no single coherent political ideology","No income/education/region joint cells invented from marginal tables"],
                "population_accounting":{"eligible_mass":sum(g["eligible_mass"] for g in groups),
                    "nonparticipant_mass":sum(g["eligible_mass"]*(1-t) for g,t in zip(groups,turnout)),
                    "undecided_participant_mass":sum(g["eligible_mass"]*t*(1-d) for g,t,d in zip(groups,turnout,decided)),
                    "invalid_ballot_decided_mass":sum(g["eligible_mass"]*t*d*(1-g["valid_ballot_probability"]) for g,t,d in zip(groups,turnout,decided)),
                    "decided_valid_mass":sum(after_weights)},
                "world_state_mutated":False,"prediction_interval":None}
        if request.get("include_group_trace",False):
            result["group_trace"]=[{**{k:v for k,v in g.items() if k!="q"},"turnout_after":turnout[i],"decided_after":decided[i],
                "before_choice":dict(zip(PARTIES,baseline_q[i])),"after_choice":dict(zip(PARTIES,final_q[i])),"delta_utility":utility_trace[i],
                "before_valid_mass":baseline_weights[i],"after_valid_mass":after_weights[i]} for i,g in enumerate(groups)]
        return result

    @staticmethod
    def settle_into_world(result,state,bindings,*,acknowledge_conditional_model=False):
        """Explicit simulation-only bridge; never called during pure inference."""
        if acknowledge_conditional_model is not True:
            raise ValueError("Settlement requires explicit acknowledgement of conditional model assumptions")
        if set(bindings) != set(PARTIES) or len(set(bindings.values())) != len(PARTIES):
            raise ValueError("Complete one-to-one world binding required, including Other")
        if not set(bindings.values()).issubset(state.variables): raise ValueError("Unknown world polling variable")
        effects={bindings[p]:result["parties"][p]["after_percent"]-state.variables[bindings[p]].value for p in PARTIES}
        from ...political_state import PoliticalAction
        update=state.apply(PoliticalAction("conditional_party_response_settlement",{"immediate":effects}))
        update.update({"event":"conditional_party_response_settlement","evidence_status":"SIMULATION_ASSUMPTION",
            "as_of":result["as_of"],
            "model_schema":result["schema_version"],"source_events":[e["id"] for e in result["event_trace"]],"effects":effects,
            "note":"Explicit absolute composition settlement, not publication-model output or observed true support"})
        return effects


class PartyResponseFunction:
    def __init__(self,model,party):self.model,self.party=model,party
    def __call__(self,request):
        result=self.model.predict(request)
        return {"party":self.party,"status":result["status"],"as_of":result["as_of"],**result["parties"][self.party]}


def predict_union(request):return PartyResponseModel().functions()["Union"](request)
def predict_spd(request):return PartyResponseModel().functions()["SPD"](request)
def predict_gruene(request):return PartyResponseModel().functions()["Grüne"](request)
def predict_fdp(request):return PartyResponseModel().functions()["FDP"](request)
def predict_linke(request):return PartyResponseModel().functions()["Linke"](request)
def predict_afd(request):return PartyResponseModel().functions()["AfD"](request)
def predict_bsw(request):return PartyResponseModel().functions()["BSW"](request)
def predict_other(request):return PartyResponseModel().functions()["Other"](request)
