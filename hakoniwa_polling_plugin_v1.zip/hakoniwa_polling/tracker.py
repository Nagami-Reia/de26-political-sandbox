"""A model-nowcast snapshot after every decision and exogenous event.

This is not an instant survey.  The latent state and the pollster-like nowcast
are stored as separate series so a small political effect may be real inside
the model but invisible after retention and publication rounding.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from typing import Mapping

from ...decision_telemetry import DecisionTelemetry, SupportPoint
from ...political_state import PoliticalState
from .observation import FieldworkObserver


def round_grid(value: float, grid: float) -> float:
    units = Decimal(str(value)) / Decimal(str(grid))
    return float(units.quantize(Decimal("1"), rounding=ROUND_HALF_UP) * Decimal(str(grid)))


@dataclass(frozen=True)
class PollSeriesSpec:
    state_variable: str
    subject: str
    constituency: str
    measure: str
    scope: str
    retention: float = 1.0
    publication_grid: float = .5
    include_latent_series: bool = True

    def __post_init__(self) -> None:
        if not 0 <= self.retention <= 1:
            raise ValueError("retention must be within 0..1")
        if self.publication_grid <= 0:
            raise ValueError("publication_grid must be positive")


class RealtimePollingTracker:
    def __init__(
        self,
        run_id: str,
        environment_id: str,
        specs: tuple[PollSeriesSpec, ...],
        start_timestamp: str,
        timestamp_by_event_id: Mapping[str, str] | None = None,
        composition_groups: tuple[Mapping[str, object], ...] = (),
    ) -> None:
        self.telemetry = DecisionTelemetry(run_id, environment_id)
        self.specs = specs
        self.start = datetime.fromisoformat(start_timestamp)
        self.timestamp_by_event_id = dict(timestamp_by_event_id or {})
        self._latent_previous: dict[str, float] = {}
        self._nowcast_continuous: dict[str, float] = {}
        self._nowcast_previous: dict[str, float] = {}
        self._composition_groups = []
        self._composition_variables: set[str] = set()
        self._composition_snapshots: list[dict[str, object]] = []
        specs_by_key = {spec.state_variable: spec for spec in specs}
        if len(specs_by_key) != len(specs):
            raise ValueError("Duplicate polling series")
        for group in composition_groups:
            variables = tuple(group["variables"])
            if not set(variables).issubset(specs_by_key) or self._composition_variables.intersection(variables):
                raise ValueError("Composition variables must be disjoint existing polling series")
            dimensions = {(specs_by_key[v].constituency, specs_by_key[v].scope, specs_by_key[v].measure) for v in variables}
            if len(dimensions) != 1:
                raise ValueError("Cannot combine different electorates, scopes or measures into one composition")
            if group.get("complete_party_universe") is not True:
                raise ValueError("Explicitly declare a complete party universe including residual Other")
            observer = FieldworkObserver(variables, float(group.get("window_minutes",4320)),
                                          float(group.get("publication_grid",.5)))
            self._composition_groups.append((str(group["key"]), variables, observer))
            self._composition_variables.update(variables)

    def _observe_compositions(self, state, timestamp, event_id):
        values = {}
        for key, variables, observer in self._composition_groups:
            raw = [state.variables[v].value for v in variables]
            if abs(sum(raw)-100) > .05:
                raise ValueError("Complete party support must sum to 100%; partial series cannot form a composition")
            snapshot = observer.observe(timestamp, raw)
            self._composition_snapshots.append({"group":key,"event_id":event_id,**snapshot})
            values.update({v:(snapshot["latent_percent"][i],snapshot["published_model_percent"][i]) for i,v in enumerate(variables)})
        return values

    def _timestamp(self, step: int) -> str:
        return (self.start + timedelta(minutes=step)).isoformat()

    def record_baseline(self, state: PoliticalState) -> None:
        compositions = self._observe_compositions(state, self._timestamp(0), "baseline")
        for spec in self.specs:
            value = state.variables[spec.state_variable].value
            if spec.state_variable in compositions:
                value = compositions[spec.state_variable][0]
            self._latent_previous[spec.state_variable] = value
            self._nowcast_continuous[spec.state_variable] = value
            published = round_grid(value, spec.publication_grid)
            if spec.state_variable in compositions:
                published = compositions[spec.state_variable][1]
            self._nowcast_previous[spec.state_variable] = published
            if spec.include_latent_series:
                self.telemetry.record_support(SupportPoint(
                    step=0, timestamp=self._timestamp(0), event_id="baseline",
                    subject=spec.subject, constituency=spec.constituency,
                    measure=f"{spec.measure}_latent", scope=spec.scope,
                    value=value, unit="percent", evidence_status="MODEL_ESTIMATE",
                    note="latent model support before event sequence",
                ))
            self.telemetry.record_support(SupportPoint(
                step=0, timestamp=self._timestamp(0), event_id="baseline",
                subject=spec.subject, constituency=spec.constituency,
                measure=f"{spec.measure}_nowcast", scope=spec.scope,
                value=published, unit="percent", evidence_status="MODEL_ESTIMATE",
                note="compositional time-window measurement assumption" if spec.state_variable in compositions else "legacy scalar model baseline after publication rounding; not a calibrated pollster",
            ))

    def record(
        self,
        state: PoliticalState,
        *,
        event_id: str,
        actor: str,
        action: str,
        event_kind: str,
        resource_changes: Mapping[str, object] | None = None,
    ) -> int:
        timestamp = self.timestamp_by_event_id.get(
            event_id,
            self._timestamp(self.telemetry.next_step),
        )
        # Validate scenario-supplied calendar timestamps before recording them.
        datetime.fromisoformat(timestamp)
        compositions = self._observe_compositions(state, timestamp, event_id)
        step = self.telemetry.record_event(
            event_id=event_id,
            timestamp=timestamp,
            actor=actor,
            action=action,
            information_update={"event_kind": event_kind},
            resource_changes=resource_changes,
        )
        for spec in self.specs:
            current = state.variables[spec.state_variable].value
            previous_latent = self._latent_previous.get(spec.state_variable, current)
            previous_continuous = self._nowcast_continuous.get(spec.state_variable, previous_latent)
            retained_delta = (current - previous_latent) * spec.retention
            continuous_nowcast = previous_continuous + retained_delta
            nowcast = round_grid(continuous_nowcast, spec.publication_grid)
            if spec.state_variable in compositions:
                current, nowcast = compositions[spec.state_variable]
                continuous_nowcast = nowcast
            self._latent_previous[spec.state_variable] = current
            self._nowcast_continuous[spec.state_variable] = continuous_nowcast
            self._nowcast_previous[spec.state_variable] = nowcast
            if spec.include_latent_series:
                self.telemetry.record_support(SupportPoint(
                    step=step, timestamp=timestamp, event_id=event_id,
                    subject=spec.subject, constituency=spec.constituency,
                    measure=f"{spec.measure}_latent", scope=spec.scope,
                    value=current, unit="percent", evidence_status="MODEL_ESTIMATE",
                    note="latent state immediately after this event",
                ))
            self.telemetry.record_support(SupportPoint(
                step=step, timestamp=timestamp, event_id=event_id,
                subject=spec.subject, constituency=spec.constituency,
                measure=f"{spec.measure}_nowcast", scope=spec.scope,
                value=nowcast, unit="percent", evidence_status="MODEL_ESTIMATE",
                note="compositional calendar-time fieldwork assumption; no instant observed survey" if spec.state_variable in compositions else f"legacy scalar assumption: retention={spec.retention}; publication_grid={spec.publication_grid}; not empirically identified",
            ))
        return step

    def to_dict(self) -> dict[str, object]:
        payload = self.telemetry.to_dict()
        payload["polling_contract"] = {
            "frequency": "one snapshot after every recorded decision or event",
            "latent_series": "continuous model state, not a survey",
            "nowcast_series": "simulation measurement; legacy scalar retention or explicit compositional calendar-time fieldwork, not an observed release",
            "actual_poll_rule": "append separately as OBSERVED with a source_id when a real poll is published",
            "world_truth_contract": "publication estimates do not mutate world support; actual electorate response requires its own evidence/model",
            "composition_policy": "opt-in complete party universes only; legacy partial series remain scalar and are not claimed to sum to 100%",
        }
        payload["composition_measurements"] = list(self._composition_snapshots)
        return payload
