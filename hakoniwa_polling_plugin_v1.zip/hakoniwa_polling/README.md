# POLLING插件：先选民反应，再民调测量

正式目录为 `hakoniwa/plugins/polling/`；本文内部文件路径均相对此目录。实现、资料、校准、历史兼容模型和报告渲染集中在这里，旧`hakoniwa/polling/`、`realtime_polling.py`等只作转接，没有第二份引擎。原始校准包保存在 `data/calibration/polling_consolidated_v1/`，不改动其57项校验文件。原包说明中的“尚未整合”是冻结时的历史状态。

唯一顺序：**事件／叙事 → 选民分组认知与参与 → 党派选择 → 汇总支持率 → 调查窗与机构测量 → 每节点民调快照／折线图**。不是先生成民调再让选民服从结果。

独立压缩包解压后目录名为`hakoniwa_polling`，无Hakoniwa主体也能运行纯计算：

```bash
python3 -m hakoniwa_polling verify
python3 -m hakoniwa_polling response --request hakoniwa_polling/examples/party_response.json --party AfD --pretty
```

在原项目中则使用`python3 -m hakoniwa.plugins.polling ...`或原总CLI。纯预测和基本盘查询只用标准库；重新拟合需numpy，重提PDF表需pdfplumber。实时世界挂钩`PollingPlugin`需要Hakoniwa主体，不属于脱离主体的独立德国政治模拟器。

## 1. 各党支持率函数：按自己的选民结构计算，联合竞争

入口：`party_response.py`。分别提供：

|党派|函数|画像如何参与|
|---|---|---|
|CDU/CSU|`predict_union`|自身192个州×年龄×登记性别组的选择概率；拜仁对应CSU，其他州对应CDU|
|SPD|`predict_spd`|SPD自己的历史组内支持分布与当期全国边际校准|
|Grüne|`predict_gruene`|绿党自己的组内支持与选民构成，不复用Union的选民结构|
|FDP|`predict_fdp`|FDP自己的组内选择、参与与战术投票信号|
|Linke|`predict_linke`|左翼党自己的州别与年龄结构|
|AfD|`predict_afd`|AfD自己的结构与收到的评价信号；没有危机必跌规则|
|BSW|`predict_bsw`|独立BSW类别，不与Other重复计算|
|其他|`predict_other`|完整组成所需的剩余桶，含Freie Wähler；不是单一意识形态行动者|

这些不是8条互不相干的线性加分公式。每条函数有不同的基线、选民构成及可覆盖的党派反应权重，但必须在同一竞争分母下计算：

```text
ΔU[g,p] = (-βD[p]×ΔD[g,p]
            +βC[p]×ΔCompetence[g,p]
            +βL[p]×ΔLeader[g,p]
            +βT[p]×ΔTactical[g,p]) / temperature

q[g,p] = q0[g,p] × exp(ΔU[g,p])
         / Σk q0[g,k] × exp(ΔU[g,k])

mass[g] = N[g] × turnout[g] × decided[g] × valid_ballot_probability[g]

share[p] = Σg mass[g] × q[g,p] / Σg mass[g]
```

内部概率0–1；输出支持率0–100%，变化用百分点。接口显示保留三位小数，内部计算和回归参数不提前取整。

**区别来自党派自己的画像，不来自编造“AfD天生更冲动”等系数。** 同一老年群体事件对各党的作用不同，是因为该组的组内竞争及其在各党选民中的占比不同。函数还允许明确传入每党的四类权重，但目前默认1.000只是中性单位约定，**不是从现有材料识别出的党派因果参数**。响应温度同样未由这些数据识别。

`delta_distance`必须是距离相对基线的变化，不是再加一遍绝对亲和度。已有基础亲和度由`q0`表示，不重复计算。可由将来的经济／文化／制度信任距离模块提供`ΔD`，但当前没有把统计低秩维度命名成这些语义维度。

### 人群与事件

目前可直接使用有联合统计依据的选择器：州、2025出生年组、登记性别。可同时改变某组的投票参与率、明确党派选择率和各党的四种评价。事件可以影响不同党派、不同群体；相同效用变化加给所有党会抵消。空事件、仅有“战争／泄密”标签不会自动给政府加分。

全国教育、东西部和城乡画像已存入YouGov资料层，但不伪造“教育×州×年龄×性别”联合分布。因此暂不接受教育或收入联合选择器。需要微观调查或经过验证的分层估计才能扩展。

每个事件必须有唯一ID、`SIMULATION_ASSUMPTION`标记及依据说明。重复事件ID、未来事件、未知人群和越界概率会报错。多个已发生事件采用**相对同一基线的累计变化**，而非对上一次输出重复叠加。

### 基线更新

默认基线是2025联邦议会二票的代表性统计，不是2026即时民意。可显式选择`calibration: "yougov_2026_10"`，以完整全国党派边际做最小KL／迭代比例校准，使全国汇总吻合所选调查。

校准后各州与细胞结果是**由历史结构推导的模型估计**，不是YouGov州级实测值。它假设2025人口／参与结构仍适用，不能宣称已准确识别2026各州漂移。全国民调也不是世界真实支持率；采用它作世界基线本身是一项建模约定。

2025代表性统计可用日期为2025-06-23；YouGov采用保守可用日期2026-10-20，保留原站2026-10-19与DAWUM2026-10-20的日期差异。2026-07-31历史环境不会自动加载后者。

### 运行

从项目根目录：

```bash
python3 -m hakoniwa polling response --request hakoniwa/plugins/polling/examples/party_response.json --pretty
python3 -m hakoniwa.plugins.polling response --request hakoniwa/plugins/polling/examples/party_response.json --party AfD --pretty
```

示例中的改革与效用信号完全虚构，仅为接口检验，不是一次实际政治预测。`include_group_trace`默认关闭；需要逐组审计时打开。

Python接口：

```python
from hakoniwa.plugins.polling import PartyResponseModel, predict_afd

model = PartyResponseModel()
all_parties = model.predict(request)       # 一次计算，八党与16州共同归一
afd = predict_afd(request)                 # 同一联合模型中只提取AfD
```

纯计算不修改世界。只有显式调用`settle_into_world(..., acknowledge_conditional_model=True)`并给出八类党派的完整一对一变量映射，才把条件性结果结算进原`PoliticalState`；它设置完整绝对组成，不把增量重复叠加。随后仍由原`RealtimePollingTracker`记录时间序列。没有完整Other桶的旧场景不会被偷偷改造成完整选举组成。

## 2. 发布民调预测：另一种目标，不反向改写真正民意

`model.py`的`PollingModel`复现原包全国／州级已拟合参数。它预测的是**下一次某机构发布值**，不是政策导致的真实民意变化。`BlendedPublicationModel`可显式加载新验证选择的研究混合参数；未设为全局默认。

```bash
python3 -m hakoniwa polling verify --pretty
python3 -m hakoniwa polling predict --request hakoniwa/plugins/polling/data/calibration/polling_consolidated_v1/examples/national_long.json --pretty
python3 -m hakoniwa.plugins.polling.benchmark --output outputs/polling_2026_10_22/benchmark
```

混合参数另需显式提供`previous_series_date`、`previous_series_percent`、目标日期和严格早于目标的预测因子日期。超过120天或不存在的同系列前值以当时共识替代。拟合到2025年底的参数不能用于冒充2025年及以前的样本外预测。

2026留出集已经随用户包给出并被查看，因此本次只是**复用滚动留出**；不能再称为新的盲测。新候选只按2026之前的验证期选择。全国长期与含BSW模型不能横向比较误差大小，因为覆盖年份、党派桶和保留样本不同。

目前未识别／验证：因果事件响应、机构真实个体权重、可校准的开放循环长期预测区间，以及画像权重所暗示的因果弹性。这里没有把研究误差当成每个模拟事件的随机涨跌幅。

## 3. 模拟中的民调测量

`observation.py`提供可选的完整组成、日历时间调查窗平均与总和保持100%的发布取整。它只观察世界轨迹。没有每增加一个决策节点就多“调查”一次的事件计数偏差。

原`RealtimePollingTracker`已接入此选项，`living_world_config.py`也读取：

```json
{
  "polling_observation": {
    "composition_groups": [{
      "key": "DE_full_vote_intention",
      "variables": ["union", "spd", "gruene", "fdp", "linke", "afd", "bsw", "other"],
      "complete_party_universe": true,
      "window_minutes": 4320,
      "publication_grid": 0.5
    }]
  }
}
```

变量名必须与场景的`poll_variables`及世界变量一致，合计100%，同一选民总体／地区／测量口径；仅有Union和AfD两条线的场景不能宣称构成完整民调。均匀72小时窗是可调整的测量假设，不是声称复刻INSA或YouGov内部算法。

初始调查窗缺历史时报告覆盖率，不编造过去数据。每次事件仍有测量快照，但快照不是每次都真的进行了一次问卷。旧标量保留率仅作为兼容行为，现明确标成未经识别的旧假设。

## 数据与可追溯性

- `data/electorates/atlas_2025.json`：16州、144个州×党派概要、192个非重叠州×年龄×登记性别细胞；另有全国合计与边际行。
- `data/electorates/yougov_2026_10.json`：全国25列交叉表、原始分母、空值、日期和方法。
- 原始官方CSV、用户PDF保存在`data/electorates/raw/`；所有来源保留哈希。没有改动同步`sources/`。
- `python3 -m hakoniwa.plugins.polling.electorates`重建官方画像；`python3 -m hakoniwa.plugins.polling.yougov`重建经校验的PDF表（需pdfplumber）。预测接口不需要numpy；重新拟合／验证需要numpy。

代表性选举统计是实际投票的分层抽样与校准扩展计数，不是把约5,000万扩展选票当成5,000万个独立受访者。不能据其扩展量计算虚假的极窄误差条。m|d|o不等于纯男性。BSW与Freie Wähler从Sonstige中拆出，不重复相加。地区收入／失业等相关性仅是选区层关联，收入实际年份为2021，不能称作个人收入投票因果。

主要来源：[官方代表性统计](https://www.bundeswahlleiterin.de/bundestagswahlen/2025/ergebnisse/repraesentative-wahlstatistik.html)、[官方方法及发布日期](https://www.bundeswahlleiterin.de/info/presse/mitteilungen/bundestagswahl-2025/30_25_ergebnisse-rws.html)、[选区结构数据](https://www.bundeswahlleiterin.de/bundestagswahlen/2025/strukturdaten.html)、[YouGov原始交叉表](https://ygo-assets-websites-editorial-emea.yougov.net/documents/YouGov_Sonntagsfrage_Oktober_2026.pdf)。

## 接入正常事件节点：推荐接口

`PollingPlugin`实现现有`event_observers`接口，不需要重写人物、制度或时钟引擎。`record_baseline`先建立选民基线；每次`record`顺序固定为：

1. 读取本节点已经发生的群体认知／参与变化；没有新证据就不强迫改变偏好。
2. 与此前已实现事件一起计算各党相对同一基线的累计选择，结算完整支持率。
3. 调查时间窗观察新轨迹，生成仿真发布值。
4. 记录本节点的潜在支持率、测量值、来源及响应审计。

`resource_changes["electorate_response"]`可携带一个`examples/party_response.json`中事件格式的对象。也可以在`response_by_event_id`事先配置节点对应的人群响应假设，或用`by_action`区分实际所选行动。它不是把行动直接换成固定百分点。

Living World配置：

```json
{
  "poll_variables": ["Union", "SPD", "Grüne", "FDP", "Linke", "AfD", "BSW", "Other"],
  "polling_plugin": {
    "enabled": true,
    "bindings": {"Union":"Union", "SPD":"SPD", "Grüne":"Grüne", "FDP":"FDP", "Linke":"Linke", "AfD":"AfD", "BSW":"BSW", "Other":"Other"},
    "window_minutes": 4320,
    "publication_grid": 0.5,
    "response_by_event_id": {}
  }
}
```

八个世界变量须在`variables`中存在并合计100%。默认把场景初始完整组成作为已声明的模拟基线，通过2025画像分解；不会偷偷把2025结果或YouGov结果覆盖进去。需要YouGov校准时显式提供`response_request.calibration`，且模拟日期须晚于证据可用时间。

媒体桥接使用`media.voter_response_bridge`而不是旧`media.opinion_response`：

```json
{
  "status": "SIMULATION_ASSUMPTION",
  "rationale": "需说明为什么此受众接受这种叙事后产生这些评价变化；系数尚未实证识别",
  "delay_minutes": 60,
  "overlap_policy": "explicit_additive_assumption",
  "audience_selectors": {"older_voters": {"cohorts":["<=1955"]}},
  "frame_party_signals": {"competence_failure":{"Union":{"delta_competence":-0.050}}}
}
```

受众、叙事名称须对应当前媒体场景。实际传入的群体评价变化按**该受众采纳份额×响应强度×显式评价系数**生成；不是全体选民自动接受标题。重叠受众相加是显式假设，不冒充已知联合分布。媒体服务只负责路由和延迟，转换逻辑归此插件。

新插件模式中，脚本直接修改党派变量、叠加旧标量响应或重复记录同一节点都会报错。旧场景的手写民调增量没有被当作已校准规律带入；它们仍是兼容场景，切换新模式前须提供完整党派与群体信号。

`plugin.export(output)`自动输出：

- `full_trace.json`：选民反应、各党函数、事件依据和测量的完整审计。
- `report_trace.json`：仅图表需要的紧凑数据。
- `report.html`：确定性第一象限折线图；不消耗LLM逐节点画图或解释的token。

原Living World整场报告仍自动包含全部使用人物的PSS折线图及民调折线图；本插件只拥有民调，不接管人物压力。

接口演示（纯虚构冲击，不是政治预测）：

```bash
python3 -m hakoniwa.plugins.polling.examples.node_stream_demo
python3 -m hakoniwa.plugins.polling.build_package --output downloads/hakoniwa_polling_plugin_v1.zip
```

原始资料版权与数据许可分别保留，见`plugin.json`与冻结资料的来源说明；本插件没有把YouGov材料重新授权为开源数据。
