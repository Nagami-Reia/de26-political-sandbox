# 2024 K-Frage blind replay

This scenario tests the current Hakoniwa persona/PSS, institutional-perception,
dual-rationality and party-interest layers against the September 2024 CDU/CSU
candidate-selection sequence.

It is not the legacy mechanism replay. The runner removes K-Frage outcome memories,
2026 memories and post-outcome relationships from the current cards before making
any decision. The observed sequence exists only in a post-run comparator.

ARCANA is neither initialized nor called.

```bash
python3 -m hakoniwa.scenarios.kfrage_2024_blind_replay.run_scenario \
  --runs 1000 --output outputs/kfrage-2024-channels-v1
```

The report includes every considered action, PSS pressure tracks, a model polling
nowcast, sensitivity runs and perturbation path shares. Those shares are not
real-world probabilities.

Version 1.1 separates execution, political success expectation and information
confidence. Keep the original 1.0 output frozen. A checkpoint match is not an
independent validation of the personas; organisational response, information
delivery and the legacy polling projection remain unresolved in this fixture.
See `hakoniwa/docs/ACTION_CHANNELS_CN.md` for the channel contract and legacy paths.

