# Source and assumption boundary

The observed resource snapshot is inherited from `hakoniwa/legacy/environment.json`
and its companion `assumptions.json` / `docs/source_notes.md` material.

Observed or directly institution-derived inputs include the CDU-chair and fraction
default, Wüst's NRW base, Söder's CSU apparatus, the absence of an automatic legal
nomination rule, and the publicly stated concern with avoiding a repeat of 2021.

Numerical resource normalization, supporting-actor resource values, perception
access, action effects, closure threshold and institutional-logic weights are model
assumptions. The report retains them as diagnostics. No decision rule reads the
September 16/17 outcome comparator.

