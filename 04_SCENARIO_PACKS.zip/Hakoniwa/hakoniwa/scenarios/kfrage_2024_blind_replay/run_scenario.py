#!/usr/bin/env python3
"""Blind retrospective validation of the current engine against the 2024 K-Frage.

The observed September 16/17 sequence is isolated in ``OBSERVED_COMPARATOR`` and
is read only after a run has finished.  Choice code never receives that object.
ARCANA is deliberately absent.
"""
from __future__ import annotations

import argparse
import copy
import json
import math
import random
import tempfile
from collections import Counter
from dataclasses import asdict, dataclass, field
from html import escape
from pathlib import Path
from typing import Mapping, Sequence

from ...action_perception import ActionPerceptionFilter
from ...action_repertoire import ActionRepertoireFilter
from ...institutional_logic import InstitutionalLogic
from ...institutional_matrix import InstitutionalMatrix
from ...party_interest import PartyInterestEngine, PartyInterestProfile, PartyState
from ...persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine, WorldEvent
from ...political_agency import AgencyHorizon
from ...rationality_evaluation import ActorRationalityProfile, RationalityEvaluator
from ...organizational_response import (
    OrganizationalBloc, PoliticalOrganization, OrganizationalRequest, OrganizationalResponseEngine,
)


ROOT = Path(__file__).resolve().parents[2]
CARDS = ROOT / "data" / "personas" / "cards_pss.json"
RATIONALITY = ROOT / "data" / "personas" / "rationality_profiles_v3.json"
LEGACY_ENVIRONMENT = ROOT / "legacy" / "environment.json"
ACTORS = ("Merz", "Soeder", "Rhein", "Guenther", "Wuest", "Frei", "Linnemann")
PRIMARY = ("Merz", "Wuest", "Soeder")
PRE_CUTOFF_MEMORY_ALLOWLIST = {
    "2010_resignation", "2021_union_candidate_conflict", "hessian_coalition_switch",
}


OBSERVED_COMPARATOR = {
    "merz_opening": "hold_default_and_bilateral_channels",
    "soeder_opening": "signal_conditional_availability",
    "wuest_choice": "withdraw_and_endorse_merz",
    "nrw_alignment": "Merz",
    "soeder_final": "bilateral_close_for_merz",
    "closure_candidate": "Merz",
    "fraktion_alignment": "Merz",
    "csu_alignment": "Joint_Merz",
}


@dataclass(frozen=True)
class Scenario:
    name: str = "baseline"
    seed: int = 20240901
    perception_sigma: float = 0.000
    contingency_sigma: float = 0.000
    merz_default_multiplier: float = 1.000
    soeder_bridgehead_bonus: float = 0.000
    fraktion_merz_shift: float = 0.000
    wuest_process_control_multiplier: float = 1.000


@dataclass
class World:
    values: dict[str, float]
    alignments: dict[str, str]
    flags: dict[str, bool]
    history: list[dict] = field(default_factory=list)

    def update(self, action: str, effects: Mapping[str, float]) -> dict:
        before = dict(self.values)
        for key, delta in effects.items():
            self.values[key] = max(0.000, min(1.000, self.values.get(key, 0.500) + float(delta)))
        row = {
            "action": action,
            "before": {key: round(value, 3) for key, value in before.items()},
            "after": {key: round(value, 3) for key, value in self.values.items()},
            "effects": {key: round(value, 3) for key, value in effects.items()},
        }
        self.history.append(row)
        return row


def _historical_resources(environment: Mapping[str, object]) -> dict[str, dict[str, float]]:
    rows: dict[str, dict[str, float]] = {}
    for actor, raw in environment["actors"].items():
        rows[actor] = {
            "formal_power": raw["formal_office_default"],
            "organization_base": max(raw["landesverband_hausmacht"], raw["party_apparatus"]),
            "parliamentary_base": raw["fraktion"],
            "network_capital": raw["union_acceptability"],
            "public_capital": raw["public_visibility"],
            "future_option": raw["future_option_value"],
        }
    rows.update({
        "Frei": {"formal_power": .410, "organization_base": .700, "parliamentary_base": .760,
                 "network_capital": .700, "public_capital": .390, "future_option": .520},
        "Linnemann": {"formal_power": .620, "organization_base": .780, "parliamentary_base": .540,
                      "network_capital": .720, "public_capital": .650, "future_option": .690},
        "Guenther": {"formal_power": .760, "organization_base": .670, "parliamentary_base": .480,
                     "network_capital": .740, "public_capital": .650, "future_option": .700},
        "Rhein": {"formal_power": .760, "organization_base": .680, "parliamentary_base": .500,
                  "network_capital": .700, "public_capital": .610, "future_option": .650},
    })
    return rows


def _sanitized_engine(resources: Mapping[str, Mapping[str, float]], scenario: Scenario) -> tuple[FreeAgentDecisionEngine, dict]:
    raw = json.loads(CARDS.read_text(encoding="utf-8"))
    removed: dict[str, list[str]] = {}
    clean = {"schema_version": raw["schema_version"], "actors": {}}
    for actor in ACTORS:
        row = copy.deepcopy(raw["actors"][actor])
        memories = row.get("event_memory", [])
        kept, cut = [], []
        for memory in memories:
            event_id = memory.get("event_id", "")
            if event_id in PRE_CUTOFF_MEMORY_ALLOWLIST:
                kept.append(memory)
            else:
                cut.append(event_id)
        removed[actor] = cut
        row["event_memory"] = kept
        row["initial_resources"] = dict(resources[actor])
        row["initial_current_state"] = {
            "energy": .800, "pressure": .280, "confidence": .740,
            "control": .700, "identity_integrity": .900,
        }
        if actor == "Wuest" and scenario.wuest_process_control_multiplier != 1.0:
            controls = row["decision_parameters"]["control_preferences"]
            controls["process"] = round(controls.get("process", .5) * scenario.wuest_process_control_multiplier, 3)
            controls["coalition"] = round(controls.get("coalition", .5) * scenario.wuest_process_control_multiplier, 3)
        neutral_relationships = {}
        for counterpart in row.get("relationship_memory", {}):
            neutral_relationships[counterpart] = {
                "trust": .500, "operational_reliability": .500,
                "dependency": {"organizational": .500, "informational": .500,
                               "electoral": .500, "personal_trust": .500},
                "alternative_capacity": {"organizational": .500, "informational": .500,
                                         "electoral": .500},
                "leverage": .500,
            }
        row["relationship_memory"] = neutral_relationships
        clean["actors"][actor] = row
    with tempfile.NamedTemporaryFile("w", suffix=".json", encoding="utf-8") as handle:
        json.dump(clean, handle, ensure_ascii=False)
        handle.flush()
        engine = FreeAgentDecisionEngine.from_json(handle.name)
    audit = {
        "cutoff": "2024-08-31",
        "removed_outcome_or_future_memories": removed,
        "retained_memory_ids": {
            actor: [memory.get("event_id", "") for memory in clean["actors"][actor].get("event_memory", [])]
            for actor in ACTORS
        },
        "relationships": "neutralized_to_0.500_to_remove_post_outcome_leakage",
        "dynamic_pss": "common_precontest_state; fixed profiles preserved",
        "resource_source": "legacy/environment.json 2024 snapshot plus explicit supporting-actor assumptions",
    }
    return engine, audit


def _rationality_profiles() -> dict[str, ActorRationalityProfile]:
    raw = json.loads(RATIONALITY.read_text(encoding="utf-8"))
    return {actor: ActorRationalityProfile(**row) for actor, row in raw["actors"].items()}


def _party_engine() -> PartyInterestEngine:
    profile = PartyInterestProfile(
        party_id="UNION_2024",
        label="CDU/CSU 2024 candidate-selection common interest",
        stable_interests={"organizational_unity": 1.000, "electoral_readiness": .900,
                          "leadership_legibility": .820},
        policy_positions={}, issue_salience={},
        strategic_interests={"party_unity": 1.000, "candidate_viability": .900,
                             "avoid_2021_repeat": .950, "procedural_legitimacy": .780},
        organizational_interests={"internal_cohesion": 1.000, "leadership_continuity": .760,
                                  "electoral_viability": .900, "information_control": .680},
        default_state=PartyState(cohesion=.720, electoral_pressure=.760,
                                 government_responsibility=0.000, narrative_control=.570),
        evidence_confidence=.720,
        source_ids=("K24_UNITY_NORM", "K24_AUTUMN_TIMING", "K24_2021_MEMORY"),
        epistemic_note="Scenario-specific organizational overlay; no post-September outcome is encoded.",
    )
    return PartyInterestEngine({"UNION_2024": profile})


def _logic() -> InstitutionalLogic:
    return InstitutionalLogic(
        logic_id="union_candidate_selection_autumn_2024",
        governability_priority=.780, electoral_survival_priority=.760,
        organizational_unity_priority=.900, fiscal_efficiency_priority=0.000,
        necessity_claim_strength=.610, alternative_legibility=.760,
        metric_dominance=.300, deviation_career_cost=.580,
        legitimacy=.740, control_concentration=.520,
        epistemic_status="MIXED_OBSERVED_NORM_AND_MODEL_ASSUMPTION",
    )


def _matrix() -> InstitutionalMatrix:
    offices = {
        "Merz": ("CDU_CHAIR", "FRACTION_CHAIR"), "Soeder": ("CSU_CHAIR", "BAVARIA_MP"),
        "Wuest": ("NRW_CDU_CHAIR", "NRW_MP"), "Frei": ("FRACTION_OPERATOR",),
        "Linnemann": ("CDU_GENERAL_SECRETARY",), "Guenther": ("SH_MP",), "Rhein": ("HE_MP",),
    }
    permissions = {office: ("signal", "consult", "endorse", "organize") for rows in offices.values() for office in rows}
    return InstitutionalMatrix("kfrage_2024_roles", offices, permissions)


AGENCY = {
    "Merz": AgencyHorizon(.920, .860, .790, .850, "MODEL_ASSUMPTION_FROM_OFFICE_DEFAULT"),
    "Wuest": AgencyHorizon(.840, .620, .580, .900, "MODEL_ASSUMPTION_FROM_NRW_BASE"),
    "Soeder": AgencyHorizon(.820, .570, .430, .610, "MODEL_ASSUMPTION_LIMITED_CDU_CARRIER"),
    "Frei": AgencyHorizon(.520, .610, .700, .800),
    "Linnemann": AgencyHorizon(.570, .650, .700, .780),
    "Guenther": AgencyHorizon(.610, .600, .650, .700),
    "Rhein": AgencyHorizon(.580, .580, .620, .680),
}


def _initial_world(environment: Mapping[str, object], scenario: Scenario) -> World:
    actors = environment["actors"]
    merz_default = actors["Merz"]["formal_office_default"] * scenario.merz_default_multiplier
    return World(
        values={
            "merz_viability": min(1.0, .42 * merz_default + .28 * actors["Merz"]["fraktion"] + .30 * actors["Merz"]["union_acceptability"]),
            "wuest_viability": .26 * actors["Wuest"]["formal_office_default"] + .34 * actors["Wuest"]["landesverband_hausmacht"] + .40 * actors["Wuest"]["union_acceptability"],
            "soeder_viability": .22 * actors["Soeder"]["formal_office_default"] + .31 * actors["Soeder"]["party_apparatus"] + .25 * actors["Soeder"]["public_visibility"] + .22 * actors["Soeder"]["union_acceptability"],
            "soeder_cdu_bridgehead": min(1.0, environment["global_constraints"]["cdu_bridgehead_soeder"] + scenario.soeder_bridgehead_bonus),
            "merz_fraktion": max(0.0, min(1.0, environment["nodes"]["Bundestagsfraktion"]["signal_strength"] + scenario.fraktion_merz_shift)),
            "union_unity": .650,
            "closure_clarity": .180,
            "public_conflict": .180,
            "merz_cdu_elite": .560,
            "wuest_cdu_elite": .430,
            "soeder_cdu_elite": .240,
        },
        alignments={"NRW_CDU": "Wuest", "Bundestagsfraktion": environment["nodes"]["Bundestagsfraktion"]["alignment"],
                    "CSU_apparatus": "Soeder"},
        flags={"wuest_active": True, "soeder_conceded": False, "merz_conceded": False},
    )


def _q(value: float) -> float:
    return round(max(0.000, min(1.000, value)), 3)


def _option(key: str, *, values: Mapping[str, float], goals: Mapping[str, float], upside: float,
            downside: float, uncertainty: float, effort: float, visibility: float,
            feasibility: float, strategy: str, identity: Sequence[str], risks: Sequence[str] = (),
            control: Sequence[str] = (), restores: float = .300, deviation: float = .000,
            instrumental: Mapping[str, float] = {}, substantive: Mapping[str, float] = {},
            party: Mapping[str, float] = {}, party_strategy: Mapping[str, float] = {},
            organization: Mapping[str, float] = {}, required: Mapping[str, float] = {}) -> ActionOption:
    return ActionOption(
        key=key, goal_impacts=goals, value_impacts=values,
        required_resources=required, upside=upside, downside=downside,
        uncertainty=uncertainty, irreversibility=min(1.0, visibility * .75),
        effort=effort, visibility=visibility, information_confidence=1.0 - uncertainty,
        control_domains=tuple(control), restores_control=restores,
        conflict_strategy=strategy, identity_tags=tuple(identity),
        event_tags=("candidate_selection", "union_internal"), risk_tags=tuple(risks),
        objective_feasibility=_q(feasibility), instrumental_impacts=instrumental,
        # These options are statements/consultations/organisational attempts,
        # not completed nominations. Physical availability is an explicit lab
        # assumption; the original feasibility input describes political odds.
        execution_feasibility=1.000,
        political_success_expectation=_q(feasibility),
        substantive_impacts=substantive, institutional_deviation=deviation,
        necessity_frame_alignment=max(0.0, party_strategy.get("avoid_2021_repeat", 0.0)),
        organizational_carrier_requirements=required,
        party_interest_impacts=party, party_strategy_impacts=party_strategy,
        organizational_impacts=organization,
    )


def _menus(stage: str, actor: str, w: Mapping[str, float]) -> tuple[ActionOption, ...]:
    unity, clarity = w["union_unity"], w["closure_clarity"]
    m, u, s = w["merz_viability"], w["wuest_viability"], w["soeder_viability"]
    bridge, frac = w["soeder_cdu_bridgehead"], w["merz_fraktion"]
    common = {"organizational_unity": .600, "electoral_readiness": .520, "leadership_legibility": .550}
    if stage == "merz_opening":
        return (
            _option("declare_candidacy_publicly", values={"strategic_direction": .88, "political_authority": .82, "unity": -.34}, goals={"secure_candidacy": .80}, upside=.82, downside=.62, uncertainty=.28, effort=.54, visibility=.96, feasibility=.62+.25*m, strategy="attack", identity=("agency","authority","strategic_direction"), risks=("irreversible",), control=("direction",), deviation=.18, instrumental={"candidate_control": .66,"unity": -.28}, substantive={"agency": .82,"future_options": -.35}, party=common, party_strategy={"party_unity": -.38,"candidate_viability": .62,"avoid_2021_repeat": -.32}, organization={"internal_cohesion": -.35,"leadership_continuity": .42}),
            _option("open_structured_consultations", values={"strategic_direction": .48, "political_authority": .38, "unity": .68}, goals={"secure_candidacy": .42}, upside=.52, downside=.24, uncertainty=.34, effort=.48, visibility=.42, feasibility=.78, strategy="institutionalize", identity=("organization","unity"), control=("organization","process"), instrumental={"candidate_control": .38,"unity": .67}, substantive={"agency": .35,"future_options": .52}, party=common, party_strategy={"party_unity": .68,"candidate_viability": .20,"avoid_2021_repeat": .74}, organization={"internal_cohesion": .62,"leadership_continuity": .25}),
            _option("hold_default_and_bilateral_channels", values={"strategic_direction": .76, "political_authority": .72, "unity": .54}, goals={"secure_candidacy": .67}, upside=.64, downside=.22, uncertainty=.30, effort=.35, visibility=.22, feasibility=.68+.24*m, strategy="negotiate", identity=("agency","strategic_direction","institutionalize"), risks=("reversible",), control=("direction","organization"), instrumental={"candidate_control": .72,"unity": .52}, substantive={"agency": .72,"future_options": .66}, party=common, party_strategy={"party_unity": .55,"candidate_viability": .68,"avoid_2021_repeat": .72}, organization={"internal_cohesion": .48,"leadership_continuity": .76}),
        )
    if stage == "soeder_opening":
        return (
            _option("demand_formal_union_ballot", values={"csu_relevance": .86,"bavarian_control": .54,"personal_option": .72,"union_unity": -.62}, goals={"preserve_option": .72}, upside=.84, downside=.78, uncertainty=.44, effort=.65, visibility=.96, feasibility=.34+.42*bridge, strategy="attack", identity=("relevance","public_signal","apparatus"), risks=("irreversible","certain_defeat"), control=("agenda","visibility"), deviation=.58, instrumental={"candidacy_access": .44,"unity": -.70}, substantive={"csu_voice": .88,"future_options": -.26}, party=common, party_strategy={"party_unity": -.72,"candidate_viability": .12,"avoid_2021_repeat": -.88}, organization={"internal_cohesion": -.62,"electoral_viability": -.25}),
            _option("stay_quiet_and_preserve_option", values={"csu_relevance": .26,"bavarian_control": .52,"personal_option": .66,"union_unity": .62}, goals={"preserve_option": .58}, upside=.38, downside=.24, uncertainty=.32, effort=.16, visibility=.08, feasibility=.92, strategy="avoid", identity=("option_value","bavaria"), risks=("reversible",), control=("apparatus",), instrumental={"candidacy_access": .08,"unity": .64}, substantive={"csu_voice": .18,"future_options": .72}, party=common, party_strategy={"party_unity": .64,"candidate_viability": -.12,"avoid_2021_repeat": .70}, organization={"internal_cohesion": .55,"electoral_viability": .10}),
            _option("signal_conditional_availability", values={"csu_relevance": .88,"bavarian_control": .68,"personal_option": .91,"union_unity": .18}, goals={"preserve_option": .90}, upside=.76, downside=.40, uncertainty=.36, effort=.40, visibility=.82, feasibility=.69+.20*s, strategy="reframe", identity=("relevance","visibility","option_value","public_signal"), risks=("reversible","public_signal"), control=("agenda","visibility","apparatus"), restores=.55, deviation=.24, instrumental={"candidacy_access": .62,"unity": .12}, substantive={"csu_voice": .85,"future_options": .86}, party=common, party_strategy={"party_unity": .12,"candidate_viability": .44,"avoid_2021_repeat": .20}, organization={"internal_cohesion": .18,"electoral_viability": .32,"information_control": .52}),
        )
    if stage in {"rhein_signal", "guenther_signal"}:
        consensus_values = ({"governable_majority": .74,"state_delivery": .56,"electoral_mandate": .48,"ideological_continuity": .28} if actor == "Rhein" else {"working_majority": .78,"democratic_norms": .62,"social_cohesion": .74,"party_advantage": .20})
        return (
            _option("invite_open_candidate_comparison", values={**consensus_values, next(iter(consensus_values)): .28}, goals={"reduce_disorder": .18}, upside=.48, downside=.58, uncertainty=.48, effort=.44, visibility=.66, feasibility=.72, strategy="negotiate", identity=("pluralism","consensus"), risks=("coalition_disorder",), control=("coalition","consensus_space"), deviation=.32, instrumental={"legibility": .42,"unity": -.25}, substantive={"fair_process": .72,"governability": .05}, party=common, party_strategy={"party_unity": -.30,"candidate_viability": .12,"procedural_legitimacy": .72,"avoid_2021_repeat": -.20}, organization={"internal_cohesion": -.22,"electoral_viability": -.05}),
            _option("remain_publicly_uncommitted", values=consensus_values, goals={"reduce_disorder": .46}, upside=.36, downside=.20, uncertainty=.28, effort=.15, visibility=.10, feasibility=.94, strategy="avoid", identity=("governability","consensus"), control=("coalition",), instrumental={"legibility": -.12,"unity": .25}, substantive={"fair_process": .52,"governability": .42}, party=common, party_strategy={"party_unity": .30,"candidate_viability": -.08,"procedural_legitimacy": .52,"avoid_2021_repeat": .38}, organization={"internal_cohesion": .22,"electoral_viability": .08}),
            _option("signal_chair_default_with_consensus_condition", values=consensus_values, goals={"reduce_disorder": .72}, upside=.58, downside=.24, uncertainty=.25, effort=.28, visibility=.55, feasibility=.58+.30*m, strategy="institutionalize", identity=("governability","operative_responsibility","consensus"), control=("coalition","delivery"), instrumental={"legibility": .78,"unity": .62}, substantive={"fair_process": .38,"governability": .80}, party=common, party_strategy={"party_unity": .62,"candidate_viability": .67,"procedural_legitimacy": .45,"avoid_2021_repeat": .70}, organization={"internal_cohesion": .58,"electoral_viability": .42,"leadership_continuity": .62}),
        )
    if stage == "wuest_choice":
        challenge_feas = .20 + .34*u + .24*w["wuest_cdu_elite"] + .22*(1-m)
        endorse_merz_feas = .22 + .34*m + .22*frac + .22*unity
        endorse_soeder_feas = .16 + .34*s + .34*bridge + .16*(1-m)
        return (
            _option("challenge_for_candidacy", values={"governability": .22,"broad_acceptance": .16,"process_control": .46,"future_option": -.58}, goals={"preserve_influence": .52}, upside=.92, downside=.90, uncertainty=.48, effort=.82, visibility=.98, feasibility=challenge_feas, strategy="attack", identity=("ambition","process_control"), risks=("public","irreversible","premature_declaration"), control=("process","coalition"), deviation=.72, instrumental={"candidate_access": .72,"unity": -.82}, substantive={"broad_acceptance": -.55,"future_option": -.72}, party=common, party_strategy={"party_unity": -.86,"candidate_viability": .05,"avoid_2021_repeat": -.92}, organization={"internal_cohesion": -.78,"electoral_viability": -.45}, required={"organization_base": .72,"network_capital": .68}),
            _option("remain_ambiguous_through_autumn", values={"governability": .18,"broad_acceptance": .34,"process_control": .52,"future_option": .72}, goals={"preserve_influence": .54}, upside=.46, downside=.42, uncertainty=.50, effort=.22, visibility=.12, feasibility=.84, strategy="avoid", identity=("timing","future_option"), risks=("reversible",), control=("process",), instrumental={"candidate_access": .24,"unity": -.08}, substantive={"broad_acceptance": .28,"future_option": .76}, party=common, party_strategy={"party_unity": -.05,"candidate_viability": -.34,"avoid_2021_repeat": .08}, organization={"internal_cohesion": -.05,"electoral_viability": -.12}),
            _option("withdraw_without_endorsement", values={"governability": .48,"broad_acceptance": .36,"process_control": .42,"future_option": .82}, goals={"preserve_influence": .58}, upside=.44, downside=.27, uncertainty=.30, effort=.26, visibility=.54, feasibility=.90, strategy="institutionalize", identity=("timing","future_option","process"), control=("process","organization"), instrumental={"candidate_access": -.22,"unity": .28}, substantive={"broad_acceptance": .30,"future_option": .86}, party=common, party_strategy={"party_unity": .30,"candidate_viability": .08,"avoid_2021_repeat": .42}, organization={"internal_cohesion": .24,"electoral_viability": .16}),
            _option("withdraw_and_endorse_soeder", values={"governability": .44,"broad_acceptance": .42,"process_control": .72,"future_option": .48}, goals={"preserve_influence": .62}, upside=.62, downside=.55, uncertainty=.38, effort=.40, visibility=.82, feasibility=endorse_soeder_feas, strategy="reframe", identity=("process_control","coalition","timing"), risks=("public","irreversible"), control=("process","coalition"), deviation=.54, instrumental={"candidate_access": -.30,"unity": .24}, substantive={"broad_acceptance": .32,"future_option": .42}, party=common, party_strategy={"party_unity": .26,"candidate_viability": .34,"avoid_2021_repeat": .38}, organization={"internal_cohesion": .22,"electoral_viability": .20}),
            _option("withdraw_and_endorse_merz", values={"governability": .82,"broad_acceptance": .78,"process_control": .88,"future_option": .78}, goals={"preserve_influence": .76}, upside=.67, downside=.32, uncertainty=.27, effort=.38, visibility=.78, feasibility=endorse_merz_feas, strategy="institutionalize", identity=("process_control","coalition","acceptance","timing","future_option"), risks=("acceptance_verified","prepared_structure"), control=("process","coalition","organization"), restores=.78, deviation=.18, instrumental={"candidate_access": -.24,"unity": .84}, substantive={"broad_acceptance": .82,"future_option": .76}, party=common, party_strategy={"party_unity": .88,"candidate_viability": .72,"avoid_2021_repeat": .92}, organization={"internal_cohesion": .86,"electoral_viability": .58,"leadership_continuity": .66}),
        )
    if stage == "frei_response":
        return (
            _option("announce_open_fraction_count", values={"organization_success": .35,"political_stability": .22,"personal_loyalty": -.22}, goals={"stabilize_organization": .28}, upside=.48, downside=.58, uncertainty=.44, effort=.62, visibility=.82, feasibility=.70, strategy="institutionalize", identity=("majority","organization"), risks=("uncounted_votes","public_split"), control=("organization","parliamentary_process"), deviation=.38, instrumental={"fraction_legibility": .62,"unity": -.42}, substantive={"institutional_voice": .72,"loyalty": -.24}, party=common, party_strategy={"party_unity": -.44,"candidate_viability": .12,"avoid_2021_repeat": -.38}, organization={"internal_cohesion": -.38,"information_control": .42}),
            _option("keep_fraction_formally_neutral", values={"organization_success": .42,"political_stability": .44,"personal_loyalty": .16}, goals={"stabilize_organization": .42}, upside=.32, downside=.26, uncertainty=.38, effort=.22, visibility=.12, feasibility=.92, strategy="avoid", identity=("organization","stability"), risks=("uncounted_votes",), control=("organization",), instrumental={"fraction_legibility": -.18,"unity": .24}, substantive={"institutional_voice": .34,"loyalty": .25}, party=common, party_strategy={"party_unity": .24,"candidate_viability": -.15,"avoid_2021_repeat": .22}, organization={"internal_cohesion": .18,"information_control": -.08}),
            _option("consolidate_legible_majority_behind_merz", values={"organization_success": .88,"political_stability": .78,"personal_loyalty": .72}, goals={"stabilize_organization": .84}, upside=.66, downside=.28, uncertainty=.24, effort=.48, visibility=.44, feasibility=.30+.50*frac+.20*m, strategy="institutionalize", identity=("organization","majority","institutional_loyalty"), risks=("counted_votes","organizational_repair"), control=("organization","parliamentary_process"), restores=.72, instrumental={"fraction_legibility": .88,"unity": .72}, substantive={"institutional_voice": .46,"loyalty": .74}, party=common, party_strategy={"party_unity": .76,"candidate_viability": .70,"avoid_2021_repeat": .82}, organization={"internal_cohesion": .78,"information_control": .70,"leadership_continuity": .68}),
        )
    if stage == "linnemann_response":
        return (
            _option("keep_party_machine_uncommitted", values={"implementation_effect": .24,"economic_reform": .08,"clarity": -.35,"consensus": .42}, goals={"produce_executable_line": .24}, upside=.28, downside=.34, uncertainty=.42, effort=.18, visibility=.08, feasibility=.94, strategy="avoid", identity=("consensus",), control=("organization",), instrumental={"implementation": -.30,"unity": .12}, substantive={"clarity": -.52,"consensus": .34}, party=common, party_strategy={"party_unity": .12,"candidate_viability": -.28,"avoid_2021_repeat": .05}, organization={"internal_cohesion": .08,"information_control": -.18}),
            _option("prepare_open_contest_logistics", values={"implementation_effect": .62,"economic_reform": .12,"clarity": .46,"consensus": .32}, goals={"produce_executable_line": .55}, upside=.52, downside=.50, uncertainty=.38, effort=.58, visibility=.32, feasibility=.76, strategy="institutionalize", identity=("implementation","clarity"), risks=("symbolic_only",), control=("execution","organization"), deviation=.28, instrumental={"implementation": .62,"unity": -.32}, substantive={"clarity": .66,"consensus": .22}, party=common, party_strategy={"party_unity": -.34,"candidate_viability": .16,"avoid_2021_repeat": -.28}, organization={"internal_cohesion": -.26,"information_control": .42}),
            _option("translate_clear_leadership_into_party_line", values={"implementation_effect": .90,"economic_reform": .32,"clarity": .88,"consensus": .48}, goals={"produce_executable_line": .86}, upside=.68, downside=.26, uncertainty=.24, effort=.48, visibility=.42, feasibility=.35+.48*clarity+.17*m, strategy="institutionalize", identity=("implementation","clarity","measurable_effect"), risks=("measurable","domain_expertise"), control=("execution","policy_mechanism","organization"), restores=.70, instrumental={"implementation": .90,"unity": .68}, substantive={"clarity": .88,"consensus": .46}, party=common, party_strategy={"party_unity": .70,"candidate_viability": .68,"avoid_2021_repeat": .78}, organization={"internal_cohesion": .72,"information_control": .68,"leadership_continuity": .58}),
        )
    if stage == "merz_final":
        return (
            _option("accept_formal_open_contest", values={"strategic_direction": .22,"political_authority": -.38,"unity": .18}, goals={"secure_candidacy": .18}, upside=.48, downside=.72, uncertainty=.48, effort=.68, visibility=.86, feasibility=.76, strategy="institutionalize", identity=("organization",), risks=("irreversible","authority_challenge"), control=("organization",), deviation=.42, instrumental={"candidate_control": -.52,"unity": -.12}, substantive={"agency": -.42,"procedural_legitimacy": .66}, party=common, party_strategy={"party_unity": -.18,"candidate_viability": .12,"avoid_2021_repeat": -.34}, organization={"internal_cohesion": -.16,"leadership_continuity": -.55}),
            _option("delay_closure_for_more_consultation", values={"strategic_direction": .26,"political_authority": .12,"unity": .38}, goals={"secure_candidacy": .25}, upside=.34, downside=.36, uncertainty=.42, effort=.28, visibility=.12, feasibility=.88, strategy="negotiate", identity=("unity",), risks=("indecision",), control=("direction",), instrumental={"candidate_control": .16,"unity": .28}, substantive={"agency": .08,"procedural_legitimacy": .52}, party=common, party_strategy={"party_unity": .30,"candidate_viability": -.25,"avoid_2021_repeat": .20}, organization={"internal_cohesion": .22,"leadership_continuity": .12}),
            _option("assert_candidacy_in_bilateral_settlement", values={"strategic_direction": .92,"political_authority": .88,"unity": .66}, goals={"secure_candidacy": .90}, upside=.82, downside=.34, uncertainty=.22, effort=.52, visibility=.62, feasibility=.26+.47*m+.17*frac+.10*clarity, strategy="negotiate", identity=("agency","authority","strategic_direction","institutionalize"), risks=("reversible",), control=("direction","organization"), restores=.72, deviation=.08, instrumental={"candidate_control": .90,"unity": .64}, substantive={"agency": .92,"procedural_legitimacy": .48}, party=common, party_strategy={"party_unity": .68,"candidate_viability": .82,"avoid_2021_repeat": .76}, organization={"internal_cohesion": .66,"leadership_continuity": .84,"electoral_viability": .62}),
        )
    if stage == "soeder_final":
        return (
            _option("demand_union_ballot", values={"csu_relevance": .82,"bavarian_control": .52,"personal_option": .64,"union_unity": -.72}, goals={"preserve_option": .62}, upside=.88, downside=.88, uncertainty=.38, effort=.72, visibility=.98, feasibility=.24+.48*bridge+.20*s, strategy="attack", identity=("relevance","apparatus","public_signal"), risks=("irreversible","certain_defeat"), control=("agenda","visibility"), deviation=.72, instrumental={"candidacy_access": .58,"unity": -.86}, substantive={"csu_voice": .88,"future_options": -.58}, party=common, party_strategy={"party_unity": -.88,"candidate_viability": -.08,"avoid_2021_repeat": -.96}, organization={"internal_cohesion": -.82,"electoral_viability": -.52}),
            _option("continue_public_pressure_without_break", values={"csu_relevance": .74,"bavarian_control": .62,"personal_option": .76,"union_unity": -.18}, goals={"preserve_option": .78}, upside=.64, downside=.50, uncertainty=.34, effort=.44, visibility=.82, feasibility=.72, strategy="reframe", identity=("relevance","visibility","option_value"), risks=("public_signal","reversible"), control=("agenda","visibility"), deviation=.30, instrumental={"candidacy_access": .42,"unity": -.26}, substantive={"csu_voice": .78,"future_options": .60}, party=common, party_strategy={"party_unity": -.28,"candidate_viability": .12,"avoid_2021_repeat": -.22}, organization={"internal_cohesion": -.22,"electoral_viability": .06}),
            _option("bilateral_close_for_merz", values={"csu_relevance": .68,"bavarian_control": .82,"personal_option": .72,"union_unity": .88}, goals={"preserve_option": .64}, upside=.58, downside=.28, uncertainty=.20, effort=.34, visibility=.72, feasibility=.24+.36*m+.24*(1-bridge)+.16*unity, strategy="negotiate", identity=("apparatus","bavaria","option_value","union_unity"), risks=("reversible",), control=("apparatus","agenda"), restores=.68, deviation=.08, instrumental={"candidacy_access": -.48,"unity": .90}, substantive={"csu_voice": .48,"future_options": .72}, party=common, party_strategy={"party_unity": .92,"candidate_viability": .72,"avoid_2021_repeat": .94}, organization={"internal_cohesion": .88,"electoral_viability": .58,"leadership_continuity": .74}),
        )
    raise KeyError(stage)


EFFECTS = {
    "declare_candidacy_publicly": {"merz_viability": .045,"union_unity": -.070,"public_conflict": .100,"closure_clarity": .055},
    "open_structured_consultations": {"union_unity": .035,"closure_clarity": .018,"public_conflict": -.010},
    "hold_default_and_bilateral_channels": {"merz_viability": .020,"union_unity": .015,"closure_clarity": .012,"public_conflict": -.010},
    "demand_formal_union_ballot": {"soeder_viability": .030,"soeder_cdu_bridgehead": .025,"union_unity": -.100,"public_conflict": .120},
    "stay_quiet_and_preserve_option": {"union_unity": .018,"public_conflict": -.012},
    "signal_conditional_availability": {"soeder_viability": .045,"soeder_cdu_bridgehead": .035,"union_unity": -.028,"public_conflict": .052},
    "invite_open_candidate_comparison": {"union_unity": -.025,"public_conflict": .028,"closure_clarity": .020},
    "remain_publicly_uncommitted": {"closure_clarity": -.010},
    "signal_chair_default_with_consensus_condition": {"merz_cdu_elite": .045,"merz_viability": .025,"union_unity": .035,"closure_clarity": .025},
    "challenge_for_candidacy": {"wuest_viability": .140,"wuest_cdu_elite": .120,"merz_viability": -.070,"union_unity": -.150,"public_conflict": .180,"closure_clarity": -.060},
    "remain_ambiguous_through_autumn": {"closure_clarity": -.025,"public_conflict": .018},
    "withdraw_without_endorsement": {"wuest_viability": -.070,"union_unity": .035,"closure_clarity": .035},
    "withdraw_and_endorse_soeder": {"wuest_viability": -.090,"soeder_viability": .110,"soeder_cdu_bridgehead": .160,"union_unity": .065,"closure_clarity": .110},
    "withdraw_and_endorse_merz": {"wuest_viability": -.090,"merz_viability": .115,"merz_cdu_elite": .100,"union_unity": .095,"closure_clarity": .120,"public_conflict": -.040},
    "announce_open_fraction_count": {"merz_fraktion": -.080,"union_unity": -.045,"public_conflict": .055,"closure_clarity": .035},
    "keep_fraction_formally_neutral": {"merz_fraktion": -.025,"closure_clarity": -.015},
    "consolidate_legible_majority_behind_merz": {"merz_fraktion": .075,"merz_viability": .045,"union_unity": .050,"closure_clarity": .065},
    "keep_party_machine_uncommitted": {"closure_clarity": -.020},
    "prepare_open_contest_logistics": {"union_unity": -.040,"public_conflict": .045,"closure_clarity": .040},
    "translate_clear_leadership_into_party_line": {"merz_viability": .035,"union_unity": .045,"closure_clarity": .070},
    "accept_formal_open_contest": {"merz_viability": -.080,"union_unity": -.055,"public_conflict": .080,"closure_clarity": .035},
    "delay_closure_for_more_consultation": {"closure_clarity": -.030,"public_conflict": .015},
    "assert_candidacy_in_bilateral_settlement": {"merz_viability": .060,"closure_clarity": .070,"union_unity": .025},
    "demand_union_ballot": {"soeder_viability": .070,"soeder_cdu_bridgehead": .055,"union_unity": -.150,"public_conflict": .180,"closure_clarity": -.060},
    "continue_public_pressure_without_break": {"soeder_viability": .025,"union_unity": -.050,"public_conflict": .075,"closure_clarity": -.025},
    "bilateral_close_for_merz": {"merz_viability": .080,"soeder_viability": -.055,"union_unity": .120,"public_conflict": -.080,"closure_clarity": .150},
}

# Physical/public acts survive a failed request; collective benefits do not.
# These are effect decompositions of the unchanged v1.1 magnitudes, not fitted
# outcome probabilities. Only the recipient can settle the remaining effects.
DIRECT_REQUEST_EFFECTS = {
    "challenge_for_candidacy": {"union_unity": -.150, "public_conflict": .180, "closure_clarity": -.060},
    "withdraw_and_endorse_merz": {"wuest_viability": -.090},
    "withdraw_and_endorse_soeder": {"wuest_viability": -.090},
    "consolidate_legible_majority_behind_merz": {},
    "translate_clear_leadership_into_party_line": {},
    "bilateral_close_for_merz": {"soeder_viability": -.055},
    "demand_union_ballot": {"union_unity": -.150, "public_conflict": .180, "closure_clarity": -.060},
    "demand_formal_union_ballot": {"union_unity": -.100, "public_conflict": .120},
}


def _organization_engine(environment, scenario):
    a = environment["actors"]
    priors = {
        "NRW_CDU": {"Merz": a["Merz"]["formal_office_default"] * scenario.merz_default_multiplier,
                    "Wuest": a["Wuest"]["landesverband_hausmacht"],
                    "Soeder": min(1.0, environment["global_constraints"]["cdu_bridgehead_soeder"] + scenario.soeder_bridgehead_bonus)},
        "Bundestagsfraktion": {"Merz": max(0, .82 + scenario.fraktion_merz_shift),
                               "Wuest": a["Wuest"]["fraktion"], "Soeder": a["Soeder"]["fraktion"]},
        "CDU_apparatus": {"Merz": a["Merz"]["party_apparatus"],
                          "Wuest": a["Wuest"]["party_apparatus"],
                          "Soeder": min(1.0, .18 + scenario.soeder_bridgehead_bonus)},
        "CSU_apparatus": {"Merz": a["Merz"]["formal_office_default"] * scenario.merz_default_multiplier,
                          "Wuest": a["Wuest"]["formal_office_default"],
                          "Soeder": a["Soeder"]["party_apparatus"]},
    }
    interests = (
        ("continuity", .400, {"viability": .25, "unity": .25, "continuity": .35, "autonomy": .15}),
        ("electoral", .350, {"viability": .60, "unity": .25, "autonomy": .15}),
        ("institutional", .250, {"viability": .20, "unity": .30, "autonomy": .50}),
    )
    organizations = {}
    for key, raw in priors.items():
        total = sum(raw.values())
        support = {candidate: value / total for candidate, value in raw.items()}
        organizations[key] = PoliticalOrganization(key, tuple(
            OrganizationalBloc(name, weight, dict(support), weights)
            for name, weight, weights in interests),
            epistemic_status="UNVALIDATED_RESOURCE_PROXY_NOT_HISTORICAL_SUPPORT")
    return OrganizationalResponseEngine(organizations, seed=scenario.seed,
                                        contingency_sigma=scenario.contingency_sigma)


class Replay:
    def __init__(self, scenario: Scenario):
        self.scenario = scenario
        self.rng = random.Random(scenario.seed)
        self.environment = json.loads(LEGACY_ENVIRONMENT.read_text(encoding="utf-8"))
        self.resources = _historical_resources(self.environment)
        self.resources["Merz"]["formal_power"] *= scenario.merz_default_multiplier
        self.personas, self.sanitization = _sanitized_engine(self.resources, scenario)
        self.world = _initial_world(self.environment, scenario)
        self.organizations = _organization_engine(self.environment, scenario)
        # Leadership affiliation in the legacy snapshot is NOT an already
        # adopted nomination. Unknown initial endorsements remain unknown.
        self.world.alignments = {key: "Uncommitted" for key in self.organizations.organizations}
        self.model_minute = 0
        self.organization_bindings = {}
        self.profiles = _rationality_profiles()
        self.party = _party_engine()
        self.logic = _logic()
        self.matrix = _matrix()
        self.repertoire = ActionRepertoireFilter(self.matrix)
        self.perception = ActionPerceptionFilter()
        self.rationality = RationalityEvaluator()
        self.trace: list[dict] = []
        self.polls: list[dict] = []
        self.pss: list[dict] = []
        self.key_actions: dict[str, str] = {}
        self._record_observation("T0")

    def _response_features(self, request):
        target = request.target.lower()
        leaders = {"NRW_CDU": "Wuest", "Bundestagsfraktion": "Merz",
                   "CDU_apparatus": "Merz", "CSU_apparatus": "Soeder"}
        return {"viability": 2*self.world.values[f"{target}_viability"]-1,
                "unity": 2*self.world.values["union_unity"]-1,
                "continuity": 1.0 if request.target == leaders[request.organization] else -1.0,
                "autonomy": request.features.get("autonomy", 0.0)}

    def _advance_organizations(self, minute):
        self.model_minute = minute
        for response in self.organizations.advance_to(minute, self._response_features):
            binding = self.organization_bindings[response.request_id]
            update = self.world.update(f"organization_response:{response.request_id}", {
                key: value * response.realization_fraction for key, value in binding["effects"].items()})
            org = self.organizations.organizations[response.organization]
            alignment = org.alignment or "Uncommitted"
            self.world.alignments[response.organization] = (
                "Joint_Merz" if response.organization == "CSU_apparatus" and alignment == "Merz" else alignment)
            pss_update = None
            if response.status in {"ACCEPTED", "PARTIAL", "REJECTED"}:
                success = 1.0 if response.status == "ACCEPTED" else response.realization_fraction
                pss_update = self.personas.apply_outcome(response.proposer, ActionOutcome(
                    binding["action"], success, workload=0.0, expected_success=binding["expected"],
                    evidence_quality=1.0, outcome_scope=.650,
                    tags=("organizational_response", response.status),
                    control_restoration=binding["restores"] * response.realization_fraction * .080))
            event = f"organization_response:{response.request_id}"
            self.trace.append({"node": event, "actor": response.organization,
                "event_kind": "organizational_response", "elapsed_model_minutes": minute,
                "arcana": {"enabled": False, "status": "DISABLED"},
                "organization_response": response.payload(), "world_update": update,
                "pss_update": pss_update})
            self._record_observation(event)

    def _organizational_request(self, chosen, actor, action):
        targets = {
            "challenge_for_candidacy": ("NRW_CDU", "Wuest"),
            "withdraw_and_endorse_merz": ("NRW_CDU", "Merz"),
            "withdraw_and_endorse_soeder": ("NRW_CDU", "Soeder"),
            "consolidate_legible_majority_behind_merz": ("Bundestagsfraktion", "Merz"),
            "bilateral_close_for_merz": ("CSU_apparatus", "Merz"),
            "demand_union_ballot": ("CSU_apparatus", "Soeder"),
            "demand_formal_union_ballot": ("CSU_apparatus", "Soeder"),
        }
        if chosen == "translate_clear_leadership_into_party_line":
            eligible = {name: self.world.values[f"{name.lower()}_viability"] for name in PRIMARY
                        if (name != "Wuest" or self.world.flags["wuest_active"])
                        and (name != "Soeder" or not self.world.flags["soeder_conceded"])}
            targets[chosen] = ("CDU_apparatus", max(eligible, key=eligible.get))
        if chosen not in targets:
            return None
        org, target = targets[chosen]
        return OrganizationalRequest(f"{actor}:{chosen}", org, actor, target,
            action.effort, 120, {"autonomy": -.8 if action.conflict_strategy == "attack" else .8})

    def perceived_world(self, actor: str) -> tuple[dict[str, float], float]:
        result = {}
        confidences = []
        for key, truth in self.world.values.items():
            own = actor.lower() in key
            access = .900 if own else .760 if key in {"union_unity","public_conflict","closure_clarity"} else .660
            noise = self.rng.gauss(0.0, self.scenario.perception_sigma * (1.15 - access))
            result[key] = _q(truth + noise)
            confidences.append(access * (1.0 - self.scenario.perception_sigma))
        return result, sum(confidences) / len(confidences)

    def perceived_resources(self, actor: str) -> dict[str, float]:
        return {key: _q(value + self.rng.gauss(0.0, self.scenario.perception_sigma * .35))
                for key, value in self.resources[actor].items()}

    def decide(self, stage: str, actor: str, goals: Mapping[str, float]) -> str:
        self._advance_organizations(self.model_minute)
        perceived_world, info_confidence = self.perceived_world(actor)
        resources = self.perceived_resources(actor)
        actions = _menus(stage, actor, perceived_world)
        objective_actions = {row.key: row for row in _menus(stage, actor, self.world.values)}
        repertoire = self.repertoire.apply(actor, actions, resources)
        perceived = self.perception.apply(actions, repertoire, self.logic, AGENCY[actor], resources, info_confidence)
        serious = [perceived[row.key].for_scoring(row) for row in actions
                   if perceived[row.key].perceived_status == "CONSIDERED"]
        if not serious:
            serious = [perceived[row.key].for_scoring(row) for row in actions
                       if perceived[row.key].role_status == "AVAILABLE"
                       and perceived[row.key].execution_feasibility > 0.0]
        if not serious:
            raise RuntimeError(f"No executable action at {stage}")
        persona_rows = {row.key: self.personas.score(actor, row, resources, goals,
                        ("candidate_selection","union_internal"), soft_resource_constraints=True) for row in serious}
        profile = self.profiles.get(actor, ActorRationalityProfile())
        rationality_rows = {row.key: self.rationality.evaluate(row, persona_rows[row.key], profile,
                            perceived_feasibility=perceived[row.key].perceived_feasibility,
                            action_assessment=perceived[row.key],
                            strategic_score=.500) for row in serious}
        party_rows = {row.key: self.party.evaluate("UNION_2024", row) for row in serious}
        combined = {row.key: round(.800*rationality_rows[row.key].choice_score + .200*party_rows[row.key].collective_score, 3)
                    for row in serious}
        order = {row.key: index for index, row in enumerate(actions)}
        chosen = max(combined, key=lambda key: (combined[key], -order[key]))
        request = self._organizational_request(chosen, actor, actions[order[chosen]])
        submission = None
        if request is not None:
            submission = self.organizations.submit(request, self.model_minute)
            direct = DIRECT_REQUEST_EFFECTS[chosen]
            self.organization_bindings[request.request_id] = {
                "action": chosen, "expected": rationality_rows[chosen].political_success_expectation,
                "restores": actions[order[chosen]].restores_control,
                "effects": {key: value-direct.get(key, 0.0) for key,value in EFFECTS[chosen].items()
                            if value-direct.get(key, 0.0) != 0.0}}
            self.personas.advance_time(actor, 0, workload=.025+.055*actions[order[chosen]].effort)
        else:
            direct = EFFECTS[chosen]
        if actor == "Wuest" and chosen.startswith("withdraw_"):
            self.world.flags["wuest_active"] = False
        if actor == "Soeder" and chosen == "bilateral_close_for_merz":
            self.world.flags["soeder_conceded"] = True
        objective_success = None if request is not None else objective_actions[chosen].objective_feasibility
        effect_multiplier = 1.000
        state_update = self.world.update(chosen, direct)
        if request is None:
            self.personas.apply_outcome(actor, ActionOutcome(
            chosen, objective_success, surprise=abs(objective_success-.500),
            tags=("candidate_selection", actions[order[chosen]].conflict_strategy, *actions[order[chosen]].identity_tags),
            expected_success=actions[order[chosen]].objective_feasibility,
            evidence_quality=info_confidence, outcome_scope=.650,
            workload=.025+.055*actions[order[chosen]].effort,
            control_restoration=actions[order[chosen]].restores_control*objective_success*.080,
            ))
        if chosen in {"challenge_for_candidacy","demand_union_ballot","demand_formal_union_ballot"}:
            event = WorldEvent(f"public_conflict:{stage}", "elite_challenge", .620,
                               ("public","union_conflict","loss_of_control","authority_challenge"), surprise=.180)
            for other in PRIMARY:
                if other != actor:
                    self.personas.apply_event(other, event)
        self.trace.append({
            "node": stage, "actor": actor, "arcana": {"enabled": False, "status": "DISABLED"},
            "objective_action_menu": [{"action": row.key, "objective_feasibility": objective_actions[row.key].objective_feasibility} for row in actions],
            "perceived_world": perceived_world, "information_confidence": round(info_confidence, 3),
            "perceived_resources": resources,
            "role_filtered_menu": {key: value.payload() for key, value in repertoire.items()},
            "perceived_action_menu": {key: value.payload() for key, value in perceived.items()},
            "evaluations": {key: {"persona": asdict(persona_rows[key]), "rationality": rationality_rows[key].payload(),
                                           "party_overlay": party_rows[key].payload(), "combined_choice_score": combined[key]}
                            for key in combined},
            "chosen_action": chosen, "chosen_menu_index": order[chosen],
            "elapsed_model_minutes": self.model_minute,
            "action_outcome": "SUBMITTED" if request is not None else "EXECUTED_LEGACY_EFFECTS",
            "organization_request": submission,
            "objective_success": round(objective_success, 3) if objective_success is not None else None,
            "effect_multiplier": round(effect_multiplier, 3),
            "world_update": state_update,
        })
        self._record_observation(stage)
        self.key_actions[stage] = chosen
        self.model_minute += 60
        return chosen

    def collective(self, stage: str, options: Sequence[ActionOption]) -> str:
        decision = self.party.decide("UNION_2024", options)
        chosen = decision.chosen_action
        self.trace.append({"node": stage, "actor": stage, "arcana": {"enabled": False, "status": "DISABLED"},
                           "collective_model": decision.payload(), "chosen_action": chosen})
        self.key_actions[stage] = chosen
        self._record_observation(stage)
        return chosen

    def _record_observation(self, node: str) -> None:
        v = self.world.values
        latent = 32.000 + .038*(v["union_unity"]-.650)*100 - .030*(v["public_conflict"]-.180)*100 + .016*(v["closure_clarity"]-.180)*100
        self.polls.append({"node": node, "Union_model_nowcast": round(max(20.0,min(40.0,latent))*2)/2,
                           "latent": round(latent,3), "not_a_survey": True})
        self.pss.append({"node": node, **{actor: round(self.personas.runtime[actor].state.pressure,3) for actor in ACTORS}})

    def run(self) -> dict:
        self.decide("merz_opening", "Merz", {"secure_candidacy": .900})
        self.decide("soeder_opening", "Soeder", {"preserve_option": .900})
        self.decide("rhein_signal", "Rhein", {"reduce_disorder": .820})
        self.decide("guenther_signal", "Guenther", {"reduce_disorder": .900})
        self.decide("wuest_choice", "Wuest", {"preserve_influence": .880})
        self.decide("frei_response", "Frei", {"stabilize_organization": .900})
        self.decide("linnemann_response", "Linnemann", {"produce_executable_line": .900})
        self.decide("merz_final", "Merz", {"secure_candidacy": .950})
        self.decide("soeder_final", "Soeder", {"preserve_option": .900})
        # Explicit observation horizon, not an automatic "flush until success".
        # The compressed minute scale is a test clock, NOT historical dates.
        self._advance_organizations(720)

        closure = self.resolve_closure()
        comparison = self.compare(closure)
        return {
            "schema_version": "hakoniwa-kfrage-blind-replay-1.2",
            "decision_channels": "separated-execution-political-success-confidence-1.0",
            "validation_scope": "dependent_checkpoints_not_independent_persona_validation",
            "organizational_calibration": {
                "status": "ENGINEERING_EXPERIMENT_ONLY",
                "accuracy_interpretation_valid": False,
                "known_limitations": ["ordinal_resources_are_not_member_support_shares",
                    "bloc_weights_response_rates_trust_and_thresholds_are_unverified",
                    "one_request_per_fixed_node_is_not_an_iterated_negotiation"]},
            "response_clock": {"unit": "compressed_model_minutes_not_historical_timestamps", "horizon":720},
            "organizations": self.organizations.payload(),
            "scenario": asdict(self.scenario),
            "arcana": {"enabled": False, "initialized": False},
            "anti_leakage": self.sanitization,
            "observed_comparator_access": "post_run_only",
            "trace": self.trace,
            "key_actions": self.key_actions,
            "final_world": {"values": {k:round(v,3) for k,v in self.world.values.items()},
                            "alignments": self.world.alignments, "flags": self.world.flags},
            "closure": closure, "observed_comparison": comparison,
            "polling": self.polls, "pss_pressure": self.pss,
            "warning": "Monte Carlo path shares are model perturbation frequencies, not real-world probabilities.",
        }

    def resolve_closure(self) -> dict:
        v = self.world.values
        scores = {
            "Merz": .34*v["merz_viability"]+.24*v["merz_fraktion"]+.22*v["merz_cdu_elite"]+.20*v["union_unity"],
            "Wuest": .45*v["wuest_viability"]+.30*v["wuest_cdu_elite"]+.25*v["union_unity"] if self.world.flags["wuest_active"] else 0.0,
            "Soeder": .42*v["soeder_viability"]+.33*v["soeder_cdu_bridgehead"]+.25*v["union_unity"] if not self.world.flags["soeder_conceded"] else 0.0,
        }
        order = sorted(scores, key=scores.get, reverse=True)
        top, second = order[:2]
        viability_sufficient = scores[top] >= .620 and scores[top]-scores[second] >= .055 and v["closure_clarity"] >= .520
        # A joint proposal by two chairs and a later party-organ decision are
        # different events. The 17 September comparator concerns the former.
        endorsed = all(self.organizations.organizations[key].alignment == top
                       for key in ("CDU_apparatus", "CSU_apparatus"))
        joint_proposal = ("Merz" if self.key_actions.get("merz_final") == "assert_candidacy_in_bilateral_settlement"
                          and self.key_actions.get("soeder_final") == "bilateral_close_for_merz" else None)
        candidate = joint_proposal
        return {"candidate": candidate, "scores": {k:round(x,3) for k,x in scores.items()},
                "candidate_semantics": "JOINT_CHAIR_PROPOSAL_NOT_FORMAL_NOMINATION",
                "formal_nomination": {"status": "NOT_MODELED", "candidate": None},
                "organizational_support_closure": top if viability_sufficient and endorsed else None,
                "threshold": .620, "minimum_margin": .055, "clarity_required": .520,
                "party_endorsements_confirmed": endorsed,
                "blocking_conditions": (["VIABILITY_OR_CLARITY_NOT_SUFFICIENT"] if not viability_sufficient else [])
                                       + (["PARTY_ENDORSEMENTS_UNRESOLVED"] if not endorsed else []),
                "rule": "mutual chair proposal; organizational response and formal nomination remain separate"}

    def compare(self, closure: Mapping[str, object]) -> dict:
        actual = {
            "merz_opening": self.key_actions.get("merz_opening"),
            "soeder_opening": self.key_actions.get("soeder_opening"),
            "wuest_choice": self.key_actions.get("wuest_choice"),
            "nrw_alignment": self.world.alignments["NRW_CDU"],
            "soeder_final": self.key_actions.get("soeder_final"),
            "closure_candidate": closure["candidate"],
            "fraktion_alignment": self.world.alignments["Bundestagsfraktion"],
            "csu_alignment": self.world.alignments["CSU_apparatus"],
        }
        matches = {key: actual[key] == expected for key, expected in OBSERVED_COMPARATOR.items()}
        return {"expected": OBSERVED_COMPARATOR, "actual": actual, "matches": matches,
                "matched": sum(matches.values()), "total": len(matches),
                "accuracy_interpretation_valid": False,
                "scope": "descriptive checkpoint comparison under unvalidated organizational assumptions",
                "result": "PASS_NATURAL_SEQUENCE" if all(matches.values()) else "MODEL_ERROR_OR_PARTIAL_REPRODUCTION"}


def scenario_set() -> dict[str, Scenario]:
    return {
        "baseline": Scenario(),
        "no_merz_default": Scenario(name="no_merz_default", merz_default_multiplier=.350),
        "strong_soeder_cdu_bridgehead": Scenario(name="strong_soeder_cdu_bridgehead", soeder_bridgehead_bonus=.380),
        "fraktion_neutralized": Scenario(name="fraktion_neutralized", fraktion_merz_shift=-.420),
        "wuest_control_reduced": Scenario(name="wuest_control_reduced", wuest_process_control_multiplier=.250),
    }


def path_label(payload: Mapping[str, object]) -> str:
    actions = payload["key_actions"]
    statuses = {row["organization"]:row["status"] for row in payload.get("organizations",{}).get("responses",[])}
    response_path = ",".join(f"{key}:{value}" for key,value in sorted(statuses.items()))
    return "__".join((actions.get("wuest_choice","unknown"), actions.get("soeder_final","unknown"),
                     f"closure_{payload['closure']['candidate'] or 'none'}", response_path))


def ensemble(base: Scenario, runs: int) -> dict:
    counts: Counter[str] = Counter()
    action_counts: dict[str, Counter[str]] = {}
    example_seeds = {}
    for index in range(runs):
        scenario = Scenario(**{**asdict(base), "seed": base.seed + 7919*index,
                               "perception_sigma": .115, "contingency_sigma": .090})
        payload = Replay(scenario).run()
        label = path_label(payload); counts[label] += 1; example_seeds.setdefault(label, scenario.seed)
        for node, action in payload["key_actions"].items():
            action_counts.setdefault(node, Counter())[action] += 1
    return {"runs": runs, "interpretation": "path shares under bounded information/contingency perturbations; not probabilities",
            "counts": dict(counts), "shares": {key:round(value/runs,4) for key,value in counts.items()},
            "node_action_shares": {node:{action:round(count/runs,4) for action,count in rows.items()} for node,rows in action_counts.items()},
            "example_seed_by_path": example_seeds}


def _line_svg(rows: Sequence[Mapping[str, object]], keys: Sequence[str], title: str, y_min: float, y_max: float) -> str:
    width,height,left,top=980,350,70,42; inner_w,inner_h=width-left-35,height-top-58
    colors=("#222222","#8d4f3a","#356d92","#6e7e42","#8b6d9c","#b17d2f","#555b6e")
    def x(i): return left+inner_w*i/max(1,len(rows)-1)
    def y(v): return top+inner_h*(1-(float(v)-y_min)/(y_max-y_min))
    out=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}"><rect width="100%" height="100%" fill="#fbfaf6"/><text x="{left}" y="24" font-size="17">{escape(title)}</text>']
    for step in range(5):
        value=y_min+(y_max-y_min)*step/4; yy=y(value)
        out.append(f'<line x1="{left}" y1="{yy:.1f}" x2="{width-35}" y2="{yy:.1f}" stroke="#ddd"/><text x="{left-8}" y="{yy+4:.1f}" text-anchor="end" font-size="11">{value:.2f}</text>')
    for index,key in enumerate(keys):
        points=' '.join(f'{x(i):.1f},{y(row[key]):.1f}' for i,row in enumerate(rows))
        out.append(f'<polyline points="{points}" fill="none" stroke="{colors[index%len(colors)]}" stroke-width="2.5"/><text x="{left+index*118}" y="{height-12}" fill="{colors[index%len(colors)]}" font-size="12">{escape(key)}</text>')
    return ''.join(out)+'</svg>'


def save(output: Path, baseline: dict, sensitivities: Mapping[str, dict], mc: dict) -> None:
    output.mkdir(parents=True, exist_ok=True)
    payload={"baseline":baseline,"sensitivities":sensitivities,"ensemble":mc}
    (output/"full_trace.json").write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
    poll_rows=[{"Union":row["latent"]} for row in baseline["polling"]]
    poll_svg=_line_svg(poll_rows,("Union",),"Union model nowcast (latent; not a survey)",28,36)
    pss_svg=_line_svg(baseline["pss_pressure"],ACTORS,"PSS pressure by actor",0,1)
    (output/"polling.svg").write_text(poll_svg,encoding="utf-8")
    (output/"pss_pressure.svg").write_text(pss_svg,encoding="utf-8")
    node_html=[]
    for row in baseline["trace"]:
        if row.get("event_kind") == "organizational_response":
            response = row["organization_response"]
            node_html.append(f'<details><summary>{escape(row["node"])} · {escape(response["status"])}</summary><p>组织自主响应，非人物再次决策；模型分钟 {row["elapsed_model_minutes"]}</p><pre>{escape(json.dumps(response,ensure_ascii=False,indent=2))}</pre></details>')
            continue
        evaluations=row.get("evaluations",{})
        table=''.join(f'<tr><td>{escape(key)}</td><td>{value["combined_choice_score"]:.3f}</td><td>{value["rationality"]["execution_feasibility"]:.3f}</td><td>{value["rationality"]["political_success_expectation"]:.3f}</td><td>{value["rationality"]["information_confidence"]:.3f}</td><td>{value["rationality"]["instrumental_score"]:.3f}</td><td>{value["rationality"]["expected_instrumental_score"]:.3f}</td><td>{value["rationality"]["substantive_score"]:.3f}</td><td>{value["persona"]["total"]:.3f}</td></tr>' for key,value in evaluations.items())
        node_html.append(f'<details><summary>{escape(row["node"])} · {escape(row["actor"])} → {escape(row["chosen_action"])}</summary><p>ARCANA: DISABLED</p><table><tr><th>行动</th><th>合成</th><th>执行</th><th>政治目标预期</th><th>信息置信度</th><th>成功时工具收益</th><th>期望工具收益</th><th>实质</th><th>人格原分</th></tr>{table}</table><pre>{escape(json.dumps(row.get("perceived_action_menu",row.get("collective_model",{})),ensure_ascii=False,indent=2))}</pre></details>')
    comparison=baseline["observed_comparison"]
    sens=''.join(f'<tr><td>{escape(name)}</td><td>{escape(path_label(row))}</td><td>{escape(row["observed_comparison"]["result"])}</td></tr>' for name,row in sensitivities.items())
    dist=''.join(f'<tr><td>{escape(key)}</td><td>{value}</td><td>{mc["shares"][key]:.3f}</td></tr>' for key,value in sorted(mc["counts"].items(),key=lambda x:-x[1]))
    html=f'''<!doctype html><html lang="zh"><meta charset="utf-8"><title>Hakoniwa · 2024 K-Frage blind replay</title><style>body{{max-width:1160px;margin:36px auto;padding:0 22px;background:#f5f2eb;color:#242321;font:15px/1.6 system-ui}}.box,details{{background:white;padding:14px;margin:12px 0;border:1px solid #ddd}}table{{width:100%;border-collapse:collapse}}td,th{{padding:7px;border-bottom:1px solid #ddd;text-align:left}}svg{{max-width:100%;height:auto}}pre{{white-space:pre-wrap;overflow-wrap:anywhere}}.warn{{border-left:4px solid #9a493e;padding-left:12px}}</style><h1>2024 CDU/CSU K-Frage · Blind Replay</h1><p class="warn">真实结局只在运行完成后比较。人物卡已删除2024结果记忆及2026记忆，关系归一化；ARCANA未初始化。频率不是现实概率。</p><div class="box"><b>Baseline:</b> {escape(path_label(baseline))}<br><b>Calibration:</b> {escape(comparison["result"])} ({comparison["matched"]}/{comparison["total"]})</div><h2>实时模型民调</h2>{poll_svg}<h2>人物实时压力</h2>{pss_svg}<h2>逐节点评价</h2>{''.join(node_html)}<h2>Sensitivity</h2><table><tr><th>设定</th><th>路径</th><th>对照</th></tr>{sens}</table><h2>扰动路径分布</h2><table><tr><th>路径</th><th>次数</th><th>份额</th></tr>{dist}</table></html>'''
    html = html.replace("<h2>实时模型民调</h2>", "<p class=\"warn\">组织偏好、抽象分组、响应速率、采纳阈值与压缩时钟均为未校准假设，不是历史党内票数或真实程序。检查点匹配不等于人物卡验证通过。以下支持率沿用旧式投影，未接入选民反应插件。</p><h2>旧式支持率投影（诊断）</h2>")
    (output/"report.html").write_text(html,encoding="utf-8")
    failed=[key for key,value in comparison["matches"].items() if not value]
    sensitivity_paths={name:path_label(row) for name,row in sensitivities.items()}
    summary=f'''# 2024 K-Frage blind replay — calibration result

- Result: **{comparison["result"]}**
- Matched checkpoints: **{comparison["matched"]}/{comparison["total"]}**
- Failed checkpoints: {", ".join(failed) if failed else "none"}
- Baseline path: `{path_label(baseline)}`
- ARCANA: disabled and not initialized

Söder's opening action was `{baseline["key_actions"]["soeder_opening"]}`.
Checkpoint matches are not independent observations and do not establish persona
validity. This version separates execution, political success expectation and
information confidence; the historical action/outcome assumptions are unchanged.

The {mc["runs"]}-run perturbation ensemble produced {len(mc["counts"])} distinct
terminal path(s). This is a model-diagnostic distribution, not a real-world
probability. A single path across the ensemble, together with unchanged paths in
all ablations, indicates excessive structural determinism rather than high
predictive confidence.

Sensitivity paths:

{chr(10).join(f"- {name}: `{path}`" for name,path in sensitivity_paths.items())}

Organisational requests now have a separate, delayed recipient response. Bloc
preferences, response rates, trust and adoption thresholds are uncalibrated model
assumptions, not reconstructed historical member votes. Failure to reproduce
endorsements is a model error, not a reason to tune these parameters to 2024.
Delivered-information propagation, other static action effects, historical
parameter provenance and the legacy polling projection remain unresolved.
Keep the old run frozen and compare this as a separate model version.
'''
    (output/"calibration_summary.md").write_text(summary,encoding="utf-8")


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs",type=int,default=1000)
    parser.add_argument("--seed",type=int,default=20240901)
    parser.add_argument("--output",type=Path,default=Path("outputs/kfrage-2024-organizations-v1"))
    args=parser.parse_args()
    baseline_scenario=Scenario(seed=args.seed)
    baseline=Replay(baseline_scenario).run()
    sensitivities={name:Replay(Scenario(**{**asdict(scenario),"seed":args.seed})).run()
                   for name,scenario in scenario_set().items() if name!="baseline"}
    mc=ensemble(baseline_scenario,args.runs)
    save(args.output,baseline,sensitivities,mc)
    print(json.dumps({"output":str(args.output),"arcana":False,"baseline_path":path_label(baseline),
                      "calibration":baseline["observed_comparison"],"ensemble":mc["shares"]},ensure_ascii=False,indent=2))


if __name__ == "__main__":
    main()

