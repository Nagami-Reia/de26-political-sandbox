"""Coarse roll-call retrodiction; target result is read only in comparison.

No 2026 persona deck, per-member target ballot, or fitted defection rate is used.
This intentionally does NOT claim a fully blinded individual-level validation.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from hashlib import sha256
from html import escape
import json
from pathlib import Path

from ...plugins.majorities import MajorityModel, run_request

HERE = Path(__file__).resolve().parent
DEFAULT_OUTPUT = Path("outputs/zustrom_2025_vote_replay")


def digest(value):
    return sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def build_request(protocol, *, runs=500, seed=20250131, overrides=None):
    """Build from the protocol alone; no reference/outcome argument exists."""
    assumptions = dict(protocol["assumptions"])
    assumptions.update(overrides or {})
    members = []
    loadings = {}
    for party, group in protocol["parties"].items():
        stance = group["announced_position"]
        for slot in range(group["seats"]):
            key = f"ANONYMOUS_{party}_{slot+1:03d}"
            member = {
                "id": key, "party": party, "groups": [],
                "position": {} if stance == "unknown" else {"proposal_alignment": float(stance == "yes")},
                "weights": {"policy": assumptions["policy_weight"]},
                "temperature": assumptions["temperature"],
                "attendance": assumptions["attendance"],
                "abstain_utility": assumptions["independent_abstain_utility"] if stance == "unknown" else assumptions["other_abstain_utility"],
                "source_status": "MODEL_ASSUMPTION",
            }
            members.append(member)
            if party in assumptions["shared_information_scope"]:
                loadings[key] = 1.0
    return {
        "schema_version": "hakoniwa-majorities-1.0",
        "as_of": protocol["cutoff"][:10],
        "body": {"id":"Bundestag_20_vote_946", "kind":"bundestag", "secret":False},
        "rule": {
            "total_weight": sum(p["seats"] for p in protocol["parties"].values()),
            "kind":"simple_cast", "quorum":"presumed",
            "authority":"Historical ordinary yes/no roll-call counting reconstruction; no new legal-status decision",
            "source_status":"MODEL_ASSUMPTION",
        },
        "issue": {
            "id":"20_12804_second_reading", "version":"pre_vote_2025_01_31_0800",
            "proposer":"CDU_CSU", "position":{"proposal_alignment":1.0},
            "assessments":{}, "source_status":"MODEL_ASSUMPTION",
        },
        "members":members, "ties":[], "stances":[],
        "contingencies":[{
            "id":"unobserved_final_interpretation", "sigma":assumptions["shared_information_sigma"],
            "loadings":loadings, "reason":assumptions["shared_information_reason"],
            "source_status":"MODEL_ASSUMPTION",
        }],
        "seed":seed, "runs":runs,
    }


def party_summary(request, forecast):
    result = {}
    evaluations = forecast["baseline"]["member_evaluations"]
    ballots = forecast["baseline"]["result"]["member_ballots"]
    for member in request["members"]:
        group = result.setdefault(member["party"], {
            "modal_counts":dict.fromkeys(("yes","no","abstain","absent"),0),
            "expected_counts":dict.fromkeys(("yes","no","abstain","absent"),0.0),
        })
        group["modal_counts"][ballots[member["id"]]] += 1
        for choice, probability in evaluations[member["id"]]["probabilities"].items():
            group["expected_counts"][choice] += probability
    return result


def predict(output, *, runs=500, sensitivity_runs=100, seed=20250131):
    """Write frozen inputs and forecasts before ever loading reference.json."""
    output.mkdir(parents=True, exist_ok=True)
    protocol = json.loads((HERE/"protocol.json").read_text())
    source_notes = json.loads((HERE/"sources.json").read_text())
    request = build_request(protocol, runs=runs, seed=seed)
    frozen_hash = digest(request)
    save(output/"frozen_protocol.json", protocol)
    save(output/"frozen_request.json", request)
    save(output/"sources.json", source_notes)
    forecast = run_request(request)
    save(output/"forecast.json", forecast)
    sensitivities = []
    for variant in protocol["sensitivity"]:
        variant_request = build_request(protocol, runs=sensitivity_runs, seed=seed,
                                        overrides={variant["parameter"]:variant["value"]})
        model = MajorityModel(variant_request)
        sensitivities.append({
            **variant, "request_sha256":digest(variant_request),
            "baseline":model.baseline()["result"],
            "ensemble":model.simulate(sensitivity_runs, seed),
        })
    summary = {
        "schema_version":"historical-vote-validation-1.0",
        "input_sha256":frozen_hash, "protocol_sha256":digest(protocol),
        "forecast_sha256":digest(forecast), "seed":seed,
        "target_result_used_by_prediction_function":False,
        "independent_blind_test":False,
        "scope":"Anonymous member slots with party-line proxy; aggregate test only",
        "baseline":forecast["baseline"]["result"],
        "expected_counts":forecast["baseline"]["expected_counts_without_shared_shocks"],
        "ensemble":forecast["ensemble"],
        "party_forecast":party_summary(request,forecast),
        "sensitivities":sensitivities,
        "polling":{"status":"NOT_RUN","reason":"Isolated roll-call validation, no voter-response simulation"},
        "pss":{"status":"NOT_RUN","actors_used":[],"reason":"Do not leak 2026 cards/state into 2025; no historical persona reconstruction in this experiment"},
    }
    save(output/"prediction_summary.json", summary)
    assert digest(request) == frozen_hash
    return summary


def compare(output):
    """Target is opened only here, after checking frozen prediction artifacts."""
    request = json.loads((output/"frozen_request.json").read_text())
    summary = json.loads((output/"prediction_summary.json").read_text())
    forecast = json.loads((output/"forecast.json").read_text())
    protocol = json.loads((output/"frozen_protocol.json").read_text())
    if digest(request) != summary["input_sha256"] or digest(forecast) != summary["forecast_sha256"] or digest(protocol) != summary["protocol_sha256"]:
        raise ValueError("frozen input/forecast/protocol changed; refuse comparison")
    reference = json.loads((HERE/"reference.json").read_text())
    if sum(reference["counts"].values()) != request["rule"]["total_weight"]:
        raise ValueError("reference and eligible roster totals differ")
    # Labels are needed for comparison, but never passed to build_request/model.
    differences = {k:summary["baseline"]["counts"][k]-v for k,v in reference["counts"].items()}
    expected_differences = {k:summary["expected_counts"].get(k,0)-v for k,v in reference["counts"].items()}
    match = summary["baseline"]["passed"] == reference["passed"]
    assessment = {
        "reference":reference, "binary_outcome_match":match,
        "modal_count_errors":differences, "expected_count_errors":expected_differences,
        "baseline_status":"COARSE_AGGREGATE_MATCH_NOT_PERSONA_VALIDATION" if match else "MODEL_ERROR_COARSE_BASELINE_FAILED",
        "no_target_fitting_performed":True,
        "individual_defection_validation":"NOT_TESTED_NO_NAMED_MEMBER_DOSSIERS",
        "causal_diagnosis_status":"INPUT_AND_MECHANISM_GAPS_IDENTIFIED; NOT AN IDENTIFIED HISTORICAL CAUSAL EXPLANATION",
        "do_not_relabel_sensitivity_as_successful_baseline":True,
        "measurement_warning":"Reference absent stores official nicht abgestimmt (no ballot cast), not established physical absence or deliberate rebellion.",
        "mechanism_gaps":[
            "Party announcements proxied to individual policy without member-specific evidence",
            "One participation rate for every group",
            "No explicit agent action to remain present but withhold a ballot",
            "No endogenous final-hours negotiation/information sequence"
        ],
    }
    save(output/"comparison.json", assessment)
    render(output, summary, assessment)
    return assessment


def render(output, summary, comparison):
    ref = comparison["reference"]
    real = ref["counts"]
    predicted = summary["baseline"]["counts"]
    lines = [
        "# 2025-01-31《限制移民流入法案》表决回放",
        "", f"结论：**{comparison['baseline_status']}**。这是群体层回溯测试，不是真正独立盲测，也不验证具体人物。",
        "", "| 票类 | 基线 | 真实 | 基线误差 |", "|---|---:|---:|---:|",
    ]
    for key in real:
        lines.append(f"| {key} | {predicted[key]} | {real[key]} | {comparison['modal_count_errors'][key]:+d} |")
    lines += [
        "", f"Baseline：{summary['baseline']['status']}；真实：{'ADOPTED' if ref['passed'] else 'REJECTED'}。",
        "", f"Ensemble：{summary['ensemble']['runs']} 次，seed={summary['seed']}，分布 `{json.dumps(summary['ensemble']['outcome_counts'])}`。这些是条件模型频率，不是现实通过概率。",
        "", "## 为什么这个结果有用", "",
        "输入把党团公开表态当作成员政策的粗略代理。它没有逐人的议题立场、最后几小时的谈判信息、拒投选择或实际缺席原因。统一出席率也无法表达党团之间不同的动员／参与情况。",
        "", "这暴露的是当前粗粒度输入与机制的缺口，不是已经证明某位议员不忠诚。尤其真实记录中的未投票，不能一律叫倒戈。",
        "", "测量上，官方的 nicht abgestimmt 只证明没投票，不证明身体缺席。本次为对照把它暂存于 absent 字段。模型未把‘人在场但主动不投票’作为人物的独立行动，不能解释所有未投票的形成机制。",
        "", "匿名成员有不同 ID，但同党使用同一套参数，所以本实验实质上仍是群体先验展开，不能冒充 733 份独立人物建模。",
        "", "## 各组逐项对照", "",
        "| 组别 | 基线 yes/no/abstain/absent | 真实 yes/no/abstain/未投票 |", "|---|---|---|",
    ]
    choices = ("yes","no","abstain","absent")
    for party, actual in ref["parties"].items():
        prior = summary["party_forecast"][party]["modal_counts"]
        lines.append(f"| {party} | {' / '.join(str(prior[k]) for k in choices)} | {' / '.join(str(actual[k]) for k in choices)} |")
    lines += ["", "## 预先列出的单因素敏感性（不选最好结果替换基线）", "",
              "| 变体 | 众数基线 | 条件运行分布 |", "|---|---|---|"]
    for item in summary["sensitivities"]:
        lines.append(f"| {item['name']} = {item['value']:.3f} | {item['baseline']['status']} | {json.dumps(item['ensemble']['outcome_counts'])} |")
    lines += [
        "", "## 防泄漏与限制", "",
        "- cutoff：2025-01-31 08:00 CET；使用表决前公开报道，网页未固定为当时的存档版本。",
        "- 真实结果已被研究者看到，因此不能声称独立盲测或严格预注册。",
        "- 支持党团席位在表决前 ARD 报道可核；其他组规模由官方结果页的成员结构元数据重建，未使用其实际投票字段生成预测。",
        "- 预测和对照分两步运行：预测函数不读取 reference.json；先保存输入与 forecast 的 SHA-256，再作比较。哈希只能防之后静默修改，不能消除研究者已知历史的偏差。",
        "- 未用任何人此次实际投票、真实出席率、或 2026 人物卡。没有按结果调参，没有寻找命中结果的 seed。",
        "- 形式规则按普通二元记名表决重建，本实验不等于全套历史法律程序审计。",
        "", "## 民调与 PSS", "",
        "此次只验证一项历史表决，不运行民意反馈，也未使用完整 Persona，故两项明确标为 NOT_RUN，不画虚构的民调／压力变化。完整箱庭情景仍须使用正常的逐节点曲线工作流。",
        "", "## 来源", "",
        f"- [Bundestag 官方结果]({ref['source']})",
        "- [表决前 ARD FAQ：2025-01-31 05:00](https://www.tagesschau.de/inland/innenpolitik/faq-abstimmung-bundestag-merz-gesetzentwurf-100.html)",
        "- [表决前 RND：2025-01-31 06:01](https://www.rnd.de/politik/zustrombegrenzungsgesetz-union-und-afd-stimmen-ueber-umstrittenes-gesetz-ab-GUG3EGVSIBFBLB5LFE5744PPNU.html)",
        "- [DLF：2025-01-30 的反对表态](https://www.deutschlandfunk.de/spd-und-gruene-fordern-von-cdu-chef-merz-verzicht-auf-gesetzesentwurf-mit-zustimmung-der-afd-100.html)",
        "", f"输入 SHA-256：`{summary['input_sha256']}`", "",
        "复现：先运行 `python3 -m hakoniwa.scenarios.zustrom_2025_vote_replay.run_scenario predict`，再运行同一模块的 `compare`。完整逐槽位评价在 forecast.json，参数与来源见 frozen_protocol.json、frozen_request.json、sources.json。",
    ]
    text = "\n".join(lines) + "\n"
    (output/"report.md").write_text(text,encoding="utf-8")
    (output/"report.html").write_text("<!doctype html><meta charset='utf-8'><title>Historical vote validation</title><style>body{max-width:1100px;margin:32px auto;padding:16px;font:16px/1.6 system-ui;background:#f7f5ef}pre{white-space:pre-wrap;overflow-wrap:anywhere}</style><pre>"+escape(text)+"</pre>",encoding="utf-8")


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("operation",choices=("predict","compare","run"),nargs="?",default="run")
    parser.add_argument("--output",type=Path,default=DEFAULT_OUTPUT)
    parser.add_argument("--runs",type=int,default=500)
    parser.add_argument("--sensitivity-runs",type=int,default=100)
    parser.add_argument("--seed",type=int,default=20250131)
    args = parser.parse_args(argv)
    if args.operation != "compare":
        summary = predict(args.output,runs=args.runs,sensitivity_runs=args.sensitivity_runs,seed=args.seed)
        print(json.dumps({"prediction_saved":str(args.output),"input_sha256":summary["input_sha256"],"baseline":summary["baseline"]["counts"],"ensemble":summary["ensemble"]["outcome_counts"]}))
    if args.operation != "predict":
        assessment = compare(args.output)
        print(json.dumps({"comparison":assessment["baseline_status"],"report":str(args.output/"report.md")},ensure_ascii=False))


if __name__ == "__main__":
    main()
