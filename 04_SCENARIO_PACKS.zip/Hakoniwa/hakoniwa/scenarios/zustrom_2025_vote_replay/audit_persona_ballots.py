"""Causal diagnostics of the named-voter adapter, without target-fitting.

Runs explicit mechanism ablations. They are diagnostics, not calibrated fixes.
Does not load the historical outcome or any later individual voting record.
"""
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path
from unittest.mock import patch

from .first_reading import HERE, load_cards, run_path, save
from .persona_ballots import prepare_protocol, decide_ballot, VALUE_CHANNELS
from ...persona_v2 import FreeAgentDecisionEngine
from ...party_interest import PartyInterestEngine


OUT=Path('outputs/zustrom_persona_audit_20261025')


def ballot_summary(path):
    return {'terminal':path['terminal'],'amended':path['amended'],'bill':path['final_bill'],
        'ballots':[{'date':n['calendar_date'],'stage':n['chosen_action'],
                    'counts':n['feedback']['result']['counts']}
                   for n in path['trace'] if n['chosen_action'] in ('second_reading_vote','third_reading_vote')]}


def main():
    p=prepare_protocol(json.loads((HERE/'first_reading_protocol.json').read_text()),
                       json.loads((HERE/'persona_voting_2024.json').read_text()))
    base=run_path(p)
    rows=[]
    for node in base['trace']:
        if not node['chosen_action'].startswith('second_reading:'):
            continue
        actor=node['actor']
        engine,_,_=load_cards(p)
        state=next(iter(node['evaluation']['scores'].values()))['diagnostics']['state_before']
        for key,value in state.items():
            setattr(engine.runtime[actor].state,key,value)
        solo=deepcopy(p);solo['persona_voting']['voters']=[actor]
        _,replayed=decide_ballot(solo,engine,node['beliefs']['public_text'],node['beliefs']['public_whips'],
                                node['calendar_date'],'second_reading')
        # Diagnostic ablation: remove policy gain's second entry through upside/
        # loss; keep the goal, public exposure and all personality weights fixed.
        original=FreeAgentDecisionEngine.decide
        def without_duplicate(self,who,actions,resources,**kwargs):
            changed=[]
            for action in actions:
                gain=action.goal_impacts.get('policy_alignment',0.)
                changed.append(replace(action,upside=0.,downside=max(0.,action.downside-max(0.,-gain))))
            return original(self,who,changed,resources,**kwargs)
        with patch.object(FreeAgentDecisionEngine,'decide',without_duplicate):
            _,ablated=decide_ballot(solo,engine,node['beliefs']['public_text'],node['beliefs']['public_whips'],
                                    node['calendar_date'],'second_reading')
        weights={v.key:v.weight for v in engine.cards[actor].dna.value_hierarchy}
        covered=sum(v for k,v in weights.items() if k in VALUE_CHANNELS)
        scores=node['evaluation']['scores']
        ranking=sorted(scores.values(),key=lambda x:x['total'],reverse=True)
        rows.append({'actor':actor,'scores':{k:v['total'] for k,v in scores.items()},
            'winner_gap':round(ranking[0]['total']-ranking[1]['total'],3),
            'value_weight_coverage':round(covered/sum(weights.values()),3),
            'unmapped_values':[k for k in weights if k not in VALUE_CHANNELS],
            'constant_channels':[key for key in ('resource_feasibility','current_state_modifier','memory_modifier','environment_compatibility')
                                 if len({v[key] for v in scores.values()})==1],
            'common_policy_gain':node['feedback']['adapter_assumptions']['policy_gain'],
            'snapshot_replay_choice':replayed[0]['choice'],
            'without_duplicate_policy_risk_choice':ablated[0]['choice'],
            'without_duplicate_policy_risk_scores':{k:v['total'] for k,v in ablated[0]['evaluation']['scores'].items()}})
    # Full-path diagnostic: a consultation attempt is not confirmed permission
    # from all other parties. Remove only that automatic support payoff.
    original_party=PartyInterestEngine.decide
    def no_automatic_agreement(self,party,options,*args,**kwargs):
        changed=[]
        for action in options:
            impacts=dict(action.party_strategy_impacts)
            if action.key=='support' and impacts.get('coalition_reliability')==1.:
                impacts['coalition_reliability']=0.
            changed.append(replace(action,party_strategy_impacts=impacts))
        return original_party(self,party,changed,*args,**kwargs)
    with patch.object(PartyInterestEngine,'decide',no_automatic_agreement):
        consultation_control=run_path(p)
    second=next(n for n in base['trace'] if n['chosen_action']=='second_reading_vote')
    counts=second['feedback']['result']['counts']
    bound={'baseline_yes_minus_no':counts['yes']-counts['no'],'controlled_seats':9,
           'maximum_margin_shift_if_all_nine_yes_to_no':18,
           'all_nine_no_counts':dict(counts,yes=counts['yes']-9,no=counts['no']+9)}
    OUT.mkdir(parents=True,exist_ok=True)
    save(OUT/'diagnostics.json',{'scope':'conditional mechanism audit, not historical validation',
        'persona_score_audit':rows,'baseline':ballot_summary(base),
        'no_automatic_consultation_payoff':ballot_summary(consultation_control),'counting_bound':bound})
    text=['# 九人格投票问题审计','',
        '本审计不读取历史目标，不寻找能复现目标的参数。对照变体仅用于定位机制。','',
        '## 已证实的问题','',
        '1. 九张卡只控制九票。379对304的75票差，九人全部倒戈也仅改变18票差，仍370对313。因此总结果不变不能证明人格模块不敏感。',
        '2. 每人使用同一政策位置先验和0.805的政策收益；政策收益同时进入目标得分、upside和负向downside，属于没有说明独立渠道的重复计入。',
        '3. 价值映射并不完整；未映射价值在本节点没有得分信号，并非这些价值在现实中不重要。具体覆盖率见表。',
        '4. 三个动作没有资源要求或资源成本，resource_feasibility均15.000；七位新增人物的0.500资源没有对选择产生区分作用。',
        '5. 各动作的压力输入、工作量、曝光和控制恢复设置相同，current_state_modifier在每位人物内部是相同常数。压力仍可通过风险偏好间接作用，但不能把曲线存在当作压力已充分驱动选择。',
        '6. 未来记忆和关系被全部清除；本节点无target_actor或关系输入。因而未检验个人忠诚、人情、网络动员或领袖背书。',
        '7. 旧回放将咨询尝试和提出修改直接设置为consultations=True，随后所有其他党支持选项的coalition_reliability变为1。没有逐党答复，跨党协商回报发生在确认之前。',
        '8. 新人物直到投票才参与，不能发起会前异议、修正案或动员。增加投票人数不等于增加整条决策链的参与者。','',
        '## 本轮修复的工程问题','',
        '- 固定每张卡对应的匿名先验席位，避免调整名单顺序或启用子集后偷偷更换个人政策先验。',
        '- 政策轴采用显式顺序，避免JSON键重排导致数组中的党派理想点错配。',
        '- 投票准备成本不再携带虚构结果证据；保留工作量，evidence_quality=0。','',
        '## 二读评分诊断','',
        '|人物|赞成|反对|弃权|胜出差|价值权重覆盖|移除重复政策风险项后|',
        '|---|---:|---:|---:|---:|---:|---|']
    for r in rows:
        scores=r['scores']
        text.append(f"|{r['actor']}|{scores['second_reading:vote_yes']:.3f}|{scores['second_reading:vote_no']:.3f}|{scores['second_reading:vote_abstain']:.3f}|{r['winner_gap']:.3f}|{r['value_weight_coverage']:.3f}|{r['without_duplicate_policy_risk_choice']}|")
    text+=['','## 协商机制对照','',json.dumps(ballot_summary(consultation_control),ensure_ascii=False,indent=2),
        '', '这是单个机制变体，不是校准后的新预测。未改变默认协商行为、人格权重或政策位置；不能选择更接近历史的变体充当成功。',
        '', '优先级：先拆开咨询尝试、对方回应与协议；再为逐议题政策立场和组织关系提供冻结证据；然后把人物放进会前协商/修改文本/动员过程。不能为制造反对票而强行增加随机性。']
    (OUT/'report.md').write_text('\n'.join(text))
    print(json.dumps({'baseline':ballot_summary(base),'consultation_control':ballot_summary(consultation_control),
                      'rows':rows,'counting_bound':bound},ensure_ascii=False))


if __name__=='__main__': main()
