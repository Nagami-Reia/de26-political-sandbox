"""Optional named-persona ballots inside the existing first-reading experiment.

Only verified 20th-term members replace anonymous seats. This is not a new
decision engine; action interpretation is an explicit, uncalibrated adapter.
"""
from copy import deepcopy
import math

from ...persona_v2 import ActionOption
from ...plugins.majorities.integration import persona_ballot_decision
from ...plugins.majorities.mechanisms import instruction_components


SEAT_ORDER = ("Merz", "Frei", "Linnemann", "Wadephul", "Dobrindt",
              "Warken", "Baer", "Hoppermann", "Amthor")
ELIGIBLE_2024 = frozenset(SEAT_ORDER)
POLICY_AXES = ("limitation_purpose", "family_reunion_stop", "federal_police_removal")
RESOURCE_KEYS = frozenset(("formal_power", "organization_base", "parliamentary_base",
                           "network_capital", "public_capital", "future_option"))
VALUE_CHANNELS = {
    "unity": "coherence", "organization_success": "coherence",
    "political_stability": "coherence", "institutional_loyalty": "coherence",
    "organizational_trust": "coherence", "csu_leverage": "coherence",
    "political_authority": "public_credibility", "social_legitimacy": "public_credibility",
    "democratic_differentiation": "public_credibility",
    "public_opportunity_frame": "public_credibility", "clarity": "clarity",
    "evidence_based_judgment": "evidence",
}


def unit(value, name):
    if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) or not 0 <= value <= 1:
        raise ValueError(f"{name} must be a finite number in 0..1")


def prepare_protocol(protocol, configuration, mode="persona"):
    p, cfg = deepcopy(protocol), deepcopy(configuration)
    if cfg.get("schema_version") != "zustrom-persona-ballots-1.0" or cfg.get("cutoff") != p["cutoff"]:
        raise ValueError("Persona ballot configuration must match this historical freeze")
    if mode not in {"persona", "background_control"}:
        raise ValueError("Unknown persona ballot mode")
    voters = cfg.get("voters", [])
    if not voters or len(voters) != len(set(voters)) or set(voters)-ELIGIBLE_2024:
        raise ValueError("Only distinct verified 2024 Bundestag persona voters may be enabled")
    if set(cfg.get("ordinary_member_resources", {})) != RESOURCE_KEYS:
        raise ValueError("Declare all ordinary-member resources; never inherit 2026 ministerial offices")
    for key, value in cfg["ordinary_member_resources"].items():
        unit(value, key)
    for key in ("information_confidence", "public_controversy_exposure", "preparation_workload"):
        unit(cfg[key], key)
    cfg["mode"] = mode
    p["persona_voting"] = cfg
    for actor in voters:
        if actor not in p["assumptions"]["actor_ids"]:
            p["assumptions"]["actor_ids"].append(actor)
            p["assumptions"]["resources"][actor] = deepcopy(cfg["ordinary_member_resources"])
    return p


def replacement_plan(p):
    voters = p.get("persona_voting", {}).get("voters", [])
    seats = p["facts"]["seats"]["CDU_CSU"]
    if len(voters) > seats or set(voters)-ELIGIBLE_2024 or len(set(voters)) != len(voters):
        raise ValueError("Invalid persona seat replacement")
    # Fixed epistemic slot per eligible card: reordering or enabling a subset
    # must not silently assign that person a different background policy prior.
    return {actor: f"ANON_CDU_CSU_{int((SEAT_ORDER.index(actor)+.5)*seats/len(SEAT_ORDER)):03d}"
            for actor in voters}


def replace_roster(p, members):
    plan = replacement_plan(p)
    reverse = {slot: actor for actor, slot in plan.items()}
    rows = deepcopy(members)
    found = set()
    for row in rows:
        if row["id"] in reverse:
            found.add(row["id"])
            row["id"] = reverse[row["id"]]
    if found != set(reverse) or len({row["id"] for row in rows}) != len(rows):
        raise ValueError("Persona voters must replace, never duplicate, eligible seats")
    return rows


def decide_ballot(p, engine, bill, whips, at, version, *, procedural=False):
    cfg = p.get("persona_voting", {})
    if cfg.get("mode") != "persona":
        return {}, []
    patches, records = {}, []
    reference = p["assumptions"].get("vote_status_quo", {}).get("position", {})
    axes = POLICY_AXES
    if set(p['facts']['bill_components']) != set(axes) or set(bill) != set(axes):
        raise ValueError('Persona ballot requires the declared three policy axes')
    ideal = dict(zip(axes, p["assumptions"]["party_ideals"]["CDU_CSU"]))
    # This common ideological prior is an assumption, not researched personal
    # opinions. Never use later actual individual ballots as policy positions.
    gain = (sum(abs(ideal[k]-reference[k])-abs(ideal[k]-bill[k]) for k in axes)/len(axes)
            if not procedural and set(axes) <= set(reference) else 0.)
    instruction = whips.get("CDU_CSU", {})
    instruction_state=instruction_components(instruction,secret=False,observability=1.)
    coherence = instruction_state['signal']
    exposure = cfg["public_controversy_exposure"] if not procedural and whips.get("AfD", {}).get("stance", 0)>0 else 0.
    confidence = cfg["information_confidence"]
    features = {
        "yes": {"coherence": coherence, "public_credibility": -exposure,
                "clarity": .5, "evidence": confidence-.5},
        "no": {"coherence": -coherence, "public_credibility": -.15 if coherence > 0 else 0.,
               "clarity": .5, "evidence": confidence-.5},
        "abstain": {"coherence": -.25*abs(coherence), "public_credibility": -.1,
                    "clarity": -.5, "evidence": .5-confidence},
    }
    # Decide everyone before applying any outcome: no one sees a peer's choice
    # merely because their name happens to be earlier in this list.
    for actor in cfg["voters"]:
        profile=engine.cards[actor].components.get('voting',{}).get('issue_adapters',{}).get('zustrom_2024',{})
        value_channels=profile.get('value_channel_map',VALUE_CHANNELS)
        options = {}
        for label, sign in (("yes", 1), ("no", -1), ("abstain", 0)):
            values = {v.key: features[label][value_channels[v.key]]
                      for v in engine.cards[actor].dna.value_hierarchy if v.key in value_channels}
            policy = sign*gain if not procedural else sign*.5
            reputational_risk = max(0., -features[label]["public_credibility"])
            options[label] = ActionOption(f"{version}:vote_{label}",
                goal_impacts={"policy_alignment": policy, "public_clarity": features[label]["clarity"]},
                value_impacts=values, upside=max(0., policy),
                downside=min(1., max(0., -policy)+reputational_risk),
                uncertainty=1-confidence, effort=.1, visibility=.8,
                information_confidence=confidence, irreversibility=.25,
                conflict_strategy="institutionalize", control_domains=("parliamentary_process",),
                identity_tags=("parliamentary_process",), risk_tags=("public_vote",))
        decision = persona_ballot_decision(engine, actor, options,
            p["assumptions"]["resources"][actor], issue_id=f"20_12804:{version}",
            available_from=at, goals={"policy_alignment": .7, "public_clarity": .3})
        patches[actor] = decision["member_patch"]
        records.append({"actor": actor, "choice": decision["member_patch"]["decided_vote"],
            "evaluation": decision["persona_trace"],
            "beliefs": {"public_text": deepcopy(bill), "public_whips": deepcopy(whips),
                "private_majority_count": "UNKNOWN", "peer_votes": "NOT_VISIBLE_BEFORE_BALLOT"},
            "adapter_assumptions": {"policy_gain": gain, "common_party_ideal": ideal,
                "perceived_party_instruction":instruction_state,
                "public_controversy_exposure": exposure, "mapped_value_channels": value_channels,
                "unmapped_values": [v.key for v in engine.cards[actor].dna.value_hierarchy if v.key not in value_channels],
                "status": "UNVALIDATED_BALLOT_INTERPRETATION_NOT_MEASURED_PREFERENCES"}})
    return patches, records
