"""Outcome-separated, coarse historical validation of the majority plugin."""
