"""First-reading frozen replay using existing persona/party/majorities engines.

This is an inspectable conditional experiment, NOT an independent blind test.
Later real-world shocks are deliberately not read by the forecast function.
"""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
from dataclasses import asdict
from datetime import date, timedelta
from html import escape
import json
from pathlib import Path
import tempfile

from ...persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine
from ...persona_repository import load_persona_payload
from ...party_interest import PartyInterestEngine, PartyInterestProfile, PartyState
from ...plugins.majorities import MajorityModel
from ...plugins.majorities.model import rng_for
from ...scenario_reporting import ScenarioReportCompiler
from .run_scenario import HERE, digest, save
from .persona_ballots import prepare_protocol, replace_roster, replacement_plan, decide_ballot

ROOT = HERE.parents[1]
OUT = Path("outputs/zustrom_first_reading")
AXES = ("limitation_purpose", "family_reunion_stop", "federal_police_removal")
COALITION = ("SPD", "Greens", "FDP")


def clip(v):
    return max(0., min(1., v))


def consultation_context(attempts):
    """Initiating contact or offering text is not the recipient's agreement.

    This replay has no confirmed bilateral-response ledger. Unknown acceptance
    supplies no positive or negative cooperation payoff; it remains explicit.
    """
    return {'attempted':bool(attempts),'counterparty_acceptance':'UNKNOWN',
            'cooperation_payoff':0.,'confirmed_deliberation_payoff':0.,
            'status':'NO_CONFIRMED_RECIPIENT_RESPONSE'}


def vote_channels(payload):
    rows=list(payload['member_evaluations'].values())
    return {'choice_sources':dict(Counter(x['choice_source'] for x in rows)),
        'active_network_members':sum(x.get('local_utilities_used_for_choice',False) and abs(x.get('weighted_terms',{}).get('network',0))>0 for x in rows),
        'active_background_discipline_members':sum(x.get('local_utilities_used_for_choice',False) and abs(x.get('weighted_terms',{}).get('discipline',0))>0 for x in rows),
        'diagnostic_discipline_modes':dict(Counter(x.get('discipline_diagnostics',{}).get('mode','NOT_APPLICABLE') for x in rows)),
        'local_effects_are_diagnostic_only_for_persona_decisions':True,
        'evaluation_contract':payload.get('evaluation_contract',{})}


def load_cards(protocol):
    raw = load_persona_payload(ROOT / "data/personas/cards_pss.json")
    sanitized = {"schema_version": raw["schema_version"], "actors": {}}
    audit = {}
    for actor in protocol["assumptions"]["actor_ids"]:
        row = deepcopy(raw["actors"][actor])
        components = row.pop('_components', {})
        # Use the modular voting adapter without importing current offices,
        # relationships, research annotations or post-freeze event memories.
        if 'voting' in components:
            row['_components'] = {'voting': deepcopy(components['voting'])}
        audit[actor] = {"removed_memories": [m.get("event_id") for m in row.get("event_memory", [])],
                        "removed_relationships": list(row.get("relationship_memory", {})),
                        "component_source": "REGISTERED_PERSONA_DIRECTORIES",
                        "retained_functional_components": list(row.get('_components', {})),
                        "research_notes_imported_into_actor_beliefs": False}
        row["event_memory"] = []
        row["relationship_memory"] = {}
        row["initial_resources"] = deepcopy(protocol["assumptions"]["resources"][actor])
        row["initial_current_state"] = deepcopy(protocol["assumptions"]["initial_pss"])
        sanitized["actors"][actor] = row
    with tempfile.NamedTemporaryFile("w", suffix=".json", encoding="utf-8") as stream:
        json.dump(sanitized, stream)
        stream.flush()
        engine = FreeAgentDecisionEngine.from_json(stream.name)
    return engine, sanitized, audit


def party_engine(p):
    profiles = {}
    for party, ideal in p["assumptions"]["party_ideals"].items():
        if party in ("CDU_CSU", "Independent"):
            continue
        profiles[party] = PartyInterestProfile(
            party_id=party, label=party + " 2024 conditional collective",
            stable_interests={"policy_gain":.900, "democratic_compromise":.600},
            policy_positions={k:2*v-1 for k,v in zip(AXES, ideal)},
            issue_salience=dict.fromkeys(AXES, .700),
            strategic_interests={"coalition_reliability":.900 if party in COALITION else .200,
                                "opposition_differentiation":.700, "decision_cost":.650},
            organizational_interests={"unity":.800},
            default_state=PartyState(government_responsibility=float(party in COALITION),
                coalition_dependency=p["assumptions"]["coalition_dependency"] if party in COALITION else 0.),
            evidence_confidence=.400, epistemic_note="All numeric preferences/weights are assumptions, NOT frozen individual pledges.")
    return PartyInterestEngine(profiles)


def make_roster(p, seed):
    a = p["assumptions"]
    members = []
    for party, seats in p["facts"]["seats"].items():
        for i in range(seats):
            key = f"ANON_{party}_{i:03d}"
            # Unknown fixed preferences, not randomly changing personalities.
            offset = (2*(i+.5)/seats-1)*a["member_policy_dispersion"]
            if seed is not None:
                offset += rng_for(seed, "unknown_preference", key).gauss(0, a["information_sigma"])
            members.append({"id":key,"party":party,
                "position":{k:clip(v+offset) for k,v in zip(AXES,a["party_ideals"][party])},
                "weights":{"policy":a["policy_weight"],"discipline":a["discipline_weight"],"mandate":a["coalition_weight"]},
                "attendance":a["participation_proxy"],"temperature":a["temperature"],
                "abstain_utility":.050,"source_status":"MODEL_ASSUMPTION"})
    return replace_roster(p, members)


def vote_model(p, members, bill, whips, at, version, *, procedural=False, persona_patches=None):
    rows = deepcopy(members)
    patches = persona_patches or {}
    if set(patches)-{m['id'] for m in rows}:
        raise ValueError('Persona patch has no eligible seat')
    assessments = {}
    for member in rows:
        if procedural:
            # Preference on migration is not a preference on granting debate.
            member["position"] = {"grant_debate":.500}
        assessments[member["id"]] = {"mandate":(-p["assumptions"]["coalition_dependency"]
            if member["party"] in COALITION and whips.get(member["party"],{}).get("stance",0) <= 0 and not procedural else 0.)}
        if member['id'] in patches:
            member.update(patches[member['id']])
            member['position'] = {}
            member['weights'] = {}
    request = {
        "schema_version":"hakoniwa-majorities-1.0","as_of":at,
        "body":{"id":"Bundestag_20","kind":"bundestag","secret":False},
        "rule":{"total_weight":sum(p["facts"]["seats"].values()),"kind":"simple_cast","quorum":"presumed",
                "source_status":"MODEL_ASSUMPTION","authority":"Ordinary count abstraction; agenda and constitutional details not fully compiled"},
        "members":rows,"issue":{"id":"20_12804","version":version,"proposer":"CDU_CSU",
            "position":{"grant_debate":.500} if procedural else bill,"assessments":assessments,"whips":whips},
        "contingencies":[{"id":party,"sigma":p["assumptions"]["shared_ballot_sigma"],
            "loadings":{m["id"]:1. for m in members if m["party"]==party},
            "reason":"Unobserved final faction-level information, not random personality", "source_status":"MODEL_ASSUMPTION"}
            for party in p["facts"]["seats"] if party!="Independent"],
    }
    # This is a comparison with the declared rejection reference, not with a
    # guessed midpoint. Missing references stay unknown under the current engine.
    # Migration is explicit in the frozen protocol, not inferred from target votes.
    if not procedural and p["assumptions"].get("vote_status_quo") is not None:
        request["issue"]["status_quo"] = deepcopy(p["assumptions"]["vote_status_quo"])
    return MajorityModel(request)


def run_path(p, seed=None, *, detailed=True):
    # A finite horizon only bounds this loop if its clock actually advances.
    for key,minimum in (('round_days',1),('first_deliberation_days',0)):
        value=p['assumptions'][key]
        if type(value) is not int or value<minimum:
            raise ValueError(f'{key} must be an integer >= {minimum}')
    if date.fromisoformat(p['horizon'])<=date.fromisoformat(p['cutoff'][:10]):
        raise ValueError('Replay horizon must be after the freeze')
    engine, cards, card_audit = load_cards(p)
    parties = party_engine(p)
    members = make_roster(p, seed)
    bill = deepcopy(p["facts"]["bill_components"])
    original_bill = dict(bill)
    whips = {"CDU_CSU":{"stance":1.,"intensity":p["assumptions"]["whip_intensity"]}}
    trace = []
    stage, terminal = "FIRST_READING", None
    at = date.fromisoformat(p["cutoff"][:10])
    deadline = date.fromisoformat(p["horizon"])
    info_quality, reported_margin = .350, None
    report_ready, amended = False, False
    consultation_attempts = []
    work_rounds, previous_at = 0, at
    initial_pss = {a:asdict(engine.runtime[a].state) for a in engine.runtime}
    persona_ballots = []

    def record(actor, action, evaluation, before, feedback, beliefs=None):
        row = {"node":f"N{len(trace)+1:03d}","calendar_date":at.isoformat(),
            "actor":actor,"chosen_action":action,"stage_before":before,"stage_after":stage,
            "evaluation":evaluation,"beliefs":beliefs or {},"feedback":feedback,
            "bill_after":dict(bill),"whips_after":deepcopy(whips),
            "all_actor_pss_after":{a:asdict(engine.runtime[a].state) for a in engine.runtime}}
        if actor in engine.runtime:
            row["decision_maker"] = actor
        trace.append(row)

    def choose(actor, options, goals, beliefs):
        decision = engine.decide(actor, options, p["assumptions"]["resources"][actor], current_goals=goals)
        return decision.chosen_action, asdict(decision)

    def settle_ballot(instructions, version, random_key, procedural=False):
        patches, decisions = decide_ballot(p, engine, bill, instructions, at.isoformat(), version, procedural=procedural)
        model = vote_model(p, members, bill, instructions, at.isoformat(), version,
                           procedural=procedural, persona_patches=patches)
        result = model.baseline() if seed is None else model.ballot(rng_for(seed, random_key, at.isoformat()).getrandbits(128))
        result['causal_channels']=vote_channels(result)
        for d in decisions:
            actor = d['actor']
            # Preparation cost, without inventing policy success or relational damage.
            engine.apply_outcome(actor, ActionOutcome(f'{version}:vote_{d["choice"]}', success=.5,
                expected_success=.5, evidence_quality=0., workload=p['persona_voting']['preparation_workload'], outcome_scope=.1))
            record(actor, f'{version}:vote_{d["choice"]}', d['evaluation'], stage,
                   {'own_seat_weight':1, 'automatic_followers':0, 'adapter_assumptions':d['adapter_assumptions'],
                    'preparation_only':True}, d['beliefs'])
        persona_ballots.append({'version':version, 'date':at.isoformat(),
            'intentions':{d['actor']:d['choice'] for d in decisions},
            'member_ballots':{k:v for k,v in (result['result'].get('member_ballots') or {}).items() if k in patches}})
        return result

    # The freeze includes the scheduled first reading, not its actual speeches.
    stage = "COMMITTEE"
    record("Procedure", "normal_first_reading_referral", {}, "FIRST_READING",
           {"action_outcome":"Debate/referral modeled as normal route", "institutional_outcome":"COMMITTEE",
            "world_outcome":"No substantive bill adoption", "assumption":"No contested referral modeled; not independently reproduced"})
    at += timedelta(days=p["assumptions"]["first_deliberation_days"])
    while at <= deadline and terminal is None:
        for actor in engine.runtime:
            engine.advance_time(actor, (at-previous_at).days, workload=.020)
        previous_at = at
        work_rounds += 1
        truth_model = vote_model(p,members,bill,whips,at.isoformat(),f"round{work_rounds}")
        expected = truth_model.baseline()["expected_counts_without_shared_shocks"]
        # Only Frei's report delivers an aggregate estimate to the leader.
        frei_options = [
            ActionOption("audit_commitments",goal_impacts={"majority_security":.850*(1-info_quality)},
                value_impacts={"organization_success":.750},uncertainty=.250,effort=.450,restores_control=.650,control_domains=("organization",)),
            ActionOption("private_cross_party_consultation",goal_impacts={"majority_security":.650,"compromise":.750},
                value_impacts={"political_stability":.800},uncertainty=.500,effort=.650,downside=.250,
                conflict_strategy="negotiate",control_domains=("organization",),restores_control=.450),
            ActionOption("mobilize_announced_supporters",goal_impacts={"majority_security":.500+max(0,reported_margin or 0.)},
                value_impacts={"organization_success":.650},uncertainty=1-info_quality,effort=.400,
                downside=.350,restores_control=.700,control_domains=("organization",)),
        ]
        action, ev = choose("Frei",frei_options,{"majority_security":1.,"compromise":.700},
                            {"previous_report":reported_margin})
        if action=="audit_commitments":
            info_quality=clip(info_quality+p["assumptions"]["probe_information_gain"])
            # Only the selected information-gathering action earns this
            # aggregate report. Consultation is NOT a free omniscient audit.
            reported_margin=(expected["yes"]-expected["no"])/len(members)
            if seed is not None:
                reported_margin+=rng_for(seed,"report",at.isoformat()).gauss(0,p["assumptions"]["information_sigma"]*(1-info_quality))
        elif action=="private_cross_party_consultation":
            consultation_attempts.append({'actor':'Frei','date':at.isoformat(),'type':'CONTACT_ATTEMPT','recipient_reply':'UNKNOWN'})
        else:
            for member in members:
                if whips.get(member["party"],{}).get("stance",0)>0:
                    member["attendance"]=clip(member["attendance"]+p["assumptions"]["mobilization_participation_gain"])
        engine.apply_outcome("Frei",ActionOutcome(action,success=.500,workload=p["assumptions"]["workload_per_decision"],
            control_restoration=.020 if action=="audit_commitments" else 0.,outcome_scope=.200))
        record("Frei",action,ev,stage,{"delivered_to":["Merz"],"report_margin":reported_margin,
            "new_aggregate_report":action=="audit_commitments",
            "forecast_scope":"BACKGROUND_PRIORS_FOR_ALL_SEATS_INCLUDING_UNOBSERVED_PERSONA_VOTES",
            "forecast_is_actual_vote":False,
            "confidence":info_quality,"participation_is_proxy_not_known_physical_presence":True},
            {"prior_report_only":True,"new_report_uncertain":True})

        # Every other faction chooses for itself from policy/coalition interests.
        for party, profile in parties.profiles.items():
            ideal=p["assumptions"]["party_ideals"][party]
            fit=1-sum(abs(v-bill[k]) for k,v in zip(AXES,ideal))/3
            contact=consultation_context(consultation_attempts)
            options=[
                ActionOption("support",issue_positions={k:2*v-1 for k,v in bill.items()},
                    party_interest_impacts={"policy_gain":2*fit-1,"democratic_compromise":contact['confirmed_deliberation_payoff']},
                    party_strategy_impacts={"coalition_reliability":contact['cooperation_payoff'],"opposition_differentiation":.300,"decision_cost":.300},
                    organizational_impacts={"unity":fit},objective_feasibility=.800),
                ActionOption("oppose",issue_positions=dict.fromkeys(AXES,-1.),
                    party_interest_impacts={"policy_gain":1-2*fit,"democratic_compromise":.000},
                    party_strategy_impacts={"coalition_reliability":.700,"opposition_differentiation":.700,"decision_cost":.100},
                    organizational_impacts={"unity":.650},objective_feasibility=.900),
                ActionOption("request_amendment",issue_positions={k:2*((bill[k]+v)/2)-1 for k,v in zip(AXES,ideal)},
                    party_interest_impacts={"policy_gain":fit,"democratic_compromise":.800},
                    party_strategy_impacts={"coalition_reliability":.650,"opposition_differentiation":.100,
                        "decision_cost":-min(1.,(at-date.fromisoformat(p["cutoff"][:10])).days/90)},
                    organizational_impacts={"unity":.700},objective_feasibility=.550),
            ]
            decision=parties.decide(party,options)
            stance={"support":1.,"oppose":-1.,"request_amendment":0.}[decision.chosen_action]
            whips[party]={"stance":stance,"intensity":p["assumptions"]["whip_intensity"]}
            record(party,decision.chosen_action,decision.payload(),stage,
                {"public_instruction_not_individual_vote":True,"consultation_context":contact,
                 "counterproposal":dict(zip(AXES,ideal)) if stance==0 else None})

        if work_rounds>=p["assumptions"]["committee_work_rounds"] and not report_ready:
            report_ready=True
            record("Committee","complete_advisory_report",{},stage,
                {"assumed_capacity_rounds":work_rounds,"report_published":True,"recommendation_is_not_plenary_adoption":True,
                 "scope":"Committee recommendation tally not calibrated; no actual November report imported"})
        belief={"report_margin":reported_margin,"confidence":info_quality,"public_whips":deepcopy(whips),"report_ready":report_ready}
        remaining=max(0.,(deadline-at).days/(deadline-date.fromisoformat(p["cutoff"][:10])).days)
        probable=clip(.500+(reported_margin or 0.))
        compromise_cost=sum(abs(bill[k]-p["assumptions"]["party_ideals"]["CDU_CSU"][i]) for i,k in enumerate(AXES))/3
        options=[
            ActionOption("maintain_text_and_wait",goal_impacts={"strategic_direction":.750,"reform":remaining*.450},
                value_impacts={"strategic_direction":.750,"unity":.550},downside=.300+.400*(1-remaining),
                uncertainty=1-info_quality,effort=.150,restores_control=.300,control_domains=("direction",)),
            ActionOption("offer_substantive_compromise",goal_impacts={"strategic_direction":.300,"reform":.750},
                value_impacts={"strategic_direction":.350-compromise_cost,"unity":.750},
                downside=.350+compromise_cost,upside=.650,uncertainty=.400,effort=.600,
                conflict_strategy="negotiate",restores_control=.600,control_domains=("direction","process")),
            ActionOption("request_plenary_agenda",goal_impacts={"strategic_direction":.850,"reform":probable},
                value_impacts={"strategic_direction":.850,"political_authority":.650},upside=.800,
                downside=1-probable,uncertainty=1-info_quality,irreversibility=.700,effort=.450,
                legal=report_ready,restores_control=.750,control_domains=("direction",)),
            ActionOption("withdraw_proposal",goal_impacts={"strategic_direction":-.600,"reform":-.800},
                value_impacts={"unity":.800,"political_authority":-.500},downside=.450,effort=.100,
                uncertainty=.200,restores_control=.400,control_domains=("process",)),
        ]
        action,ev=choose("Merz",options,{"strategic_direction":1.,"reform":.900},belief)
        before=stage
        if action=="offer_substantive_compromise":
            target=p["assumptions"]["party_ideals"]["FDP"]
            for k,v in zip(AXES,target):
                bill[k]+=p["assumptions"]["offer_movement"]*(v-bill[k])
            consultation_attempts.append({'actor':'Merz','date':at.isoformat(),'type':'TEXT_OFFER','recipient_reply':'UNKNOWN'})
            amended=bill!=original_bill
            # New text requires renewed committee work, not instant floor access.
            report_ready=False
            work_rounds=0
        elif action=="withdraw_proposal":
            stage=terminal="WITHDRAWN"
        engine.apply_outcome("Merz",ActionOutcome(action,success=.500,
            workload=p["assumptions"]["workload_per_decision"],outcome_scope=.200))
        record("Merz",action,ev,before,{"amended":amended,"institutional_success_not_assumed":True},belief)
        recess=(at.month==12 and at.day>=20) or (at.month==1 and at.day<=5)
        if action=="request_plenary_agenda" and report_ready and not recess:
            # Granting debate is a distinct institutional vote, not passage.
            agenda_whips={"CDU_CSU":{"stance":1.,"intensity":p["assumptions"]["whip_intensity"]}}
            for party in parties.profiles:
                # A distinct collective decision on procedure. No fixed
                # government=no / opposition=yes scheduling shortcut.
                options=[
                    ActionOption("grant_debate",party_interest_impacts={"democratic_compromise":.800,"policy_gain":.000},
                        party_strategy_impacts={"coalition_reliability":.300,"opposition_differentiation":.450,"decision_cost":.350},
                        organizational_impacts={"unity":.250},objective_feasibility=.800),
                    ActionOption("defer_debate",party_interest_impacts={"democratic_compromise":-.450,"policy_gain":.000},
                        party_strategy_impacts={"coalition_reliability":.750,"opposition_differentiation":-.200,"decision_cost":-.350},
                        organizational_impacts={"unity":.650},objective_feasibility=.750),
                ]
                response=parties.decide(party,options)
                agenda_whips[party]={"stance":1. if response.chosen_action=="grant_debate" else -1.,
                    "intensity":p["assumptions"]["whip_intensity"]}
                record(party,response.chosen_action,response.payload(),stage,{"procedural_decision_not_bill_support":True})
            voted=settle_ballot(agenda_whips,"agenda","agenda",procedural=True)
            record("Bundestag","agenda_request_vote",voted if detailed else {},stage,
                {"result":voted["result"],"causal_channels":voted['causal_channels'],"assumption":"Independent party procedural choices; ordinary procedural count abstraction"})
            if voted["result"]["passed"]:
                before=stage; stage="SECOND_READING"
                voted=settle_ballot(whips,"second_reading","second")
                stage="THIRD_READING_READY" if voted["result"]["passed"] else "REJECTED_SECOND_READING"
                record("Bundestag","second_reading_vote",voted if detailed else {},before,{"result":voted["result"],"causal_channels":voted['causal_channels']})
                if not voted["result"]["passed"]:
                    terminal=stage
                else:
                    # No new floor amendments modeled: next reading is allowed,
                    # but still needs its own independent joint ballot.
                    before=stage
                    third=settle_ballot(whips,"third_reading","third")
                    stage="BUNDESTAG_ADOPTED_BUNDESRAT_PENDING" if third["result"]["passed"] else "REJECTED_THIRD_READING"
                    terminal=stage
                    record("Bundestag","third_reading_vote",third if detailed else {},before,
                        {"result":third["result"],"causal_channels":third['causal_channels'],"law_in_force":False,"floor_amendments":False})
        at+=timedelta(days=p["assumptions"]["round_days"])
    return {"seed":seed,"terminal":terminal or "PENDING_AT_HORIZON","final_stage":stage,
        "amended":amended,"final_bill":bill,"initial_pss":initial_pss,"trace":trace,
        "cards_used":cards,"card_sanitization":card_audit,"arcana":False,
        "persona_ballots":persona_ballots,"persona_voting":p.get('persona_voting'),"seat_replacements":replacement_plan(p),
        "consultation_attempts":consultation_attempts,
        "cooperation_settlement":"UNKNOWN_RECIPIENT_ACCEPTANCE_NEVER_AUTO_REWARDED",
        "polling":{"status":"NOT_RUN_FUTURE_ANCHOR_BLOCKED","reason":p["contract"]["polling"]},
        "historical_world_limitation":p["contract"]["later_actual_events"]}


def predict(output=OUT,runs=100,protocol=None):
    p=deepcopy(protocol) if protocol is not None else json.loads((HERE/"first_reading_protocol.json").read_text())
    output.mkdir(parents=True,exist_ok=True)
    save(output/"frozen_protocol.json",p)
    save(output/"sources.json",json.loads((HERE/"first_reading_sources.json").read_text()))
    baseline=run_path(p)
    save(output/"baseline.json",baseline)
    save(output/"cards_used.json",baseline["cards_used"])
    rows=[]
    for index in range(runs):
        path=run_path(p,rng_for(p["seed"],"path",index).getrandbits(128),detailed=False)
        rows.append({"seed":path["seed"],"terminal":path["terminal"],"amended":path["amended"],
            "nodes":len(path["trace"]),"ballots":[{"date":n["calendar_date"],"action":n["chosen_action"],"counts":n["feedback"]["result"]["counts"]}
                for n in path["trace"] if n["chosen_action"] in ("second_reading_vote","third_reading_vote")]})
    summary={"input_sha256":digest(p),"baseline_sha256":digest(baseline),"runs":runs,
        "code_sha256":digest(Path(__file__).read_text()),"cards_used_sha256":digest(baseline["cards_used"]),
        "engine_file_hashes":{name:digest((ROOT/name).read_text()) for name in
            ("persona_v2.py","persona_repository.py","political_state_system.py","party_interest.py","plugins/majorities/model.py","plugins/majorities/rules.py","plugins/majorities/mechanisms.py","plugins/majorities/integration.py","scenarios/zustrom_2025_vote_replay/persona_ballots.py")},
        "baseline_terminal":baseline["terminal"],"baseline_nodes":len(baseline["trace"]),
        "persona_voting":p.get('persona_voting'),"seat_replacements":replacement_plan(p),
        "policy_reference_status":("EXPLICIT_REJECTION_REFERENCE" if p["assumptions"].get("vote_status_quo") is not None else "MISSING_STATUS_QUO_POLICY_UNKNOWN"),
        "execution_scope":"CUSTOM_WEEKLY_REPLAY_USING_PERSONA_PSS_PARTY_AND_MEMBER_VOTES_NOT_FULL_LIVING_WORLD",
        "paths":rows,"path_counts":dict(Counter(r["terminal"] for r in rows)),
        "warning":"Conditional model paths, not real-world probabilities; no selected successful seed replaces baseline"}
    save(output/"prediction_summary.json",summary)
    return summary


def compare_and_report(output=OUT):
    p=json.loads((output/"frozen_protocol.json").read_text())
    b=json.loads((output/"baseline.json").read_text())
    s=json.loads((output/"prediction_summary.json").read_text())
    if digest(p)!=s["input_sha256"] or digest(b)!=s["baseline_sha256"]:
        raise ValueError("Frozen artifacts changed")
    reference=json.loads((HERE/"reference.json").read_text())
    votes=[n for n in b["trace"] if n["chosen_action"]=="second_reading_vote"]
    match=bool(votes and not b["amended"] and votes[-1]["calendar_date"]==reference["vote_date"]
               and not votes[-1]["feedback"]["result"]["passed"])
    comp={"target_stage_text_date_match":match,"full_sequence_validation":"NOT_TESTED_NO_FULL_INTERMEDIATE_COMPARATOR",
          "status":"TARGET_MATCH_NOT_FULL_VALIDATION" if match else "MODEL_PATH_ERROR_NOT_REPRODUCED",
          "reference":reference,"baseline_votes":votes,"count_comparison_valid":bool(votes and not b["amended"] and votes[-1]["calendar_date"]==reference["vote_date"]),
          "warning":"A rejection of a different text/date is not full historical reproduction"}
    save(output/"comparison.json",comp)
    points=[{"step":0,"actor":actor,"value":state["pressure"]} for actor,state in b["initial_pss"].items()]
    for i,node in enumerate(b["trace"],1):
        points.extend({"step":i,"actor":actor,"value":state["pressure"]} for actor,state in node["all_actor_pss_after"].items())
    svg=ScenarioReportCompiler._line_chart_svg(points,series_field="actor",title="Persona PSS · conditional simulation",y_max=1.,y_label="Pressure 0–1")
    (output/"pss_pressure.svg").write_text(svg)
    individual_charts=[]
    for actor in b['initial_pss']:
        chart=ScenarioReportCompiler._line_chart_svg([x for x in points if x['actor']==actor],series_field='actor',title=actor+' PSS',y_max=1.,y_label='Pressure 0–1')
        (output/f'pss_{actor}.svg').write_text(chart)
        individual_charts.append('<details><summary>'+escape(actor)+' pressure</summary>'+chart+'</details>')
    header=["# 从一读冻结：《限制移民流入法案》多节点回放","",
        f"冻结：{p['cutoff']}；观察终点：{p['horizon']}。不是独立盲测，分析者知道历史。",
        f"基线：{b['terminal']}；{len(b['trace'])}节点；修改原案：{b['amended']}。",
        f"历史复现：{comp['status']}。{s['runs']}条整段重跑路径：{json.dumps(s['path_counts'])}。不是现实概率。","",
        f"最终模型文本轴（非法律原文）：{json.dumps(b['final_bill'])}。三轴原案均为1.000；修改后不能把票数误差当原案预测误差。",
        f"本轮表决：{json.dumps([{'date':n['calendar_date'],'stage':n['chosen_action'],'counts':n['feedback']['result']['counts']} for n in b['trace'] if n['chosen_action'] in ('second_reading_vote','third_reading_vote')],ensure_ascii=False)}","",
        f"人格投票配置：{json.dumps(b.get('persona_voting'),ensure_ascii=False)}",
        f"逐轮个人意向：{json.dumps(b.get('persona_ballots'),ensure_ascii=False)}",
        "新增人格只替换原有匿名席位，每人一票、没有自动追随者；投票行动解释与共同政策先验尚未校准。不同选择不保证改变多数。","",
        "因果接线：同次投票使用固定立场快照，不回写实际个票用于同次网络评价；预估票数与真正表决分开。协商尝试及修改文本不再自动兑现他党合作收益；对方回复未知。逐轮causal_channels区分实际贡献与只供展示的诊断分量。","",
        "## 边界与审计","",
        "人物调用现有 Persona/PSS；他党调用现有 PartyInterestEngine；逐人投票调用 majorities 插件。不是把实际票数重新抽样。个人政策位置与党团指令分开；纪律现已显式启用，未将任何人的不投票动机写死。",
        f"投票否决基线：{s.get('policy_reference_status','UNRECORDED')}。三轴0表示没有引入本提案的对应新增条款，不代表现实完全没有移民限制或警察权限；中间轴值与个人偏好仍是模型假设。",
        "运行范围：旧有周步长专用回放，调用Persona/PSS、党派集合体和成员投票，并非完整LivingWorld/客观立法状态机/制度反馈管线；不能把本轮称为13项修复的整机历史验证。",
        "席位按一读前重建：Union196/SPD207/Greens117/FDP91/AfD77/Linke28/BSW10/无党团7，总计733。不能沿用1月底FDP90/AfD76的结构。",
        "现有人格DNA为事后推断，只移除了未来记忆、关系与资源，不宣称消除了全部后见之明。匿名成员偏好、党派利益参数、调度与委员会处理能力均为假设，不是史料测量。",
        "没有注入后来的袭击、联盟解体、议员退团、默克尔声明或真实1月动员；未模拟这些外部机制也会导致复现失败。基线逐人众数只是确定性诊断，联合采样路径另列，不能把两者混为现实预测。",
        "程序为有限状态实验，不是完整德国法律执行器：普通委员会移交作为起点常规路线；委员会未做逐席表决；议程准入的党派倾向为角色假设，并非已考据的实际程序票；整案二读表决是简化，不包含逐条修正案。即使Bundestag通过也不等于生效。",
        "压力曲线见 pss_pressure.svg。民调未运行：现有基本盘插件使用2025锚点，早于其可用日期运行会信息穿越；本次不伪造2024民调或画假曲线。ARCANA关闭。","",
        "## 逐节点（全量评估在 baseline.json）","",
        "|节点|模型日期|行动者|选择|阶段|","|---|---|---|---|---|"]
    header += [f"|{n['node']}|{n['calendar_date']}|{n['actor']}|{n['chosen_action']}|{n['stage_after']}|" for n in b["trace"]]
    header += ["","复现命令：`python -m hakoniwa.scenarios.zustrom_2025_vote_replay.first_reading run --runs 100`。predict与compare可分开运行；compare在输入与预测哈希验证后才读取真实结果。来源见 first_reading_sources.json。"]
    (output/"report.md").write_text("\n".join(header),encoding="utf-8")
    details=[]
    for n in b["trace"]:
        details.append(f"<details><summary>{escape(n['node']+' · '+n['calendar_date']+' · '+n['actor']+' → '+n['chosen_action'])}</summary><pre>{escape(json.dumps(n,ensure_ascii=False,indent=2))}</pre></details>")
    (output/"report.html").write_text('<!doctype html><meta charset="utf-8"><title>一读冻结回放</title><style>body{max-width:1100px;margin:35px auto;font:16px system-ui;line-height:1.6;padding:20px}pre{white-space:pre-wrap;font-size:12px}summary{cursor:pointer;padding:10px;border-bottom:1px solid #ddd}svg{max-width:100%;height:auto}</style><h1>从一读冻结 · 多节点回放</h1><pre>'+escape("\n".join(header[:header.index('## 逐节点（全量评估在 baseline.json）')]))+'</pre>'+svg+''.join(individual_charts)+'<h2>逐节点完整评估与反馈</h2>'+''.join(details),encoding="utf-8")
    return comp


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=("predict","compare","run"),default="run",nargs="?")
    parser.add_argument("--runs",type=int,default=100)
    parser.add_argument("--output",type=Path,default=OUT)
    parser.add_argument("--protocol",type=Path,help="Explicit frozen protocol for replaying a control or migrated input")
    parser.add_argument('--persona-config',type=Path)
    parser.add_argument('--persona-mode',choices=('persona','background_control'),default='persona')
    args=parser.parse_args()
    if args.runs<1: parser.error("runs must be positive")
    if args.command in ("predict","run"):
        protocol=json.loads((args.protocol or HERE/'first_reading_protocol.json').read_text())
        if args.persona_config:
            protocol=prepare_protocol(protocol,json.loads(args.persona_config.read_text()),args.persona_mode)
        summary=predict(args.output,args.runs,protocol=protocol)
        print(json.dumps({k:summary[k] for k in ("baseline_terminal","baseline_nodes","path_counts","input_sha256")},ensure_ascii=False))
    if args.command in ("compare","run"):
        result=compare_and_report(args.output)
        print(result["status"])


if __name__=="__main__":
    main()
