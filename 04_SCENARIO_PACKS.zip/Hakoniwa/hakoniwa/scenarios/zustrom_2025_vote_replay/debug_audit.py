"""Diagnose the frozen replay without changing its inputs or fitting its result.

Run: python -m hakoniwa.scenarios.zustrom_2025_vote_replay.debug_audit
The whip experiment is a synthetic mechanism probe, not a new forecast.
"""
from copy import deepcopy
import json
from pathlib import Path

from ...plugins.majorities import MajorityModel
from .run_scenario import HERE, DEFAULT_OUTPUT, digest, save


def audit(output=Path("outputs/zustrom_2025_debug")):
    request = json.loads((DEFAULT_OUTPUT / "frozen_request.json").read_text())
    summary = json.loads((DEFAULT_OUTPUT / "prediction_summary.json").read_text())
    assert digest(request) == summary["input_sha256"], "Frozen input changed"
    model = MajorityModel(request)
    baseline = model.baseline()
    evaluations = baseline["member_evaluations"]
    discipline_count = sum(e["weighted_terms"]["discipline"] != 0 for e in evaluations.values())
    assert discipline_count == 0
    participation_probes = []
    for participation in (.800, .900, .950, .990):
        probe = deepcopy(request)
        for member in probe["members"]:
            member["attendance"] = participation
        result = MajorityModel(probe).baseline()
        participation_probes.append({
            "participation": participation,
            "modal_counts": result["result"]["counts"],
            "expected_counts": result["expected_counts_without_shared_shocks"],
        })
        assert result["result"]["counts"]["absent"] == 0
    whip_probes = []
    for weight in (.000, .200):
        probe = deepcopy(request)
        probe["issue"]["whip"] = {"stance": 1., "intensity": 1., "parties": ["CDU_CSU", "FDP"]}
        for member in probe["members"]:
            member["weights"]["discipline"] = weight
        variant = MajorityModel(probe)
        result = variant.baseline()
        whip_probes.append({
            "synthetic_discipline_weight": weight,
            "status": "MECHANISM_PROBE_NOT_CALIBRATION",
            "modal_counts": result["result"]["counts"],
            "union_example": variant.evaluate_member("ANONYMOUS_CDU_CSU_001"),
            "ensemble": variant.simulate(100, request["seed"]),
        })
    assert whip_probes[1]["union_example"]["probabilities"]["yes"] > whip_probes[0]["union_example"]["probabilities"]["yes"]
    assert whip_probes[1]["modal_counts"] == whip_probes[0]["modal_counts"]
    # Reference enters only evaluation of the failure, never the mechanism probes.
    reference = json.loads((HERE / "reference.json").read_text())
    group_metrics = {}
    for party, counts in reference["parties"].items():
        cast = sum(counts[k] for k in ("yes", "no", "abstain"))
        total = cast + counts["absent"]
        group_metrics[party] = {
            "yes_among_cast": counts["yes"] / cast if cast else None,
            "yes_among_members": counts["yes"] / total,
            "no_ballot_rate": counts["absent"] / total,
            "no_ballot_reason": "UNKNOWN; not evidence of physical absence or rebellion",
        }
    payload = {
        "frozen_input_sha256": digest(request),
        "original_files_unchanged": True,
        "members": len(evaluations), "nonzero_discipline_contributions": discipline_count,
        "whip_configured": "whip" in request["issue"],
        "distinct_member_weight_sets": sorted({json.dumps(m["weights"], sort_keys=True) for m in request["members"]}),
        "supporter_probabilities": evaluations["ANONYMOUS_CDU_CSU_001"]["probabilities"],
        "modal_counts": baseline["result"]["counts"],
        "expected_counts": baseline["expected_counts_without_shared_shocks"],
        "participation_probes": participation_probes, "synthetic_whip_probes": whip_probes,
        "reference_group_metrics_evaluation_only": group_metrics,
        "limitations": ["No estimated historical discipline coefficient", "No identified cause for individual nonparticipation", "No new predictive validation", "No persona/PSS/polling run"],
    }
    output.mkdir(parents=True, exist_ok=True)
    save(output / "audit.json", payload)
    report = """# 表决回放 debug：党团纪律与票数交付

结论：不是已经发现计票算术错误，而是回放没有启用纪律、输入重复编码党团立场，且逐人众数基线掩盖了参与风险。本诊断不修改原基线，也不拿真实票数调参。

## 已由代码与重复实验确认

1. `build_request()` 只有 policy 权重，没有 issue.whip，也没有 discipline 权重。733 人的纪律贡献全部为零。插件虽有接口，本场景根本没有调用其行为机制。
2. 把公开党团立场复制为每个人的政策位置，同党成员除 ID 外基本同质。支持者净效用为 +0.800，反对者为 −0.800，温度为 0.200。投票条件下支持者赞成倾向约 0.982；这已经事先编码了高度整齐的党团行为，不是模型从关系、利益或纪律中推导出来的。
3. 每个人分别取众数不等于整场最典型的票数。参与参数为 0.950 时，众数基线无人未投票，但期望未投票数为 36.650。将参与参数从 0.800 调到 0.990，四个探针的众数基线仍都没有未投票者；期望值则正常变化。这是汇总方式的局限，不是随机模拟没有采样缺席。
4. 人工给 Union/FDP 添加正向纪律只是机制探针：支持者赞成倾向上升，众数基线不变。参数 0.200 是任意诊断值，不是历史估计。不能用提高纪律来修复这个错误预测；它只会进一步强化本来已被高估的支持。

## 历史事实：不能把所有未交付票都叫倒戈

官方记录中 Union 为 184 赞成、0 反对、0 弃权、12 未投票；FDP 为 67 赞成、2 反对、5 弃权、16 未投票。Union 的已投票者赞成率是 100%，但全体席位的赞成交付率约 93.878%；FDP 对应约 90.541% 和 74.444%。分母不同，政治含义也不同。

未投票只证明没有投票记录，不证明身体缺席、策略性拒投或反对领导。要解释动机必须继续查逐人声明、请假/疾病情况、前后表决记录与协调过程。也不能据一次结果估计稳定的个人忠诚。

当天还经历了延迟、跨党谈判和退回委员会的争议；当前模型只在一个时点计算一次匿名偏好，没有模拟这段形成实际多数的过程。

## 通用插件还有哪些表达能力不足

- whip 只有一套全局 stance/intensity/parties，无法在同一议案里同时配置各党团不同方向、不同强度的动员。
- 纪律只是加到赞成/反对净效用的一个项，没有分别表达通知异议、争取让步、议程调整、动员到场与最后交付选票。
- attendance 同时承担未投票概率，却又可能被当作物理在场；人在场但不投票尚非独立行动。将官方 nicht abgestimmt 对齐 absent 只能作为粗略对照，不能作为已查明的缺席原因。
- 本次没有调用具体人物卡，不能从失败推出 Merz/Frei 人格模型错误。

## 建议修订顺序（尚未改变行为）

先分开个人政策偏好、党团建议和实际投票承诺；未知个人偏好保留未知，而非用党团声明覆盖。再把身体可出席、选择参与、赞成/反对/弃权分层处理；各党团分别配置 whip，协调行动必须通过可见报告和承诺改变支持。保留逐人众数用于调试，但不能把它当唯一预测，应并列呈现期望票数、联合运行分布和不确定性来源。没有证据时使用明确标记的情景区间，而非填入历史实际缺席率冒充预测。

法定自由委任不等于不存在党团协调。历史版 CDU/CSU 工作规则 §17 同时写有自由表决、重要异议提前通报和未参加记名投票的事后通报，§18 规定出席与请假要求。但手头文件明确属于第19届、2018年，不能直接声称其条文在2025年仍原样有效。

## 来源及边界

- [联邦议院官方记名表决946](https://www.bundestag.de/parlament/plenum/abstimmung/abstimmung/?id=946)：真实计票，专用于事后评估。
- [ARD 2025-01-31 18:23](https://www.tagesschau.de/inland/bundestagswahl/migrationsgesetz-abgelehnt-100.html)：当日谈判、延迟、退回委员会争议；结果已更正为349票反对。
- [CDU/CSU 第19届工作规则，2018-04-17](https://www.cducsu.de/sites/default/files/2018-05/WP19%20Arbeitsordnung_17.04.2018_0.pdf)：读取§17–18；仅作历史组织机制证据，不冒充2025适用版本。
- 尝试访问 FDP Anja Merten 个人解释旧网址，实际返回党团首页，未取得原文，不作为个人动机证据。

复现：`python -m hakoniwa.scenarios.zustrom_2025_vote_replay.debug_audit`。结构化数值见同目录 audit.json。原实验输入、预测与对照结果未覆盖。本次为诊断，不运行民调或PSS，不生成虚构曲线。
"""
    (output / "report.md").write_text(report, encoding="utf-8")
    return payload


if __name__ == "__main__":
    result = audit()
    print(json.dumps({k: result[k] for k in ("frozen_input_sha256", "members", "nonzero_discipline_contributions", "expected_counts")}, ensure_ascii=False, indent=2))
