"""Fictional, bounded three-site crisis adapter using existing personas/PSS/clock."""
