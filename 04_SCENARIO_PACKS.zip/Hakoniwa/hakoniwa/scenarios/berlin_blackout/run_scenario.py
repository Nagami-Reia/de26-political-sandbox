"""12-hour fictional scenario, not a replacement for the main world/persona engine."""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
from dataclasses import asdict
from hashlib import sha256
from html import escape
import json
from pathlib import Path
import random

from ...information_filter import InformationFilter
from ...persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine, WorldEvent
from ...political_state import PoliticalState, StateVariable
from ...political_state_system import quantize3
from ...realtime_polling import PollSeriesSpec, RealtimePollingTracker
from ...scenario_reporting import ScenarioReportCompiler, ScenarioReportingPolicy
from ...world_clock import WorldClock, DELIVERY, COMPLETION, DISPATCH

HERE = Path(__file__).resolve().parent
CARDS = HERE.parents[1]/"data/personas/cards_pss.json"

LABELS = {
    "verify": "核实本地情况", "organize": "组织人员与内部汇报", "protect": "安排局部防护与检查",
    "government": "请求柏林危机响应并追踪回执", "broadcast": "发布带不确定性说明的通报",
    "care": "核对人员需求并分配物资", "rest": "短暂休息并交接", "charge": "留用供电给设备充电",
    "wait": "暂缓决定、保存资源", "call": "联系并请求情况更新", "move": "尝试转移到另一地点"
}

# Common environment descriptions, never actor-specific bonuses or first-option answers.
VALUES = {
    "verify": {"evidence_based_judgment": .85, "clarity": .65, "process_control": .50, "fiscal_accountability": .25},
    "organize": {"organization_success": .80, "organizational_trust": .75, "organizational_reconstruction": .70, "process_control": .70, "working_majority": .50, "union_unity": .35},
    "protect": {"state_capacity": .70, "policy_control": .60, "implementation_effect": .65, "state_delivery": .65, "governability": .50, "government_function": .65},
    "government": {"strategic_direction": .75, "political_authority": .55, "state_capacity": .65, "bavarian_control": .35, "governable_majority": .45, "implementation_credibility": .40},
    "broadcast": {"clarity": .75, "democratic_norms": .45, "broad_acceptance": .50, "csu_relevance": .55, "political_authority": .35, "organizational_trust": .25},
    "care": {"social_cohesion": .85, "democratic_responsibility": .70, "state_delivery": .65, "party_inclusion": .65, "unity": .55, "implementation_effect": .45},
    "call": {"personal_loyalty": .70, "unity": .65, "union_unity": .60, "government_alignment": .55, "organizational_trust": .45, "broad_acceptance": .30},
    "move": {"future_option": .45, "personal_option": .45, "political_stability": -.20, "process_control": -.20},
    "charge": {"assigned_duty": .30, "implementation_credibility": .25},
    "rest": {}, "wait": {}
}


def bound(value):
    return max(0.0, min(1.0, value))


class BerlinCrisis:
    def __init__(self, seed: int, config: dict | None = None):
        self.config = deepcopy(config or json.loads((HERE/"config.json").read_text(encoding="utf-8")))
        self.seed = seed
        self.clock = WorldClock(self.config["start"])
        self.engine = FreeAgentDecisionEngine.from_json(CARDS)
        self.actors = deepcopy(self.config["actors"])
        self.sites = deepcopy(self.config["sites"])
        for row in self.actors.values():
            row.update(busy=False, alive=True, health=1.0, transit=None, last_actions=[])
        self.known_sites = {a:{b:r["site"] for b,r in self.actors.items()} for a in self.actors}
        for row in self.sites.values():
            row.update(threat=.10, disruption=.0, continuity=.20, unmet_need=.25, incidents=0)
        self.p = self.config["parameters"]
        self.info = InformationFilter({a: {} for a in self.actors}, delivery_only=True)
        self.rng = {name: random.Random(int.from_bytes(sha256(f"{seed}:{name}".encode()).digest()[:8], "big"))
                    for name in ("world", "reports", "delivery", "execution")}
        self.initial_pss = {a: asdict(self.engine.runtime[a].state) for a in self.actors}
        self.trace, self.decisions, self.messages, self.pending, self.outcomes = [], [], [], {}, []
        self.network = self.p["network_initial"]
        self.city_threat = self.p["city_threat_initial"]
        self.world_state = PoliticalState({key: StateVariable(key, value, evidence="SIMULATION_ASSUMPTION")
            for key, value in self.config["polling_anchors"].items()}, {}, {})
        specs = tuple(PollSeriesSpec(key, key, "synthetic_anchor", "frozen_no_new_survey", "fictional_Berlin")
                      for key in self.world_state.variables)
        self.polls = RealtimePollingTracker(f"berlin-fiction-{seed}", "fictional-three-sites", specs, self.config["start"])
        self.polls.record_baseline(self.world_state)
        for actor in self.actors:
            self.local_report(actor, "meeting_staff", confidence=.55)
            self.clock.schedule(5, "decision", {"actor": actor}, phase=DISPATCH)
        self.clock.schedule(self.config["power_failure_minute"], "blackout")
        for site,row in self.sites.items():
            self.clock.schedule(row["backup_until"], "backup_exhausted", {"site":site})
        self.clock.schedule(self.p["tick_minutes"], "world_tick")
        self.record("opening", {"note": "会议仍在进行；仅有含混的本地异常报告，不授予丧尸全知解释。"})

    def powered(self, site):
        return self.clock.minute < self.config["power_failure_minute"] or self.clock.minute < self.sites[site]["backup_until"]

    def occupants(self, site):
        return [a for a, r in self.actors.items() if r["site"] == site and r["transit"] is None]

    def local_report(self, actor, source, confidence=.75):
        site = self.actors[actor]["site"]
        if self.actors[actor]["transit"]:
            return
        observations = {}
        for key in ("threat", "coordination", "unmet_need", "continuity", "disruption"):
            reported = bound(self.sites[site][key]+self.rng["reports"].gauss(0, self.p["report_error_sigma"]))
            observations[f"{site}:{key}"] = {"estimate": 100*reported, "confidence": confidence, "source": source}
        self.info.deliver(actor, observations, message_id=f"local:{actor}:{self.clock.minute}:{source}")

    def perceive(self, actor, key, fallback=.5):
        belief = self.info.states[actor].beliefs.get(f"{self.actors[actor]['site']}:{key}")
        return belief.estimate/100 if belief else fallback

    def record(self, kind, data, decision=None):
        event_id = f"event:{len(self.trace)+1}"
        time = self.clock.at().isoformat()
        self.polls.timestamp_by_event_id[event_id] = time
        self.polls.record(self.world_state, event_id=event_id, actor=data.get("actor", "world"),
                          action=kind, event_kind=kind)
        self.trace.append({"node": event_id, "calendar_date": time, "elapsed_minutes": self.clock.minute,
            "kind": kind, "details": deepcopy(data), "decision": decision,
            "actors_used": list(self.actors), "all_actor_pss_after": {
                a: asdict(self.engine.runtime[a].state) for a in self.actors},
            "physical_after": {"actors": {a:{k:v for k,v in r.items() if k != "last_actions"} for a,r in self.actors.items()}, "sites": deepcopy(self.sites),
                               "network": self.network, "city_threat": self.city_threat}})

    def elapse(self, minutes):
        for actor, row in self.actors.items():
            self.engine.elapse_minutes(actor, minutes)
            row["battery"] = max(0, row["battery"]-minutes/60*self.p["idle_battery_per_hour"])
            state = self.engine.runtime[actor].state
            state.energy = max(0, state.energy-minutes/60*self.p["ambient_workload_per_hour"])

    def menu(self, actor):
        row = self.actors[actor]
        site = row["site"]
        threat, coordination = self.perceive(actor, "threat"), self.perceive(actor, "coordination")
        need, continuity = self.perceive(actor, "unmet_need"), self.perceive(actor, "continuity")
        energy = self.engine.runtime[actor].state.energy
        recent = [key for minute, key in row["last_actions"] if self.clock.minute-minute < self.p["repetition_window_minutes"]]
        recipes = [
            ("verify", 20, {"information": .90}, .16, "institutionalize", ("process",)),
            ("organize", 30, {"coordination": .85, "protection": .30}, .20, "institutionalize", ("organization", "process")),
            ("protect", 35, {"protection": .90}, .40, "institutionalize", ("execution",)),
            ("government", 30, {"continuity": .90, "information": .25}, .28, "negotiate", ("direction", "execution")),
            ("broadcast", 20, {"coordination": .40, "continuity": .35}, .50, "reframe", ("direction",)),
            ("care", 30, {"protection": .50, "needs": .90}, .22, "negotiate", ("coalition", "execution")),
            ("rest", 30, {"recovery": .95}, .20, "avoid", ()),
            ("wait", 25, {"recovery": .25, "information": .10}, .35, "avoid", ())]
        if self.powered(site) and row["battery"] < .85:
            recipes.append(("charge", 30, {"battery": .95}, .12, "institutionalize", ("execution",)))
        if row["battery"] > self.p["active_phone_cost"]:
            for target in self.actors:
                if target != actor and self.known_sites[actor][target] != site:
                    recipes.append((f"call:{target}", 20, {"contact": .85, "information": .35}, .27, "negotiate", ("organization", "coalition")))
        for destination in self.sites:
            if destination != site:
                recipes.append((f"move:{destination}", self.travel_time(site, destination), {"protection": threat-.40, "contact": .30}, .80, "avoid", ("process",)))
        goals = {"information": .45, "coordination": 1-coordination, "protection": threat,
                 "needs": need, "continuity": 1-continuity, "recovery": 1-energy,
                 "battery": 1-row["battery"], "contact": .40}
        options, metadata = [], {}
        for key, duration, impacts, downside, strategy, domains in recipes:
            family = key.split(":")[0]
            if energy < self.p["minimum_active_energy"] and family not in {"rest", "wait"}:
                continue
            if family in {"move", "protect"} and row["health"] < .35:
                continue
            if family in {"government", "broadcast"} and row["battery"] <= self.p["active_phone_cost"]:
                continue
            target = key.split(":", 1)[1] if family == "call" else None
            fatigue = 1/(1+recent.count(key))
            values = {k: v*fatigue for k, v in VALUES[family].items()}
            if family == "care" and need < .2:
                values = {k: v*max(.1, need/.2) for k,v in values.items()}
            options.append(ActionOption(key, goal_impacts={k: v*fatigue for k,v in impacts.items()},
                value_impacts=values, upside=.45+.20*max(impacts.values()), downside=downside,
                uncertainty=.55, information_confidence=.5, effort=duration/100,
                irreversibility=.65 if family == "move" else .10,
                visibility=.7 if family == "broadcast" else .05, control_domains=domains,
                restores_control=.4*fatigue if family in {"organize", "government", "protect"} else .15*fatigue,
                conflict_strategy=strategy, target_actor=target,
                identity_tags=tuple(k for k,v in values.items() if v > 0),
                event_tags=("uncertain", "systemic_crisis"), risk_tags=("systemic_crisis",)))
            metadata[key] = {"duration": duration, "family": family, "target": target,
                             "expected_direct_goal": LABELS[family], "repetition_discount": fatigue}
        return options, metadata, goals

    def travel_time(self, first, second):
        return self.config["travel_minutes"].get(f"{first}|{second}", self.config["travel_minutes"].get(f"{second}|{first}"))

    def decide(self, actor):
        row = self.actors[actor]
        if row["busy"] or not row["alive"] or self.clock.minute >= self.config["duration_minutes"]:
            return
        options, meta, goals = self.menu(actor)
        # Preserve the actual card. Crisis-specific resources do not replace personality.
        resources = dict(self.engine.cards[actor].initial_resources)
        decision = self.engine.decide(actor, options, resources, goals, ("uncertain", "systemic_crisis"))
        key = decision.chosen_action
        data = meta[key]
        row["busy"] = True
        if data["family"] in {"call", "government", "broadcast"}:
            row["battery"] = max(0, row["battery"]-self.p["active_phone_cost"])
        if data["family"] == "move":
            row["transit"] = key.split(":")[1]
        node = f"decision:{len(self.decisions)+1}"
        evaluation = {"node": node, "decision_maker": actor, "calendar_date": self.clock.at().isoformat(),
            "site": row["site"], "actor_belief_state": self.info.payload(self.info.states[actor]),
            "pss_before": asdict(self.engine.runtime[actor].state), "battery_before_execution": row["battery"],
            "current_goals": goals, "action_menu": {o.key: {**asdict(o), **meta[o.key]} for o in options},
            "last_known_sites": deepcopy(self.known_sites[actor]),
            "action_evaluations": {k: asdict(v) for k,v in decision.scores.items()},
            "chosen_action": key, "arcana": {"enabled": False}, "status": "PENDING_EXECUTION"}
        self.decisions.append(evaluation)
        self.pending[node] = {"actor": actor, "key": key, "meta": data, "origin": row["site"], "evaluation": evaluation}
        self.clock.schedule(self.clock.minute+data["duration"], "complete", {"node": node}, phase=COMPLETION)
        self.record("actor_decision", {"actor": actor, "node": node, "action": key, "duration": data["duration"]}, evaluation)

    def transmit(self, sender, receiver, payload, kind):
        message = {"id": f"message:{len(self.messages)+1}", "sender": sender, "receiver": receiver,
                   "sent_at": self.clock.minute, "kind": kind, "payload": deepcopy(payload), "status": "IN_TRANSIT"}
        self.messages.append(message)
        self.clock.schedule(self.clock.minute+self.rng["delivery"].randint(3,18), "message", {"index": len(self.messages)-1})

    def complete(self, node):
        job = self.pending.pop(node)
        actor, key, meta = job["actor"], job["key"], job["meta"]
        row, site = self.actors[actor], self.sites[job["origin"]]
        if not row["alive"]:
            row["busy"] = False
            job["evaluation"].update(status="CANCELLED_INCAPACITATED")
            self.record("action_cancelled", {"actor":actor,"action":key,"reason":"PHYSICAL_INCAPACITY"})
            return
        family = meta["family"]
        before = deepcopy(site)
        success, expected_success, evidence_quality, outcome_scope = .5, .5, .45, .35
        reason = "PARTIAL"
        if family == "verify":
            self.local_report(actor, "deliberate_local_check", .90)
            success, reason = .85, "LOCAL_REPORT_RECEIVED_NOT_CITY_TRUTH"
            expected_success, evidence_quality, outcome_scope = .85, .90, .35
        elif family in {"organize", "protect", "care"}:
            probability = bound(.85-.35*site["disruption"])
            expected_success = .35 + .65 * probability
            evidence_quality, outcome_scope = .82, .55
            success = 1.0 if self.rng["execution"].random() < probability else .35
            if family == "organize":
                old = site["coordination"]
                site["coordination"] = bound(old+.18*success)
                success = (site["coordination"]-old)/.18
            if family == "protect":
                old = site["protection"]
                site["protection"] = bound(old+.16*success)
                success = (site["protection"]-old)/.16
            if family == "care":
                delivered = min(site["supplies"], .10*success)
                site["supplies"] -= delivered
                site["unmet_need"] = bound(site["unmet_need"]-delivered)
                success = delivered/.10
            reason = "LOCAL_EXECUTION_ONLY"
            for recipient in self.occupants(row["site"]): self.local_report(recipient, f"local_result:{actor}", .75)
        elif family == "rest":
            success = bound(1-site["threat"]*.5)
            expected_success, evidence_quality, outcome_scope = success, .95, .25
            self.engine.runtime[actor].state.energy = bound(self.engine.runtime[actor].state.energy+.18*success)
            reason = "REST_NOT_CRISIS_RESOLUTION"
        elif family == "charge":
            success = 1.0 if self.powered(row["site"]) else 0.0
            expected_success, evidence_quality, outcome_scope = success, 1.0, .30
            row["battery"] = bound(row["battery"]+.30*success)
            reason = "POWER_AVAILABLE" if success else "POWER_LOST_DURING_CHARGE"
        elif family in {"call", "broadcast", "government"}:
            recipient = meta["target"] if family == "call" else ("Berlin_operations" if family == "government" else "public_channel")
            beliefs = {k: asdict(v) for k,v in self.info.states[actor].beliefs.items()}
            self.transmit(actor, recipient, {"reports": beliefs, "origin": row["site"]}, family)
            success, reason = .5, "SENT_NOT_DELIVERED_OR_IMPLEMENTED"
            expected_success, evidence_quality, outcome_scope = .5, .35, .20
        elif family == "move":
            destination = key.split(":")[1]
            chance = bound(.75-.45*self.city_threat-.15*self.sites[destination]["disruption"])
            expected_success, evidence_quality, outcome_scope = chance, .95, .65
            success = 1.0 if self.rng["execution"].random() < chance else 0.0
            if success: row["site"] = destination
            else: row["health"] = bound(row["health"]-self.p["failed_transfer_health_cost"]*self.city_threat)
            row["transit"] = None
            self.known_sites[actor][actor] = row["site"]
            reason = "ARRIVED" if success else "TRANSFER_ABORTED_RETURNED_TO_ORIGIN"
            self.local_report(actor, "arrival_or_return", .90)
        else:
            success, reason = .5, "WAITED_NO_NEW_FACT_GUARANTEED"
        pss = self.engine.apply_outcome(actor, ActionOutcome(key, success,
            tags=(family, "crisis_action"), workload=.025+meta["duration"]*.0007,
            control_restoration=.025*success if family in {"organize", "protect", "government"} else 0,
            expected_success=expected_success, evidence_quality=evidence_quality,
            outcome_scope=outcome_scope))
        outcome = {"actor": actor, "action": key, "at": self.clock.minute,
            "action_outcome": {"success": success, "meaning": reason},
            "institutional_outcome": {"status": "NO_LEGISLATIVE_TRANSITION_OR_EXTRA_LEGAL_POWER_GRANTED"},
            "world_outcome": {"site_before": before, "site_after": deepcopy(site), "actual_site": row["site"]},
            "pss_update": pss}
        job["evaluation"].update(status="EXECUTED", outcome=outcome)
        self.outcomes.append(outcome)
        row["last_actions"].append((self.clock.minute,key))
        row["busy"] = False
        self.record("action_completed", outcome)
        self.clock.schedule(self.clock.minute+5, "decision", {"actor": actor}, phase=DISPATCH)

    def deliver(self, index):
        message = self.messages[index]
        sender, receiver = message["sender"], message["receiver"]
        recipient_active = receiver not in self.actors or self.actors[receiver]["battery"] > .01
        ok = recipient_active and self.rng["delivery"].random() < self.network
        message.update(status="DELIVERED" if ok else "NOT_DELIVERED", settled_at=self.clock.minute)
        if ok and receiver in self.actors:
            observations = {key: {"estimate": item["estimate"], "confidence": item["confidence"], "source": f"person:{sender}"}
                            for key,item in message["payload"]["reports"].items()}
            # Origin evidence is preserved in the message audit; scalar fusion is a known limitation.
            self.info.deliver(receiver, observations, message_id=message["id"])
            if sender in self.actors:
                self.known_sites[receiver][sender] = message["payload"]["origin"]
            # Receipt alone is not evidence of loyalty or operational reliability.
        elif ok and receiver == "Berlin_operations":
            self.clock.schedule(self.clock.minute+self.rng["execution"].randint(30,90), "response",
                                {"actor": sender, "origin": message["payload"]["origin"], "parent": message["id"]})
        self.record("message_settled", message)

    def tick(self):
        dt = self.p["tick_minutes"]/60
        self.city_threat = bound(self.city_threat+self.p["city_threat_growth_per_hour"]*dt+self.rng["world"].gauss(0,self.p["city_threat_noise"]*dt))
        if self.clock.minute >= self.config["power_failure_minute"]:
            self.network = max(self.p["network_floor"], self.network-self.p["network_decay_per_hour_after_blackout"]*dt)
        events = []
        for name, site in self.sites.items():
            site["threat"] = bound(self.city_threat*(1-.65*site["protection"])+site["disruption"]*.25)
            site["unmet_need"] = bound(site["unmet_need"]+.025*dt)
            site["coordination"] = bound(site["coordination"]-self.p["coordination_decay_per_hour"]*dt)
            hazard = (self.p["incident_base_per_hour"]+self.p["incident_threat_factor"]*site["threat"])*dt
            if self.rng["world"].random() < hazard:
                incident = self.rng["world"].choice(("external_impact", "local_access_problem", "staff_needs_assistance"))
                severity = self.rng["world"].uniform(.25,.65)
                site["incidents"] += 1
                site["disruption"] = bound(site["disruption"]+.12*severity)
                site["unmet_need"] = bound(site["unmet_need"]+.15*severity)
                events.append({"site":name,"type":incident,"severity":severity,"hazard_this_tick":hazard})
                occupants = self.occupants(name)
                if incident in {"external_impact", "local_access_problem"} and occupants and self.rng["world"].random() < self.p["physical_injury_chance"]:
                    victim = self.rng["world"].choice(occupants)
                    self.actors[victim]["health"] = bound(self.actors[victim]["health"]-self.p["physical_injury_scale"]*severity)
                    self.actors[victim]["alive"] = self.actors[victim]["health"] > 0
                    events[-1]["physical_harm"] = {"actor":victim,"health":self.actors[victim]["health"],"status":"ABSTRACT_NOT_CLINICAL"}
                for actor in self.occupants(name):
                    self.engine.apply_event(actor, WorldEvent(f"{name}:{incident}:{self.clock.minute}", incident,
                        severity, ("loss_of_control", "systemic_crisis"), workload=.02))
                    self.local_report(actor, "witnessed_local_incident", .85)
            elif self.rng["reports"].random() < self.p["staff_report_chance_per_tick"]:
                occupants = self.occupants(name)
                if occupants: self.local_report(self.rng["reports"].choice(occupants), "staff_initiated_report", .60)
        self.record("world_tick", {"physical_events":events, "note":"发生率和严重程度独立于人物评分；未获报告者不自动知道。"})
        if self.clock.minute+self.p["tick_minutes"] <= self.config["duration_minutes"]:
            self.clock.schedule(self.clock.minute+self.p["tick_minutes"], "world_tick")

    def handle(self, event):
        if event.kind == "decision": self.decide(event.data["actor"])
        elif event.kind == "complete": self.complete(event.data["node"])
        elif event.kind == "message": self.deliver(event.data["index"])
        elif event.kind == "world_tick": self.tick()
        elif event.kind == "backup_exhausted":
            for actor in self.occupants(event.data["site"]):
                self.engine.apply_event(actor, WorldEvent(f"backup:{event.data['site']}","local_power_loss",.30,("loss_of_control",)))
            self.record("backup_exhausted", {"site":event.data["site"],"note":"虚构局部备用窗口结束；不表示所有电子设备同时失效。"})
        elif event.kind == "blackout":
            for actor in self.actors:
                self.engine.apply_event(actor, WorldEvent("grid_blackout", "loss_of_mains", .45,
                    ("loss_of_control", "uncertain")))
            self.record("grid_blackout", {"note":"T+1h市电中断；各地虚构备用窗口和手机电量仍分开计算。"})
        elif event.kind == "response":
            site = self.sites[event.data["origin"]]
            delivered = self.rng["execution"].random() < bound(.75-.40*self.city_threat)
            if delivered: site["continuity"] = bound(site["continuity"]+.12)
            self.record("organization_response", {**event.data,"implemented_local_coordination":delivered,
                "note":"响应可能有限，不自动消除全城危机；回执仍要另行传递。"})
            self.transmit("Berlin_operations", event.data["actor"], {"reports":{},"origin":event.data["origin"]}, "ack")

    def run(self):
        self.clock.advance(self.config["duration_minutes"], self.handle, self.elapse)
        self.record("observation_horizon", {"note":"T+12h观察停止，不是危机结束；未完成行动与消息保留。"})
        report = ScenarioReportCompiler(self.initial_pss, ScenarioReportingPolicy()).compile(self.trace,(self.polls,))
        boundary_actors = [a for a in self.actors if self.engine.runtime[a].state.pressure <= .001
                           or self.engine.runtime[a].state.pressure >= .999
                           or self.engine.runtime[a].state.confidence <= .001
                           or self.engine.runtime[a].state.confidence >= .999]
        diagnostics = [
            {"code":"PSS_BOUNDARY_CHECK", "actors":boundary_actors,
             "meaning":("检测到状态触及上下限；相关后期选择不能用于验证人格。" if boundary_actors
                        else "本次未检测到confidence/pressure触及0或1；仍不把曲线解释为现实人格测量。")},
            {"code":"CALIBRATED_CONFIDENCE", "meaning":"行动反馈按事前预期、证据质量和影响范围更新；例行完成、休息与仅发送消息不再等价于政治能力大胜。"},
            {"code":"RELATIONSHIP_CONFLICT_NOT_TESTED", "meaning":"关系参数参与联系对象评分；未完整实现请求—接受/拒绝—履约—修复，不能据本局判定关系稳定。"},
            {"code":"AGGREGATE_PHYSICAL_MODEL", "meaning":"危险是聚合压力、局部事件和抽象损伤；尚无感染传播或尸群实体模型。"}]
        return quantize3({"schema_version":"fictional-berlin-run-1.0","seed":self.seed,"arcana":False,
            "config":self.config,"clock":self.clock.payload(),
            "trace":[{**r,"decision": {"node":r['decision']['node']} if r['decision'] else None} for r in self.trace],
            "decisions":self.decisions,
            "messages":self.messages,"outcomes":self.outcomes,"actors":self.actors,"sites":self.sites,
            "persona_cards_used":{a:asdict(self.engine.cards[a]) for a in self.actors},
            "cards_sha256":sha256(CARDS.read_bytes()).hexdigest(),"scenario_report":report,
            "model_diagnostics":diagnostics,
            "polling_status":"FROZEN_SYNTHETIC_ANCHORS_NO_NEW_SURVEYS", "source_notes":"SOURCE_NOTES.md"})


def save(payload, output):
    output.mkdir(parents=True,exist_ok=True)
    (output/"full_trace.json").write_text(json.dumps(payload,ensure_ascii=False,separators=(",",":")),encoding="utf-8")
    report=payload["scenario_report"]
    polling=report["charts"]["polling_svg"].replace("实时民调：潜在支持与模型即时估计","民调：无新增调查，合成锚点冻结")
    (output/"pss_pressure.svg").write_text(report["charts"]["pss_pressure_svg"],encoding="utf-8")
    (output/"polling.svg").write_text(polling,encoding="utf-8")
    summaries=[]
    for hour in range(13):
        row=next(r for r in reversed(payload["trace"]) if r["elapsed_minutes"]<=hour*60)
        summaries.append({"hour":hour,"time":row["calendar_date"],"physical":row["physical_after"],"pss":row["all_actor_pss_after"]})
    (output/"hourly_snapshots.json").write_text(json.dumps(summaries,ensure_ascii=False,indent=2),encoding="utf-8")
    lines=["# 柏林三地危机：T=0至T+12h",f"\n完全架空；seed={payload['seed']}；ARCANA关闭。", "\n地理地址是真实锚点；所有建筑资源、人员到场、危机与执行参数均为假设。人格跨情境外推未经验证。", "\n民调没有新调查，图中只是冻结的合成锚点，不是危机民意预测。", "\n## 逐小时状态"]
    for row in summaries:
        physical=row["physical"]
        lines.append(f"\n### T+{row['hour']}h · {row['time']}")
        lines.append("\n"+"；".join(f"{site}：危险{r['threat']:.3f}、防护{r['protection']:.3f}、未满足需求{r['unmet_need']:.3f}、事件{r['incidents']}次" for site,r in physical["sites"].items()))
    lines.extend(["\n## 最后位置与PSS", "\n|人物|位置|电量|压力|能量|", "|---|---|---:|---:|---:|"])
    for actor,row in payload["actors"].items():
        pss=payload["trace"][-1]["all_actor_pss_after"][actor]
        lines.append(f"|{actor}|{row['site']}{'→'+row['transit'] if row['transit'] else ''}|{row['battery']:.3f}|{pss['pressure']:.3f}|{pss['energy']:.3f}|")
    lines.extend(["\n## 人物实际选择概览", "\n|人物|第一步|最多选择的行动|", "|---|---|---|"])
    for actor in payload['actors']:
        decisions=[d for d in payload['decisions'] if d['decision_maker']==actor]
        counts=Counter(d['chosen_action'].split(':')[0] for d in decisions)
        lines.append(f"|{actor}|{decisions[0]['chosen_action']}|"+"、".join(f"{LABELS[key]}×{number}" for key,number in counts.most_common(3))+"|")
    lines.append("\n## 必须保留的模型误差")
    lines.extend("\n- "+d['code']+"："+d['meaning'] for d in payload['model_diagnostics'])
    lines.extend(["\n## 审计与完整节点", f"\n{len(payload['decisions'])}次人物决策，{len(payload['trace'])}条事件记录。HTML逐节点保留所有候选行动、评分分项、信念、执行结果；full_trace.json保存人物卡和完整回放资料。", "\n本轮不宣称完成通用制度状态机、完整信息渠道模型或真实生存能力校准。健康为抽象损伤指标，未模拟感染转化、临床救治和专业护卫行动。PSS confidence使用事前预期、证据质量和影响范围校准；其曲线仍只能作为模型内部状态，不能验证真人性格。"])
    (output/"report.md").write_text("\n".join(lines),encoding="utf-8")
    compact=[]
    for d in payload["decisions"]:
        compact.append({k:d[k] for k in ("node","decision_maker","calendar_date","site","pss_before","actor_belief_state","chosen_action","status")})
        compact[-1]["evaluations"]={k:{f:s[f] for f in ("total","goal_alignment","resource_feasibility","risk_calculation","current_state_modifier","memory_modifier","identity_consistency","relationship_history_modifier","environment_compatibility","repetition_modifier","hard_rejections")} for k,s in d["action_evaluations"].items()}
        compact[-1]["options"]={k:{"label":LABELS[v["family"]],"minutes":v["duration"]} for k,v in d["action_menu"].items()}
        compact[-1]["outcome"]=d.get("outcome",{"status":"PENDING_AT_HORIZON"})
        ranked=sorted(d['action_evaluations'].items(),key=lambda kv:kv[1]['total'],reverse=True)
        gap=ranked[0][1]['total']-ranked[1][1]['total'] if len(ranked)>1 else 0
        compact[-1]['score_summary']=f"选项分差{gap:.3f}（旧引擎分，不是概率）；信念和PSS来自本节点之前，执行结果独立结算。"
    (output/"report_trace.json").write_text(json.dumps(compact,ensure_ascii=False,separators=(",",":")),encoding="utf-8")
    details="".join(f"<details class='node' data-index='{i}'><summary>{escape(d['calendar_date'])} · {escape(d['decision_maker'])} · {escape(d['chosen_action'])} · {d['status']}</summary></details>" for i,d in enumerate(compact))
    events="".join(f"<tr><td>T+{r['elapsed_minutes']/60:.2f}h</td><td>{escape(r['kind'])}</td><td>{escape(json.dumps({k:v for k,v in r['details'].items() if k not in {'payload','reports'}},ensure_ascii=False))}</td></tr>" for r in payload["trace"] if r["kind"] in {"grid_blackout","backup_exhausted","world_tick","organization_response","message_settled"})
    document='<!doctype html><html lang="zh"><meta charset="utf-8"><title>柏林三地危机 · 12h</title><style>body{max-width:1200px;margin:30px auto;padding:20px;font:15px/1.7 system-ui;background:#f5f2ec;color:#222}details{background:white;margin:8px 0;padding:10px}table{border-collapse:collapse;width:100%}td,th{padding:6px;border-bottom:1px solid #ddd;text-align:left}pre,td{overflow-wrap:anywhere;white-space:pre-wrap}svg{max-width:100%;height:auto}</style><h1>柏林三地危机 · T=0—T+12h</h1><p>完全架空。ARCANA关闭。既有人物卡不修改；人格向生存情境的外推未经校准。建筑布局/备用电源/出行时间均为虚构，不是现实安保资料。</p><p>11人PSS逐事件记录；民调无新增调查，合成锚点冻结。观察结束不代表危机解除；健康仅为抽象损伤，未模拟感染转化。confidence按预测误差与证据范围更新，但曲线仍不能验证真人性格。</p>'
    document+=f"<p>Seed {payload['seed']} · {len(payload['decisions'])}次决策 · {len(payload['trace'])}条事件</p>"+report["charts"]["pss_pressure_svg"]+polling
    document+='<h2>模型警报：不是人物结论</h2><ul>'+''.join('<li>'+escape(d['meaning'])+'</li>' for d in payload['model_diagnostics'])+'</ul>'
    document+='<h2>逐小时快照</h2><table><tr><th>小时</th><th>三地危险（聚合假设）</th><th>设备电量耗尽人数</th></tr>'+''.join(f"<tr><td>T+{r['hour']}h</td><td>"+'；'.join(f"{name} {s['threat']:.3f}" for name,s in r['physical']['sites'].items())+f"</td><td>{sum(a['battery']<=.001 for a in r['physical']['actors'].values())}</td></tr>" for r in summaries)+'</table>'
    document+="<h2>物理世界与消息</h2><table><tr><th>时间</th><th>事件</th><th>记录</th></tr>"+events+"</table><h2>每个人每一节点的评价与决策</h2>"+details
    document+='<script type="application/json" id="nodes">'+json.dumps(compact,ensure_ascii=False,separators=(",",":")).replace("<","\\u003c")+'</script>'
    document+='''<script>
const nodes=JSON.parse(document.getElementById('nodes').textContent);
document.querySelectorAll('.node').forEach(el=>el.addEventListener('toggle',()=>{
 if(!el.open){el.querySelector('.detail')?.remove();return;}
 document.querySelectorAll('.node[open]').forEach(other=>{if(other!==el){other.open=false;other.querySelector('.detail')?.remove();}});
 if(el.querySelector('.detail'))return;
 const n=nodes[Number(el.dataset.index)], box=document.createElement('div');box.className='detail';
 const table=document.createElement('table'), header=table.insertRow();
 ['行动','总分','目标/价值','资源','风险','PSS','记忆','身份','关系'].forEach(label=>{const c=document.createElement('th');c.textContent=label;header.appendChild(c);});
 Object.entries(n.evaluations).sort((a,b)=>b[1].total-a[1].total).forEach(([key,s])=>{const tr=table.insertRow();[key+' · '+n.options[key].label,s.total,s.goal_alignment,s.resource_feasibility,s.risk_calculation,s.current_state_modifier,s.memory_modifier,s.identity_consistency,s.relationship_history_modifier].forEach(v=>{tr.insertCell().textContent=typeof v==='number'?v.toFixed(3):v;});});
 const explanation=document.createElement('p');explanation.textContent=n.score_summary;box.appendChild(explanation);box.appendChild(table);const pre=document.createElement('pre');pre.textContent=JSON.stringify({beliefs:n.actor_belief_state,pss:n.pss_before,outcome:n.outcome},null,2);box.appendChild(pre);el.appendChild(box);
}));</script></html>'''
    (output/"report.html").write_text(document,encoding="utf-8")


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--seed",type=int,default=20261016)
    parser.add_argument("--output",type=Path,default=HERE.parents[2]/"outputs/berlin_blackout_12h")
    args=parser.parse_args()
    payload=BerlinCrisis(args.seed).run()
    save(payload,args.output)
    print(json.dumps({"seed":args.seed,"decisions":len(payload["decisions"]),"events":len(payload["trace"]),"output":str(args.output),"positions":{a:r['site'] for a,r in payload['actors'].items()},"model_diagnostics":payload['model_diagnostics']},ensure_ascii=False))


if __name__=="__main__": main()
