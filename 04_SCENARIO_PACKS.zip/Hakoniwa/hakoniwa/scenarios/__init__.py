"""Saved, reproducible scenario definitions."""

