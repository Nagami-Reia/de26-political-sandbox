#!/usr/bin/env python3
"""Fictional scandal test: continuous evidence, sparse material decisions."""
from __future__ import annotations

import argparse
import json
import random
from dataclasses import asdict
from html import escape
from pathlib import Path

from ...decision_cadence import EvidenceUpdate, MaterialDecisionGate
from ...narrative_media import (
    AudienceSegment, MediaChannel, NarrativeArena, NarrativeFact, NarrativeFrame,
    NarrativeMove,
)
from ...party_interest import PartyInterestEngine, PartyState
from ...persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine


ROOT = Path(__file__).resolve().parents[2]
CARDS = ROOT / "data/personas" / "cards_pss.json"
PARTIES = ROOT / "data/parties" / "party_interest_profiles.json"


def option(key, *, values, upside, downside, feasibility, strategy,
           institutional=0.0, visibility=.65, information=.65):
    return ActionOption(
        key,
        goal_impacts={"protect_democratic_capacity": .75, "retain_government_control": .62},
        value_impacts=values,
        upside=upside, downside=downside, uncertainty=1-information,
        irreversibility=.25+.45*visibility, effort=.48, visibility=visibility,
        information_confidence=information,
        control_domains=("direction", "organization", "process"),
        restores_control=.45, conflict_strategy=strategy,
        identity_tags=tuple(values),
        event_tags=("foreign_influence", "party_scandal", "evidence_integrity"),
        risk_tags=("systemic_crisis", "relationally_fragile"),
        objective_feasibility=feasibility,
        institutional_deviation=institutional,
    )


def persona_menu(actor: str, stage: int, evidence: float) -> tuple[ActionOption, ...]:
    info = max(.25, evidence)
    if actor == "Dobrindt":
        return (
            option("investigative_firewall", values={"institutional_control": .9, "security_delivery": .82},
                   upside=.72, downside=.22, feasibility=.88, strategy="institutionalize", information=info),
            option("centralize_executive_taskforce", values={"security_delivery": .95, "political_control": .72},
                   upside=.82, downside=.62, feasibility=.67, strategy="attack", institutional=.18, information=info),
            option("wait_for_prosecutors", values={"institutional_control": .55, "security_delivery": .28},
                   upside=.35, downside=.46, feasibility=.94, strategy="avoid", visibility=.12, information=info),
        )
    if actor == "Frei":
        return (
            option("classified_crossparty_briefing", values={"organization_success": .9, "political_stability": .86},
                   upside=.7, downside=.24, feasibility=.86, strategy="institutionalize", information=info),
            option("union_only_attack_line", values={"personal_loyalty": .72, "organization_success": .58},
                   upside=.78, downside=.62, feasibility=.78, strategy="attack", information=info),
            option("defer_parliamentary_response", values={"political_stability": .34, "organization_success": .2},
                   upside=.3, downside=.55, feasibility=.9, strategy="avoid", visibility=.1, information=info),
        )
    return (
        option("evidence_first_democratic_firewall", values={"strategic_direction": .88, "political_authority": .72, "unity": .82},
               upside=.74, downside=.28, feasibility=.86, strategy="institutionalize", information=info),
        option("maximal_public_offensive", values={"strategic_direction": .9, "political_authority": .94, "unity": .38},
               upside=.88, downside=.76, feasibility=.7, strategy="attack", visibility=.95, information=info),
        option("hold_until_case_file", values={"strategic_direction": .28, "political_authority": .35, "unity": .68},
               upside=.34, downside=.5, feasibility=.93, strategy="avoid", visibility=.08, information=info),
    )


def afd_menu(evidence: float) -> tuple[ActionOption, ...]:
    return (
        ActionOption("deny_and_counterattack", objective_feasibility=max(.25, .9-.65*evidence),
            party_interest_impacts={"electoral_opposition": .9-1.5*evidence,
                                    "national_sovereignty": .72-.8*evidence},
            party_strategy_impacts={"party_unity": .72-evidence,
                                    "opposition_differentiation": .92-.55*evidence,
                                    "narrative_ownership": .78-.7*evidence},
            organizational_impacts={"organizational_survival": .55-.85*evidence,
                                    "legal_operability": .25-1.2*evidence,
                                    "electoral_viability": .8-1.3*evidence,
                                    "reputation_protection": .4-1.35*evidence,
                                    "internal_cohesion": .8-.35*evidence,
                                    "leadership_continuity": .72,
                                    "information_control": .8-.55*evidence}),
        ActionOption("suspend_accused_and_internal_audit", objective_feasibility=.86,
            party_interest_impacts={"electoral_opposition": .25, "national_sovereignty": .35},
            party_strategy_impacts={"party_unity": -.25, "opposition_differentiation": .15, "narrative_ownership": .5},
            organizational_impacts={"organizational_survival": .72,"legal_operability": .82,
                                    "electoral_viability": .3,"reputation_protection": .62,
                                    "internal_cohesion": -.25,"leadership_continuity": -.42,
                                    "information_control": .28}),
        ActionOption("limited_admission_external_review", objective_feasibility=.72,
            party_interest_impacts={"electoral_opposition": -.45, "national_sovereignty": .28},
            party_strategy_impacts={"party_unity": -.55, "opposition_differentiation": -.25, "narrative_ownership": .25},
            organizational_impacts={"organizational_survival": .55,"legal_operability": .95,
                                    "electoral_viability": -.2,"reputation_protection": .76,
                                    "internal_cohesion": -.62,"leadership_continuity": -.72,
                                    "information_control": .08}),
    )


def evidence_stream() -> tuple[EvidenceUpdate, ...]:
    return (
        EvidenceUpdate("press_inquiry", "2026-10-16 07:10", "national_media", "foreign_funding", .18),
        EvidenceUpdate("screenshot", "2026-10-16 07:24", "national_media", "foreign_funding", .27),
        EvidenceUpdate("response_deadline", "2026-10-16 09:00", "press_office", "public_response", .27, decision_required=True),
        EvidenceUpdate("bank_metadata", "2026-10-16 11:40", "investigators", "foreign_funding", .47),
        EvidenceUpdate("second_outlet", "2026-10-16 13:15", "regional_media", "foreign_funding", .51),
        EvidenceUpdate("prosecutor_precheck", "2026-10-16 17:30", "prosecutor", "criminal_process", .64,
                       institutional_state_changed=True, action_menu_changed=True),
        EvidenceUpdate("routine_denials", "2026-10-17 08:00", "party_statements", "narrative", .61),
        EvidenceUpdate("committee_requests", "2026-10-17 12:10", "bundestag_offices", "oversight", .66),
        EvidenceUpdate("briefing_deadline", "2026-10-17 16:00", "bundestag_calendar", "oversight", .68,
                       decision_required=True),
        EvidenceUpdate("foreign_contact_log", "2026-10-19 06:30", "joint_investigation", "espionage", .82,
                       action_menu_changed=True, resource_delta=-.18),
        EvidenceUpdate("duplicate_tip", "2026-10-19 07:05", "anonymous_source", "espionage", .82,
                       payload={"source_reliability": .42, "aggregate_confidence_unchanged": True}),
        EvidenceUpdate("corroboration_deadline", "2026-10-19 14:00", "security_cabinet", "espionage", .83,
                       decision_required=True),
        EvidenceUpdate("committee_hearing_notice", "2026-10-21 09:00", "bundestag", "oversight", .84,
                       institutional_state_changed=True),
        EvidenceUpdate("routine_interview", "2026-10-22 18:00", "television", "narrative", .8),
        EvidenceUpdate("first_poll_fieldwork", "2026-10-24 12:00", "poll_tracker", "public_response", .74,
                       resource_delta=-.14, decision_required=True),
        EvidenceUpdate("negative_evidence", "2026-10-26 10:00", "forensic_review", "espionage_scope", .68,
                       action_menu_changed=True),
        EvidenceUpdate("week_two_strategy", "2026-10-27 09:00", "party_calendar", "political_strategy", .69,
                       decision_required=True),
    )


def narrative_components():
    frames = (
        NarrativeFrame("rule_of_law", "afd_scandal", ("government",),
            ("foreign_influence", "evidence_integrity"), (), ("mainstream", "security", "floating"),
            .82, .62, .72, support_impacts={"Union": .13, "AFD": -.28}, legitimacy_impacts={"government": .18}),
        NarrativeFrame("partisan_exploitation", "afd_scandal", ("government",),
            ("party_scandal",), ("evidence_integrity",), ("mainstream", "floating"),
            .52, .88, .9, support_impacts={"Union": .08, "AFD": .08}, legitimacy_impacts={"government": -.12}),
        NarrativeFrame("political_persecution", "afd_scandal", ("AFD",),
            ("party_scandal",), ("foreign_influence", "evidence_integrity"), ("afd_core", "floating"),
            .48, .92, .9, support_impacts={"AFD": .22, "Union": -.07}, legitimacy_impacts={"AFD": -.08}),
        NarrativeFrame("internal_cleanup", "afd_scandal", ("AFD",),
            ("evidence_integrity",), (), ("afd_core", "floating", "mainstream"),
            .7, .44, .58, support_impacts={"AFD": .06}, legitimacy_impacts={"AFD": .12}),
    )
    channels = (MediaChannel("national", .88, .9, .72, .24,
        {"mainstream": .9, "security": .85, "floating": .8, "afd_core": .55}),)
    audiences = (
        AudienceSegment("mainstream", .36, .8, .48, ("evidence_integrity",), {"government": .62, "AFD": .28}),
        AudienceSegment("floating", .28, .82, .7, ("party_scandal",), {"government": .5, "AFD": .42}),
        AudienceSegment("afd_core", .22, .92, .82, ("political_persecution",), {"government": .18, "AFD": .86}),
        AudienceSegment("security", .14, .76, .4, ("foreign_influence",), {"government": .72, "AFD": .22}),
    )
    return frames, channels, audiences


def line_svg(rows):
    keys=("Union","AFD","SPD","GRUENE")
    colors=("#222","#3973ac","#c42b3b","#4e9a52")
    w,h,l,t=900,340,65,35
    iw,ih=w-l-30,h-t-60
    xs=[l+iw*i/max(1,len(rows)-1) for i in range(len(rows))]
    def y(v): return t+ih*(1-(v-10)/20)
    out=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}"><rect width="100%" height="100%" fill="#faf8f2"/>']
    for n in range(10,31,5): out.append(f'<line x1="{l}" y1="{y(n):.1f}" x2="{w-30}" y2="{y(n):.1f}" stroke="#ddd"/><text x="{l-8}" y="{y(n)+4:.1f}" text-anchor="end">{n}%</text>')
    for key,color in zip(keys,colors):
        pts=' '.join(f'{x:.1f},{y(r["nowcast"][key]):.1f}' for x,r in zip(xs,rows))
        out.append(f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="3"/><text x="{l+keys.index(key)*120}" y="{h-10}" fill="{color}">{key}</text>')
    return ''.join(out)+"</svg>"


def run(seed: int) -> dict:
    rng=random.Random(seed)
    personas=FreeAgentDecisionEngine.from_json(CARDS)
    parties=PartyInterestEngine.from_json(PARTIES)
    parties.states["AFD"]=PartyState(cohesion=.58,electoral_pressure=.9,government_responsibility=0,narrative_control=.42)
    gate=MaterialDecisionGate()
    batches=[]
    for update in evidence_stream():
        batch=gate.ingest(update)
        if batch: batches.append(batch)
    actors=("Merz","Dobrindt","Frei","Merz","Frei","Dobrindt","Merz","Frei","Merz")
    frames,channels,audiences=narrative_components()
    arena=NarrativeArena(frames,channels,audiences,seed=seed,stochastic=True)
    latent={"Union":25.0,"AFD":25.0,"SPD":15.0,"GRUENE":12.0}
    polls=[{"node":"T0 synthetic anchor","latent":dict(latent),"nowcast":dict(latent)}]
    nodes=[]
    for index,batch in enumerate(batches):
        actor=actors[min(index,len(actors)-1)]
        evidence=batch.evidence[-1].confidence
        menu=persona_menu(actor,index,evidence)
        resources=personas.cards[actor].initial_resources
        decision=personas.decide(actor,menu,resources,
            current_goals={"protect_democratic_capacity":.88,"retain_government_control":.72},
            scene_tags=("foreign_influence","party_scandal","evidence_integrity"),soft_resource_constraints=True)
        afd_state=PartyState(cohesion=max(.25,.82-.55*evidence),electoral_pressure=.9,
            government_responsibility=0,narrative_control=max(.2,.8-.55*evidence),
            organizational_threat=evidence,legal_exposure=max(0,evidence-.2),
            reputation_pressure=min(1,.25+.75*evidence))
        afd_decision=parties.decide("AFD",afd_menu(evidence),state=afd_state)
        chosen=next(row for row in menu if row.key==decision.chosen_action)
        expected=chosen.objective_feasibility
        observed=max(0,min(1,expected+rng.uniform(-.16,.12)))
        pss=personas.apply_outcome(actor,ActionOutcome(chosen.key,observed,
            tags=(chosen.conflict_strategy,"party_scandal"),expected_success=expected,
            evidence_quality=evidence,outcome_scope=.58,workload=.05))
        gov_frame="partisan_exploitation" if chosen.key in {"maximal_public_offensive","union_only_attack_line"} else "rule_of_law"
        afd_frame="political_persecution" if afd_decision.chosen_action=="deny_and_counterattack" else "internal_cleanup"
        fact=NarrativeFact(f"fact_{index+1}","afd_scandal",("foreign_influence","party_scandal","evidence_integrity"),
            salience=min(.95,.55+.05*index),ambiguity=1-evidence,evidence_strength=evidence,news_competition=.15)
        narrative=arena.resolve_round(fact,(
            NarrativeMove("government",gov_frame,"national",.78,.08,.85),
            NarrativeMove("AFD",afd_frame,"national",.84,.1,.9),
        ))
        for party,delta in narrative.support_deltas.items():
            if party in latent: latent[party]=round(max(0,latent[party]+60.0*delta),3)
        polls.append({"node":batch.node_id,"latent":dict(latent),
            "nowcast":{k:round(v*2)/2 for k,v in latent.items()}})
        nodes.append({"batch":batch.payload(),"actor":actor,"action_menu":[row.key for row in menu],
            "evaluations":{k:asdict(v) for k,v in decision.scores.items()},"chosen_action":decision.chosen_action,
            "outcome":{"observed":round(observed,3),"expected":round(expected,3),"pss":pss},
            "afd_collective":afd_decision.payload(),"narrative":narrative.payload(),"polling_after":polls[-1]})
    return {"schema_version":"afd-scandal-event-driven-1.0","fictional":True,"arcana":False,"seed":seed,
        "contract":"Messages are evidence. Only material changes create decision nodes.",
        "evidence_updates":len(gate.audit),"decision_nodes":len(nodes),"compression_ratio":round(len(gate.audit)/len(nodes),3),
        "nodes":nodes,"pending_evidence":gate.pending_payload(),"polling":polls,
        "pss_final":{a:asdict(personas.runtime[a].state) for a in set(actors)}}


def save(payload: dict, output: Path):
    output.mkdir(parents=True,exist_ok=True)
    (output/"full_trace.json").write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
    (output/"polling.svg").write_text(line_svg(payload["polling"]),encoding="utf-8")
    rows=[]
    for n in payload["nodes"]:
        ev='；'.join(f'{x["at"]} {x["topic"]}' for x in n["batch"]["evidence"])
        scores=''.join(f'<tr><td>{escape(k)}</td><td>{v["total"]:.3f}</td><td>{v["environment_compatibility"]:.3f}</td><td>{v["repetition_modifier"]:.3f}</td></tr>' for k,v in n["evaluations"].items())
        afd=n["afd_collective"]; afd_choice=afd["evaluations"][afd["chosen_action"]]
        rows.append(f'<details><summary>{escape(n["batch"]["node_id"])} · {escape(n["actor"])} → {escape(n["chosen_action"])}</summary><p><b>为什么开节点：</b>{escape(", ".join(n["batch"]["trigger_reasons"]))}</p><p><b>节点内证据流：</b>{escape(ev)}</p><p><b>AfD集合体：</b>{escape(afd["chosen_action"])} · 事件分类 {escape(afd_choice["diagnostics"]["event_fit_classification"])} · 政策适用性 {escape(afd_choice["diagnostics"]["programmatic_applicability"])} · 政策分 {afd_choice["programmatic_score"]:.3f} · 组织生存分 {afd_choice["organizational_survival_score"]:.3f}</p><table><tr><th>选项</th><th>总分</th><th>环境适配</th><th>重复修正</th></tr>{scores}</table></details>')
    html=f'''<!doctype html><html lang="zh"><meta charset="utf-8"><title>AfD丑闻 · 事件驱动节点测试</title><style>body{{max-width:1050px;margin:30px auto;padding:20px;background:#f4f1e9;color:#222;font:15px/1.6 system-ui}}details{{background:#fff;padding:12px;margin:10px 0}}table{{border-collapse:collapse;width:100%}}td,th{{padding:6px;border-bottom:1px solid #ddd;text-align:left}}img{{width:100%}}.warning{{border-left:4px solid #9b2f38;padding-left:12px}}</style><h1>AfD大型丑闻 · 事件驱动节点测试</h1><p class="warning">完全架空，不是在陈述现实中的任何指控。ARCANA关闭。民调为模型nowcast，不是调查。</p><p>{payload["evidence_updates"]}条证据/消息被压缩为{payload["decision_nodes"]}个实质决策节点；比率 {payload["compression_ratio"]}:1。消息仍全部留在审计轨迹中。</p><img src="polling.svg" alt="model polling nowcast"><h2>实质节点</h2>{''.join(rows)}</html>'''
    (output/"report.html").write_text(html,encoding="utf-8")


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--seed",type=int,default=20261016)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    payload=run(args.seed); save(payload,args.output)
    print(json.dumps({"seed":args.seed,"evidence_updates":payload["evidence_updates"],
        "decision_nodes":payload["decision_nodes"],"output":str(args.output)},ensure_ascii=False))


if __name__=="__main__": main()
