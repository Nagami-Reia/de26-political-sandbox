"""Hypothetical AfD scandal used to validate event-driven decision cadence."""
