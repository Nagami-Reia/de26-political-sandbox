# AI入口：政治箱庭模拟器

你拿到的是一个自包含、仅依赖 Python 标准库的政治角色决策沙盒。它不是现实预测器，也不允许人格直接改写世界结果。

## 先做这三步

在解压后的目录运行：

```bash
python3 run_cli.py validate --pretty
python3 run_cli.py actors
python3 run_cli.py protocol
```

如果 `python3` 不存在，寻找环境中可用的 Python 3.10+。不要联网安装依赖；本包不需要第三方库。

## 权威文件

- `hakoniwa/data/personas/cards_pss.json`：当前唯一正式人物卡，共17人。
- `hakoniwa/persona_v2.py`：人物决策、关系记忆、habituation与归因转换。
- `hakoniwa/political_state_system.py`：PSS压力—恢复系统。
- `hakoniwa/cli.py`：机器接口与JSON协议。
- `hakoniwa/decision_space.py`：由新事件动态生成认知、目标、策略、风格与后果分支。
- `hakoniwa/README.md`、`hakoniwa/docs/ARCHITECTURE.md`、`hakoniwa/docs/V3_IMPLEMENTATION.md`：模型边界。

不要把旧的 `cards.json` 或 `cards_v2.json` 当成当前卡；它们只用于早期版本复现。

## 给AI最简单的玩法

### 查看人物

```bash
python3 run_cli.py card Merz --pretty
```

### 让人物面对AI提供的事件和选项

```bash
python3 run_cli.py decide Merz \
  --request hakoniwa/examples/decision_request.json \
  --pretty
```

输出包含每个选项的完整评分、人物选择、PSS以及关系状态。AI负责构造世界事实和行动菜单；人格引擎只负责选择。

### 连续互动

`play` 使用一行一个JSON的持久会话：

```bash
python3 run_cli.py play Merz < hakoniwa/examples/play_session.jsonl
```

支持命令：`event`、`decide`、`outcome`、`advance_time`、`state`、`quit`。

## AI必须遵守的模型边界

1. 人格卡是决策函数，不是剧情脚本。
2. 世界、权限、行动菜单和结果由环境层提供。
3. 随机项只能代表不可观测信息或外部偶然性，不能代表“人格随机”。
4. 模型数值是可修改假设，不是现实概率或心理诊断。
5. observed facts、model assumptions、unknown black boxes必须分开陈述。
6. 关系是定向的：`Merz→Frei`不等于`Frei→Merz`。
7. 重复事件应使用同一个`event_type`，这样habituation和结构性归因才能识别模式。
8. 行动若作用于关系，应设置`relationship_posture`：`repair`、`boundary`、`rupture`、`comply`或`exit`。

## 修改后如何自检

```bash
python3 -m unittest discover -s . -p 'test*.py'
python3 run_cli.py validate --pretty
```

任何新增人物都必须进入正式 `cards_pss.json`，并保持所有参数在 `0.000–1.000`，除明确允许为负的valence或效果方向。

## 推荐给另一个GPT的开场提示

> 先完整阅读 AI_START_HERE.md，然后运行 validate、actors 和 protocol。把 cards_pss.json 视为唯一正式人物卡。你可以创建新的世界事件和行动菜单，但不得让人格模块直接决定世界事实或行动结果。每轮保存完整JSON trace，并明确区分事实、模型假设和未知黑箱。
