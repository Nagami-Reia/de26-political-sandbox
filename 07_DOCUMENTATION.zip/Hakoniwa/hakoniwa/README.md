# Hakoniwa

Hakoniwa is an auditable political decision sandbox. It separates objective
world state, institutions, incomplete information, personas, party collectives,
strategic interaction, outcomes, media narratives, polling observation and
dynamic political state.

It is not an election oracle, a psychological diagnosis, or a claim that model
path frequencies are real-world probabilities.

## Run

```bash
python3 -m hakoniwa validate --pretty
python3 -m hakoniwa actors
python3 -m hakoniwa protocol
python3 -m hakoniwa scenarios
```

One decision:

```bash
python3 -m hakoniwa decide Merz \
  --request hakoniwa/examples/decision_request.json --pretty
```

Persistent JSONL session:

```bash
python3 -m hakoniwa play Merz < hakoniwa/examples/session.jsonl
```

Tests:

```bash
python3 -m unittest discover -s . -p 'test_*.py'
```

## Directory map

```text
hakoniwa/
├── core Python modules           decision, state, information and world engines
├── checks/                       objective constitutional and institutional checks
├── procedures/                   procedure state and resolution
├── interaction/                  intents and compilation
├── data/
│   ├── personas/                 canonical persona deck and provenance
│   ├── parties/                  party collective profiles
│   ├── environments/             shared world configurations
│   ├── calibration/              observation/calibration material
│   └── research/                 model research notes
├── plugins/
│   └── arcana/                   optional seeded advisory plugin
├── scenarios/                    runnable scenario sources; no generated reports
├── examples/                     requests and embedding examples
├── labs/                         experimental fixtures
├── tests/                        regression and behavioral tests
├── docs/                         architecture and subsystem documentation
└── legacy/                       archived engines, including 2024 K-Frage calibration
```

The package name is `hakoniwa`. K-Frage now appears only where it belongs: the
historical 2024 retrospective and its calibration data.

## Canonical contracts

- `data/personas/cards_pss.json` is the canonical persona deck.
- Personality chooses among perceived actions; it never creates world facts.
- Messages are evidence updates, not automatically decision nodes.
- Party policy interests and organizational-survival interests are separate.
- PSS confidence uses expected-versus-observed outcomes, evidence quality and
  outcome scope; it is not a cumulative victory counter.
- Facts affect support through narrative/audience processing, then polling
  observation. Generated charts are model traces, not surveys.
- ARCANA is optional and disabled by default.

## Historical compatibility

The original 2024 K-Frage calibration remains at:

```bash
python3 -m hakoniwa.legacy.kfrage_2024_retrospective
```

It is retained for retrospective calibration only and is not the canonical
Hakoniwa runtime.

## Documentation

- `docs/MODEL_OVERVIEW_CN.md`
- `docs/ARCHITECTURE.md`
- `docs/DECISION_SPACE.md`
- `docs/LIVING_POLITICAL_WORLD.md`
- `docs/NARRATIVE_MEDIA.md`
- `data/personas/PERSONA_V2.md`
- `data/personas/POLITICAL_STATE_SYSTEM.md`
