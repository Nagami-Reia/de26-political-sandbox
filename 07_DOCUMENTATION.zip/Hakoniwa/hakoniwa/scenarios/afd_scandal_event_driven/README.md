# AfD scandal — event-driven cadence test

This is a wholly fictional stress test dated 2026-10-16. It is not a claim
about any real person or party event. The scenario tests one architectural rule:

> messages and reports enter an evidence buffer; only a material change opens a
> decision node.

Material changes are evidence-classification crossings, a changed action menu,
an institutional transition, a material resource shift, or a real deadline.
ARCANA is disabled. Party collectives use existing programme/interest profiles;
Merz, Dobrindt and Frei use the existing persona deck. Poll movement is mediated
through competing narrative frames and is a model nowcast, not survey data.

Run:

```bash
python -m hakoniwa.scenarios.afd_scandal_event_driven.run_scenario \
  --seed 20261016 --output /tmp/afd-scandal-test
```
