# 外部政治环境：现实考据与实现边界

核查日：2026-10-15。第一轮36份一手资料、27条证据/假设/未知项记录，见 [机器可读账本](evidence_ledger.json)。这是制度与运作机制考据，不是一次完整的当日人事、经济或安全态势刷新。原历史快照的2026-07-31截止时间不变。

## 考据怎样进入代码

记录包含来源、层级、证据地位、可支持的命题与实际实现位置。相同机构的日历和计划文件可交叉核对日期，但不算两家独立证据。搜索索引可读、全文打不开的资料单独标注，不能当作已完整研读。

五种地位：`REAL_OBSERVED`（来源直接支持）、`MODEL_INFERRED`（明确推论）、`SIMULATION_ASSUMPTION`（运行假设）、`SCENARIO_GENERATED`（模拟结果）、`UNKNOWN`（未知）。现实观察必须有有效来源ID；程序只能检查引用存在，不能证明来源真的支持用户填写的数值。语义核查仍需人工。

模拟改变观察值后，当前值改标为模拟生成，保留最初地位与最后改变它的行动。完整轨迹是客观审计视角，不能整份作为人物下一轮输入。

## 六层映射

| 层 | 考据支持的结构 | 本轮实际接入 | 尚未实现/估计 |
|---|---|---|---|
| L1 时间空间 | 官方会议周、统计日程、24/7机构 | 官方会议周参考、GMLZ独立日历、原分钟事件时钟 | 交通、个人预约、有取消/恢复代价的紧急抢占 |
| L2 制度法律 | GG、GOBT、GGO效力及适用对象不同 | 账本接入原检查框架；日历不等于授权 | 完整立法生命周期、定足数争议流程、逐法案同意权分类 |
| L3 资源容量 | 财政授权和行政组织不能凭意志生成 | 保留有限队列，容量默认值明确是假设 | 预算科目、承诺授权、人员/技能、采购 |
| L4 社会政治 | 经济状态、统计报告、民调投射不同 | 保留世界变量/政党集合体，禁止伪装当前事实 | 当日宏观快照、群体参数的实证拟合 |
| L5 信息传播 | 消息流转、保密、提前获取、公开时间 | 已送达信念、延迟/错误报告、私有/隐藏事实隔离 | 自动转发、泄密率、拟合后的公众反应 |
| L6 事件后果 | 机构自行运转、联邦与州分工 | 无人物也能推进机构/事件；完成时结算 | 通用实施惯性、撤回成本、外生风险率 |

不能把JSON开关写成true就宣称缺失机制已实现。

## 日程不是法律许可

[Bundestag官方2026日历](https://www.bundestag.de/parlament/plenum/sitzungskalender/bt2026-1084980)与[计划文件21/432](https://dserver.bundestag.de/btd/21/004/2100432.pdf)一致：22个计划会议周；10月为5–9和12–16日。已逐周录入，只代表计划，不证明某项议案当日获准表决。

[GOBT §20](https://www.gesetze-im-internet.de/btgo_2025/__20.html)涉及具体日程与议程。[GG 39(3)](https://www.gesetze-im-internet.de/gg/art_39.html)允许提前召集，并规定特定请求下必须召集。因此“非会议周”不等于“法律禁止开会”；“紧急”也不等于“自动获准表决”。代码返回日程背景、非常召集路线和NOT_DETERMINED许可状态。

Bundesrat精确2026日程获取失败，保留UNKNOWN，不能照抄Bundestag。内阁[通常周三开会](https://www.bundesregierung.de/breg-de/aktuelles/das-bundeskabinett-346746)是实践节奏，不是所有政府活动只能周三进行。

[BBK GMLZ](https://www.bbk.bund.de/DE/Themen/GMLZ/gmlz_node.html)明确连续运转。实现为该机构独立全天日历，而非给所有部长全天行动能力。其600分钟默认预算仍是兼容性假设，不是BBK观测值；连续覆盖需要的人员轮班模型尚未建成。

## 表决、立法和执行不能混成一次成功判定

[GOBT §45](https://www.gesetze-im-internet.de/btgo_2025/__45.html)不仅有超过半数成员在场的要求，还规定质疑、清点和正式认定程序；弃权与无效票也计入在场。当前通用投票接口没有完整实现这些步骤，不能宣称通过了全套德国议事程序审计。

[GG 42](https://www.gesetze-im-internet.de/gg/art_42.html)的默认多数与特殊程序的成员多数、特别多数要区分。[GG 38](https://www.gesetze-im-internet.de/gg/art_38.html)保护自由委任：党团纪律影响行为，但不是保证赞成票的法律命令。

[GG全文](https://www.gesetze-im-internet.de/gg/BJNR000010949.html)第76、78、83、84条与[第77条](https://www.gesetze-im-internet.de/gg/art_77.html)要求区分政府提案前置、Bundestag通过、Bundesrat同意/异议、调解、生效及执行机关。六周不是一切法案的固定等待时间，也不是所有政策都有Bundesrat同意权。将来须逐案确定法律类别和分支，不能用“总理努力程度”跳过程序。

[GGO](https://www.verwaltungsvorschriften-im-internet.de/bsvwvbund_21072009_O11313012.htm)规定部门分工、协调、记录与参与。这支持组织流程和行政惯性，但不能据此编出“所有部门平均延迟三天”。[NKR报告](https://www.normenkontrollrat.bund.de/Webs/NKR/SharedDocs/Downloads/DE/Jahresberichte/2024-jahresbericht.pdf?__blob=publicationFile&v=3)的改进建议不能自动升格为现行法。

[BHO](https://www.gesetze-im-internet.de/bho/BJNR012840969.html)及[HG2026](https://www.gesetze-im-internet.de/hg_2026/BJNR1570A0025.html)支持预算授权与执行资源分离。当前注意力预算不是财政预算，没有实现的预算检查不会假装已通过。

## 信息存在不等于人物知道

[VSA](https://www.verwaltungsvorschriften-im-internet.de/bsvwvbund_13032023_SII554001405.htm)的按需知悉、GGO流转责任，以及[IFG例外](https://www.gesetze-im-internet.de/ifg/__3.html)共同支持“事实—获取—认知”分离；它们不提供政治人物私人网络的准确拓扑。

原InformationFilter读取每个真实变量，再加噪声/降低置信度，仍泄露答案。新共享链默认DELIVERED_ONLY：反复observe不刷新真相，反事实分支也不能刷新。旧场景/构造器默认模式保留，未迁移的旧入口并未自动修复。

消息包含时间、收件人、来源、报告值和置信度。报告可以错；未收到的人不获得该变量。PUBLIC表示可公开，不表示所有人物已读过；收件人仍须明确列出。初始信念是显式先验，不是复制真实初值。缺少资源报告时保留人物卡先验，不读取真实资源补洞。

PRIVATE事件不自动开公共媒体轮次；HIDDEN事件可先改变世界而不通知人物。公开/泄密需要另一个明确事件/传播动作；当前没有自动泄密率或完整安全许可执行。

## 媒体、公众认知和支持率

[GLES](https://www.gesis.org/gles/ueberblick)及其[2025资料](https://www.gesis.org/en/gles/2025-federal-election)提供可用于估计的数据；[FGW说明](https://www.forschungsgruppe.de/FAQ/)区分调查政治情绪与投射。它们不支持统一的“每次采访加三点”因果系数，也不公开足以复制全套专有模型的参数。

共享环境已删除support_points_per_unit:3。叙事竞争仍计算受众解释；未提供意见响应模型时只记录认知结果，不改变支持率。试验响应需标为SIMULATION_ASSUMPTION，逐目标指定尺度、单次变化上限、延迟并保存理由。它仍是简化的假设桥接器，不是经过估计的选民模型。当前不存在经验证的INSA复制品，也未做完整多党支持总和守恒模型。

## 世界的其他时钟

[Destatis发布](https://www.destatis.de/DE/Presse/Wochenvorschau/_inhalt.html)与[修订日程](https://www.destatis.de/DE/Methoden/Revisionen/Tabellen/revisionskalender-vgr-bip.html)说明报告发布不等于真实经济。[Eurostat](https://ec.europa.eu/eurostat/en/web/products-eurostat-news/w/wdn-20260105-1)还区分下周已确认与更远期暂定安排。这些日程不依赖主角行动。

[BA日程](https://statistik.arbeitsagentur.de/DE/Navigation/Service/Veroeffentlichungskalender/Veroeffentlichungskalender-Nav.html)的官方索引显示统计产品、公报和提前获取时间不同；[地方BA日历](https://www.arbeitsagentur.de/vor-ort/rd-rps/presse/veroeffentlichungstermine)交叉确认日期。未导入未公布的失业率，也未把预定日期编成必然坏消息。

[ECB日历](https://www.ecb.europa.eu/press/calendars/mgcgc/html/index.en.html)给出会议日期，不给未来利率结果。[DWD资料入口](https://www.dwd.de/DE/leistungen/opendata/hilfe.html?lsbId=627548)表明警报有空间标识；全文403，本轮没有重建完整CAP规则或估计灾害概率。

## 下一轮考据优先级

1. 编译普通立法、同意法案和异议法案程序，增加时限/权限/定足数测试矩阵。
2. 获取Bundesrat、委员会、党组织与州政府的带版本日历，不以“通常”代替日期。
3. 追踪一项真实政策的起草、协调、通过和实施，用记录估计行政延迟，不凭空定惯性常数。
4. 分析GLES等数据再估计公众响应，处理选择偏差、共同冲击、滞后和零效应。
5. 单独刷新当日人事/预算/宏观与外交事实，逐值保留观测、发布、来源和修订状态。

本轮没有把待办提前写成已完成机制，也没有修改人格卡或预设政治结局。

## 验证记录

2026-10-15运行全库`unittest discover -s . -p 'test_*.py'`：160项通过。本轮增加14项外部环境测试，包括无人物世界、周末机构执行、隐藏事实、延迟错误报告、私人媒体隔离、无默认民调增益、延迟有界反馈、来源校验、资源未知不窥视客观资本及确定性复现。

另执行真实CLI入口`python3 -m hakoniwa world`：返回六层公共环境、36来源/27记录、DELIVERED_ONLY及禁用默认意见响应；不启动情景。测试验证的是工程契约，不能证明数值参数有效或完成现实预测校准。
