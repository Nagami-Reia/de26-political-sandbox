"""Deterministic synthetic mechanism checks; no real-person or poll scenario."""
from copy import deepcopy
import json
from pathlib import Path
from hakoniwa.plugins.majorities import MajorityModel
from hakoniwa.plugins.majorities.model import BEHAVIOR_VERSION

OUT=Path(__file__).resolve().parents[2]/'outputs/majorities_v11_20261025'


def request():
    return {'as_of':'2026-10-25','body':{'id':'SYNTHETIC_COMMITTEE','kind':'faction','secret':False},
        'rule':{'total_weight':1,'quorum':'none'},
        'issue':{'id':'toy','version':'v1','proposer':'L'},
        'members':[{'id':'A','party':'P','weights':{'network':1.,'risk':1.,'discipline':1.},
                    'attendance':1.,'temperature':.2}]}


def main():
    cases={}
    for strength in (.001,.2,.8):
        raw=request()
        raw['ties']=[{'from':'A','to':'L','influence':strength,'evidence_kind':'synthetic_explicit_assumption','issue_scope':'toy'}]
        raw['stances']=[{'actor':'L','stance':1.}]
        cases[f'network_{strength:.3f}']=raw
    old=request();old['issue']['assessments']={'A':{'risk':.8}}
    cases['relative_support_risk_legacy']=old
    new=request();new['issue']['assessments']={'A':{'choice_impacts':{
        'yes':{'risk':.8},'no':{'risk':.8},'abstain':{'risk':0.}}}}
    cases['independent_costs_both_sides_dangerous']=new
    for secret in (False,True):
        raw=request();raw['body']['secret']=secret
        raw['issue']['whips']={'P':{'stance':1.,'coordination':.3,'sanction':.6}}
        cases['discipline_secret' if secret else 'discipline_public']=raw
    results={key:{'request':raw,'evaluation':MajorityModel(raw).evaluate_member('A'),
                  'baseline':MajorityModel(raw).baseline()} for key,raw in cases.items()}
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'results.json').write_text(json.dumps({'behavior_version':BEHAVIOR_VERSION,
        'kind':'SYNTHETIC_MECHANISM_DEMO_NOT_POLITICAL_FORECAST','cases':results},ensure_ascii=False,indent=2))
    lines=['# 组织多数插件 v1.1：机制验证','',
        '这些是一人合成实验，检查机制方向与可解释性，不是现实投票概率，也不是带人物卡的情景模拟；不生成虚假的民调或PSS曲线。','',
        '|案例|赞成|反对|弃权|网络贡献原值|纪律贡献原值|',
        '|---|---:|---:|---:|---:|---:|']
    for key,row in results.items():
        e=row['evaluation'];v=e['probabilities'];terms=e['raw_terms']
        lines.append(f"|{key}|{v['yes']:.3f}|{v['no']:.3f}|{v['abstain']:.3f}|{terms.get('network',0):.3f}|{terms.get('discipline',0):.3f}|")
    lines+=['','## 解释','',
        '- 网络作用由方向×饱和强度构成，强度为min(1,sum(influence))。弱联系近似没有影响；这是有界模型假设，不是历史估计。',
        '- 旧risk明确解释为相对支持指数，仍可作对照；新choice_impacts对三个行动分别扣成本，不会把赞成的成本镜像成反对的奖励。',
        '- 党团coordination与sanction需同时明确输入，秘密表决只移除可观察制裁。协调输入不代表已证实存在规范承诺。',
        '- 没有增加自动忠诚、领袖票仓、投票后的关系奖励或民调奖励。关系强度须来自显式输入；runtime_tie不会按信任值自动猜影响力。',
        '- 所有变化均保留原始分量；旧network计算可用normalized_direction_legacy作对照。尚未修复Persona关系层的零证据学习和归因缺陷。']
    (OUT/'report.md').write_text('\n'.join(lines))
    print('\n'.join(lines[:13]))


if __name__=='__main__':main()
