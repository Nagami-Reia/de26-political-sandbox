"""Verify frozen replay diagnostics and distinguish cycles from missing links."""
from copy import deepcopy
import json
from pathlib import Path
from hakoniwa.plugins.majorities import MajorityModel

ROOT=Path(__file__).resolve().parents[2]
OLD=ROOT/'outputs/zustrom_vote_v11_rerun_20261025'
NEW=ROOT/'outputs/zustrom_feedback_debug_20261025'


def load(folder,name):return json.loads((folder/name).read_text())


def describe(folder):
    b=load(folder,'baseline.json');s=load(folder,'prediction_summary.json')
    votes=[n for n in b['trace'] if n['chosen_action'] in ('second_reading_vote','third_reading_vote')]
    primary=next(n for n in votes if n['chosen_action']=='second_reading_vote')
    rows=list(primary['evaluation']['member_evaluations'].values())
    return {'nodes':len(b['trace']),'date':primary['calendar_date'],'amended':b['amended'],
        'votes':[{'stage':n['chosen_action'],'counts':n['feedback']['result']['counts']} for n in votes],
        'path_counts':s['path_counts'],'input_sha256':s['input_sha256'],
        'path_seeds':[x['seed'] for x in s['paths']],
        'named_votes':b['persona_ballots'][1]['intentions'],
        'network_contacts':sum(x.get('network_diagnostics',{}).get('contacts',0) for x in rows),
        'active_network_members':sum(x['local_utilities_used_for_choice'] and abs(x['weighted_terms'].get('network',0))>0 for x in rows),
        'actual_background_discipline_members':sum(x['local_utilities_used_for_choice'] and abs(x['weighted_terms'].get('discipline',0))>0 for x in rows),
        'persona_local_utility_ignored':sum(not x['local_utilities_used_for_choice'] for x in rows),
        'causal_channels':primary['feedback'].get('causal_channels')}


def main():
    assert load(OLD,'frozen_protocol.json')==load(NEW,'frozen_protocol.json')
    old,new=describe(OLD),describe(NEW)
    assert old['input_sha256']==new['input_sha256'] and old['path_seeds']==new['path_seeds']
    raw={'as_of':'2026-10-25','body':{'id':'toy','kind':'faction'},
        'rule':{'total_weight':2,'quorum':'none'},'issue':{'id':'x','version':'1'},
        'members':[{'id':a,'attendance':1.,'weights':{'network':1.}} for a in ('A','B')],
        'ties':[{'from':a,'to':b,'influence':1.,'evidence_kind':'synthetic','issue_scope':'x'} for a,b in (('A','B'),('B','A'))],
        'stances':[{'actor':'A','stance':1.},{'actor':'B','stance':-1.}]}
    m=MajorityModel(raw);before=deepcopy(m.request);ballot=m.baseline()
    assert m.request==before and m.stances=={'A':1.,'B':-1.}
    assert ballot['result']['member_ballots']=={'A':'no','B':'yes'}
    result={'same_frozen_input_and_seeds':True,'before':old,'after':new,
        'reciprocal_edge_probe':{'request':raw,'ballot':ballot,'snapshot_unchanged':True},
        'verdict':'NO_SAME_BALLOT_RECURSION; UNCONFIRMED_COOPERATION_PAYOFF_AND_PERSONA_INSTRUCTION_BRIDGE_FIXED',
        'historical_reproduction':'STILL_FAILED_DATE_AND_TEXT_DIFFER; PATH_SHARES_NOT_REAL_WORLD_PROBABILITIES'}
    (NEW/'feedback_debug.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    lines=['# 人际影响与票数：回路核对及修复','',
        '核对对象：上一轮v1.1冻结重跑、当前first_reading回放与MajorityModel。不是对所有历史场景的无环证明。','',
        '## 结论','',
        '没有发现同一次表决中的计算死循环。evaluate_member只读取固定stances快照，不递归求别人的票，实际投票也不回写为同次公开立场。即使A与B互相影响，也能单次结算；双向关系图不等于循环函数调用。',
        '跨回合“公开立场影响预测、预测影响行动、行动改变下一回合环境”属于有时间推进的反馈，不能一概删除。若场景作者另写“不断用本轮个票替换立场直到收敛”，可能振荡，但当前回放没有这个循环。','',
        '另发现一个真实的配置漏洞：round_days若为0或负数，有限horizon也无法保证while循环终止。本次实际冻结值是7，不是此前重跑的原因；现已在运行前拒绝不前进的时钟、非法起步时间与反向观察区间。','',
        '## 上轮诊断哪些成立，哪些需收窄','',
        '- 成立：该场景成员网络contacts为0，个人关系在冻结载入时清空；没有真实人际网络贡献，所以不能把结果不变归因于网络自我锁定。',
        '- 成立：没有逐行动choice_impacts，仍使用intensity，所以三项新机制没有得到这份输入的实质检验。',
        '- 需收窄：“没有新网络作用”不等于“没有组织信号作用”。党派公开指令进入背景纪律，且经coherence进入九张人物卡；Frei的报告也会影响Merz的议程评价。',
        '- 需收窄：733条discipline_diagnostics并不是733人的有效纪律贡献。九人实际由Persona选票，本地成员效用不再替他们投票；当前背景纪律非零人数单独统计。',
        '- 预估票数使用全体席位的背景先验，正式表决才替换九人的Persona决定。两者是不同精度，不应伪称人物已知全部真实意向，也不能把预测当已结算票数。','',
        '## 本轮修复','',
        '1. 取消“发起协商/提出修改→自动获得他党合作收益”的跳步。联系和文本提议只记录尝试；没有接收方确认时，合作和已确认审议收益都标UNKNOWN、不给奖惩。没有凭空添加一份成功协议。',
        '2. 人格投票适配器此前只读intensity，会漏读新coordination/sanction。现与背景成员共用同一指令解释函数，避免场景迁移后九人丢失组织信号。当前冻结输入仍用intensity，因此该修复本身没有改本轮九人的选择。',
        '3. 每次表决增加causal_channels和固定快照契约，区分实际生效通道、诊断分量、背景预测和真实投票。',
        '4. 新增互相影响不递归、同次不回写、重复运行无变异、协商尝试不等于接受、Persona读取新字段、诊断贡献不重复计算等测试。','',
        '## 同输入同种子重跑','',
        '|项目|修复前|修复后|','|---|---|---|',
        f"|二读计票|{old['votes'][0]['counts']}|{new['votes'][0]['counts']}|",
        f"|30条整段路径|{old['path_counts']}|{new['path_counts']}|",
        f"|模型节点/日期|{old['nodes']} / {old['date']}|{new['nodes']} / {new['date']}|",
        f"|实际背景纪律非零人数|{old['actual_background_discipline_members']}|{new['actual_background_discipline_members']}|",
        f"|人际网络非零人数|{old['active_network_members']}|{new['active_network_members']}|",'',
        '九人仍全部赞成；没有强制倒戈。变化来自移除未经确认的协商奖惩。路径频率仅描述这个未校准模型，不能当作现实通过概率。',
        '模型仍在不同历史日期、不同文本上表决，历史复现仍失败。主回放还没有真正的双边谈判回应、承诺兑现和被考据的人际网络；本轮没有用猜测关系填补空白。','',
        '## 因果顺序','',
        '上轮公开党派指令 → 本轮背景预估 → 选择盘票时才交付报告 → 人物决定修改/等待/提请议程 → 各党形成自己的公开选择 → 九人各自投票 → 同一快照一次计票。',
        '实际个票没有返回同次network；投票器本身不改人际关系。任何事后关系更新都必须是下一阶段、有证据与归因的事件。','',
        '本轮564项回归测试通过。HTML报告保留九人的逐节点评估及压力曲线；民调仍因锚点晚于冻结日期而未运行。']
    (NEW/'feedback_debug.md').write_text('\n'.join(lines))
    print(json.dumps({'verdict':result['verdict'],'old':old['path_counts'],'new':new['path_counts']},ensure_ascii=False))


if __name__=='__main__':main()
