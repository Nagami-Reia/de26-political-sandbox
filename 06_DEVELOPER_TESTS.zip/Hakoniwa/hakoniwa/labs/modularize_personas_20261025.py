"""One-time lossless split of the existing 17-person deck. Never adds actors."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / 'data/personas'
CHANNEL_VALUES = {
    'party_vote':('party_advantage','party_recovery','csu_relevance','political_authority'),
    'state_vote':('electoral_mandate','electoral_containment','regional_representation','bavarian_control','broad_acceptance'),
    'personal_approval':('political_authority','personal_option','public_opportunity_frame'),
    'party_base':('organizational_trust','party_inclusion','unity','union_unity','csu_and_home_base'),
    'policy_support':('social_legitimacy','broad_acceptance','democratic_responsibility','social_cohesion'),
}
BALLOT_VALUES = {
    'unity':'coherence', 'organization_success':'coherence', 'political_stability':'coherence',
    'institutional_loyalty':'coherence', 'organizational_trust':'coherence', 'csu_leverage':'coherence',
    'political_authority':'public_credibility', 'social_legitimacy':'public_credibility',
    'democratic_differentiation':'public_credibility', 'public_opportunity_frame':'public_credibility',
    'clarity':'clarity', 'evidence_based_judgment':'evidence',
}


def write(path, row):
    path.write_text(json.dumps(row, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def main():
    if (ROOT/'registry.json').exists():
        raise SystemExit('Repository already split; edit components, do not rerun migration')
    deck = json.loads((ROOT/'cards_pss.json').read_text())
    rationality = {p.name:json.loads(p.read_text()) for p in ROOT.glob('rationality_profiles*.json')}
    registry = {'schema_version':'persona-registry-1.0', 'created_at':'2026-10-25',
        'contract':'Actor folders are authoritative; compatibility snapshots are generated. No new actors or numerical calibration.',
        'deck_metadata':{k:v for k,v in deck.items() if k!='actors'}, 'actors':{}}
    for actor, raw in deck['actors'].items():
        folder = ROOT/'actors'/actor
        folder.mkdir(parents=True, exist_ok=True)
        values = {v['key']:v['weight'] for v in raw['fixed_personality']['value_hierarchy']}
        row = lambda component, **kw: {'actor':actor,'component':component, **kw}
        modules = {
            'behavior':row('behavior', fixed_personality=raw['fixed_personality'],
                decision_parameters=raw['decision_parameters'], evidence_confidence=raw['evidence_confidence'],
                source_ids=raw['source_ids'], parameter_status='PRESERVED_LEGACY_MODEL_ASSUMPTIONS'),
            'pss':row('pss',profile=raw['political_state_system'],initial_state=raw['initial_current_state'],
                snapshot_as_of=deck.get('as_of'),contract='Initial state is a dated scenario prior, not current biography'),
            'resources':row('resources',initial_resources=raw['initial_resources'],snapshot_as_of=deck.get('as_of'),
                contract='Environment replaces these dated priors; personality does not grant offices, money or votes'),
            'memory':row('memory',event_memory=raw.get('event_memory',[]),
                contract='Historical replay must filter memories by its freeze; new research does not auto-enter memory'),
            'relationships':row('relationships',relationship_memory=raw.get('relationship_memory',{}),
                parameter_status='PRESERVED_MODEL_STATE_NOT_MEASURED_SOCIAL_NETWORK',
                contract='Directed relations; employment or shared state does not establish a faction or a communication permission'),
            'voting':row('voting',adapter='hakoniwa.plugins.majorities.integration.persona_ballot_decision',
                eligibility='VERIFY_BODY_MEMBERSHIP_AND_DATE_IN_WORLD', legal_vote_options=['yes','no','abstain'],
                value_hierarchy_reference='behavior.fixed_personality.value_hierarchy',
                issue_adapters={'zustrom_2024':{'value_channel_map':{k:v for k,v in BALLOT_VALUES.items() if k in values},
                    'unmapped_values':[k for k in values if k not in BALLOT_VALUES],
                    'status':'PRESERVED_UNCALIBRATED_ISSUE_TRANSLATION_NOT_PERSONAL_POLICY_PREFERENCES'}},
                contract='Context supplies options, costs, received instructions and policy positions. No automatic party yes vote or seat grant.'),
            'polling':row('polling',adapter='hakoniwa.political_poll_feedback.profile_for',
                channel_weights={c:max((values[k] for k in ks if k in values),default=.5) for c,ks in CHANNEL_VALUES.items()},
                derivation={c:{k:values[k] for k in ks if k in values} for c,ks in CHANNEL_VALUES.items()},
                fallback=.5,status='UNVALIDATED_MODEL_ASSUMPTION',
                contract='Only delivered publications enter beliefs; receiver decides whether to continue, revise, pause or withdraw'),
            'communication':row('communication',auto_forward=False,forwarding_requires='EXPLICIT_SELECTED_ACTION',
                known_relationship_targets=list(raw.get('relationship_memory',{})),
                allowed_channels=['scenario_authorized_report_channel'],
                default_channel_access='DENY_UNLESS_WORLD_AUTHORIZES',
                contract='Contact list is not access or delivery. Only forward a received belief; recipient has own trust, delay and reaction. No automatic faction cascade.'),
            'rationality':row('rationality',profiles={name:p['actors'][actor] for name,p in rationality.items() if actor in p['actors']},
                status='PRESERVED_MODEL_ASSUMPTIONS'),
            'evidence':row('evidence',legacy_source_ids=raw.get('source_ids',[]),
                research_as_of='2026-10-25',new_sources=[],claims=[],unknowns=[],
                runtime_parameter_updates_applied=False,
                contract='Research observations, interpretations and unknowns stay separate; no inferred mental-health diagnosis or automatic numerical fitting'),
        }
        for name, data in modules.items():
            write(folder/(name+'.json'),data)
        write(folder/'manifest.json',{'schema_version':'persona-package-1.0','actor':actor,'name':raw['name'],
            'components':{name:name+'.json' for name in modules},'analysis':'analysis.md',
            'runtime_contract':'One shared decision engine, per-person data and adapters; research does not overwrite a historical snapshot'})
        (folder/'README.md').write_text(f'''# {raw['name']} · {actor}

本目录是该人物的权威配置；共享引擎执行它，不复制一套个人 AI。

| 文件 | 负责什么 |
| --- | --- |
| analysis.md | 有来源的行为分析、影响力、反例与未知 |
| behavior.json | 固定人格、价值排序、条件风险和冲突方式 |
| voting.json | 既有投票器接口及逐议题价值映射；不授予议席 |
| relationships.json | 有方向的人际关系、依赖与历史初始状态 |
| polling.json | 各种已送达民调的接收权重与复审接口 |
| communication.json | 向别人转达信息的边界；默认不自动转发 |
| pss.json | 压力—恢复参数及有日期的初始状态 |
| resources.json | 有日期的初始资源；须由世界更新 |
| memory.json | 历史记忆；回溯冻结时须过滤 |
| rationality.json | 工具、实质、人格、战略的既有权重 |
| evidence.json | 来源、观察、推断、未知与参数更新状态 |

修改目录后运行 `python -m hakoniwa.persona_repository export` 更新兼容视图。
''',encoding='utf-8')
        (folder/'analysis.md').write_text(f"# {raw['name']} · 人格与行为逻辑\n\n既有人格类型：{raw['fixed_personality']['archetype']}。\n\n固定量化参数完整保留。扩展考据将按观察／解释／未知补入，不自动改变历史人物记忆、职位或数值。\n",encoding='utf-8')
        registry['actors'][actor]='actors/'+actor
    write(ROOT/'registry.json',registry)
    print(json.dumps({'actors':len(registry['actors']),'behavior_parameter_changes':0}))


if __name__=='__main__':main()
