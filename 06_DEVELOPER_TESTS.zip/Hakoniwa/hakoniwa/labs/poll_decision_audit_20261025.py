"""Audit existing poll -> information -> decision -> task feedback.

Synthetic comparisons expose current missing links; they do not estimate real
politicians' sensitivity or create future polling data for historical replays.
"""
from copy import deepcopy
from dataclasses import asdict, replace
import ast
import json
from pathlib import Path

from hakoniwa.living_world_config import load_living_world
from hakoniwa.living_world import LivingPoliticalWorld, Task, Capacity
from hakoniwa.world_clock import WorldClock
from hakoniwa.persona_v2 import FreeAgentDecisionEngine, WorldEvent
from hakoniwa.political_state import PoliticalAction
from hakoniwa.rationality_evaluation import ActorRationalityProfile

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'outputs/poll_decision_unbound_control_20261025'
FIXTURE=ROOT/'examples/living_world.json'


def decision_with_report(actor,node,value):
    world,_=load_living_world(FIXTURE)
    game=world.game
    game.information.deliver(actor,{'Union':{'estimate':value,'confidence':.9,'source':'synthetic_poll_release'}},message_id='synthetic_release')
    plan=game.prepare_decision(node)
    return {'choice':plan['chosen_key'],'scores':plan['combined_choice_scores'],
        'poll_belief':game.information.payload(plan['beliefs'])['beliefs']['Union'],
        'resource_bindings':game.resource_bindings.get(actor,{})}


def task_world(*,withdraw=False):
    original,_=load_living_world(FIXTURE)
    game=original.game
    node=game.nodes['security_coordination'];action=node.actions[0]
    key='withdraw_proposal' if withdraw else 'continue_reform'
    game.nodes['audit_reform']=replace(node,key='audit_reform',actions=(replace(action,
        choice=replace(action.choice,key=key),
        world=PoliticalAction(key,{'immediate':{} if withdraw else {'coordination_quality':2}})),))
    task=Task('policy','Merz',0,180,10,node='audit_reform',lifecycle='STAGED',
              action_timing={key:{'execution_minutes':60}})
    tasks=[task]
    caps={'Merz':Capacity()}
    if withdraw:
        tasks.append(Task('policy_followup','staff',0,180,10,dependencies=('policy',),effects={'government_capacity':1}))
        caps['staff']=Capacity()
    world=LivingPoliticalWorld(game,WorldClock('2026-10-19T08:00:00+02:00'),caps,tasks)
    return world,task


def main():
    comparisons={}
    for actor,node in (('Merz','reform_agenda'),('Frei','faction_briefing'),('Wadephul','allied_channel')):
        high=decision_with_report(actor,node,30.)
        low=decision_with_report(actor,node,10.)
        assert high['scores']==low['scores'] and high['choice']==low['choice']
        comparisons[actor]={'high_poll':high,'low_poll':low,'scores_identical':True}

    world,task=task_world()
    def release(w,event):
        w.game.information.deliver('Merz',{'Union':{'estimate':10.,'confidence':.9,'source':'synthetic_poll_release'}},message_id='mid_execution_poll')
        w.notify_information('Merz','mid_execution_poll')
        return {'synthetic_report_only':True,'poll_belief':w.game.information.payload(w.game.information.states['Merz'])}
    world.register_event_handler('audit_poll_release',release)
    world.clock.schedule(20,'audit_poll_release',{})
    world.run_until(world.clock.at(100).isoformat())
    assert task.status=='COMPLETED' and task.committed_at==10 and task.finished==70
    staged={'task':asdict(task),'poll_belief':asdict(world.game.information.states['Merz'].beliefs['Union']),
            'trace_events':[x.get('kind') for x in world.trace],
            'interpretation':'Committed plan continues; notify_information wakes waiting only. No automatic political review/cancellation.'}

    world,task=task_world(withdraw=True)
    world.run_until(world.clock.at(100).isoformat())
    child=world.tasks['policy_followup']
    assert task.action_outcome=='SUCCEEDED' and child.status=='COMPLETED'
    withdrawal={'parent':asdict(task),'child':asdict(child),
        'interpretation':'Successful withdrawal task can satisfy a generic action_success dependency; project continuation needs explicit institutional/project state.'}

    engine=FreeAgentDecisionEngine.from_json(ROOT/'data/personas/cards_pss.json')
    profiles={}
    raw=json.loads((ROOT/'data/personas/cards_pss.json').read_text())
    for actor,card in engine.cards.items():
        # Use effective damage before memory resonance to distinguish a PSS
        # coefficient from a demonstrated choice-utility polling weight.
        impact=engine.pss.calculate_impact(actor,WorldEvent('synthetic_poll_decline','poll_decline',.2,('poll_decline',)))
        profiles[actor]={'stress_resistance':card.pss_profile.stress_resistance,
            'explicit_poll_decline_tag_sensitivity':card.pss_profile.sensitivity_map.get('poll_decline'),
            'fallback_tag_sensitivity':.5,'effective_pressure_delta_for_synthetic_event':impact.state_deltas['pressure'],
            'value_hierarchy':{v.key:v.weight for v in card.dna.value_hierarchy},
            'dedicated_poll_decision_weight':'NOT_DEFINED',
            'personality_numeric_status':'MODEL_ASSUMPTION_NOT_MEASURED_BEHAVIOR'}
    rationality={}
    for name in ('rationality_profiles_v3.json','rationality_profiles_expansion_2026_09.json'):
        for actor,values in json.loads((ROOT/'data/personas'/name).read_text())['actors'].items():
            rationality[actor]={'profile':values,'has_metric_specific_weights':bool(values.get('instrumental_metric_weights') or values.get('substantive_metric_weights'))}

    cancel_calls=[]
    for path in ROOT.rglob('*.py'):
        rel=str(path.relative_to(ROOT))
        if rel.startswith(('tests/','labs/')):continue
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='cancel_task':
                cancel_calls.append({'file':rel,'line':node.lineno})
    historical=json.loads((ROOT.parent/'outputs/zustrom_feedback_debug_20261025/baseline.json').read_text())
    result={'schema_version':'poll-decision-feedback-audit-1.0','synthetic_static_menu_comparisons':comparisons,
        'committed_task_report_probe':staged,'withdrawal_dependency_probe':withdrawal,
        'actor_profiles':profiles,'rationality_profiles':rationality,
        'direct_production_cancel_task_calls':cancel_calls,
        'historical_replay_polling':historical['polling'],
        'warning':'Legacy inputs without poll_feedback project bindings are negative controls, not a claim that the new integrated service is inactive',
        'integrated_example':'examples/poll_feedback.json'}
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'probes.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({'static_poll_differential_choices':{a:x['scores_identical'] for a,x in comparisons.items()},
        'committed_task_after_new_poll':staged['task']['status'],'withdrawal_followup':child.status,
        'cancel_calls':cancel_calls,'actors':len(profiles)},ensure_ascii=False))


if __name__=='__main__':main()
