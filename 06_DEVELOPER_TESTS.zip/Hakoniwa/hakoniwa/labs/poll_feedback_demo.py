"""Run the integrated, synthetic poll/decision/task lifecycle example."""
import json
from pathlib import Path
from hakoniwa.living_world_config import load_living_world
from hakoniwa.living_world import LivingPoliticalWorld


def main():
    root=Path(__file__).resolve().parents[1]
    world,until=load_living_world(root/'examples/poll_feedback.json')
    payload=world.run_until(until)
    out=root.parent/'outputs/poll_feedback_integrated_20261025'
    LivingPoliticalWorld.save(payload,out)
    (out/'scenario_input.json').write_text(json.dumps(world.configuration,ensure_ascii=False,indent=2))
    reviews=[r for r in world.services['poll_feedback'].history if 'action' in r]
    summary={'scope':'SYNTHETIC_ENGINEERING_DEMO_NOT_REAL_GERMAN_POLITICAL_PREDICTION',
        'reviews':[{'actor':world.policy_projects[r['project']].owner,'at':r['at'],
                    'choice':r['action'],'status':r['status'],'signal':r['appraisal']['signal']} for r in reviews],
        'final_projects':{k:p.status for k,p in world.policy_projects.items()},
        'tasks':{k:{'status':t.status,'committed_at':t.committed_at,'finished':t.finished} for k,t in world.tasks.items()},
        'attention_minutes':{a:sum(c.spent_by_day.values()) for a,c in world.capacities.items()},
        'report_valid':payload['scenario_report']['valid']}
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(json.dumps(summary,ensure_ascii=False))


if __name__=='__main__':main()
