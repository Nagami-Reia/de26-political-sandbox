"""Attach sourced qualitative research without mutating personality coefficients.

Run after the lossless directory migration. Existing historical snapshots remain
unchanged. Evidence annotations are not actor knowledge or executable scripts.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / 'data/personas'
RESEARCH = ROOT / 'research_20261025'


def read(path):return json.loads(path.read_text(encoding='utf-8'))
def write(path,row):path.write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def render(value):
    if isinstance(value,str):return value
    if isinstance(value,list):return '\n'.join('- '+render(v).replace('\n','\n  ') for v in value)
    if isinstance(value,dict):return '\n'.join(f'{k}：{render(v)}' for k,v in value.items())
    return str(value)


def main():
    registry=read(ROOT/'registry.json')
    sources={};analyses={};failures=[]
    for name in ('core','governance','remaining'):
        data=read(RESEARCH/(name+'.json'))
        for row in data['sources']:
            if row['id'] in sources:raise ValueError('Duplicate research source ID')
            sources[row['id']]=row
        analyses.update(data['actor_analyses'])
        failures.extend(data.get('failed_or_limited_attempts',[]))
    if set(analyses)!=set(registry['actors']):raise ValueError('Research coverage must equal the existing roster')
    shared=read(RESEARCH/'shared.json')['sources']
    for actor,relative in registry['actors'].items():
        folder=ROOT/relative;analysis=analyses[actor]
        # Include cross-actor evidence when an explicit claim cites it; don't
        # assume all records tagged with an actor prove every inference.
        ids=set(analysis.get('source_ids',[]))
        own=[r for r in sources.values() if r.get('actor')==actor or r['id'] in ids]
        evidence=read(folder/'evidence.json')
        evidence.update({'new_sources':own,'analysis':analysis,'research_as_of':'2026-10-25',
            'shared_method_source_ids':[s['id'] for s in shared if s['access_status'].startswith('OPENED')],
            'unknowns':analysis.get('unknowns',[]),'runtime_parameter_updates_applied':False,
            'historical_use':'New dated evidence may inform researcher interpretation, never silently enter past actor beliefs or event memories'})
        write(folder/'evidence.json',evidence)
        behavior=read(folder/'behavior.json')
        behavior['research_annotations']={'as_of':'2026-10-25','rules':analysis['behavior_rules'],
            'execution_status':'ANNOTATIONS_NOT_ACTION_SCRIPT_OR_NUMERIC_UPDATE',
            'counterevidence':analysis.get('counterevidence',[])}
        write(folder/'behavior.json',behavior)
        influence={'actor':actor,'component':'influence','as_of':'2026-10-25',
            'channels':analysis.get('influence',[]),'status':'SOURCED_QUALITATIVE_ANALYSIS',
            'source_ids':analysis.get('source_ids',[]),
            'contract':'A channel of influence is not a quantity of controlled votes, a faction roster, a current office or guaranteed information access'}
        write(folder/'influence.json',influence)
        manifest=read(folder/'manifest.json');manifest['components']['influence']='influence.json'
        write(folder/'manifest.json',manifest)
        sections=[f"# {manifest['name']} · 行为逻辑与人格分析",'研究更新：2026-10-25。数值参数保持既有版本；以下解释不能当作已测量的私人心理。',
            '## 既有决策模型',f"类型：{behavior['fixed_personality']['archetype']}。核心驱动：{behavior['fixed_personality']['core_drive']}。",
            '执行时继续使用 behavior.json 的价值排序、条件风险与冲突方式；世界负责行动可行性、制度权限与客观结果。']
        for title,key in [('整体解释','summary'),('可核实的公开行为','observed_facts'),('条件→行为规则','behavior_rules'),
                          ('影响力渠道及边界','influence'),('反证与不能过度推断的地方','counterevidence'),('仍然未知','unknowns')]:
            if key in analysis:sections.extend(['## '+title,render(analysis[key])])
        sections.extend(['## 资料与运行边界',
            '来源ID、网页地址、正文／摘要／受阻状态见 evidence.json；共享制度和研究文献只在 ../../research_20261025/shared.json 保存一份。',
            '不从任命或雇佣推导派系；不从一句采访推导稳定心理数值；不把本次资料或后来的职位自动注入旧快照。',
            '投票读 voting.json；社会关系读 relationships.json；民调读 polling.json；信息转发读 communication.json；影响力证据读 influence.json。'])
        (folder/'analysis.md').write_text('\n\n'.join(sections)+'\n',encoding='utf-8')
        readme=folder/'README.md'
        text=readme.read_text()
        if '| influence.json |' not in text:text=text.replace('| evidence.json |','| influence.json | 有来源的影响力渠道与控制边界 |\n| evidence.json |')
        readme.write_text(text,encoding='utf-8')
    records=list(sources.values())+shared
    opened=[s for s in records if s['access_status'].startswith('OPENED') or
            s['access_status'] in {'FULL_TEXT_READ','PARTIAL_TEXT_READ_PAYWALL','EXCERPT_ONLY_READ'}]
    urls={s['url'] for s in opened}
    summary={'as_of':'2026-10-25','actors':list(registry['actors']),
        'source_records':len(records),'opened_readable_records':len(opened),
        'opened_unique_urls':len(urls),'failed_or_limited_separate_records':failures,
        'access_status_counts':{status:sum(s['access_status']==status for s in records) for status in sorted({s['access_status'] for s in records})},
        'research_limit':'Readable includes explicitly labelled abstracts, paid introductory sections and selected PDF pages; not all are full-text articles.',
        'new_actors':0,'numeric_personality_parameter_changes':0}
    write(RESEARCH/'summary.json',summary)
    print(json.dumps({k:v for k,v in summary.items() if k!='failed_or_limited_separate_records'},ensure_ascii=False))


if __name__=='__main__':main()
