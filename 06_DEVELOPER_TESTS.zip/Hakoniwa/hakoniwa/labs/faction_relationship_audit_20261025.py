"""Behavioral follow-up audit without tuning outcomes.

Assertions establish fixed regression cases and remaining limitations.
Probe identifiers retain the original defect names for comparison, not verdicts.
No historical ballot comparator is read. Earlier output is preserved.
"""
from copy import deepcopy
from dataclasses import asdict, replace
from pathlib import Path
import ast
import json
import random

from hakoniwa.persona_v2 import (ActionOption, ActionOutcome, FreeAgentDecisionEngine,
    RelationshipMemory, WorldEvent)
from hakoniwa.party_interest import PartyInterestEngine, PartyInterestProfile
from hakoniwa.plugins.majorities.service import MemberVoteService, VoteRule, BallotGroupPrior
from hakoniwa.plugins.majorities import MajorityModel
from hakoniwa.organizational_response import (OrganizationalBloc, PoliticalOrganization,
    OrganizationalRequest, OrganizationalResponseEngine)

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'outputs/faction_relationship_followup_20261025'


def engine():
    return FreeAgentDecisionEngine.from_json(ROOT/'data/personas/cards_pss.json')


def request():
    return json.loads((ROOT/'plugins/majorities/examples/committee.json').read_text())


def main():
    probes={}
    probes['legacy_discipline_inert']={'status':'RETIRED',
        'reason':'Legacy sampler removed; group-prior adapter no longer accepts discipline'}

    raw=request();raw['ties'][0]['influence']=1.
    strong=MajorityModel(raw).evaluate_member('A')
    raw['ties'][0]['influence']=1e-9
    weak=MajorityModel(raw).evaluate_member('A')
    assert strong['raw_terms']['network']>weak['raw_terms']['network']
    probes['network_strength_cancels']={'status':'FIXED_BOUNDED_STRENGTH','strong':strong['raw_terms']['network'],
        'tiny':weak['raw_terms']['network'],'same_probabilities':strong['probabilities']==weak['probabilities']}

    raw=request();raw['members'][0]['weights']={'risk':1.}
    raw['issue']['assessments']['A']={'risk':.8}
    ev=MajorityModel(raw).evaluate_member('A')
    assert ev['utilities']['no']==.8 and ev['utilities']['yes']==-.8
    probes['risk_is_opposition_reward']={'utilities':ev['utilities'],'probabilities':ev['probabilities']}

    e=engine();e.runtime['Merz'].relationships.pop('UNKNOWN_PERSON',None)
    a=ActionOption('test',target_actor='UNKNOWN_PERSON',relationship_posture='repair')
    score=e.score('Merz',a,{},{});r=score.diagnostics['relationship']
    assert r['evidence_status']=='UNKNOWN_NEUTRAL' and score.relationship_history_modifier==0
    probes['unknown_relationship_is_substantive_prior']={'status':'FIXED_NEUTRAL_UNKNOWN','relationship':r,
        'repair_bonus':score.relationship_history_modifier,
        'persisted': 'UNKNOWN_PERSON' in e.runtime['Merz'].relationships}

    for success,label in ((1.,'zero_evidence_heals_relationship'),(.2,'zero_evidence_records_failure')):
        e=engine();rel=RelationshipMemory('Frei',loyalty_injury=.8,structural_unreliability=.6)
        e.runtime['Merz'].relationships['Frei']=rel
        before=asdict(rel);pss_before=asdict(e.runtime['Merz'].state)
        e.apply_outcome('Merz',ActionOutcome('unobserved_targeted_policy',success,
            target_actor='Frei',evidence_quality=0.,outcome_scope=0.,workload=0.))
        assert asdict(rel)==before and asdict(e.runtime['Merz'].state)==pss_before
        probes[label]={'status':'FIXED_EVIDENCE_GATE','before':before,'after':asdict(rel),'pss_unchanged':True}

    e=engine();e.runtime['Merz'].relationships['Frei']=RelationshipMemory('Frei')
    event=WorldEvent('same_report','operational_error',.1,('error',),
                     relationship_deltas={'Frei':{'trust':-.1}})
    e.apply_event('Merz',event);once=asdict(e.runtime['Merz'].relationships['Frei'])
    e.apply_event('Merz',event);twice=asdict(e.runtime['Merz'].relationships['Frei'])
    assert once==twice and once['betrayal_count']==0
    probes['duplicate_relationship_event']={'status':'FIXED_EVENT_IDEMPOTENCE','once':once,'twice':twice}

    # A lapse of reliability is no longer automatically personal betrayal.
    e=engine();e.runtime['Merz'].relationships['Frei']=RelationshipMemory('Frei')
    e.apply_event('Merz',WorldEvent('capacity_delay','administrative_delay',0.,(),
        relationship_deltas={'Frei':{'operational_reliability':-.1}}))
    rel=e.runtime['Merz'].relationships['Frei']
    assert rel.betrayal_count==0 and rel.loyalty_injury==0
    probes['reliability_loss_automatically_betrayal']={'status':'FIXED_EXPLICIT_ATTRIBUTION','relationship':asdict(rel)}

    org=PoliticalOrganization('org',(OrganizationalBloc('bloc',1.,{'A':.4,'B':.6},{'fit':1.}),),decision_capacity=0.)
    o=OrganizationalResponseEngine({'org':org})
    o.submit(OrganizationalRequest('q','org','M','A',1.,60,{'fit':1.}),0)
    response=o.advance_to(60)[0]
    o.organizations['org'].decision_capacity=1.
    later=o.advance_to(120)
    assert response.status=='DEFERRED' and later==[] and o.requests['q']['status']=='DEFERRED'
    probes['deferred_is_not_rescheduled']={'response':response.payload(),'after_capacity_returns':later}

    profile=PartyInterestProfile('P','toy',{'benefit':1.},{},{},{})
    pe=PartyInterestEngine({'P':profile})
    decision=pe.decide('P',(ActionOption('impossible',legal=False,party_interest_impacts={'benefit':1.}),
                            ActionOption('possible',party_interest_impacts={'benefit':-1.})))
    assert decision.chosen_action=='impossible'
    probes['standalone_party_choice_ignores_legality']=decision.payload()

    # Mutating the caller's input silently changes an already-created model.
    raw=request();m=MajorityModel(raw);before=m.evaluate_member('A')['probabilities']
    raw['members'][0]['decided_vote']='no'
    after=m.evaluate_member('A')['probabilities']
    assert before==after
    probes['validated_model_aliases_caller_objects']={'status':'FIXED_SNAPSHOT_ISOLATION','before':before,'after':after,
        'validated_snapshot_has_decided_vote':'decided_vote' in m.request['members'][0]}

    # Inventory actual call sites, distinguish definitions from runtime use.
    symbols={'MajorityModel','persona_ballot_decision','runtime_tie','OrganizationalResponseEngine',
             'MemberVoteService','PartyInterestEngine','power_indices'}
    calls={key:[] for key in symbols}
    scanned=[]
    for file in sorted(ROOT.rglob('*.py')):
        relative=str(file.relative_to(ROOT))
        if relative.startswith(('tests/','labs/')):continue
        tree=ast.parse(file.read_text())
        scanned.append(relative)
        for node in ast.walk(tree):
            if isinstance(node,ast.Call):
                name=node.func.id if isinstance(node.func,ast.Name) else node.func.attr if isinstance(node.func,ast.Attribute) else ''
                if name in calls:calls[name].append({'file':relative,'line':node.lineno})
    OUT.mkdir(parents=True,exist_ok=True)
    data={'schema_version':'faction-relationship-code-audit-1.0','probes':probes,
          'call_inventory':calls,'scanned_production_python_files':len(scanned),
          'scope':'Executable code audit, not empirical validation or exhaustive verification of all scenario data'}
    (OUT/'probes.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
    print(json.dumps({'confirmed_probes':len(probes),'scanned_files':len(scanned),'call_inventory':calls},ensure_ascii=False))


if __name__=='__main__':main()
