"""Non-mutating behavioral audit, separate from successful regression tests.

Run: python -m hakoniwa.labs.system_audit_2026_10_24
Writes diagnostics only; deliberately does not repair or recalibrate engines.
"""
from __future__ import annotations

import ast
from copy import deepcopy
from dataclasses import asdict, replace
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

from hakoniwa.action_perception import ActionPerceptionFilter
from hakoniwa.action_repertoire import ActionRepertoireFilter
from hakoniwa.checks.constitutional import build_gg_check_engine
from hakoniwa.checks.context import CheckContext, BundestagState
from hakoniwa.decision_space import DecisionSpaceGenerator, StrategyEffectModel
from hakoniwa.information_filter import InformationFilter, AccessRule
from hakoniwa.institutional_logic import InstitutionalLogic, PRIORITY_FIELDS
from hakoniwa.institutional_matrix import InstitutionalMatrix
from hakoniwa.interaction.intents import Intent
from hakoniwa.persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine
from hakoniwa.political_agency import AgencyHorizon
from hakoniwa.political_state import PoliticalAction, PoliticalState, StateVariable
from hakoniwa.plugins.majorities.service import MemberVoteService, VoteRule
from hakoniwa.plugins.majorities import MajorityModel
from hakoniwa.plugins.majorities.rules import BallotRule
from hakoniwa.rationality_evaluation import RationalityEvaluator, ActorRationalityProfile
from hakoniwa.system_feedback import SystemFeedbackAssessor, SystemFeedbackContext, SystemFeedbackLedger

ROOT=Path(__file__).resolve().parents[1]
OUTPUT=ROOT.parent/"outputs/system_audit_2026_10_24"
CARDS=ROOT/"data/personas/cards_pss.json"


def write(path, value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+"\n",encoding="utf-8")


def world():
    return PoliticalState({"x":StateVariable("x",50)}, {"M":50}, {})


def engine():
    return FreeAgentDecisionEngine.from_json(CARDS)


def counts(yes=0,no=0,abstain=0,absent=0):
    return {"yes":yes,"no":no,"abstain":abstain,"absent":absent,"invalid":0}


def inventory():
    rows=[]
    markers=("LayeredSimulationOrchestrator","LivingPoliticalWorld","WorldClock","InformationFilter",
             "DecisionSpaceGenerator","OutcomeResolver","NarrativeArena","PollingPlugin","MajorityModel",
             "build_gg_check_engine","OrganizationalResponseEngine","StrategicGame")
    for path in sorted(ROOT.rglob("*.py")):
        text=path.read_text(encoding="utf-8")
        tree=ast.parse(text,filename=str(path))
        calls=[n.func.id if isinstance(n.func,ast.Name) else n.func.attr for n in ast.walk(tree)
               if isinstance(n,ast.Call) and isinstance(n.func,(ast.Name,ast.Attribute))]
        rows.append({"file":str(path.relative_to(ROOT)),"lines":len(text.splitlines()),
            "sha256":sha256(text.encode()).hexdigest(),
            "direct_calls":{m:calls.count(m) for m in markers if m in calls},
            "delivery_only_literal_true":"delivery_only=True" in text or "delivery_only = True" in text,
            "test_file":path.name.startswith("test_"),
            "literal_first_option_good":"good = index == 0" in text})
    return {"scope":"All Python files syntax-scanned; direct-call inventory is NOT proof of transitive runtime coverage",
            "python_files":len(rows),"rows":rows}


def probes():
    rows=[]
    def add(key, reproduced, detail, scope, kind="IMPLEMENTATION_OR_CONTRACT_DEFECT"):
        rows.append({"id":key,"reproduced":bool(reproduced),"kind":kind,"scope":scope,"detail":detail})

    base=PoliticalAction("attempt",{"immediate":{"x":10}},capital_delta={"M":-10},
        pressure_delta={"crisis":15},locks_add=("bill_adopted",),closes_actions=("alternative",),next_node="victory")
    # Explicitly declare these legacy accounts as conditional when testing
    # structural transitions. Attempt-cost semantics have their own probe below.
    branches=DecisionSpaceGenerator._outcomes("attempt",base,.500,.500,StrategyEffectModel(base.effects,
        capital_delta=base.capital_delta,pressure_delta=base.pressure_delta,
        legacy_account_deltas_are_outcome=True))
    failure=next(b for b in branches if b.key=="failure")
    state=world();state.apply(failure.world_action)
    add("A01_FAILURE_RETAINS_ROUTE_LOCKS", "bill_adopted" in state.locks,
        {"branch":failure.key,"effects":failure.world_action.effects,"locks":sorted(state.locks),
         "closed_actions":sorted(state.closed_actions),"next_node":failure.world_action.next_node},
        "Generic generated branch resolver; only relevant to callers using such structural fields")
    attempt_model=StrategyEffectModel(base.effects,attempt_capital_delta={"M":-10},attempt_pressure_delta={"crisis":15})
    attempt_base=replace(base,capital_delta={},pressure_delta={})
    attempt_failure=next(b for b in DecisionSpaceGenerator._outcomes("attempt",attempt_base,.500,.500,attempt_model) if b.key=="failure")
    paid=world();paid.apply(attempt_failure.world_action)
    add("A02_FAILURE_ERASES_ATTEMPT_COST",paid.capital["M"]==50 and paid.pressures["crisis"]==0,
        {"declared_cost":-10,"settled_cost":paid.capital["M"]-50,"declared_pressure":15,
         "settled_pressure":paid.pressures["crisis"],"accounting":attempt_failure.accounting},
        "Executed-attempt deltas must remain payable when conditional payoff fails",kind="MODEL_DEFAULT_DEFECT")

    e=engine();a=ActionOption("plain_consultation",conflict_strategy="negotiate")
    for _ in range(3):e.apply_outcome("Frei",ActionOutcome(a.key,.500,workload=0,evidence_quality=0,outcome_scope=0))
    score=e.score("Frei",a,{},{});history=deepcopy(e.runtime["Frei"].action_history)
    add("A03_HANDWRITTEN_REPETITION_NOT_MATCHED",score.repetition_modifier==0,
        {"score_family":score.diagnostics["action_family"],"stored_families":[r["family"] for r in history],
         "recent_family_uses":score.diagnostics["recent_family_uses"],"penalty":score.repetition_modifier},
        "Handwritten action keys: score uses conflict strategy fallback, outcome storage uses raw key")

    e=engine();probe=ActionOption("next_probe",event_tags=("UNIQUE_AUDIT_TAG",))
    before=e.score("Merz",probe,{},{}).memory_modifier
    state_before=asdict(e.runtime["Merz"].state)
    e.apply_outcome("Merz",ActionOutcome("prior_probe",1.,tags=("UNIQUE_AUDIT_TAG",),workload=0,evidence_quality=0,outcome_scope=0))
    after=e.score("Merz",probe,{},{}).memory_modifier
    add("A04_ZERO_EVIDENCE_STILL_CREATES_VALENCED_MEMORY",after!=before,
        {"memory_score_before":before,"memory_score_after":after,
         "dynamic_state_unchanged":state_before==asdict(e.runtime["Merz"].state)},
        "PSS evidence gates state updates, not memory severity/valence; later persona scoring reads those memories")

    rules={"M":{"x":AccessRule(0.,source="unavailable")}}
    observed=InformationFilter(rules).observe("M",world())
    add("A05_ZERO_ACCESS_LEGACY_REVEALS_TRUTH","x" in observed.beliefs and observed.beliefs["x"].estimate==50,
        InformationFilter.payload(observed),"Legacy InformationFilter delivery_only=False; delivered-only path does not do this")
    noisy={"M":{"x":AccessRule(.500,noise=10)}}
    left=InformationFilter(noisy,seed=7,stochastic=True)
    right=InformationFilter(noisy,seed=7,stochastic=True)
    left.observe("M",world(),commit=False)
    x=left.observe("M",world(),commit=True).beliefs["x"].estimate
    y=right.observe("M",world(),commit=True).beliefs["x"].estimate
    add("A06_NONCOMMIT_OBSERVATION_CONSUMES_RNG",x!=y,{"with_extra_preview":x,"without_preview":y},
        "InformationFilter method/old StrategicGame; canonical response forecast and LivingWorld planner explicitly restore RNG")
    protected=InformationFilter(rules,delivery_only=True).observe("M",world())
    add("CONTROL_DELIVERED_ONLY_HIDES_TRUTH",not protected.beliefs,{},"Current delivered-only path",kind="PROTECTED_CONTROL")

    ctx=CheckContext(0,BundestagState(733),{}, {})
    bundle=build_gg_check_engine().check(ctx,Intent("unknown","M","replace_chancelor_typo"))
    add("A07_UNKNOWN_INTENT_FAILS_OPEN",bundle.resolution.value=="executable",bundle.payload(),
        "Unrecognized intent is NOT_APPLICABLE everywhere then executable; missing coverage cannot be called a passed legal review")

    old=MemberVoteService()
    empty=old.settle("probe","vote",VoteRule("two_thirds_cast",10),0,0,10,0)
    new=BallotRule(10,"fraction_cast").settle(counts(abstain=10))
    add("A08_LEGACY_EMPTY_FRACTION_VOTE_PASSES",empty.passed and not new["passed"],
        {"legacy":asdict(empty),"new_plugin":new},"Legacy vote path vs newer majorities plugin")
    try:
        invalid=old.settle("probe","vote",VoteRule("simple_cast",10),999,0,0,0)
        invalid_accepted=invalid.passed
        invalid_detail={"declared_members":10,"accepted_yes":invalid.yes,"passed":invalid.passed}
    except ValueError as error:
        invalid_accepted=False
        invalid_detail={"declared_members":10,"submitted_yes":999,"rejected":True,"reason":str(error)}
    add("A09_LEGACY_ROSTER_CONSERVATION_UNCHECKED",invalid_accepted,
        invalid_detail,"Legacy MemberVoteService.settle")

    def perceived(logic,exposures=None):
        a=ActionOption("probe",institutional_deviation=.400,
            institutional_pressure_exposure=exposures or {})
        matrix=InstitutionalMatrix("probe",{}, {})
        rep=ActionRepertoireFilter(matrix).apply("M",(a,),{})
        return ActionPerceptionFilter().apply((a,),rep,logic,AgencyHorizon(),{})["probe"].payload()
    neutral=InstitutionalLogic.neutral()
    changed=replace(neutral,governability_priority=1.,electoral_survival_priority=1.,
                    fiscal_efficiency_priority=1.,organizational_unity_priority=1.)
    priority_probes={channel:{
        "neutral":perceived(neutral,{channel:.500})["political_success_expectation"],
        "active":perceived(replace(neutral,**{field:1.}),{channel:.500})["political_success_expectation"],
    } for channel,field in PRIORITY_FIELDS.items()}
    add("A10_INSTITUTIONAL_PRIORITY_FIELDS_INERT",
        any(row["neutral"]==row["active"] for row in priority_probes.values()),
        {"channels":priority_probes,"undeclared_exposure_unchanged":perceived(neutral)==perceived(changed),
         "model":"DOMINANT_ENVELOPE_V1_UNCALIBRATED"},
        "Priorities require explicit perceived resistance exposure; no inferred utility bonus or change to objective outcomes",kind="DISCONNECTED_CAPABILITY")

    # Fixed preference .6 is closer to status quo .5 than proposal .8, yet
    # distance-only signed scoring gives the proposal positive support.
    request={"schema_version":"hakoniwa-majorities-1.0","as_of":"2024-09-12",
        "body":{"id":"toy","kind":"faction"},"rule":{"total_weight":1,"quorum":"none"},
        "issue":{"id":"toy","version":"v1","position":{"x":.800},
                 "status_quo":{"position":{"x":.500},"source_status":"MODEL_ASSUMPTION"}},
        "members":[{"id":"m","position":{"x":.600},"weights":{"policy":1.},"temperature":.200}]}
    ev=MajorityModel(request).evaluate_member("m")
    add("A11_POLICY_DISTANCE_OMITS_STATUS_QUO",ev["utilities"]["yes"]>ev["utilities"]["no"],
        {"ideal":.600,"declared_status_quo":.500,"proposal":.800,
         "utilities":ev["utilities"],"comparison":ev["policy_comparison"],
         "note":"Explicit toy assumptions, not evidence of actual MP preferences"},
        "New member vote utility; conceptual default, not arithmetic error",kind="MODEL_SPECIFICATION_DEFECT")

    state=world()
    rejected_reason=None
    try:
        state.apply(PoliticalAction("impossible",{"immediate":{"x":10}},feasibility=0.))
    except ValueError as error:
        rejected_reason=str(error)
    add("A12_RAW_STATE_SETTLEMENT_IGNORES_FEASIBILITY",state.variables["x"].value==60,
        {"feasibility":0.,"before":50,"after":state.variables["x"].value,"rejected_reason":rejected_reason},
        "Unresolved intended effects cannot be ledger entries; resolved facts and explicit deterministic assumptions remain distinct",kind="UNGUARDED_SETTLEMENT_CONTRACT")
    e=engine()
    action=ActionOption("reinforce_probe",necessity_frame_alignment=1.,
        instrumental_impacts={"capacity":.800},substantive_impacts={"autonomy":.400})
    evaluation=RationalityEvaluator().evaluate(action,e.score("Merz",action,{},{}),ActorRationalityProfile())
    def repeat_feedback(times):
        logic=InstitutionalLogic.neutral()
        agency=AgencyHorizon()
        ledger=SystemFeedbackLedger()
        for _ in range(times):
            feedback=SystemFeedbackAssessor().assess(action,evaluation,logic,.800)
            logic,agency,_=ledger.apply(feedback,SystemFeedbackContext("one_causal_outcome",1.),
                logic,agency,actor="Merz",enabled=True)
        return {"necessity":logic.necessity_claim_strength,"alternative_legibility":logic.alternative_legibility}
    one,ten=repeat_feedback(1),repeat_feedback(10)
    add("A13_SYSTEM_FEEDBACK_COUNTS_NODES_NOT_TIME",one!=ten,{"one_node":one,"ten_nodes":ten},
        "One declared causal outcome, repeated diagnostic/settlement calls; canonical ledger must not count nodes as new institutional events",kind="MODEL_SPECIFICATION_DEFECT")
    from hakoniwa.plugins.polling.electorates import ElectorateAtlas
    try:
        ElectorateAtlas().state("NW",as_of="2024-09-12")
        blocked=False
    except ValueError:
        blocked=True
    add("CONTROL_POLLING_ANCHOR_CUTOFF",blocked,{"future_anchor_blocked":blocked},
        "2025 demographic atlas refuses a 2024 query",kind="PROTECTED_CONTROL")
    return rows


def main():
    OUTPUT.mkdir(parents=True,exist_ok=True)
    scan=inventory();write(OUTPUT/"inventory.json",scan)
    checks=probes();write(OUTPUT/"probes.json",checks)
    # No baseline is recomputed or overwritten by this audit.
    baseline=ROOT.parent/"outputs/zustrom_first_reading/baseline.json"
    if baseline.exists():
        payload=json.loads(baseline.read_text())
        write(OUTPUT/"replay_wiring.json",{
            "baseline_source":str(baseline),"baseline_sha256":sha256(baseline.read_bytes()).hexdigest(),
            "nodes":len(payload["trace"]),"actions":dict(__import__('collections').Counter(
                n["actor"]+":"+n["chosen_action"] for n in payload["trace"])),
            "explicit_unknown_vote_reports":sum(n["actor"]=="Frei" and n["feedback"].get("report_margin") is None for n in payload["trace"]),
            "file_direct_calls":next(r["direct_calls"] for r in scan["rows"] if r["file"]=="scenarios/zustrom_2025_vote_replay/first_reading.py")})
    completed=subprocess.run([sys.executable,"-m","unittest","discover","-s","hakoniwa/tests"],
        cwd=ROOT.parent,capture_output=True,text=True)
    (OUTPUT/"regression.txt").write_text(completed.stdout+completed.stderr)
    summary={"python_files_syntax_scanned":scan["python_files"],"probe_count":len(checks),
        "reproduced_pathologies":sum(c["reproduced"] and c["kind"]!="PROTECTED_CONTROL" for c in checks),
        "regression_exit_code":completed.returncode,
        "behavior_changes_made":False,"scope":"Broad source/wiring audit plus targeted behavioral probes; not exhaustive verification"}
    write(OUTPUT/"summary.json",summary)
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=="__main__":main()
