"""Small runnable examples for embedding the Hakoniwa engine."""
