"""Zero access is absence of observation, not low-confidence omniscience."""
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
import unittest

from hakoniwa.information_filter import AccessRule, Belief, InformationFilter
from hakoniwa.political_state import PoliticalAction, PoliticalState, StateVariable
from hakoniwa.persona_v2 import FreeAgentDecisionEngine
from hakoniwa.free_agent_game import FreeAgentGame
from hakoniwa.strategic_game import ActorDecisionModel, StrategicGame


def world(value=50, uncertainty=0):
    return PoliticalState({"x": StateVariable("x", value, uncertainty=uncertainty)}, {}, {})


class InformationAccessTests(unittest.TestCase):
    def test_zero_access_creates_no_belief(self):
        for commit in (False, True):
            with self.subTest(commit=commit):
                info = InformationFilter({"A": {"x": AccessRule(0)}})
                self.assertNotIn("x", info.observe("A", world(), commit=commit).beliefs)
                self.assertNotIn("x", info.states["A"].beliefs)

    def test_no_access_retains_prior_without_freshening_or_decay(self):
        info = InformationFilter({"A": {"x": AccessRule(0)}})
        info.deliver("A", {"x": {"estimate": 23, "confidence": .8, "source": "staff"}}, message_id="prior")
        before = deepcopy(info.states["A"].beliefs["x"])
        for value in (50, 90, 10):
            actual = info.observe("A", world(value), commit=True).beliefs["x"]
            self.assertEqual(asdict(actual), asdict(before))

    def test_explicit_revocation_does_not_refresh_previous_observation(self):
        info = InformationFilter({"A": {"x": AccessRule(1)}})
        info.observe("A", world(30), commit=True)
        info.rules["A"]["x"] = AccessRule(0)
        self.assertEqual(info.observe("A", world(90), commit=True).beliefs["x"].estimate, 30)

    def test_hidden_variable_does_not_consume_randomness(self):
        info = InformationFilter({"A": {"x": AccessRule(0, noise=10)}}, stochastic=True)
        before = info.rng.getstate()
        info.observe("A", world(), commit=True)
        self.assertEqual(info.rng.getstate(), before)

    def test_positive_access_preserves_biased_observation_without_truth_metadata(self):
        info = InformationFilter({"A": {"x": AccessRule(.8, bias=7, source="staff")}})
        observed = info.observe("A", world(), commit=True)
        self.assertEqual(observed.beliefs["x"].estimate, 57)
        self.assertAlmostEqual(observed.beliefs["x"].confidence, .6)
        self.assertIsNone(observed.beliefs["x"].last_truth)
        self.assertIsNone(info.payload(observed)["beliefs"]["x"]["last_truth"])

    def test_zero_source_trust_does_not_create_artificial_confidence(self):
        info = InformationFilter({"A": {"x": AccessRule(1, source="staff")}})
        info.states["A"].source_trust["staff"] = 0
        self.assertNotIn("x", info.observe("A", world()).beliefs)

    def test_total_uncertainty_does_not_create_artificial_confidence(self):
        info = InformationFilter({"A": {"x": AccessRule(1)}})
        self.assertNotIn("x", info.observe("A", world(uncertainty=1)).beliefs)

    def test_delivered_only_still_requires_messages(self):
        info = InformationFilter({"A": {"x": AccessRule(1)}}, delivery_only=True)
        self.assertFalse(info.observe("A", world(), commit=True).beliefs)
        info.deliver("A", {"x": {"estimate": 12, "confidence": .8, "source": "staff"}}, message_id="report")
        self.assertEqual(info.observe("A", world(90), commit=True).beliefs["x"].estimate, 12)

    def test_noncommitting_observation_still_preserves_prior(self):
        info = InformationFilter({"A": {"x": AccessRule(.8)}})
        info.states["A"].beliefs["x"] = Belief(20, .8, "prior")
        before = deepcopy(info.states["A"])
        info.observe("A", world(80), commit=False)
        self.assertEqual(info.states["A"], before)

    def test_hidden_truth_changes_do_not_change_actor_payload(self):
        info = InformationFilter({"A": {"x": AccessRule(0, bias=5, noise=20)}}, stochastic=True)
        before = info.payload(deepcopy(info.states["A"]))
        for value in (0, 17, 50, 100):
            self.assertEqual(info.payload(info.observe("A", world(value), commit=True)), before)

    def test_unknown_legacy_utility_requires_prior_not_hidden_truth(self):
        info = InformationFilter({"A": {"x": AccessRule(0)}})
        model = ActorDecisionModel("A", {"immediate": {"x": 1}})
        game = StrategicGame(world(99), {}, {"A": model}, info)
        action = PoliticalAction("probe", {"immediate": {"x": 5}})
        with self.assertRaisesRegex(ValueError, "Missing belief.*explicit prior"):
            game.evaluate("A", action, game.state)
        info.states["A"].beliefs["x"] = Belief(20, .6, "explicit_prior")
        row = game.evaluate("A", action, game.state)["variable_evaluations"][0]
        self.assertEqual(row["perceived_before"], 20)

    def test_legacy_resource_binding_uses_explicit_card_prior_when_unobserved(self):
        cards = Path(__file__).resolve().parents[1] / "data/personas/cards_pss.json"
        personas = FreeAgentDecisionEngine.from_json(cards)
        info = InformationFilter({"Merz": {"x": AccessRule(0)}})
        game = FreeAgentGame(world(99), {}, personas, info,
            {"Merz": {"formal_power": "variable:x"}})
        resources = game._perceived_resources("Merz", info.observe("Merz", game.state))
        self.assertEqual(resources["formal_power"], personas.cards["Merz"].initial_resources["formal_power"])


if __name__ == "__main__":
    unittest.main()
