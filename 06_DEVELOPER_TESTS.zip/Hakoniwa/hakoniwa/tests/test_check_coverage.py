"""No applicable check is not a successful check."""
from pathlib import Path
import unittest

from hakoniwa.checks.base import CheckResult, CheckStatus, CompiledRule, Resolution, resolution_for
from hakoniwa.checks.constitutional import build_gg_check_engine
from hakoniwa.checks.context import CheckContext, BundestagState
from hakoniwa.checks.engine import CheckEngine, InstitutionalResolver, RuleRegistry
from hakoniwa.interaction.intents import Intent, IntentCompiler
from hakoniwa.free_agent_game import WorldAction
from hakoniwa.information_filter import InformationFilter
from hakoniwa.persona_v2 import ActionOption, FreeAgentDecisionEngine
from hakoniwa.political_state import PoliticalAction, PoliticalState, StateVariable
from hakoniwa.scenario_reporting import ScenarioReportingPolicy
from hakoniwa.simulation_orchestrator import LayeredConfiguration, LayeredSimulationOrchestrator, SimulationNodeV3


ROOT = Path(__file__).resolve().parents[1]


def context():
    return CheckContext(0, BundestagState(630), {"M": frozenset({"bundestag_member"})}, {})


def registry(status, kind="known"):
    return RuleRegistry((CompiledRule("TEST", frozenset({kind}),
        lambda ctx, intent: CheckResult(status, "TEST"),
        "test fixture", "not a legal rule", "test-only"),))


class CheckCoverageTests(unittest.TestCase):
    def test_unknown_intent_is_not_executable(self):
        result = build_gg_check_engine().check(context(), Intent("i", "M", "replace_chancelor_typo"))
        self.assertNotEqual(result.resolution, Resolution.EXECUTABLE)
        self.assertEqual(result.resolution.value, "unassessed")

    def test_empty_engine_is_not_permission(self):
        result = CheckEngine({}).check(context(), Intent("i", "M", "anything"))
        self.assertEqual(result.resolution.value, "unassessed")

    def test_empty_result_set_is_not_permission(self):
        self.assertEqual(resolution_for(()).value, "unassessed")

    def test_registered_rule_declining_applicability_is_not_permission(self):
        result = CheckEngine({"test": registry(CheckStatus.NOT_APPLICABLE)}).check(context(), Intent("i", "M", "known"))
        self.assertEqual(result.resolution.value, "unassessed")

    def test_pass_with_unrelated_layer_is_still_executable(self):
        result = CheckEngine({"test": registry(CheckStatus.PASS), "other": RuleRegistry()}).check(context(), Intent("i", "M", "known"))
        self.assertEqual(result.resolution, Resolution.EXECUTABLE)

    def test_existing_precedence_is_preserved(self):
        for statuses, expected in (
            ((CheckStatus.PASS, CheckStatus.BLOCKED), Resolution.BLOCKED),
            ((CheckStatus.PASS, CheckStatus.PENDING), Resolution.PENDING),
            ((CheckStatus.PASS, CheckStatus.ROUTED), Resolution.REQUIRES_PROCEDURE),
            ((CheckStatus.PENDING, CheckStatus.ROUTED), Resolution.PENDING),
        ):
            with self.subTest(statuses=statuses):
                self.assertEqual(resolution_for(tuple(CheckResult(s, str(i)) for i, s in enumerate(statuses))), expected)

    def test_unassessed_has_machine_readable_reason(self):
        bundle = CheckEngine({"test": RuleRegistry()}).check(context(), Intent("i", "M", "unknown"))
        result = InstitutionalResolver().resolve(bundle)
        self.assertIn("NO_APPLICABLE_CHECK", result.reasons)
        self.assertEqual(result.payload()["resolution"], "unassessed")
        self.assertEqual(result.effects, ())

    def test_known_institutional_action_still_routes(self):
        result = build_gg_check_engine().check(context(), Intent("i", "M", "replace_chancellor"))
        self.assertEqual(result.resolution, Resolution.REQUIRES_PROCEDURE)

    def test_compiler_does_not_correct_typos_into_legal_operations(self):
        item = IntentCompiler().compile(intent_id="i", actor="M", verb="replace_chancelor_typo")
        self.assertEqual(item.intent_type, "replace_chancelor_typo")
        self.assertEqual(build_gg_check_engine().check(context(), item).resolution.value, "unassessed")

    def test_explicit_alias_still_routes(self):
        item = IntentCompiler().compile(intent_id="i", actor="M", verb="constructive_vote_no_confidence")
        self.assertEqual(build_gg_check_engine().check(context(), item).resolution, Resolution.REQUIRES_PROCEDURE)

    def run_action(self, intent=None):
        action = WorldAction(PoliticalAction("attempt", {"immediate": {"x": 10}}, locks_add=("adopted",)),
            ActionOption("attempt"), intent=intent)
        game = LayeredSimulationOrchestrator(
            PoliticalState({"x": StateVariable("x", 50)}, {}, {}),
            {"n": SimulationNodeV3("n", "Merz", (action,))},
            FreeAgentDecisionEngine.from_json(ROOT / "data/personas/cards_pss.json"),
            InformationFilter({"Merz": {}}, delivery_only=True), {},
            LayeredConfiguration.from_environment_json(ROOT / "data/environments/2026-07-31/environment.json"),
            objective_check_engine=build_gg_check_engine(), check_context_provider=lambda state: context(),
            reporting_policy=ScenarioReportingPolicy.diagnostics_only())
        return game.run("n")

    def test_unknown_intent_does_not_apply_world_effects_or_locks(self):
        result = self.run_action(Intent("i", "Merz", "replace_chancelor_typo"))
        self.assertEqual(result["world_state"]["variables"]["x"]["value"], 50)
        self.assertEqual(result["world_state"]["locks"], [])
        self.assertEqual(result["trace"][0]["institutional_resolution"]["resolution"], "unassessed")

    def test_ordinary_action_without_institutional_intent_still_runs(self):
        result = self.run_action()
        self.assertEqual(result["world_state"]["variables"]["x"]["value"], 60)
        self.assertEqual(result["trace"][0]["institutional_resolution"]["resolution"], "not_invoked")


if __name__ == "__main__":
    unittest.main()
