"""Intent, declared contingencies, and realized ledger entries are distinct."""
from copy import deepcopy
from dataclasses import asdict, replace
import json
from pathlib import Path
import unittest

from hakoniwa.checks.constitutional import build_gg_check_engine
from hakoniwa.checks.context import BundestagState, CheckContext
from hakoniwa.decision_space import DecisionEvent, DecisionSpaceGenerator, OutcomeResolver, StrategyEffectModel
from hakoniwa.free_agent_game import FreeAgentGame, FreeAgentNode, WorldAction
from hakoniwa.information_filter import InformationFilter
from hakoniwa.interaction.intents import Intent
from hakoniwa.persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine, WorldEvent
from hakoniwa.political_state import PoliticalAction, PoliticalState, StateVariable, PressureRule
from hakoniwa.scenario_reporting import ScenarioReportingPolicy
from hakoniwa.simulation_orchestrator import LayeredConfiguration, LayeredSimulationOrchestrator, SimulationNodeV3, V3FeatureFlags

ROOT = Path(__file__).resolve().parents[1]
CARDS = ROOT / "data/personas/cards_pss.json"
ENV = ROOT / "data/environments/2026-07-31/environment.json"


def world():
    return PoliticalState({"x": StateVariable("x", 50)}, {"Merz": 50}, {"crisis": 80})


def candidate(**kwargs):
    return PoliticalAction("attempt", {"immediate": {"x": 10}, "long": {"x": 20}},
        capital_delta={"Merz": 5}, pressure_delta={"crisis": -10},
        locks_add=("adopted",), closes_actions=("alternative",), next_node="after", **kwargs)


class SettlementContractTests(unittest.TestCase):
    def test_unresolved_uncertain_effects_cannot_mutate_any_ledger_channel(self):
        for feasibility in (0, .4, .999):
            state = world()
            before = deepcopy(state.payload())
            with self.subTest(feasibility=feasibility), self.assertRaisesRegex(ValueError, "Unresolved effects"):
                state.apply(candidate(feasibility=feasibility))
            self.assertEqual(state.payload(), before)

    def test_certain_declared_default_is_labeled_not_a_success_draw(self):
        state = world()
        result = state.apply(PoliticalAction("known", {"immediate": {"x": 2}}))
        self.assertEqual(state.variables["x"].value, 52)
        self.assertEqual(result["settlement_basis"], "DETERMINISTIC_DEFAULT")

    def test_confirmed_fact_is_not_erased_by_prior_low_feasibility(self):
        state = world()
        result = state.apply(candidate(feasibility=0, effect_status="REALIZED"))
        self.assertEqual(state.variables["x"].value, 60)
        self.assertEqual(state.capital["Merz"], 55)
        self.assertEqual(result["settlement_basis"], "REALIZED")

    def test_explicit_deterministic_assumption_is_full_not_fractional_effect(self):
        state = world()
        result = state.apply(candidate(feasibility=.4, effect_status="DETERMINISTIC_ASSUMPTION"))
        self.assertEqual(state.variables["x"].value, 60)
        self.assertIn("adopted", state.locks)
        self.assertEqual(result["settlement_basis"], "DETERMINISTIC_ASSUMPTION")

    def test_invalid_status_or_feasibility_is_rejected(self):
        for value in (-1, 1.1, True, float("nan"), float("inf"), "0.5"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                candidate(feasibility=value)
        with self.assertRaises(ValueError):
            candidate(effect_status="REALIZED_BECAUSE_I_WANT_IT")

    def test_settlement_metadata_survives_json_roundtrip(self):
        action = candidate(feasibility=.2, effect_status="REALIZED")
        restored = PoliticalAction(**json.loads(json.dumps(asdict(action))))
        self.assertEqual(restored.settlement_basis(), "REALIZED")

    def test_resolved_failure_keeps_attempt_cost_and_no_success_lock(self):
        model = StrategyEffectModel({"immediate": {"x": 10}}, attempt_capital_delta={"Merz": -3})
        branches = DecisionSpaceGenerator._outcomes("attempt", PoliticalAction("attempt", model.effects,
            feasibility=.5, locks_add=("adopted",)), .5, .5, model)
        failure = next(b for b in branches if b.key == "failure")
        state = world()
        state.apply(failure.world_action)
        self.assertEqual(failure.world_action.effect_status, "REALIZED")
        self.assertEqual(state.capital["Merz"], 47)
        self.assertEqual(state.variables["x"].value, 50)
        self.assertNotIn("adopted", state.locks)

    def game(self, pair=None, *, resolver=None, event=None, flags=None):
        config = LayeredConfiguration.from_environment_json(ENV)
        if flags is not None:
            config = replace(config, flags=flags)
        after = WorldAction(PoliticalAction("after", {"immediate": {"x": 20}}), ActionOption("after"))
        return LayeredSimulationOrchestrator(world(), {
            "n": SimulationNodeV3("n", "Merz", (pair,) if pair is not None else (), decision_event=event),
            "after": SimulationNodeV3("after", "Merz", (after,)),
        }, FreeAgentDecisionEngine.from_json(CARDS), InformationFilter({"Merz": {}}, delivery_only=True), {}, config,
            objective_check_engine=build_gg_check_engine(),
            check_context_provider=lambda state: CheckContext(0, BundestagState(630), {}, {}),
            decision_generator=DecisionSpaceGenerator() if event is not None else None,
            outcome_resolver=resolver,
            pressure_rules=(PressureRule("crisis", 70, "threshold", {"x": -7}),),
            reporting_policy=ScenarioReportingPolicy.diagnostics_only())

    def test_static_canonical_unresolved_action_cannot_settle_or_award_pss(self):
        pair = WorldAction(candidate(feasibility=0), ActionOption("attempt"),
            actor_outcomes={"Merz": ActionOutcome("attempt", 1)})
        game = self.game(pair)
        before, pss = deepcopy(game.state.payload()), deepcopy(game.personas.payload())
        with self.assertRaisesRegex(ValueError, "Unresolved effects"):
            game.run("n")
        self.assertEqual(game.state.payload(), before)
        self.assertEqual(game.personas.payload(), pss)

    def test_explicit_zero_execution_is_not_overridden_in_shadow_mode(self):
        pair = WorldAction(PoliticalAction("attempt", {"immediate": {"x": 10}}),
            ActionOption("attempt", execution_feasibility=0))
        game = self.game(pair)
        before = deepcopy(game.state.payload())
        with self.assertRaisesRegex(ValueError, "no execution capacity"):
            game.run("n")
        self.assertEqual(game.state.payload(), before)

    def test_legacy_persona_driver_also_checks_zero_execution(self):
        pair = WorldAction(PoliticalAction("attempt", {"immediate": {"x": 10}}),
            ActionOption("attempt", execution_feasibility=0))
        game = FreeAgentGame(world(), {"n": FreeAgentNode("n", "Merz", (pair,))},
            FreeAgentDecisionEngine.from_json(CARDS), InformationFilter({"Merz": {}}, delivery_only=True), {})
        with self.assertRaisesRegex(ValueError, "no execution capacity"):
            game.run("n")
        self.assertEqual(game.state.variables["x"].value, 50)

    def test_low_political_success_is_not_zero_execution(self):
        pair = WorldAction(PoliticalAction("speech", {"immediate": {"x": 1}}),
            ActionOption("speech", political_success_expectation=0, execution_feasibility=1))
        result = self.game(pair).run("n")
        self.assertNotEqual(result["trace"][0]["operational_feedback"]["action_execution"], "NOT_EXECUTED")

    def event(self):
        return DecisionEvent("event", "party", ("votes",), .5, .5,
            {"private_negotiation": StrategyEffectModel({"immediate": {"x": 1}})},
            allowed_strategy_keys=("private_negotiation",))

    def test_generated_actions_without_resolver_fail_before_world_settlement(self):
        game = self.game(event=self.event())
        before = deepcopy(game.state.payload())
        with self.assertRaisesRegex(ValueError, "require an outcome resolver"):
            game.run("n")
        self.assertEqual(game.state.payload(), before)

    def test_generated_chosen_branch_is_a_realized_ledger_entry(self):
        game = self.game(event=self.event(), resolver=OutcomeResolver(stochastic=False))
        result = game.run("n")
        row = result["trace"][0]
        self.assertEqual(row["operational_feedback"]["state_update"]["settlement_basis"], "REALIZED")
        self.assertIsNotNone(row["operational_feedback"]["outcome_branch"])

    def test_forecast_can_assume_effects_without_authorizing_actual_settlement(self):
        pair = WorldAction(candidate(feasibility=.4), ActionOption("attempt"))
        game = self.game(pair, flags=V3FeatureFlags(strategic_response_uses_perceived_menu=True))
        before = deepcopy(game.state.payload())
        path = game._forecast_response_path(pair, game.state)
        self.assertTrue(path)
        self.assertEqual(path[0]["forecast_contract"], "CONDITIONAL_ON_DECLARED_EFFECTS_NOT_RESOLVED_OUTCOMES")
        self.assertEqual(game.state.payload(), before)
        with self.assertRaisesRegex(ValueError, "Unresolved effects"):
            game.run("n")
        self.assertEqual(game.state.payload(), before)

    def test_institutional_nonexecution_has_no_success_route_rewards_or_feedback(self):
        pair = WorldAction(candidate(), ActionOption("attempt"),
            actor_events={"Merz": (WorldEvent("reward", "win", .8, ("victory",)),)},
            actor_outcomes={"Merz": ActionOutcome("attempt", 1)},
            intent=Intent("i", "Merz", "unknown_typo"))
        game = self.game(pair, flags=V3FeatureFlags(system_feedback_mutates_world=True))
        before, pss, logic = deepcopy(game.state.payload()), deepcopy(game.personas.payload()), game.logic
        result = game.run("n")
        self.assertEqual([r["node"] for r in result["trace"]], ["n"])
        self.assertEqual(game.state.payload(), before)
        self.assertEqual(game.personas.payload(), pss)
        self.assertEqual(game.logic, logic)
        self.assertFalse(result["trace"][0]["system_feedback_applied"])
        self.assertEqual(result["trace"][0]["operational_feedback"]["action_execution"], "NOT_EXECUTED")


if __name__ == "__main__":
    unittest.main()
