from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from hakoniwa.scenarios.zustrom_2025_vote_replay import run_scenario as replay
from hakoniwa.plugins.majorities import MajorityModel


class HistoricalVoteReplayTests(unittest.TestCase):
    def setUp(self):
        self.protocol = json.loads((replay.HERE / "protocol.json").read_text())

    def test_roster_is_complete_anonymous_and_not_real_person_dossiers(self):
        request = replay.build_request(self.protocol,runs=2)
        self.assertEqual(len(request["members"]),733)
        self.assertEqual(len({m["id"] for m in request["members"]}),733)
        self.assertTrue(all(m["id"].startswith("ANONYMOUS_") for m in request["members"]))
        self.assertTrue(all("decided_vote" not in m for m in request["members"]))
        self.assertEqual(request["ties"],[])

    def test_single_factor_changes_do_not_mutate_protocol(self):
        before = deepcopy(self.protocol)
        first = replay.build_request(self.protocol)
        second = replay.build_request(self.protocol,overrides={"attendance":.9})
        self.assertEqual(before,self.protocol)
        self.assertNotEqual(first["members"][0]["attendance"],second["members"][0]["attendance"])
        self.assertEqual(first["members"][0]["position"],second["members"][0]["position"])

    def test_party_announcements_do_not_come_from_target_ballots(self):
        request = replay.build_request(self.protocol,runs=2)
        model = MajorityModel(request)
        # Verify the declared coarse proxy's source, not an obsolete guarantee
        # that a party announcement becomes an individual's supporting ballot.
        # This protocol supplies no rejection alternative; A11 must not invent it.
        for member in request["members"]:
            stance = self.protocol["parties"][member["party"]]["announced_position"]
            expected = {} if stance == "unknown" else {"proposal_alignment": float(stance == "yes")}
            self.assertEqual(member["position"], expected)
            self.assertNotIn("decided_vote", member)
            row = model.evaluate_member(member["id"])
            self.assertEqual(row["raw_terms"]["policy"], 0)
            self.assertIn("status_quo", row["unknown"])

    def test_predict_never_reads_reference_and_compare_checks_hashes(self):
        real_reader = Path.read_text

        def guarded(path,*args,**kwargs):
            if path.name == "reference.json":
                raise AssertionError("Prediction attempted to read target labels")
            return real_reader(path,*args,**kwargs)

        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            with patch.object(Path,"read_text",guarded):
                summary = replay.predict(output,runs=2,sensitivity_runs=1)
            self.assertFalse(summary["independent_blind_test"])
            self.assertFalse(summary["target_result_used_by_prediction_function"])
            comparison = replay.compare(output)
            self.assertEqual(sum(comparison["reference"]["counts"].values()),733)
            frozen = json.loads((output/"frozen_request.json").read_text())
            frozen["members"][0]["attendance"] = .5
            (output/"frozen_request.json").write_text(json.dumps(frozen))
            with self.assertRaises(ValueError):
                replay.compare(output)


if __name__ == "__main__":
    unittest.main()
