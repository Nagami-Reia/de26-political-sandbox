"""Action-family identity must agree in evaluation and settled history."""
from copy import deepcopy
from pathlib import Path
import unittest

from hakoniwa.persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine


CARDS = Path(__file__).resolve().parents[1] / "data/personas/cards_pss.json"


class ActionFamilyTests(unittest.TestCase):
    def setUp(self):
        self.engine = FreeAgentDecisionEngine.from_json(CARDS)

    def score(self, action):
        return self.engine.score("Frei", action, {}, {})

    def settle(self, key, success=.2, times=3):
        for _ in range(times):
            self.engine.apply_outcome("Frei", ActionOutcome(
                key, success, workload=0, expected_success=.65,
            ))

    def test_handwritten_repetition_is_matched(self):
        action = ActionOption("plain_consultation", conflict_strategy="negotiate")
        self.assertEqual(self.score(action).repetition_modifier, 0)
        self.settle(action.key)
        score = self.score(action)
        self.assertEqual(score.diagnostics["recent_family_uses"], 3)
        self.assertEqual(score.diagnostics["action_family"], "plain_consultation")
        self.assertLess(score.repetition_modifier, -2)

    def test_all_conflict_styles_use_the_same_storage_contract(self):
        for style in ("negotiate", "attack", "avoid", "institutionalize", "reframe"):
            with self.subTest(style=style):
                action = ActionOption("manual_" + style, conflict_strategy=style)
                self.settle(action.key, times=1)
                self.assertEqual(self.score(action).diagnostics["recent_family_uses"], 1)

    def test_different_manual_actions_are_not_merged_by_conflict_style(self):
        self.settle("consult_spd")
        score = self.score(ActionOption("consult_states", conflict_strategy="negotiate"))
        self.assertEqual(score.diagnostics["recent_family_uses"], 0)
        self.assertEqual(score.repetition_modifier, 0)

    def test_generated_strategy_is_shared_across_nodes_and_styles(self):
        self.settle("node1__coordination__private")
        score = self.score(ActionOption("node2__coordination__public", conflict_strategy="negotiate"))
        self.assertEqual(score.diagnostics["action_family"], "coordination")
        self.assertEqual(score.diagnostics["recent_family_uses"], 3)

    def test_different_generated_strategies_are_not_merged(self):
        self.settle("node1__coordination__private")
        score = self.score(ActionOption("node2__public_signal__public", conflict_strategy="negotiate"))
        self.assertEqual(score.repetition_modifier, 0)

    def test_failed_repetition_costs_more_than_successful_repetition(self):
        action = ActionOption("manual_consult", conflict_strategy="negotiate")
        self.settle(action.key, success=.9)
        success = self.score(action).repetition_modifier
        self.engine = FreeAgentDecisionEngine.from_json(CARDS)
        self.settle(action.key, success=.1)
        failure = self.score(action).repetition_modifier
        self.assertLess(failure, success)
        self.assertLess(success, 0)

    def test_recent_window_and_cap_are_preserved(self):
        action = ActionOption("manual_consult", uncertainty=1, conflict_strategy="negotiate")
        self.settle(action.key, success=0, times=12)
        score = self.score(action)
        self.assertEqual(score.diagnostics["recent_family_uses"], 6)
        self.assertEqual(score.repetition_modifier, -12)
        for index in range(6):
            self.settle("unrelated_" + str(index), times=1)
        self.assertEqual(self.score(action).repetition_modifier, 0)

    def test_scoring_does_not_write_history_or_change_family_metadata(self):
        self.settle("manual_consult")
        before = deepcopy(self.engine.runtime["Frei"].action_history)
        for key in ("manual_consult", "another_action", "n__coordination__private"):
            self.score(ActionOption(key, conflict_strategy="negotiate"))
        self.assertEqual(self.engine.runtime["Frei"].action_history, before)

    def test_preexisting_raw_key_history_remains_readable(self):
        self.engine.runtime["Frei"].action_history.append({
            "action": "plain_consultation", "family": "plain_consultation", "success": .2,
        })
        score = self.score(ActionOption("plain_consultation", conflict_strategy="negotiate"))
        self.assertEqual(score.diagnostics["recent_family_uses"], 1)
        self.assertLess(score.repetition_modifier, 0)


if __name__ == "__main__":
    unittest.main()
