"""Attempt expenditure is unconditional on success, never inferred by sign."""
from copy import deepcopy
from dataclasses import asdict
import json
from pathlib import Path
import unittest

from hakoniwa.decision_space import (
    DecisionEvent, DecisionSpaceGenerator, OutcomeResolver, ResolvedOutcome, StrategyEffectModel,
)
from hakoniwa.information_filter import InformationFilter
from hakoniwa.persona_v2 import FreeAgentDecisionEngine
from hakoniwa.political_state import PoliticalAction, PoliticalState, StateVariable
from hakoniwa.scenario_reporting import ScenarioReportingPolicy
from hakoniwa.simulation_orchestrator import LayeredConfiguration, LayeredSimulationOrchestrator, SimulationNodeV3

ROOT=Path(__file__).resolve().parents[1]


def resolve_branches(model):
    base=PoliticalAction("attempt",model.effects,
        capital_delta=model.outcome_capital_delta or model.capital_delta,
        pressure_delta=model.outcome_pressure_delta or model.pressure_delta)
    return {b.key:b for b in DecisionSpaceGenerator._outcomes("attempt",base,.500,.500,model)}


class ForceFailure:
    def resolve(self,action):
        b=next(b for b in action.outcome_branches if b.key=="failure")
        return ResolvedOutcome(action.world_action.choice.key,b.key,b.conditional_weight,b.success_level,
            b.world_action,False,sum(row.conditional_weight*row.success_level for row in action.outcome_branches),
            accounting=b.accounting)


class OutcomeAccountingTests(unittest.TestCase):
    def model(self,**kw):
        return StrategyEffectModel({"immediate":{"x":10}},**kw)

    def test_ambiguous_legacy_account_delta_is_not_silently_scaled(self):
        with self.assertRaises(ValueError):
            self.model(capital_delta={"M":-10})

    def test_failure_pays_attempt_cost_without_receiving_reward(self):
        model=self.model(attempt_capital_delta={"M":-10},outcome_capital_delta={"M":20},
            attempt_pressure_delta={"crisis":3},outcome_pressure_delta={"crisis":-8})
        action=resolve_branches(model)["failure"].world_action
        self.assertEqual(action.capital_delta,{"M":-10})
        self.assertEqual(action.pressure_delta,{"crisis":3})

    def test_attempt_paid_exactly_once_in_every_branch(self):
        rows=resolve_branches(self.model(attempt_capital_delta={"M":-10},outcome_capital_delta={"M":20}))
        self.assertEqual(rows["success"].world_action.capital_delta["M"],10)
        self.assertEqual(rows["partial_success"].world_action.capital_delta["M"],-1)
        self.assertEqual(rows["failure"].world_action.capital_delta["M"],-10)

    def test_signed_amount_does_not_determine_timing(self):
        rows=resolve_branches(self.model(attempt_capital_delta={"M":2},outcome_capital_delta={"M":-8}))
        self.assertEqual(rows["failure"].world_action.capital_delta["M"],2)
        self.assertEqual(rows["success"].world_action.capital_delta["M"],-6)

    def test_failure_can_add_conditional_backlash_to_attempt_cost(self):
        rows=resolve_branches(self.model(attempt_capital_delta={"M":-10},
            outcome_account_overrides={"failure":{"capital_delta":{"M":-4},"pressure_delta":{"crisis":12}}}))
        self.assertEqual(rows["failure"].world_action.capital_delta,{"M":-14})
        self.assertEqual(rows["failure"].world_action.pressure_delta,{"crisis":12})
        self.assertEqual(rows["success"].world_action.capital_delta,{"M":-10})

    def test_attempt_variable_spending_is_not_scaled_with_result(self):
        rows=resolve_branches(self.model(attempt_effects={"x":-2}))
        self.assertEqual(rows["failure"].world_action.effects["immediate"]["x"],-2)
        self.assertEqual(rows["partial_success"].world_action.effects["immediate"]["x"],2.5)
        self.assertEqual(rows["success"].world_action.effects["immediate"]["x"],8)

    def test_effect_override_replaces_only_outcome_not_attempt(self):
        model=self.model(attempt_effects={"x":-2},
            outcome_effect_overrides={"failure":{"immediate":{"x":-5}}})
        self.assertEqual(resolve_branches(model)["failure"].world_action.effects["immediate"]["x"],-7)

    def test_attempts_and_rewards_are_netted_before_world_clamping(self):
        model=self.model(attempt_capital_delta={"M":-10},outcome_capital_delta={"M":20})
        state=PoliticalState({"x":StateVariable("x",50)},{"M":5},{})
        state.apply(resolve_branches(model)["success"].world_action)
        self.assertEqual(state.capital["M"],15)  # Not clamp(5-10)+20 == 20.

    def test_legacy_accounting_requires_explicit_outcome_declaration(self):
        model=self.model(capital_delta={"M":-10},legacy_account_deltas_are_outcome=True)
        self.assertEqual(resolve_branches(model)["failure"].world_action.capital_delta,{"M":0})
        with self.assertRaises(ValueError):
            self.model(capital_delta={"M":2},outcome_capital_delta={"M":3},legacy_account_deltas_are_outcome=True)

    def test_legacy_pressure_alias_requires_the_same_timing_declaration(self):
        with self.assertRaises(ValueError):self.model(pressure_delta={"crisis":10})
        rows=resolve_branches(self.model(pressure_delta={"crisis":10},legacy_account_deltas_are_outcome=True))
        self.assertEqual(rows["failure"].world_action.pressure_delta,{"crisis":0})

    def test_lower_level_helper_cannot_accept_undeclared_base_accounts(self):
        base=PoliticalAction("attempt",{"immediate":{"x":10}},capital_delta={"M":-10})
        with self.assertRaises(ValueError):
            DecisionSpaceGenerator._outcomes("attempt",base,.500,.500,self.model())

    def test_explicit_empty_override_removes_reward_not_attempt_cost(self):
        model=self.model(attempt_capital_delta={"M":-10},outcome_capital_delta={"M":20},
            outcome_account_overrides={"success":{"capital_delta":{}}})
        self.assertEqual(resolve_branches(model)["success"].world_action.capital_delta,{"M":-10})

    def test_json_roundtrip_matches_python_accounting(self):
        model=self.model(attempt_capital_delta={"M":-10},attempt_effects={"x":-2},
            outcome_account_overrides={"failure":{"capital_delta":{"M":-4}}})
        restored=StrategyEffectModel(**json.loads(json.dumps(asdict(model))))
        self.assertEqual(resolve_branches(model),resolve_branches(restored))

    def test_later_input_mutation_does_not_rewrite_declared_attempt_cost(self):
        costs={"M":-10};penalties={"failure":{"capital_delta":{"M":-4}}}
        model=self.model(attempt_capital_delta=costs,outcome_account_overrides=penalties)
        costs["M"]=-999;penalties["failure"]["capital_delta"]["M"]=-999
        self.assertEqual(resolve_branches(model)["failure"].world_action.capital_delta,{"M":-14})

    def test_invalid_or_unknown_accounting_is_rejected(self):
        for kwargs in ({"attempt_capital_delta":{"M":float("nan")}},
                       {"outcome_pressure_delta":{"crisis":float("inf")}},
                       {"attempt_effects":{"x":True}},
                       {"attempt_effects":{"immediate":{"x":-1}}},
                       {"outcome_account_overrides":{"sucess":{}}},
                       {"outcome_account_overrides":{"failure":{"capital_dleta":{}}}},
                       {"outcome_account_overrides":{"failure":{"pressure_delta":{"x":False}}}}):
            with self.subTest(kwargs=kwargs),self.assertRaises(ValueError):self.model(**kwargs)

    def test_numeric_overrides_do_not_restore_success_locks(self):
        model=self.model(attempt_capital_delta={"M":-10})
        base=PoliticalAction("attempt",model.effects,locks_add=("bill_adopted",),next_node="win")
        rows={b.key:b for b in DecisionSpaceGenerator._outcomes("attempt",base,.500,.500,model)}
        self.assertEqual(rows["failure"].world_action.locks_add,())
        self.assertIsNone(rows["failure"].world_action.next_node)

    def test_accounting_does_not_mutate_inputs_or_change_branch_weights(self):
        raw={"M":-10};before=deepcopy(raw)
        no_cost=resolve_branches(self.model())
        paid=resolve_branches(self.model(attempt_capital_delta=raw))
        self.assertEqual(raw,before)
        self.assertEqual([b.conditional_weight for b in no_cost.values()],
                         [b.conditional_weight for b in paid.values()])

    def test_full_pipeline_settles_and_logs_attempt_cost_after_failure(self):
        model=self.model(attempt_capital_delta={"Merz":-10},outcome_capital_delta={"Merz":20},
                         attempt_pressure_delta={"crisis":3})
        event=DecisionEvent("negotiation","party",("votes","coalition"),.500,.500,
            {"private_negotiation":model},allowed_strategy_keys=("private_negotiation",))
        state=PoliticalState({"x":StateVariable("x",50)},{"Merz":50},{"crisis":0})
        before=state.payload()
        engine=FreeAgentDecisionEngine.from_json(ROOT/"data/personas/cards_pss.json")
        info=InformationFilter({"Merz":{}},delivery_only=True)
        generated=DecisionSpaceGenerator().generate("Merz",event,info.observe("Merz",state),
            engine.cards["Merz"],engine.runtime["Merz"],engine.cards["Merz"].initial_resources)
        self.assertEqual(state.payload(),before)  # Planning does not spend anything.
        outcome=OutcomeResolver(seed=42).resolve(generated.actions[0])
        self.assertEqual(state.payload(),before)  # Resolver returns a settlement, does not apply twice.
        self.assertIn("accounting",outcome.payload())
        game=LayeredSimulationOrchestrator(state,{"n":SimulationNodeV3("n","Merz",(),decision_event=event)},
            engine,info,{},LayeredConfiguration.from_environment_json(ROOT/"data/environments/2026-07-31/environment.json"),
            decision_generator=DecisionSpaceGenerator(),outcome_resolver=ForceFailure(),
            reporting_policy=ScenarioReportingPolicy.diagnostics_only())
        result=game.run("n")
        self.assertEqual(state.capital["Merz"],40)
        self.assertEqual(state.pressures["crisis"],3)
        self.assertEqual(state.variables["x"].value,50)
        row=result["trace"][0]["operational_feedback"]["outcome_branch"]["accounting"]
        self.assertEqual(row["attempt"]["capital_delta"],{"Merz":-10})
        self.assertEqual(row["contingent"]["capital_delta"],{"Merz":0})


if __name__=="__main__":unittest.main()
