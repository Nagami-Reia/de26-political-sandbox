import unittest

from hakoniwa.scenarios.kfrage_2024_blind_replay.run_scenario import OBSERVED_COMPARATOR, Replay, Scenario


class KfrageBlindReplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.payload = Replay(Scenario()).run()

    def test_arcana_is_absent(self):
        self.assertEqual(self.payload["arcana"], {"enabled": False, "initialized": False})
        self.assertTrue(all(row["arcana"]["status"] == "DISABLED" for row in self.payload["trace"]))

    def test_post_outcome_memories_are_removed(self):
        removed = self.payload["anti_leakage"]["removed_outcome_or_future_memories"]
        self.assertIn("2024_kfrage_closure", removed["Merz"])
        self.assertIn("2024_kfrage_withdrawal", removed["Wuest"])
        self.assertIn("2024_no_cdu_bridgehead", removed["Soeder"])
        retained = self.payload["anti_leakage"]["retained_memory_ids"]
        self.assertEqual(
            {event_id for rows in retained.values() for event_id in rows},
            {"2010_resignation", "2021_union_candidate_conflict", "hessian_coalition_switch"},
        )
        self.assertEqual(self.payload["observed_comparator_access"], "post_run_only")

    def test_menu_order_does_not_encode_the_observed_path(self):
        rows = {row["node"]: row for row in self.payload["trace"] if "chosen_menu_index" in row}
        self.assertEqual(rows["merz_opening"]["chosen_menu_index"], 2)
        self.assertEqual(rows["wuest_choice"]["chosen_menu_index"], 4)
        self.assertEqual(rows["soeder_final"]["chosen_menu_index"], 2)

    def test_comparator_reports_actual_matches_without_prescribing_model_result(self):
        replay = Replay(Scenario())
        replay.run()
        for candidate in ("Merz", "Wuest", None):
            comparison = replay.compare({"candidate": candidate})
            expected_matches = {key: comparison["actual"][key] == value
                                for key, value in OBSERVED_COMPARATOR.items()}
            self.assertEqual(comparison["matches"], expected_matches)
            self.assertEqual(comparison["matched"], sum(expected_matches.values()))
            expected_result = ("PASS_NATURAL_SEQUENCE" if all(expected_matches.values())
                               else "MODEL_ERROR_OR_PARTIAL_REPRODUCTION")
            self.assertEqual(comparison["result"], expected_result)


if __name__ == "__main__":
    unittest.main()
