from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest

from hakoniwa.scenarios.berlin_blackout.run_scenario import BerlinCrisis, save


class BerlinBlackoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.payload = BerlinCrisis(20261016).run()

    def test_same_seed_same_complete_path(self):
        self.assertEqual(self.payload, BerlinCrisis(20261016).run())

    def test_exact_twelve_hours_and_blackout_not_automatic_device_failure(self):
        self.assertEqual(self.payload['clock']['elapsed_minutes'],720)
        blackout=[r for r in self.payload['trace'] if r['kind']=='grid_blackout']
        self.assertEqual([r['elapsed_minutes'] for r in blackout],[60])
        self.assertTrue(all(r['battery']>0 for r in blackout[0]['physical_after']['actors'].values()))

    def test_no_actor_overlaps_actions(self):
        for actor in self.payload['actors']:
            decisions=[r for r in self.payload['decisions'] if r['decision_maker']==actor]
            for first,second in zip(decisions,decisions[1:]):
                start=next(r['elapsed_minutes'] for r in self.payload['trace'] if r.get('decision',{} ) and r['decision']['node']==first['node'])
                finish=start+first['action_menu'][first['chosen_action']]['duration']
                next_start=next(r['elapsed_minutes'] for r in self.payload['trace'] if r.get('decision',{}) and r['decision']['node']==second['node'])
                self.assertGreaterEqual(next_start,finish)

    def test_initial_beliefs_only_local_and_known_positions_are_not_live_truth(self):
        world=BerlinCrisis(1)
        self.assertTrue(all(k.startswith('KAH:') for k in world.info.states['Frei'].beliefs))
        world.actors['Merz']['site']='KAH'
        actions,_,_=world.menu('Frei')
        self.assertIn('call:Merz',[a.key for a in actions])

    def test_menu_order_is_not_winning_rule_and_people_differ(self):
        families={d['chosen_action'].split(':')[0] for d in self.payload['decisions']}
        self.assertGreaterEqual(len(families),5)
        self.assertTrue(any(d['chosen_action']!=next(iter(d['action_menu'])) for d in self.payload['decisions']))

    def test_saturated_resource_cannot_count_as_full_success(self):
        world=BerlinCrisis(1)
        world.sites['KAH']['coordination']=1
        world.pending['probe']={'actor':'Frei','key':'organize','meta':{'family':'organize','duration':30},'origin':'KAH','evaluation':{}}
        world.complete('probe')
        self.assertEqual(world.outcomes[-1]['action_outcome']['success'],0)

    def test_messages_and_requests_do_not_immediately_become_world_success(self):
        self.assertTrue(any(m['status']=='NOT_DELIVERED' for m in self.payload['messages']))
        requests=[r for r in self.payload['outcomes'] if r['action']=='government']
        self.assertTrue(requests)
        self.assertTrue(all(r['action_outcome']['meaning']=='SENT_NOT_DELIVERED_OR_IMPLEMENTED' for r in requests))
        self.assertTrue(all(r['institutional_outcome']['status']=='NO_LEGISLATIVE_TRANSITION_OR_EXTRA_LEGAL_POWER_GRANTED' for r in requests))

    def test_resources_and_charts_cover_every_actor_and_event(self):
        report=self.payload['scenario_report']
        self.assertTrue(report['valid'])
        self.assertEqual(set(report['used_persona_cards']),set(self.payload['actors']))
        self.assertEqual(len(report['pss_pressure_series']),11*(len(self.payload['trace'])+1))
        for turn in self.payload['trace']:
            self.assertTrue(all(0<=r['battery']<=1 and 0<=r['health']<=1 for r in turn['physical_after']['actors'].values()))
        for party,value in self.payload['config']['polling_anchors'].items():
            points=[r['value'] for r in report['polling_series'] if r['subject']==party]
            self.assertTrue(points)
            self.assertEqual(set(points),{value})

    def test_renderer_uses_compact_payload_and_lazy_single_detail(self):
        with tempfile.TemporaryDirectory() as directory:
            output=Path(directory)
            save(self.payload,output)
            html=(output/'report.html').read_text()
            self.assertIn("other.querySelector('.detail')?.remove()",html)
            self.assertNotIn('AdviceType.',html)
            self.assertEqual(len(json.loads((output/'hourly_snapshots.json').read_text())),13)
            self.assertEqual(len(json.loads((output/'report_trace.json').read_text())),len(self.payload['decisions']))

    def test_pss_calibration_and_remaining_limits_are_reported(self):
        codes={row['code'] for row in self.payload['model_diagnostics']}
        self.assertIn('PSS_BOUNDARY_CHECK',codes)
        self.assertIn('CALIBRATED_CONFIDENCE',codes)
        self.assertIn('RELATIONSHIP_CONFLICT_NOT_TESTED',codes)


if __name__=='__main__': unittest.main()
