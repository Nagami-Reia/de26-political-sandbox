"""Real task/decision/clock integration for explicitly selected persona relays."""
from copy import deepcopy
from dataclasses import asdict
from datetime import datetime, timedelta
import unittest

from hakoniwa.tests.test_political_poll_feedback import config, load, release, START
from hakoniwa.political_state import PoliticalAction


POLL_KEY = 'poll:party_vote:DE:Union:synthetic'


def at(minute):
    return (datetime.fromisoformat(START) + timedelta(minutes=minute)).isoformat()


def communication_config(*, sender_receives=True, active=True, reliability=1., latency=4):
    raw = config()
    raw['until'] = at(120)
    raw['nodes'] = [{'key':'relay_node', 'owner':'Merz', 'actions':[
        {'choice':{'key':'send', 'conflict_strategy':'institutionalize'}}]},
        {'key':'recipient_node', 'owner':'Frei', 'actions':[{'choice':{'key':'continue_work'}}]}]
    raw['tasks'] = [
        {'key':'relay_task', 'owner':'Merz', 'node':'relay_node',
         'release':at(2), 'deadline':at(50), 'duration':5},
        {'key':'recipient_work', 'owner':'Frei', 'node':'recipient_node', 'release':at(60),
         'deadline':at(120), 'duration':30}]
    raw['poll_feedback'] = {
        'projects':[{'key':'recipient_project', 'owner':'Frei', 'party':'Union',
                     'tasks':['recipient_work'], 'policy_value_keys':['organization_success'],
                     'policy_merit':.3}],
        'releases':[release(recipients=['Merz','Frei']),
                    release('bad',1,10.,recipients=['Merz'] if sender_receives else ['Wadephul'])]}
    raw['persona_communication'] = {
        'channels':[{'id':'private_call','sender':'Merz','recipient':'Frei',
                     'latency_minutes':latency,'reliability':reliability,'active':active}],
        'actions':[{'task':'relay_task','action':'send','channel':'private_call','release_id':'bad'}]}
    return raw


class PersonaCommunicationTests(unittest.TestCase):
    def test_selected_completed_action_delivers_after_actual_latency(self):
        world, _ = load(communication_config())
        world.run_until(at(7))
        service = world.services['persona_communication']
        self.assertEqual(world.tasks['relay_task'].status, 'COMPLETED')
        self.assertEqual(world.tasks['relay_task'].action_outcome, 'SUCCEEDED')
        self.assertEqual(service.history[0]['status'], 'SENT_NOT_DELIVERED')
        self.assertEqual(service.history[0]['sent_minute'], 7)
        self.assertEqual(service.history[0]['arrival_minute'], 11)
        self.assertEqual(world.game.information.states['Frei'].beliefs[POLL_KEY].estimate, 30.)
        world.run_until(at(10))
        self.assertEqual(world.game.information.states['Frei'].beliefs[POLL_KEY].source, 'synthetic_poll')
        world.run_until(at(11))
        self.assertEqual(world.game.information.states['Frei'].beliefs[POLL_KEY].source, 'persona:Merz')

    def test_sender_cannot_read_release_it_did_not_receive_or_latent_world(self):
        world, _ = load(communication_config(sender_receives=False))
        world.game.state.apply(PoliticalAction('hidden_change', {'immediate':{'Union':75.}}))
        world.run_until(at(20))
        service = world.services['persona_communication']
        self.assertEqual(service.history[0]['status'], 'BLOCKED')
        self.assertEqual(world.game.information.states['Frei'].beliefs[POLL_KEY].estimate, 30.)
        self.assertFalse(any(r.get('release',{}).get('forwarded_by') for r in world.services['poll_feedback'].history))
        self.assertFalse(world.services['poll_feedback'].review_nodes)

    def test_unselected_send_action_cannot_transmit(self):
        raw = communication_config()
        raw['nodes'][0]['actions'][0]['choice']['legal'] = False
        raw['nodes'][0]['actions'].append({'choice':{'key':'hold', 'legal':True}})
        world, _ = load(raw)
        world.run_until(at(20))
        settled = next(row for row in world.game.trace if row['node']=='living_task:relay_task')
        self.assertEqual(settled['chosen_action'], 'hold')
        self.assertEqual(world.services['persona_communication'].history, [])
        with self.assertRaises(ValueError):
            world.services['persona_communication'].send(world.services['persona_communication'].bindings[0])

    def test_closed_channel_cannot_send_or_deliver(self):
        world, _ = load(communication_config(active=False))
        world.run_until(at(20))
        self.assertEqual(world.services['persona_communication'].history[0]['status'], 'BLOCKED')
        self.assertEqual(world.game.information.states['Frei'].beliefs[POLL_KEY].estimate, 30.)
        world, _ = load(communication_config())
        world.run_until(at(7))
        world.services['persona_communication'].channels['private_call']['active'] = False
        world.run_until(at(11))
        self.assertEqual(world.services['persona_communication'].history[-1]['status'], 'DELIVERY_FAILED_CHANNEL_CLOSED')
        self.assertEqual(world.game.information.states['Frei'].beliefs[POLL_KEY].estimate, 30.)

    def test_relay_uses_received_belief_then_recipient_source_trust(self):
        world, _ = load(communication_config(reliability=.8))
        world.game.information.states['Frei'].source_trust['persona:Merz'] = .2
        world.run_until(at(11))
        service = world.services['poll_feedback']
        original = next(row for row in service.history if row['release']['id']=='bad')
        relayed = next(row for row in service.history if row['release'].get('forwarded_by'))
        sender_belief = original['delivered_beliefs']['Merz']
        row = relayed['release']
        self.assertEqual(row['value_percent'], sender_belief['estimate'])
        self.assertNotEqual(row['value_percent'], 10.)
        self.assertEqual(row['delivery_source'], 'persona:Merz')
        self.assertEqual(row['confidence'], sender_belief['confidence'] * .8)
        effective = sender_belief['confidence'] * .8 * .2
        expected = (row['value_percent'] * effective + 30. * .75) / (effective + .75)
        actual = world.game.information.states['Frei'].beliefs[POLL_KEY]
        self.assertAlmostEqual(actual.estimate, expected, places=4)
        self.assertEqual(actual.source, 'persona:Merz')

    def test_recipient_owns_review_and_original_party_support_is_unchanged(self):
        world, _ = load(communication_config())
        supports = {k:v.value for k,v in world.game.state.variables.items()}
        relationships = deepcopy(world.game.personas.runtime['Frei'].relationships)
        world.run_until(at(30))
        service = world.services['poll_feedback']
        relay = next(row for row in service.history if row['release'].get('forwarded_by'))
        self.assertEqual(relay['triggered_projects'], ['recipient_project'])
        settled = [row for row in world.trace if row['kind']=='policy_review_settled']
        self.assertEqual(len(settled), 1)
        completed = next(row for row in world.trace if row['kind']=='task_completed'
                         and str(row.get('task')).startswith('policy_review:'))
        self.assertEqual(world.tasks[completed['task']].owner, 'Frei')
        self.assertEqual({k:v.value for k,v in world.game.state.variables.items()}, supports)
        self.assertEqual(world.game.personas.runtime['Frei'].relationships, relationships)

    def test_duplicate_delivery_does_not_repeat_pressure_or_review(self):
        from hakoniwa.world_clock import DELIVERY
        world, _ = load(communication_config())
        world.run_until(at(11))
        service = world.services['persona_communication']
        identity = next(row['id'] for row in service.history if row.get('status')=='SENT_NOT_DELIVERED')
        prior = deepcopy(world.game.personas.runtime['Frei'].state)
        history_len = len(world.services['poll_feedback'].history)
        review_count = len(world.services['poll_feedback'].review_nodes)
        world.clock.schedule(11,'persona_poll_delivery',{'id':identity,'channel':'private_call'},phase=DELIVERY)
        world.run_until(at(11))
        self.assertEqual(world.game.personas.runtime['Frei'].state, prior)
        self.assertEqual(len(world.services['poll_feedback'].history), history_len)
        self.assertEqual(len(world.services['poll_feedback'].review_nodes), review_count)
        self.assertEqual(service.history[-1]['status'], 'DUPLICATE_IGNORED')

    def test_forwarded_report_is_not_a_new_poll_measurement(self):
        world, _ = load(communication_config())
        payload = world.run_until(at(30))
        history = world.services['poll_feedback'].history
        relay = next(row['release'] for row in history if row['release'].get('forwarded_by'))
        self.assertFalse(relay['modeled'])
        self.assertEqual(relay['evidence_status'], 'FORWARDED_PERSONA_BELIEF')
        self.assertEqual(relay['origin_release_id'], 'bad')
        self.assertEqual(relay['source'], 'synthetic_poll')
        self.assertNotIn('measurement', relay)
        # Two real release events, one social relay: no third survey point.
        points = [p for p in payload['scenario_report']['polling_series']
                  if p.get('measure')=='party_vote_published_release']
        self.assertEqual(len(points), 2)

    def test_bad_configuration_is_rejected(self):
        changes = [
            ('channel','latency_minutes',0), ('channel','latency_minutes',True),
            ('channel','latency_minutes',1.5), ('channel','reliability',True),
            ('channel','reliability',float('nan')), ('channel','reliability',1.1),
            ('channel','active','yes'), ('channel','recipient','Merz'),
            ('channel','recipient','UNKNOWN_PERSON'), ('binding','task','absent'),
            ('binding','channel','absent'), ('binding','release_id','absent'),
            ('binding','action','absent')]
        for kind,key,value in changes:
            with self.subTest(kind=kind,key=key,value=value):
                raw = communication_config()
                raw['persona_communication']['channels' if kind=='channel' else 'actions'][0][key] = value
                with self.assertRaises(ValueError): load(raw)
        raw = communication_config(); raw.pop('poll_feedback')
        with self.assertRaises(ValueError): load(raw)
        raw = communication_config()
        raw['persona_communication']['channels'].append(deepcopy(raw['persona_communication']['channels'][0]))
        with self.assertRaises(ValueError): load(raw)

    def test_missing_sender_is_a_validation_error_not_loader_key_error(self):
        raw = communication_config()
        del raw['persona_communication']['channels'][0]['sender']
        with self.assertRaises(ValueError): load(raw)

    def test_cannot_send_before_work_has_completed(self):
        world, _ = load(communication_config())
        world.run_until(at(3))
        service = world.services['persona_communication']
        with self.assertRaises(ValueError): service.send(service.bindings[0])
        self.assertEqual(service.history, [])

    def test_repeated_send_does_not_create_another_delivery(self):
        world, _ = load(communication_config())
        world.run_until(at(7))
        service = world.services['persona_communication']
        service.send(service.bindings[0])
        self.assertEqual(len(service.history), 1)
        world.run_until(at(11))
        relays = [row for row in world.services['poll_feedback'].history
                  if row['release'].get('forwarded_by')]
        self.assertEqual(len(relays), 1)

    def test_forwarding_old_report_does_not_read_senders_newer_blended_belief(self):
        raw = communication_config()
        raw['poll_feedback']['releases'].append(release('newer',2,80.,recipients=['Merz']))
        world, _ = load(raw)
        world.run_until(at(11))
        history = world.services['poll_feedback'].history
        old = next(row for row in history if row['release']['id']=='bad')
        latest = next(row for row in history if row['release']['id']=='newer')
        relay = next(row['release'] for row in history if row['release'].get('forwarded_by'))
        self.assertEqual(relay['value_percent'], old['delivered_beliefs']['Merz']['estimate'])
        self.assertNotEqual(relay['value_percent'], latest['delivered_beliefs']['Merz']['estimate'])
        self.assertEqual(relay['published_at'], old['release']['published_at'])

    def test_zero_channel_reliability_cannot_trigger_recipient_policy_review(self):
        world, _ = load(communication_config(reliability=0.))
        world.run_until(at(30))
        self.assertEqual(world.game.information.states['Frei'].beliefs[POLL_KEY].estimate, 30.)
        self.assertFalse(world.services['poll_feedback'].review_nodes)

    def test_same_original_report_via_two_channels_is_not_two_independent_shocks(self):
        raw = communication_config()
        other = deepcopy(raw['persona_communication']['channels'][0]); other['id']='second_call'
        raw['persona_communication']['channels'].append(other)
        binding = deepcopy(raw['persona_communication']['actions'][0]); binding['channel']='second_call'
        raw['persona_communication']['actions'].append(binding)
        world, _ = load(raw)
        world.run_until(at(11))
        relays = [row for row in world.services['poll_feedback'].history
                  if row['release'].get('forwarded_by')]
        self.assertEqual(len(relays), 2)
        self.assertEqual(sum('Frei' in row['delivered_beliefs'] for row in relays), 1)
        self.assertEqual(sum(len(row['pss_updates']) for row in relays), 1)
        self.assertEqual(len(world.services['poll_feedback'].review_nodes), 1)

    def test_later_direct_source_replaces_same_poll_relay_without_double_fusion_or_pressure(self):
        world, _ = load(communication_config())
        control, _ = load(communication_config(active=False))
        world.run_until(at(11))
        self.assertEqual(world.game.information.states['Frei'].beliefs[POLL_KEY].source, 'persona:Merz')
        before_turn = world.game.personas.runtime['Frei'].turn
        before_reviews = len(world.services['poll_feedback'].review_nodes)
        for simulation in (world, control):
            simulation.run_until(at(12))
            # The same original publication can reach someone later through a
            # direct source. Its fieldwork/publication date is not rewritten.
            simulation.services['poll_feedback'].schedule(
                release('bad_direct',1,10.,recipients=['Frei']))
            simulation.run_until(at(12))
        actual = world.game.information.states['Frei'].beliefs[POLL_KEY]
        direct_only = control.game.information.states['Frei'].beliefs[POLL_KEY]
        self.assertEqual(actual, direct_only)
        self.assertEqual(actual.source, 'synthetic_poll')
        corrections = world.services['poll_feedback'].history[-1]
        self.assertEqual(corrections['same_poll_direct_source_corrections'], ['Frei'])
        self.assertEqual(world.game.personas.runtime['Frei'].turn, before_turn)
        self.assertEqual(len(world.services['poll_feedback'].review_nodes), before_reviews)
        applied = [update for record in world.services['poll_feedback'].history
                   for update in record['pss_updates'] if update.get('actor')=='Frei'
                   and update.get('status')!='DUPLICATE_IGNORED']
        self.assertEqual(len(applied), 1)

    def test_forwarded_model_publication_preserves_origin_without_new_measurement(self):
        raw = communication_config()
        original = raw['poll_feedback']['releases'].pop()
        for key in ('value_percent','fieldwork_start','fieldwork_end','evidence_status'):
            original.pop(key)
        original['variable'] = 'Union'
        raw['poll_feedback']['publications'] = [original]
        world, _ = load(raw)
        world.run_until(at(11))
        history = world.services['poll_feedback'].history
        measured = next(row['release'] for row in history if row['release']['id']=='bad')
        forwarded = next(row['release'] for row in history if row['release'].get('forwarded_by'))
        self.assertIn('measurement', measured)
        self.assertNotIn('measurement', forwarded)
        self.assertEqual(forwarded['origin_measurement'], measured['measurement'])
        self.assertFalse(forwarded['is_new_poll_publication'])
        self.assertFalse(forwarded['modeled'])
        self.assertEqual(forwarded['evidence_status'], 'FORWARDED_PERSONA_BELIEF')

    def test_correcting_first_indirect_anchor_is_not_a_new_poll_decline(self):
        raw = communication_config()
        raw['poll_feedback']['releases'][0]['recipients'] = ['Merz']
        world, _ = load(raw)
        world.run_until(at(11))
        service = world.services['poll_feedback']
        self.assertEqual(world.game.information.states['Frei'].beliefs[POLL_KEY].source, 'persona:Merz')
        self.assertFalse(service.review_nodes)
        world.run_until(at(12))
        service.schedule(release('bad_direct',1,10.,recipients=['Frei']))
        world.run_until(at(12))
        reference = world.policy_projects['recipient_project'].references[POLL_KEY]
        self.assertEqual(reference['belief']['estimate'], 10.)
        self.assertEqual(reference['belief']['source'], 'synthetic_poll')
        self.assertFalse(service.review_nodes)
        self.assertFalse(service.history[-1]['pss_updates'])
