"""Execution, political outcomes, and evidence are distinct causal channels."""
import unittest
from dataclasses import replace
from pathlib import Path

from hakoniwa.action_perception import ActionPerceptionFilter
from hakoniwa.action_repertoire import ActionRepertoireFilter
from hakoniwa.institutional_logic import InstitutionalLogic
from hakoniwa.institutional_matrix import InstitutionalMatrix
from hakoniwa.persona_v2 import ActionOption, ActionScore, FreeAgentDecisionEngine
from hakoniwa.political_agency import AgencyHorizon
from hakoniwa.rationality_evaluation import ActorRationalityProfile, RationalityEvaluator


class ActionChannelTests(unittest.TestCase):
    def setUp(self):
        self.matrix = InstitutionalMatrix("test", {"M": ("chair",)}, {"chair": ("speak",)})
        self.logic = InstitutionalLogic.neutral()
        self.agency = AgencyHorizon()
        self.resources = {}

    def assess(self, action, *, confidence=1.0, agency=None):
        repertoire = ActionRepertoireFilter(self.matrix).apply("M", (action,), self.resources)
        return ActionPerceptionFilter().apply(
            (action,), repertoire, self.logic, agency or self.agency,
            self.resources, confidence,
        )[action.key]

    @staticmethod
    def persona(total=0.0):
        return ActionScore("a", total, 0, 0, 0, 0, 0, 0, (), {})

    def test_weak_political_odds_do_not_remove_a_possible_speech(self):
        action = ActionOption("speak", execution_feasibility=1.0, political_success_expectation=0.01)
        row = self.assess(action)
        self.assertEqual(row.perceived_status, "CONSIDERED")
        self.assertEqual(row.execution_feasibility, 1.0)
        self.assertEqual(row.political_success_expectation, 0.01)

    def test_low_confidence_changes_neither_execution_nor_political_odds(self):
        action = ActionOption("a", execution_feasibility=0.8, political_success_expectation=0.6)
        high, low = self.assess(action), self.assess(action, confidence=0.01)
        self.assertEqual(high.execution_feasibility, low.execution_feasibility)
        self.assertEqual(high.political_success_expectation, low.political_success_expectation)
        self.assertEqual(low.perceived_status, "CONSIDERED")
        self.assertEqual(low.information_confidence, 0.01)

    def test_action_confidence_limits_evidence_confidence_only(self):
        row = self.assess(ActionOption("a", information_confidence=0.1))
        self.assertEqual(row.information_confidence, 0.1)
        self.assertEqual(row.execution_feasibility, 1.0)

    def test_lack_of_a_party_carrier_does_not_disable_individual_speech(self):
        row = self.assess(ActionOption("speak"), agency=replace(self.agency, access_to_organizational_carrier=0.0))
        self.assertEqual(row.carrier_access, 1.0)
        self.assertEqual(row.perceived_status, "CONSIDERED")

    def test_declared_carrier_shortage_affects_outcome_not_execution(self):
        self.resources = {"endorsers": 0.1}
        row = self.assess(ActionOption("request_support", organizational_carrier_requirements={"endorsers": 0.5}))
        self.assertEqual(row.execution_feasibility, 1.0)
        self.assertEqual(row.political_success_expectation, 0.2)
        self.assertEqual(row.perceived_status, "CONSIDERED")

    def test_execution_resource_shortage_is_not_multiplied_again_as_same_carrier_shortage(self):
        self.resources = {"staff": 0.25}
        action = ActionOption("a", required_resources={"staff": 0.5},
                              organizational_carrier_requirements={"staff": 0.5})
        row = self.assess(action)
        self.assertEqual(row.execution_feasibility, 0.5)
        self.assertEqual(row.political_success_expectation, 1.0)
        self.assertIn("overlapping_resource_requirements_counted_once", row.reasons)

    def test_stricter_carrier_requirement_retains_residual_shortfall(self):
        self.resources = {"staff": 0.25}
        row = self.assess(ActionOption("a", required_resources={"staff": 0.5},
                                       organizational_carrier_requirements={"staff": 0.8}))
        self.assertEqual(row.execution_feasibility, 0.5)
        self.assertEqual(row.political_success_expectation, 0.625)

    def test_zero_execution_capacity_is_not_executable(self):
        self.assertEqual(self.assess(ActionOption("a", execution_feasibility=0.0)).perceived_status, "NOT_EXECUTABLE")

    def test_missing_authority_is_still_unavailable(self):
        row = self.assess(ActionOption("a", required_institutional_permissions=("appoint",)))
        self.assertEqual(row.perceived_status, "UNAVAILABLE")

    def test_institutional_legibility_can_still_narrow_consideration(self):
        self.logic = replace(self.logic, alternative_legibility=0.0)
        row = self.assess(ActionOption("a", institutional_deviation=1.0))
        self.assertEqual(row.perceived_status, "NOT_SERIOUSLY_CONSIDERED")

    def test_legacy_field_is_explicitly_marked_political_not_execution(self):
        row = self.assess(ActionOption("a", objective_feasibility=0.01))
        self.assertEqual(row.execution_feasibility, 1.0)
        self.assertEqual(row.political_success_expectation, 0.01)
        self.assertEqual(row.expectation_source, "LEGACY_OBJECTIVE_FEASIBILITY")

    def test_explicit_political_expectation_overrides_legacy_field(self):
        row = self.assess(ActionOption("a", objective_feasibility=0.01, political_success_expectation=0.7))
        self.assertEqual(row.political_success_expectation, 0.7)

    def test_success_weights_conditional_instrumental_outcomes_once(self):
        action = ActionOption("a", execution_feasibility=1.0, political_success_expectation=0.25,
                              instrumental_impacts={"gain": 1.0}, instrumental_failure_impacts={"gain": -1.0})
        profile = ActorRationalityProfile(1.0, 0.0, 0.0, 0.0)
        row = RationalityEvaluator().evaluate(action, self.persona(), profile, action_assessment=self.assess(action))
        self.assertEqual(row.instrumental_score, 1.0)
        self.assertEqual(row.failure_instrumental_score, 0.0)
        self.assertEqual(row.expected_instrumental_score, 0.25)
        self.assertEqual(row.choice_score, 0.25)

    def test_political_odds_do_not_multiply_substantive_or_identity_score(self):
        profile = ActorRationalityProfile(0.0, 0.5, 0.5, 0.0)
        action = ActionOption("a", execution_feasibility=1.0, substantive_impacts={"principle": 0.8})
        values = [RationalityEvaluator().evaluate(replace(action, political_success_expectation=p),
                                                 self.persona(30), profile).choice_score for p in (0.0, 1.0)]
        self.assertEqual(*values)

    def test_weak_evidence_is_not_an_extra_total_utility_multiplier(self):
        action = ActionOption("a", execution_feasibility=1.0, political_success_expectation=0.5)
        evaluator = RationalityEvaluator()
        high = evaluator.evaluate(action, self.persona(), ActorRationalityProfile(), action_assessment=self.assess(action))
        low = evaluator.evaluate(action, self.persona(), ActorRationalityProfile(), action_assessment=self.assess(action, confidence=0.01))
        self.assertEqual(high.choice_score, low.choice_score)

    def test_persona_confidence_affects_ambiguity_not_resource_feasibility(self):
        path = Path(__file__).resolve().parents[1] / "data/personas/cards_pss.json"
        engine = FreeAgentDecisionEngine.from_json(path)
        action = ActionOption("a", uncertainty=0.8, execution_feasibility=1.0, political_success_expectation=0.5)
        high = engine.score("Merz", self.assess(action).for_scoring(action), {}, {})
        low = engine.score("Merz", self.assess(action, confidence=0.01).for_scoring(action), {}, {})
        self.assertEqual(high.resource_feasibility, low.resource_feasibility)
        self.assertEqual(high.environment_compatibility, low.environment_compatibility)
        self.assertLess(low.risk_calculation, high.risk_calculation)

    def test_new_channel_inputs_are_bounded(self):
        for field in ("execution_feasibility", "political_success_expectation"):
            for value in (-0.1, 1.1, float("nan"), float("inf")):
                with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                    ActionOption("a", **{field: value})


if __name__ == "__main__":
    unittest.main()
