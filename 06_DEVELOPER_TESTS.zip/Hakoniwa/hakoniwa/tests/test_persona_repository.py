"""The modular repository is storage organization, not a new decision engine."""
from copy import deepcopy
from dataclasses import asdict
import json
from pathlib import Path
import shutil
import tempfile
import unittest

from hakoniwa.persona_repository import (
    COMPONENTS, ROOT, assemble_deck, load_bundle, load_persona_payload,
)
from hakoniwa.persona_v2 import ActionOption, FreeAgentDecisionEngine, _parse_card
from hakoniwa.political_poll_feedback import profile_for
from hakoniwa.plugins.majorities.integration import persona_ballot_decision
from hakoniwa.scenarios.zustrom_2025_vote_replay.persona_ballots import replacement_plan


ACTORS = {'Merz', 'Frei', 'Wuest', 'Soeder', 'Linnemann', 'Guenther',
          'Wadephul', 'Evers', 'Rhein', 'Schulze', 'Dobrindt', 'Kretschmer',
          'Warken', 'Baer', 'Hoppermann', 'Amthor', 'Reiche'}


def legacy_payload():
    return json.loads((ROOT / 'cards_pss.json').read_text(encoding='utf-8'))


def legacy_engine():
    return FreeAgentDecisionEngine({a: _parse_card(a, raw)
        for a, raw in legacy_payload()['actors'].items()})


class PersonaRepositoryTests(unittest.TestCase):
    def small_repository(self, temporary):
        root = Path(temporary) / 'personas'
        folder = root / 'actors' / 'Merz'
        shutil.copytree(ROOT / 'actors' / 'Merz', folder)
        registry = json.loads((ROOT / 'registry.json').read_text())
        registry['actors'] = {'Merz': 'actors/Merz'}
        (root / 'registry.json').write_text(json.dumps(registry))
        return root

    def test_exact_existing_actor_roster_and_complete_manifests(self):
        payload = assemble_deck()
        self.assertEqual(set(payload['actors']), ACTORS)
        self.assertEqual(len(payload['actors']), 17)
        for actor in ACTORS:
            with self.subTest(actor=actor):
                bundle = load_bundle(actor)
                self.assertEqual(set(bundle['components']), set(COMPONENTS))
                self.assertEqual(bundle['manifest']['actor'], actor)
                self.assertEqual(bundle['manifest']['name'], payload['actors'][actor]['name'])

    def test_assembled_compatibility_view_is_exactly_equal_to_old_deck(self):
        self.assertEqual(assemble_deck(), legacy_payload())

    def test_all_supported_repository_entrypoints_load_same_components(self):
        expected = load_persona_payload(ROOT)
        for entry in (ROOT / 'registry.json', ROOT / 'cards_pss.json'):
            self.assertEqual(load_persona_payload(entry), expected)

    def test_all_actor_numerical_models_and_two_decision_menus_are_preserved(self):
        old, new = legacy_engine(), FreeAgentDecisionEngine.from_json(ROOT)
        for actor in ACTORS:
            with self.subTest(actor=actor):
                before, after = old.cards[actor], new.cards[actor]
                self.assertEqual(asdict(before.dna), asdict(after.dna))
                self.assertEqual(asdict(before.pss_profile), asdict(after.pss_profile))
                self.assertEqual(before.initial_resources, after.initial_resources)
                self.assertEqual(asdict(old.runtime[actor]), asdict(new.runtime[actor]))
                other = next(iter(old.runtime[actor].relationships), 'unknown_contact')
                menus = [
                    (ActionOption('push', upside=.8, downside=.65, uncertainty=.4,
                        value_impacts={v.key:.35 for v in before.dna.value_hierarchy}),
                     ActionOption('verify', upside=.4, downside=.15, uncertainty=.1,
                        effort=.2, conflict_strategy='institutionalize')),
                    (ActionOption('talk', target_actor=other, relationship_posture='repair',
                        upside=.55, downside=.3, conflict_strategy='negotiate'),
                     ActionOption('boundary', target_actor=other, relationship_posture='boundary',
                        upside=.6, downside=.5, conflict_strategy='attack')),
                ]
                for actions in menus:
                    # Compare the entire score trace, rather than a preferred winner.
                    left = old.decide(actor, actions, before.initial_resources)
                    right = new.decide(actor, actions, after.initial_resources)
                    self.assertEqual(asdict(left), asdict(right))

    def test_polling_component_preserves_legacy_derived_channel_weights(self):
        old, new = legacy_engine(), FreeAgentDecisionEngine.from_json(ROOT)
        for actor in ACTORS:
            with self.subTest(actor=actor):
                self.assertEqual(profile_for(old.cards[actor])['channel_weights'],
                                 profile_for(new.cards[actor])['channel_weights'])

    def test_voting_component_preserves_options_without_granting_seats(self):
        old, new = legacy_engine(), FreeAgentDecisionEngine.from_json(ROOT)
        actions = {key: ActionOption('ballot_'+key, upside=value, downside=.3)
                   for key, value in [('yes', .5), ('no', .4), ('abstain', .3)]}
        for actor in ACTORS:
            with self.subTest(actor=actor):
                component = new.cards[actor].components['voting']
                self.assertEqual(set(component['legal_vote_options']), {'yes', 'no', 'abstain'})
                self.assertEqual(component['eligibility'], 'VERIFY_BODY_MEMBERSHIP_AND_DATE_IN_WORLD')
                args = dict(issue_id='test', available_from='2024-09-12T08:00:00+02:00')
                left = persona_ballot_decision(old, actor, actions, {}, **args)
                right = persona_ballot_decision(new, actor, actions, {}, **args)
                self.assertEqual(left['member_patch'], right['member_patch'])
                self.assertEqual(left['persona_trace'], right['persona_trace'])
                self.assertFalse(right['persona_component']['seat_granted'])
                self.assertNotIn('seats', right)
                self.assertEqual(set(right['member_patch']),
                    {'id', 'decided_vote', 'source_status', 'source_ids', 'available_from'})
        # Merely having a registered card does not make a person a 2024 MdB.
        with self.assertRaises(ValueError):
            replacement_plan({'persona_voting':{'voters':['Wuest']},
                              'facts':{'seats':{'CDU_CSU':196}}})

    def test_runtime_mutation_does_not_rewrite_initial_card_or_another_run(self):
        first, second = FreeAgentDecisionEngine.from_json(ROOT), FreeAgentDecisionEngine.from_json(ROOT)
        before = asdict(second.runtime['Merz'])
        first.runtime['Merz'].state.pressure = .001
        first.runtime['Merz'].relationships['Frei'].trust = .001
        first.runtime['Merz'].memories.clear()
        self.assertEqual(asdict(second.runtime['Merz']), before)
        self.assertEqual(asdict(first.cards['Merz'].runtime), before)

    def test_input_payload_cannot_mutate_loaded_component_contracts(self):
        payload = load_persona_payload(ROOT)
        raw = payload['actors']['Merz']
        engine = FreeAgentDecisionEngine({'Merz': _parse_card('Merz', raw)})
        expected = deepcopy(engine.cards['Merz'].components)
        raw['_components']['polling']['channel_weights']['party_vote'] = .001
        raw['_components']['communication']['auto_forward'] = True
        self.assertEqual(engine.cards['Merz'].components, expected)

    def test_separately_loaded_bundles_do_not_share_mutable_input(self):
        first = load_bundle('Merz')
        second = load_bundle('Merz')
        first['components']['behavior']['decision_parameters']['ambition'] = .001
        first['card']['relationship_memory'].clear()
        self.assertNotEqual(first['components']['behavior'], second['components']['behavior'])
        self.assertTrue(second['card']['relationship_memory'])

    def test_registry_folder_path_escape_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = self.small_repository(temporary)
            file = root / 'registry.json'
            registry = json.loads(file.read_text())
            registry['actors']['Merz'] = '../outside'
            file.write_text(json.dumps(registry))
            with self.assertRaisesRegex(ValueError, 'escapes'):
                load_bundle('Merz', root)

    def test_component_path_escape_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = self.small_repository(temporary)
            file = root / 'actors/Merz/manifest.json'
            manifest = json.loads(file.read_text())
            manifest['components']['behavior'] = '../Frei/behavior.json'
            file.write_text(json.dumps(manifest))
            with self.assertRaisesRegex(ValueError, 'escapes'):
                load_bundle('Merz', root)

    def test_explicit_old_overlay_stays_independent_from_latest_repository(self):
        payload = legacy_payload()
        raw = deepcopy(payload['actors']['Merz'])
        raw['decision_parameters']['ambition'] = .123
        raw['event_memory'] = []
        overlay = {'schema_version':'persona-cards-pss-1.0', 'actors':{'Merz':raw}}
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'cards_pss.json'
            path.write_text(json.dumps(overlay))
            standalone = FreeAgentDecisionEngine.from_json(path)
            combined = FreeAgentDecisionEngine.from_json_files(ROOT, path)
            self.assertEqual(standalone.cards['Merz'].dna.ambition, .123)
            self.assertEqual(standalone.cards['Merz'].components, {})
            self.assertEqual(combined.cards['Merz'].components, {})
            self.assertEqual(combined.runtime['Merz'].memories, [])
            self.assertEqual(set(combined.cards), ACTORS)
            self.assertEqual(asdict(combined.cards['Merz'].dna),
                             asdict(standalone.cards['Merz'].dna))

    def test_research_annotation_never_becomes_actor_knowledge_or_memory(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = self.small_repository(temporary)
            before = FreeAgentDecisionEngine.from_json(root)
            file = root / 'actors/Merz/evidence.json'
            data = json.loads(file.read_text())
            data['unreviewed_future_annotation'] = {
                'event_id':'future_knowledge_canary', 'event_memory':[{'secret':'latest news'}],
                'trust_in_frei':0., 'assumed_policy_success':1.}
            file.write_text(json.dumps(data))
            after = FreeAgentDecisionEngine.from_json(root)
            self.assertEqual(asdict(before.runtime['Merz']), asdict(after.runtime['Merz']))
            self.assertEqual(before.cards['Merz'].initial_resources, after.cards['Merz'].initial_resources)
            self.assertNotIn('future_knowledge_canary',
                             [m.event_id for m in after.runtime['Merz'].memories])


if __name__ == '__main__':
    unittest.main()
