"""A tolerable proposal can still be worse than the rejection alternative."""
from copy import deepcopy
import unittest

from hakoniwa.plugins.majorities import MajorityModel


def request(ideal=.6, proposal=.8, status_quo=.5):
    raw = {
        "schema_version": "hakoniwa-majorities-1.0", "as_of": "2024-09-12",
        "body": {"id": "toy", "kind": "faction"},
        "rule": {"total_weight": 1, "quorum": "none"},
        "issue": {"id": "toy", "version": "v1", "position": {"x": proposal}},
        "members": [{"id": "m", "position": {"x": ideal}, "weights": {"policy": 1}, "temperature": .2}],
    }
    if status_quo is not None:
        raw["issue"]["status_quo"] = {"position": {"x": status_quo}, "source_status": "MODEL_ASSUMPTION"}
    return raw


class VoteStatusQuoTests(unittest.TestCase):
    def evaluate(self, **kwargs):
        return MajorityModel(request(**kwargs)).evaluate_member("m")

    def test_closer_status_quo_yields_negative_policy_support(self):
        row = self.evaluate()
        self.assertAlmostEqual(row["raw_terms"]["policy"], -.1)
        self.assertGreater(row["utilities"]["no"], row["utilities"]["yes"])
        self.assertEqual(MajorityModel(request()).baseline()["result"]["member_ballots"]["m"], "no")

    def test_closer_proposal_yields_positive_policy_support(self):
        row = self.evaluate(ideal=.8, proposal=.7, status_quo=.3)
        self.assertAlmostEqual(row["raw_terms"]["policy"], .4)
        self.assertGreater(row["utilities"]["yes"], row["utilities"]["no"])

    def test_equal_policy_outcomes_do_not_manufacture_support(self):
        row = self.evaluate(ideal=.5, proposal=.8, status_quo=.2)
        self.assertAlmostEqual(row["raw_terms"]["policy"], 0)

    def test_missing_status_quo_is_unknown_not_midpoint_or_legacy_formula(self):
        row = self.evaluate(status_quo=None)
        self.assertEqual(row["raw_terms"]["policy"], 0)
        self.assertIn("status_quo", row["unknown"])
        self.assertIn("policy", row["unknown"])
        self.assertEqual(row["policy_comparison"]["status"], "UNKNOWN_STATUS_QUO")

    def test_comparison_uses_same_axes_and_salience_for_both_outcomes(self):
        raw = request()
        raw["issue"]["position"] = {"x": .8, "y": .1}
        raw["issue"]["status_quo"]["position"] = {"x": .5, "y": .9}
        raw["members"][0].update(position={"x": .6, "y": .2}, salience={"x": 1, "y": .5})
        row = MajorityModel(raw).evaluate_member("m")
        self.assertAlmostEqual(row["raw_terms"]["policy"], (.1+.5*.7)/1.5-(.2+.5*.1)/1.5)
        self.assertEqual(row["policy_comparison"]["dimensions"], ["x", "y"])

    def test_partial_baseline_is_visible_and_not_mixed_with_unmatched_axes(self):
        raw = request()
        raw["issue"]["position"]["y"] = .9
        raw["members"][0]["position"]["y"] = .1
        row = MajorityModel(raw).evaluate_member("m")
        self.assertAlmostEqual(row["raw_terms"]["policy"], -.1)
        self.assertEqual(row["policy_comparison"]["status"], "PARTIAL_COMPARISON")
        self.assertEqual(row["policy_comparison"]["missing_status_quo_dimensions"], ["y"])

    def test_no_common_or_salient_dimensions_gives_unknown_policy(self):
        for case in ("different_axes", "zero_salience"):
            raw = request()
            if case == "different_axes":
                raw["issue"]["status_quo"]["position"] = {"y": .5}
            else:
                raw["members"][0]["salience"] = {"x": 0}
            with self.subTest(case=case):
                row = MajorityModel(raw).evaluate_member("m")
                self.assertEqual(row["raw_terms"]["policy"], 0)
                self.assertIn("policy", row["unknown"])

    def test_future_or_unsourced_observed_baseline_is_rejected(self):
        for patch in (
            {"source_status": "OBSERVED"},
            {"source_status": "OBSERVED", "source_ids": ["future"], "available_from": "2024-09-13"},
        ):
            raw = request()
            raw["issue"]["status_quo"].update(patch)
            with self.subTest(patch=patch), self.assertRaises(ValueError):
                MajorityModel(raw)

    def test_sourced_baseline_provenance_is_retained(self):
        raw = request()
        raw["issue"]["status_quo"].update(source_status="OBSERVED", source_ids=["test-source"], available_from="2024-09-11")
        row = MajorityModel(raw).evaluate_member("m")
        self.assertEqual(row["policy_comparison"]["status_quo_provenance"]["source_ids"], ["test-source"])

    def test_invalid_baseline_is_rejected(self):
        for value in (None, {}, {"position": {}}, {"position": {"x": True}},
                      {"position": {"x": float("nan")}}, {"position": {"x": 1.1}},
                      {"position": {"x": .5}, "typo": 1}):
            raw = request()
            raw["issue"]["status_quo"] = value
            with self.subTest(value=value), self.assertRaises(ValueError):
                MajorityModel(raw)

    def test_explicit_legacy_mode_is_available_and_labeled(self):
        raw = request(status_quo=None)
        raw["issue"]["policy_mode"] = "legacy_proposal_distance"
        row = MajorityModel(raw).evaluate_member("m")
        self.assertAlmostEqual(row["raw_terms"]["policy"], .6)
        self.assertEqual(row["policy_comparison"]["status"], "LEGACY_NONCOMPARATIVE")

    def test_unknown_or_ambiguous_policy_mode_is_rejected(self):
        for mode in ("typo", "legacy_proposal_distance"):
            raw = request()
            raw["issue"]["policy_mode"] = mode
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                MajorityModel(raw)

    def test_discipline_and_exchange_can_outweigh_policy_comparison(self):
        raw = request()
        raw["members"][0].update(party="P", weights={"policy": 1, "discipline": .8, "exchange": .4})
        raw["issue"]["whip"] = {"stance": 1, "intensity": 1, "parties": ["P"]}
        raw["issue"]["assessments"] = {"m": {"exchange": .5}}
        row = MajorityModel(raw).evaluate_member("m")
        self.assertLess(row["weighted_terms"]["policy"], 0)
        self.assertGreater(row["utilities"]["yes"], row["utilities"]["no"])

    def test_proposal_red_line_remains_separate_from_relative_improvement(self):
        raw = request(ideal=0, proposal=.8, status_quo=1)
        raw["members"][0]["max_policy_distance"] = .5
        row = MajorityModel(raw).evaluate_member("m")
        self.assertGreater(row["raw_terms"]["policy"], 0)
        self.assertTrue(row["yes_excluded_by_personal_red_line"])
        self.assertEqual(row["probabilities"]["yes"], 0)

    def test_runtime_persona_vote_is_not_overridden_by_policy_diagnostic(self):
        raw = request()
        raw["members"][0].update(decided_vote="yes", source_status="RUNTIME_MODEL_STATE",
            source_ids=["test-decision"], available_from="2024-09-12")
        model = MajorityModel(raw)
        self.assertLess(model.evaluate_member("m")["raw_terms"]["policy"], 0)
        self.assertEqual(model.ballot(7)["result"]["member_ballots"]["m"], "yes")

    def test_request_is_not_mutated_and_seed_is_reproducible(self):
        raw = request()
        before = deepcopy(raw)
        model = MajorityModel(raw)
        self.assertEqual(model.ballot(19), model.ballot(19))
        self.assertEqual(raw, before)


if __name__ == "__main__":
    unittest.main()
