"""Clock, capacity and causal ordering tests for the existing engine integration."""
from dataclasses import replace
from pathlib import Path
import unittest

from hakoniwa.living_world import LivingPoliticalWorld, Task, Capacity
from hakoniwa.living_world_config import load_living_world
from hakoniwa.world_clock import WorldClock, WorkCalendar, DELIVERY, COMPLETION, DEADLINE, DISPATCH
from hakoniwa.checks.constitutional import build_gg_check_engine
from hakoniwa.checks.context import BundestagState, CheckContext
from hakoniwa.interaction.intents import Intent


ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "examples/living_world.json"


class WorldClockTests(unittest.TestCase):
    def test_same_minute_phase_order_and_exact_deadline(self):
        clock = WorldClock("2026-10-19T08:00:00+02:00")
        for phase in (DISPATCH, DEADLINE, COMPLETION, DELIVERY):
            clock.schedule(60, str(phase), phase=phase)
        seen = []
        clock.advance(60, lambda row: seen.append(row.phase))
        self.assertEqual(seen, [DELIVERY, COMPLETION, DEADLINE, DISPATCH])

    def test_rejects_naive_timestamps_past_and_duplicate_events(self):
        with self.assertRaises(ValueError):
            WorldClock("2026-10-19T08:00:00")
        clock = WorldClock("2026-10-19T08:00:00+02:00")
        clock.schedule(20, "once", event_id="unique")
        with self.assertRaises(ValueError):
            clock.schedule(30, "twice", event_id="unique")
        clock.advance(30, lambda _: None)
        with self.assertRaises(ValueError):
            clock.schedule(29, "past")

    def test_elapsed_time_uses_utc_across_dst_and_calendar_skips_weekend(self):
        clock = WorldClock("2026-10-23T17:30:00+02:00")
        slot = WorkCalendar().next_slot(clock, 0, 90)
        self.assertEqual(clock.at(slot).isoformat(), "2026-10-26T08:00:00+01:00")
        self.assertEqual(slot, 3810)

    def test_cancellation_and_incremental_advance(self):
        clock = WorldClock("2026-10-19T08:00:00+02:00")
        cancelled = clock.schedule(10, "cancelled")
        clock.cancel(cancelled)
        clock.schedule(20, "keep")
        seen, elapsed = [], []
        clock.advance(15, lambda e: seen.append(e.kind), elapsed.append)
        clock.advance(30, lambda e: seen.append(e.kind), elapsed.append)
        self.assertEqual(seen, ["keep"])
        self.assertEqual(sum(elapsed), 30)

    def test_handler_cannot_reorder_an_already_started_minute(self):
        clock = WorldClock("2026-10-19T08:00:00+02:00")
        clock.schedule(1, "complete", phase=COMPLETION)
        with self.assertRaises(ValueError):
            clock.advance(1, lambda _: clock.schedule(1, "retroactive_information", phase=DELIVERY))


class LivingWorldTests(unittest.TestCase):
    def build(self):
        return load_living_world(FIXTURE)

    def test_complete_on_deadline_and_conditional_jobs_require_choice(self):
        world, horizon = self.build()
        result = world.run_until(horizon)
        self.assertEqual(result["tasks"]["faction_round"]["status"], "COMPLETED")
        self.assertEqual(result["tasks"]["faction_round"]["finished"], 150)
        self.assertEqual(result["tasks"]["coordination_memo"]["status"], "UNRELEASED")
        self.assertEqual(result["tasks"]["allied_fact_sheet"]["status"], "COMPLETED")

    def test_organization_effect_occurs_only_after_implementation(self):
        world, _ = self.build()
        before = world.run_until("2026-10-19T10:30:00+02:00")
        self.assertEqual(before["tasks"]["allied_fact_sheet"]["status"], "RUNNING")
        value = before["world_state"]["variables"]["coordination_quality"]["value"]
        after = world.run_until("2026-10-19T12:00:00+02:00")
        self.assertEqual(after["world_state"]["variables"]["coordination_quality"]["value"], value+3)

    def test_personal_attention_never_overlaps_or_exceeds_daily_budget(self):
        world, horizon = self.build()
        result = world.run_until(horizon)
        for actor in world.used_personas:
            intervals = sorted((t.started, t.finished) for t in world.tasks.values()
                               if t.owner == actor and t.started is not None and t.finished is not None)
            for left, right in zip(intervals, intervals[1:]):
                self.assertLessEqual(left[1], right[0])
            self.assertTrue(all(minutes <= world.capacities[actor].daily_minutes
                                for minutes in result["capacities"][actor]["spent_by_day"].values()))
        self.assertEqual(result["tasks"]["reform_return_next_day"]["status"], "COMPLETED")

    def test_every_event_has_pressure_and_poll_snapshot_with_calendar_time(self):
        world, horizon = self.build()
        result = world.run_until(horizon)
        report = result["scenario_report"]
        self.assertTrue(report["valid"])
        steps = set(range(len(result["trace"])+1))
        self.assertEqual({row["step"] for row in report["polling_series"]}, steps)
        for actor in world.used_personas:
            self.assertEqual({row["step"] for row in report["pss_pressure_series"] if row["actor"] == actor}, steps)
        node = next(row for row in result["political_decisions"] if row["decision_maker"] == "Wadephul")
        self.assertEqual(node["calendar_date"], "2026-10-19T09:30:00+02:00")
        delivery = next(row for row in result["trace"] if row["kind"] == "information_delivered")
        self.assertEqual(delivery["details"]["affected"], ["Wadephul"])

    def test_same_input_replays_identically_and_only_rule_trigger_activates_remedy(self):
        first, horizon = self.build()
        second, _ = self.build()
        self.assertEqual(first.run_until(horizon), second.run_until(horizon))
        self.assertEqual(first.tasks["remedy_coordination"].status, "COMPLETED")
        self.assertEqual(first.fired_rules, {"coordination_gap"})

    def test_cycle_and_unlimited_person_capacity_are_rejected(self):
        original, _ = self.build()
        with self.assertRaises(ValueError):
            LivingPoliticalWorld(original.game, WorldClock("2026-10-19T08:00:00+02:00"),
                {"Merz": Capacity(slots=2)}, [Task("a", "Merz", 0, 90, 30, node="security_coordination")])
        with self.assertRaises(ValueError):
            LivingPoliticalWorld(original.game, WorldClock("2026-10-19T08:00:00+02:00"),
                {"Merz": Capacity()}, [
                    Task("a", "Merz", 0, 90, 30, node="security_coordination", dependencies=("b",)),
                    Task("b", "Merz", 0, 90, 30, node="security_coordination", dependencies=("a",))])

    def test_closed_procedure_window_blocks_execution(self):
        original, _ = self.build()
        task = Task("window", "Merz", 0, 150, 60, node="security_coordination", requires_windows=((0, 30),))
        world = LivingPoliticalWorld(original.game, WorldClock("2026-10-19T08:00:00+02:00"),
                                     {"Merz": Capacity()}, [task])
        world.run_until("2026-10-19T11:00:00+02:00")
        self.assertEqual(task.status, "MISSED")
        self.assertIsNone(task.started)

    def test_time_changes_do_not_bypass_legal_checks_or_release_blocked_followups(self):
        original, _ = self.build()
        game = original.game
        node = game.nodes["security_coordination"]
        option = node.actions[0]
        game.nodes["illegal"] = replace(node, key="illegal", actions=(replace(option,
            intent=Intent("dismiss", "Merz", "dismiss_chancellor")),))
        game.objective_check_engine = build_gg_check_engine()
        game.check_context_provider = lambda state: CheckContext(
            now_hours=10, bundestag=BundestagState(630), actor_roles={}, office_holders={})
        task = Task("legal_check", "Merz", 0, 180, 60, node="illegal",
                    followups={option.choice.key: ("forbidden_implementation",)})
        job = Task("forbidden_implementation", "staff", 0, 180, 30,
                   activation="conditional", effects={"coordination_quality": 10})
        world = LivingPoliticalWorld(game, WorldClock("2026-10-19T08:00:00+02:00"),
                                     {"Merz": Capacity(), "staff": Capacity()}, [task, job])
        result = world.run_until("2026-10-19T11:00:00+02:00")
        self.assertEqual(result["political_decisions"][0]["institutional_resolution"]["resolution"], "blocked")
        self.assertEqual(job.status, "UNRELEASED")
        self.assertEqual(game.state.variables["coordination_quality"].value, 48)
        self.assertEqual(game.check_context_provider(game.state).now_hours, 13)

    def test_recovery_depends_on_elapsed_time_not_number_of_clock_events(self):
        one, horizon = self.build()
        two, _ = self.build()
        first = one.run_until(horizon)
        two.run_until("2026-10-19T12:17:00+02:00")
        second = two.run_until(horizon)
        for actor in one.used_personas:
            self.assertEqual(first["persona_runtime"]["actors"][actor]["runtime"]["state"],
                             second["persona_runtime"]["actors"][actor]["runtime"]["state"])

    def test_new_agenda_task_can_be_submitted_after_time_has_advanced(self):
        world, _ = self.build()
        world.run_until("2026-10-20T12:00:00+02:00")
        world.submit_task(Task("new_agenda", "Merz", world.clock.minute, world.clock.minute+120,
                               30, node="reform_agenda"))
        world.run_until("2026-10-20T15:00:00+02:00")
        self.assertEqual(world.tasks["new_agenda"].status, "COMPLETED")


if __name__ == "__main__":
    unittest.main()
