from dataclasses import replace
from pathlib import Path
import json
import math
import tempfile
import unittest

from hakoniwa.living_world import LivingPoliticalWorld, Task, Capacity
from hakoniwa.living_world_config import load_living_world
from hakoniwa.world_clock import WorldClock
from hakoniwa.political_state import PoliticalAction, StateVariable
from hakoniwa.opportunity_windows import OpportunityWindow, OpportunityRegistry
from hakoniwa.political_timing import TimingReport, TimingBeliefs
from hakoniwa.checks.constitutional import build_gg_check_engine
from hakoniwa.checks.context import CheckContext, BundestagState
from hakoniwa.interaction.intents import Intent

FIXTURE=Path(__file__).resolve().parents[1]/"examples/living_world.json"
START="2026-10-19T08:00:00+02:00"


def build(tasks=(),windows=()):
    original,_=load_living_world(FIXTURE)
    game=original.game
    game.state.variables["closed"]=StateVariable("closed",0)
    for actor,node_key in (("Merz","security_coordination"),("Frei","faction_briefing")):
        node=game.nodes[node_key];a=node.actions[0]
        game.nodes["single_"+actor]=replace(node,key="single_"+actor,actions=(replace(a,
            choice=replace(a.choice,key="act"),world=PoliticalAction("act",{"immediate":{"coordination_quality":10}})),))
    world=LivingPoliticalWorld(game,WorldClock(START),{t.owner:Capacity() for t in tasks},list(tasks))
    world.install_opportunities(tuple(windows))
    return world


def until(w,minute):return w.run_until(w.clock.at(minute).isoformat())


class DeadlineAndOutcomeTests(unittest.TestCase):
    def test_soft_late_preserves_effect(self):
        task=Task("job","staff",0,30,60,effects={"coordination_quality":10})
        w=build([task]);until(w,90)
        self.assertEqual(task.status,"COMPLETED_LATE");self.assertEqual(task.action_outcome,"SUCCEEDED")
        self.assertEqual(w.game.state.variables["coordination_quality"].value,58)

    def test_hard_expiry_stops_effect_and_reclaims_only_unspent_time(self):
        task=Task("job","staff",0,30,60,effects={"coordination_quality":10},deadline_policy="HARD")
        w=build([task]);until(w,90)
        self.assertEqual(task.status,"EXPIRED");self.assertEqual(task.work_status,"INTERRUPTED")
        self.assertEqual(w.game.state.variables["coordination_quality"].value,48)
        self.assertEqual(sum(w.capacities["staff"].spent_by_day.values()),30)

    def test_exact_hard_deadline_is_inclusive(self):
        task=Task("job","staff",0,60,60,effects={"coordination_quality":10},deadline_policy="HARD")
        w=build([task]);until(w,90)
        self.assertEqual(task.status,"COMPLETED");self.assertEqual(w.game.state.variables["coordination_quality"].value,58)

    def test_decay_uses_elapsed_time_not_number_of_events(self):
        def run(sliced):
            t=Task("job","staff",0,30,90,effects={"coordination_quality":10},deadline_policy="DECAY",late_decay_per_hour=1)
            w=build([t])
            if sliced:
                for at in (5,13,31,47,65):until(w,at)
            until(w,100);return w.game.state.variables["coordination_quality"].value
        self.assertAlmostEqual(run(False),48+10/math.e)
        self.assertAlmostEqual(run(False),run(True))

    def test_blocked_institution_cannot_unlock_action_success_dependency(self):
        parent=Task("parent","Merz",0,180,30,node="single_Merz")
        child=Task("child","staff",0,180,30,dependencies=("parent",),effects={"coordination_quality":5})
        review=Task("review","review_staff",0,180,30,dependencies=("parent",),dependency_outcomes={"parent":"work_complete"},effects={"government_capacity":1})
        w=build([parent,child,review]);node=w.game.nodes["single_Merz"];a=node.actions[0]
        w.game.nodes[node.key]=replace(node,actions=(replace(a,intent=Intent("dismiss","Merz","dismiss_chancellor")),))
        w.game.objective_check_engine=build_gg_check_engine()
        w.game.check_context_provider=lambda state:CheckContext(now_hours=0,bundestag=BundestagState(630),actor_roles={},office_holders={})
        until(w,180)
        self.assertEqual(parent.work_status,"COMPLETED");self.assertEqual(parent.action_outcome,"BLOCKED")
        self.assertEqual(child.status,"BLOCKED");self.assertEqual(review.status,"COMPLETED")
        self.assertEqual(w.game.state.variables["coordination_quality"].value,48)


class DeferredEffectTests(unittest.TestCase):
    def register(self,w,*,delay=30,duration=0,policy="CANCEL",conditions=()):
        w.game.state.apply(PoliticalAction("source",{"medium":{"coordination_quality":12}},effect_timing={"medium":{
            "delay_minutes":delay,"duration_minutes":duration,"conditions":conditions,"on_condition_loss":policy}}))

    def test_lump_realizes_once_at_due_time(self):
        w=build();self.register(w)
        until(w,29);self.assertEqual(w.game.state.variables["coordination_quality"].value,48)
        until(w,30);self.assertEqual(w.game.state.variables["coordination_quality"].value,60)
        until(w,600);self.assertEqual(w.game.state.variables["coordination_quality"].value,60)
        self.assertEqual(w.game.state.pending_effects[0]["status"],"REALIZED")

    def test_legacy_horizon_does_not_invent_a_due_date(self):
        w=build();w.game.state.apply(PoliticalAction("legacy",{"long":{"coordination_quality":12}}))
        out=until(w,60*24*31)
        self.assertEqual(w.game.state.variables["coordination_quality"].value,48)
        self.assertEqual(out["temporal_system"]["unscheduled_legacy_effects"][0]["status"],"UNSCHEDULED")

    def test_accrual_pause_does_not_backfill_and_is_partition_invariant(self):
        def run(sliced):
            w=build();self.register(w,delay=0,duration=60,policy="PAUSE",conditions=({"variable":"closed","operator":"eq","value":0},))
            w.add_event(30,"pause",(),effects={"closed":1},visibility="HIDDEN")
            w.add_event(45,"resume",(),effects={"closed":-1},visibility="HIDDEN")
            if sliced:
                for at in (10,20,35,40,50):until(w,at)
            until(w,60);return w
        a,b=run(False),run(True)
        self.assertAlmostEqual(a.game.state.variables["coordination_quality"].value,57)
        self.assertAlmostEqual(a.game.state.variables["coordination_quality"].value,b.game.state.variables["coordination_quality"].value)
        self.assertEqual(a.game.state.pending_effects[0]["status"],"PARTIAL")
        self.assertAlmostEqual(a.game.state.pending_effects[0]["realized_fraction"],.75)

    def test_condition_cancel_is_irreversible_without_new_action(self):
        w=build();self.register(w,delay=0,duration=60,conditions=({"variable":"closed","operator":"eq","value":0},))
        w.add_event(30,"stop",(),effects={"closed":1},visibility="HIDDEN")
        w.add_event(45,"restore",(),effects={"closed":-1},visibility="HIDDEN")
        until(w,60)
        self.assertAlmostEqual(w.game.state.variables["coordination_quality"].value,54)
        self.assertEqual(w.game.state.pending_effects[0]["status"],"CANCELLED")

    def test_unknown_conditions_do_not_become_true_from_missing_zero(self):
        w=build();self.register(w,conditions=({"variable":"missing","operator":"eq","value":0},))
        until(w,60);self.assertEqual(w.game.state.variables["coordination_quality"].value,48)
        self.assertEqual(w.game.state.pending_effects[0]["reason"],"CONDITION_UNKNOWN")

    def test_deferred_polling_reward_is_rejected(self):
        w=build();w.game.state.apply(PoliticalAction("bad",{"medium":{"Union":5}},effect_timing={"medium":{"delay_minutes":30}}))
        with self.assertRaises(ValueError):until(w,60)

    def test_timing_validation_occurs_before_immediate_effect(self):
        w=build()
        with self.assertRaises(ValueError):w.game.state.apply(PoliticalAction("bad",{"immediate":{"coordination_quality":1},"medium":{"coordination_quality":5}},effect_timing={"medium":{"delay_minutes":-1}}))
        self.assertEqual(w.game.state.variables["coordination_quality"].value,48)

    def test_opposing_concurrent_effects_are_netted_before_clamping(self):
        for order in ((10,-10),(-10,10)):
            w=build();w.game.state.variables["coordination_quality"]=StateVariable("coordination_quality",97)
            for n,v in enumerate(order):w.game.state.apply(PoliticalAction(str(n),{"medium":{"coordination_quality":v}},effect_timing={"medium":{"delay_minutes":30}}))
            until(w,60)
            self.assertEqual(w.game.state.variables["coordination_quality"].value,97)

    def test_lump_phase_follows_same_minute_task_completion(self):
        t=Task("job","staff",0,60,30,effects={"closed":1})
        w=build([t]);self.register(w,conditions=({"variable":"closed","operator":"eq","value":1},))
        until(w,60)
        self.assertEqual(w.game.state.pending_effects[0]["status"],"REALIZED")
        self.assertEqual(w.game.state.variables["coordination_quality"].value,60)


class StagedActionTests(unittest.TestCase):
    def task(self,**kwargs):
        return Task("job","Merz",0,180,10,node="single_Merz",lifecycle="STAGED",action_timing={"act":{"execution_minutes":60}},**kwargs)

    def test_commitment_does_not_settle_world_and_choice_is_frozen(self):
        t=self.task();w=build([t]);until(w,10)
        self.assertEqual(t.committed_action,"act");self.assertEqual(t.committed_at,10)
        self.assertEqual(w.game.state.variables["coordination_quality"].value,48)
        node=w.game.nodes["single_Merz"];a=node.actions[0]
        w.game.nodes[node.key]=replace(node,actions=(replace(a,world=PoliticalAction("changed",{"immediate":{"coordination_quality":90}}),choice=replace(a.choice,key="changed")),))
        until(w,70)
        self.assertEqual(w.game.state.variables["coordination_quality"].value,58)
        self.assertEqual(w.game.trace[-1]["chosen_action"],"act")

    def test_own_attention_and_action_execution_time_both_count(self):
        t=self.task();w=build([t]);until(w,70)
        self.assertEqual(t.started,0);self.assertEqual(t.execution_started,10);self.assertEqual(t.finished,70)
        self.assertEqual(sum(w.capacities["Merz"].spent_by_day.values()),70)

    def test_external_execution_releases_personal_attention(self):
        t=self.task();t.action_timing["act"]["attention_required"]=False
        w=build([t]);until(w,20)
        self.assertFalse(w.capacities["Merz"].busy)
        self.assertEqual(sum(w.capacities["Merz"].spent_by_day.values()),10)
        until(w,70);self.assertEqual(t.status,"COMPLETED")

    def test_preparation_can_precede_procedure_but_personal_execution_must_fit(self):
        t=self.task(requires_windows=((60,120),));w=build([t])
        until(w,10)
        self.assertEqual(t.committed_at,10);self.assertIsNone(t.execution_started)
        until(w,120)
        self.assertEqual(t.execution_started,60);self.assertEqual(t.finished,120)

    def test_external_execution_waits_for_procedure_without_occupying_person(self):
        t=self.task(requires_windows=((60,120),));t.action_timing["act"]["attention_required"]=False
        w=build([t]);until(w,40)
        self.assertIsNone(t.execution_started);self.assertFalse(w.capacities["Merz"].busy)
        until(w,120)
        self.assertEqual(t.execution_started,60);self.assertEqual(t.finished,120)
        self.assertEqual(sum(w.capacities["Merz"].spent_by_day.values()),10)

    def test_cancel_keeps_spent_cost_but_no_unrealized_reward(self):
        t=self.task();w=build([t]);until(w,20)
        self.assertTrue(w.cancel_task("job","withdraw after receiving new evidence"))
        until(w,100)
        self.assertEqual(t.status,"CANCELLED");self.assertEqual(sum(w.capacities["Merz"].spent_by_day.values()),20)
        self.assertEqual(w.game.state.variables["coordination_quality"].value,48)

    def test_hard_expiry_during_execution_does_not_reselect_or_pay(self):
        t=Task("job","Merz",0,30,10,node="single_Merz",lifecycle="STAGED",deadline_policy="HARD",action_timing={"act":{"execution_minutes":60}})
        w=build([t]);until(w,100)
        self.assertEqual(t.status,"EXPIRED");self.assertEqual(t.committed_action,"act")
        self.assertFalse(w.game.trace);self.assertEqual(w.game.state.variables["coordination_quality"].value,48)

    def test_execution_rechecks_actual_institutional_authority(self):
        t=self.task();w=build([t]);node=w.game.nodes["single_Merz"];a=node.actions[0]
        w.game.nodes[node.key]=replace(node,actions=(replace(a,intent=Intent("dismiss","Merz","dismiss_chancellor")),))
        w.game.objective_check_engine=build_gg_check_engine()
        w.game.check_context_provider=lambda state:CheckContext(now_hours=0,bundestag=BundestagState(630),actor_roles={},office_holders={})
        until(w,70)
        self.assertEqual(t.work_status,"COMPLETED");self.assertEqual(t.action_outcome,"BLOCKED")
        self.assertEqual(w.game.state.variables["coordination_quality"].value,48)

    def test_optional_advice_is_drawn_once_at_commitment_and_still_reported(self):
        from hakoniwa.plugins.arcana import ArcanaService, ArcanaConfig
        t=self.task();w=build([t]);w.game.arcana=ArcanaService(ArcanaConfig(enabled=True,master_seed=7))
        until(w,10)
        self.assertEqual(w.game.arcana._occurrences[("living_task:job","Merz")],1)
        out=until(w,70)
        self.assertEqual(w.game.arcana._occurrences[("living_task:job","Merz")],1)
        self.assertEqual(w.game.trace[-1]["arcana"]["status"],"REUSED_COMMITMENT")
        self.assertTrue(any(r.get("arcana",{}).get("status")=="RUN" for r in out["trace"]))


class OpportunityTests(unittest.TestCase):
    def test_window_can_have_opened_or_expired_before_simulation_origin(self):
        w=build()
        self.assertEqual(OpportunityWindow("old",opens_at=-120,closes_at=-1).check(w.game.state,0),"EXPIRED")
        self.assertEqual(OpportunityWindow("open",opens_at=-120,closes_at=60).check(w.game.state,0),"OPEN")

    def test_conditions_and_resources_derive_window(self):
        w=build();win=OpportunityWindow("x",opens_when=({"variable":"coordination_quality","operator":"ge","value":50},),closes_when=({"variable":"closed","operator":"ge","value":1},))
        self.assertEqual(win.check(w.game.state,0),"NOT_READY")
        w.game.state.apply(PoliticalAction("support",{"immediate":{"coordination_quality":5}}))
        self.assertEqual(win.check(w.game.state,0),"OPEN")
        w.game.state.apply(PoliticalAction("rival",{"immediate":{"closed":1}}))
        self.assertEqual(win.check(w.game.state,0),"CLOSED_CONDITION")

    def test_secret_closure_blocks_payoff_but_does_not_release_attention_early(self):
        t=Task("job","Merz",0,180,10,node="single_Merz",lifecycle="STAGED",window="x",action_timing={"act":{"execution_minutes":60}})
        w=build([t],[OpportunityWindow("x",closes_when=({"variable":"closed","operator":"ge","value":1},))])
        w.add_event(30,"rival_closed",(),effects={"closed":1},visibility="HIDDEN")
        until(w,40)
        self.assertEqual(t.status,"RUNNING")
        self.assertIn("job",w.capacities["Merz"].busy)
        until(w,100)
        self.assertEqual(t.status,"EXPIRED");self.assertEqual(w.game.state.variables["coordination_quality"].value,48)
        self.assertEqual(sum(w.capacities["Merz"].spent_by_day.values()),70)
        self.assertNotIn("closed",w.game.information.states["Merz"].beliefs)

    def test_explicit_physical_interrupt_releases_unspent_attention(self):
        t=Task("job","Merz",0,180,10,node="single_Merz",lifecycle="STAGED",window="x",action_timing={"act":{"execution_minutes":60}})
        w=build([t],[OpportunityWindow("x",running_policy="INTERRUPT",closes_when=({"variable":"closed","operator":"eq","value":1},))])
        w.add_event(30,"physical_interruption",(),effects={"closed":1},visibility="HIDDEN")
        until(w,40)
        self.assertEqual(t.status,"EXPIRED");self.assertEqual(sum(w.capacities["Merz"].spent_by_day.values()),30)

    def test_negotiated_extension_requires_authority_and_does_not_change_beliefs(self):
        w=build(windows=[OpportunityWindow("x",closes_at=20,allocation_authority="organizer")])
        with self.assertRaises(ValueError):w.extend_opportunity("x",60,authority="Merz",reason="wishes to wait")
        w.extend_opportunity("x",60,authority="organizer",reason="verified agreement")
        until(w,40)
        self.assertEqual(w.opportunities.windows["x"].check(w.game.state,40),"OPEN")
        self.assertIsNone(w.timing_beliefs.estimate("Merz","x",40,{}))

    def test_simultaneous_claims_do_not_choose_by_insertion_order(self):
        w=build()
        def run(order):
            registry=OpportunityRegistry((OpportunityWindow("x",capacity=1),))
            for key in order:registry.request("x",key,key,10)
            return registry.settle_batch("x",10,w.game.state)
        self.assertEqual(run(("A","B")),run(("B","A")))
        self.assertEqual(run(("A","B")),{"A":"CONTESTED","B":"CONTESTED"})

    def test_two_person_contest_waits_for_actual_allocator(self):
        tasks=[Task(a,a,0,180,10,node="single_"+a,lifecycle="STAGED",window="x",action_timing={"act":{"execution_minutes":20}}) for a in ("Merz","Frei")]
        w=build(tasks,[OpportunityWindow("x",capacity=1,allocation_authority="supporting_organization")])
        until(w,15)
        self.assertEqual({t.status for t in tasks},{"WAITING_ALLOCATION"})
        with self.assertRaises(ValueError):w.resolve_opportunity("x",["Frei"],authority="unknown")
        w.resolve_opportunity("x",["Frei"],authority="supporting_organization")
        until(w,60)
        self.assertEqual(tasks[1].action_outcome,"SUCCEEDED");self.assertEqual(tasks[0].action_outcome,"FAILED")
        self.assertEqual(w.game.state.variables["coordination_quality"].value,58)

    def test_expiry_protection_is_explicit_and_never_overrides_condition_loss(self):
        w=build();win=OpportunityWindow("x",closes_at=20,preserve_expiry_after_commit=True,closes_when=({"variable":"closed","operator":"eq","value":1},))
        win.claims["a"]="Merz"
        self.assertEqual(win.check(w.game.state,30,"a"),"OPEN")
        self.assertEqual(win.check(w.game.state,30,"b"),"EXPIRED")
        w.game.state.apply(PoliticalAction("loss",{"immediate":{"closed":1}}))
        self.assertEqual(win.check(w.game.state,30,"a"),"CLOSED_CONDITION")


class TimingBeliefTests(unittest.TestCase):
    def test_access_or_objective_existence_does_not_deliver_a_belief(self):
        store=TimingBeliefs()
        self.assertIsNone(store.estimate("Merz","x",0,{}))
        store.deliver("Merz",TimingReport("x","staff","m1",0,.8,.9,1,120),10)
        self.assertIsNone(store.estimate("Frei","x",10,{}))
        self.assertEqual(store.estimate("Merz","x",20,{})["remaining_minutes"],100)

    def test_duplicate_source_does_not_multiply_confidence(self):
        store=TimingBeliefs()
        store.deliver("M",TimingReport("x","staff","a",0,.8,.8,1,120),0)
        first=store.estimate("M","x",0,{})
        store.deliver("M",TimingReport("x","staff","b",0,.8,.8,1,120),0)
        self.assertEqual(first["confidence"],store.estimate("M","x",0,{})["confidence"])

    def test_waiting_is_persona_choice_with_finite_budget_and_real_time(self):
        t=Task("job","Merz",0,180,10,node="single_Merz",importance=0)
        w=build([t]);w.configure_waiting({"Merz":{"window":"topic","review_minutes":30,"max_wait_minutes":30}})
        w.deliver_timing_report("Merz",TimingReport("topic","staff","forecast",0,1,1,1,1000))
        until(w,100)
        self.assertTrue(any(r["kind"]=="actor_waiting" for r in w.trace))
        self.assertEqual(t.started,30);self.assertEqual(t.finished,40)
        self.assertEqual(sum(w.capacities["Merz"].spent_by_day.values()),10)

    def test_unreported_real_expiry_does_not_change_actor_waiting_evaluation(self):
        def start(closes):
            t=Task("job","Merz",0,180,10,node="single_Merz",importance=0,window="x")
            w=build([t],[OpportunityWindow("x",closes_at=closes)])
            w.configure_waiting({"Merz":{"window":"x","review_minutes":30,"max_wait_minutes":30}})
            w.deliver_timing_report("Merz",TimingReport("x","staff","forecast",0,1,1,1,1000))
            until(w,40)
            waits=[r["details"]["evaluations"] for r in w.trace if r["kind"]=="actor_waiting"]
            return waits,t.action_outcome
        a,b=start(20),start(120)
        self.assertEqual(a[0],b[0]);self.assertEqual(a[1],"FAILED");self.assertEqual(b[1],"SUCCEEDED")

    def test_reported_window_and_different_action_durations_affect_choice(self):
        t=Task("job","Merz",0,180,10,node="single_Merz",lifecycle="STAGED",window="x",action_timing={
            "fast":{"execution_minutes":10},"slow":{"execution_minutes":60}})
        # Build with the complete two-action menu before validating the task.
        original,_=load_living_world(FIXTURE);game=original.game
        node=game.nodes["security_coordination"];a=node.actions[0]
        game.nodes["single_Merz"]=replace(node,key="single_Merz",current_goals={"coordination":1},actions=tuple(
            replace(a,world=PoliticalAction(key,{"immediate":{"coordination_quality":1}}),
                    choice=replace(a.choice,key=key,goal_impacts={"coordination":goal})) for key,goal in (("fast",.6),("slow",.9))))
        w=LivingPoliticalWorld(game,WorldClock(START),{"Merz":Capacity()},[t])
        w.install_opportunities([OpportunityWindow("x",closes_at=180)])
        w.deliver_timing_report("Merz",TimingReport("x","staff","narrow",0,0,1,1,30))
        until(w,80)
        self.assertEqual(t.committed_action,"fast")
        temporal=w.game.trace[-1]["temporal_assessment"]
        self.assertLess(temporal["slow"]["expected_goal_survival"],temporal["fast"]["expected_goal_survival"])


class LoaderTests(unittest.TestCase):
    def test_json_loader_accepts_explicit_lifecycle_delay_window_and_reports(self):
        raw=json.loads(FIXTURE.read_text())
        raw["tasks"]=raw["tasks"][:1]
        raw["tasks"][0].update({"followups":{},"lifecycle":"STAGED","duration":10,
            "action_timing":{a["choice"]["key"]:{"execution_minutes":20} for a in raw["nodes"][0]["actions"]},"window":"x"})
        raw["reactive_rules"]=[];raw["events"]=[]
        raw["opportunity_windows"]=[{"key":"x","opens_at":START,"closes_at":"2026-10-19T12:00:00+02:00"}]
        raw["timing_reports"]=[{"actor":"Merz","window":"x","source":"staff","message_id":"a","observed_at":START,
            "received_at":START,"information_gain":.5,"confidence":.8,"available_probability":1,"remaining_minutes":240}]
        for action in raw["nodes"][0]["actions"]:
            action["deferred_effects"]={"medium":{"coordination_quality":1}}
            action["effect_timing"]={"medium":{"delay_minutes":30}}
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/"i.json";path.write_text(json.dumps(raw))
            w,horizon=load_living_world(path);out=w.run_until(horizon)
            self.assertEqual(w.tasks["security_meeting"].committed_at,10)
            self.assertEqual(w.tasks["security_meeting"].finished,30)
            self.assertTrue(any(r.get("status")=="REALIZED" for r in w.game.state.pending_effects))
            self.assertTrue(out["scenario_report"]["valid"])
            self.assertTrue(out["scenario_report"]["charts"]["polling_svg"])
            self.assertTrue(out["scenario_report"]["charts"]["pss_pressure_svg"])


if __name__=="__main__":unittest.main()
