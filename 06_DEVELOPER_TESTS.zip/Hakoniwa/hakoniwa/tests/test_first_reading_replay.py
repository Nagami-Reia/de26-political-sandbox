from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from hakoniwa.plugins.majorities import MajorityModel
from hakoniwa.scenarios.zustrom_2025_vote_replay.first_reading import (
    HERE, load_cards, make_roster, predict, run_path, vote_model,
)


def protocol():
    return json.loads((HERE/"first_reading_protocol.json").read_text())


class FirstReadingTests(unittest.TestCase):
    def test_migrated_policy_reference_is_explicit_and_not_used_for_procedure(self):
        p=protocol(); members=make_roster(p,None)
        model=vote_model(p,members,p["facts"]["bill_components"],{},"2024-09-12","test")
        row=model.evaluate_member("ANON_CDU_CSU_000")
        self.assertEqual(row["policy_comparison"]["status"],"COMPARATIVE")
        self.assertEqual(model.request["issue"]["status_quo"],p["assumptions"]["vote_status_quo"])
        agenda=vote_model(p,members,p["facts"]["bill_components"],{},"2024-09-12","agenda",procedural=True)
        self.assertNotIn("status_quo",agenda.request["issue"])

    def test_control_with_missing_reference_remains_unknown_and_future_reference_rejected(self):
        p=protocol(); members=make_roster(p,None)
        p["assumptions"].pop("vote_status_quo",None)
        model=vote_model(p,members,p["facts"]["bill_components"],{},"2024-09-12","control")
        self.assertIn("status_quo",model.evaluate_member("ANON_CDU_CSU_000")["unknown"])
        p["assumptions"]["vote_status_quo"]={"position":p["facts"]["bill_components"],
            "source_status":"OBSERVED","source_ids":["future"],"available_from":"2025-01-31"}
        with self.assertRaises(ValueError):
            vote_model(p,members,p["facts"]["bill_components"],{},"2024-09-12","bad")

    def test_initial_roster_not_january_roster(self):
        p=protocol()
        members=make_roster(p,None)
        self.assertEqual(len(members),733)
        self.assertEqual(sum(m["party"]=="FDP" for m in members),91)
        self.assertEqual(sum(m["party"]=="AfD" for m in members),77)
        self.assertGreater(len({m["position"]["family_reunion_stop"] for m in members if m["party"]=="FDP"}),50)

    def test_future_memories_and_offices_removed(self):
        p=protocol(); engine,cards,audit=load_cards(p)
        for actor,row in cards["actors"].items():
            self.assertEqual(row["event_memory"],[])
            self.assertEqual(row["relationship_memory"],{})
            self.assertEqual(row["initial_current_state"],p["assumptions"]["initial_pss"])
            self.assertEqual(set(engine.cards[actor].components), {'voting'})
            self.assertEqual(audit[actor]['component_source'], 'REGISTERED_PERSONA_DIRECTORIES')
            self.assertFalse(audit[actor]['research_notes_imported_into_actor_beliefs'])
        self.assertIn("NOT chancellor",p["facts"]["offices"]["Merz"])

    def test_party_whips_opposite_and_not_duplicated(self):
        p=protocol(); rows=make_roster(p,None)
        model=vote_model(p,rows,p["facts"]["bill_components"],
            {"CDU_CSU":{"stance":1.,"intensity":.800},"SPD":{"stance":-1.,"intensity":.500}},
            "2024-09-12","test")
        self.assertGreater(model.evaluate_member("ANON_CDU_CSU_000")["weighted_terms"]["discipline"],0)
        self.assertLess(model.evaluate_member("ANON_SPD_000")["weighted_terms"]["discipline"],0)
        self.assertEqual(model.evaluate_member("ANON_FDP_000")["weighted_terms"]["discipline"],0)
        secret=deepcopy(model.request);secret["body"]["secret"]=True
        self.assertEqual(MajorityModel(secret).evaluate_member("ANON_SPD_000")["weighted_terms"]["discipline"],0)
        bad=deepcopy(model.request);bad["issue"]["whip"]={"stance":1.,"parties":["SPD"]}
        with self.assertRaises(ValueError):MajorityModel(bad)
        bad=deepcopy(model.request)
        bad["issue"]["whips"]["SPD"].update(source_status="OBSERVED",source_ids=["future"],available_from="2025-01-31")
        with self.assertRaises(ValueError):MajorityModel(bad)

    def test_prediction_cannot_read_historical_target(self):
        p=protocol();p["horizon"]="2024-09-20"
        original=Path.read_text
        def guarded(path,*args,**kwargs):
            if path.name in ("reference.json","comparison.json"):
                raise AssertionError("Historical outcome leakage")
            return original(path,*args,**kwargs)
        with tempfile.TemporaryDirectory() as directory,patch.object(Path,"read_text",guarded):
            result=predict(Path(directory),runs=1,protocol=p)
        self.assertEqual(result["baseline_terminal"],"PENDING_AT_HORIZON")

    def test_joint_replay_and_no_early_third_reading(self):
        p=protocol();p["horizon"]="2024-10-10"
        a=run_path(p,20240912,detailed=False)
        self.assertEqual(a,run_path(p,20240912,detailed=False))
        self.assertTrue(all(set(n["all_actor_pss_after"])=={"Merz","Frei"} for n in a["trace"]))
        previous=None
        for n in a["trace"]:
            if n["actor"]=="Frei" and n["chosen_action"]!="audit_commitments":
                self.assertFalse(n["feedback"]["new_aggregate_report"])
            if n["chosen_action"]=="third_reading_vote":
                self.assertEqual(previous["chosen_action"],"second_reading_vote")
                self.assertTrue(previous["feedback"]["result"]["passed"])
            previous=n


if __name__=="__main__":unittest.main()
