"""No protagonist, hidden truth, official calendar context, no media bonus."""
import json
from pathlib import Path
import tempfile
import unittest

from hakoniwa.information_filter import InformationFilter
from hakoniwa.living_world_config import load_living_world
from hakoniwa.political_state import PoliticalAction, PoliticalState, StateVariable
from hakoniwa.world_environment import WorldEnvironment, DEFAULT_ENVIRONMENT

ROOT = Path(__file__).resolve().parents[1]


class ExternalEnvironmentTests(unittest.TestCase):
    def load(self, raw):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/"input.json"
            path.write_text(json.dumps(raw), encoding="utf-8")
            return load_living_world(path, environment_path=DEFAULT_ENVIRONMENT)

    def autonomous(self):
        return {"schema_version": "living-world-config-1.0", "start": "2026-10-17T00:00:00+02:00",
                "until": "2026-10-17T03:00:00+02:00", "variables": {"pressure": 40, "Union": 24},
                "poll_variables": ["Union"], "events": [
                    {"key": "external_change", "at": "2026-10-17T01:00:00+02:00",
                     "visibility": "HIDDEN", "effects": {"pressure": 5}}]}

    def media(self):
        raw = json.loads((ROOT/"examples/shared_world_inputs.json").read_text(encoding="utf-8"))
        raw.pop("history")
        raw.pop("parliament")
        raw["tasks"] = []
        route = raw["media"]["history_routes"]["reform_coordination_needed"]
        raw["media"]["event_routes"] = {"news": route}
        raw["events"] = [{"key": "news", "at": "2026-10-19T09:00:00+02:00", "affected": ["Merz"]}]
        return raw

    def test_real_calendar_is_not_an_execution_gate(self):
        external = WorldEnvironment.load().external
        self.assertEqual(len(external.profile["institutional_calendars"]["Bundestag"]["session_weeks"]), 22)
        self.assertEqual(external.calendar_context("Bundestag", "2026-10-12")["status"], "PLANNED_SESSION_WEEK")
        context = external.calendar_context("Bundestag", "2026-10-21")
        self.assertEqual(context["status"], "OUTSIDE_PLANNED_SESSION_WEEKS")
        self.assertEqual(context["execution_permission"], "NOT_DETERMINED")
        self.assertEqual(context["extraordinary_session_route"], "GG_39_3")
        self.assertEqual(external.calendar_context("Bundesrat", "2026-10-12")["status"], "UNKNOWN")
        self.assertEqual(external.calendar_context("Bundestag", "2027-10-12")["status"], "UNKNOWN")

    def test_source_ledger_has_distinct_statuses_and_no_faked_sources(self):
        external = WorldEnvironment.load().external
        self.assertEqual(len(external.sources), 36)
        with self.assertRaises(ValueError):
            external.validate_provenance({"status": "REAL_OBSERVED", "sources": []})
        with self.assertRaises(ValueError):
            external.validate_provenance({"status": "REAL_OBSERVED", "sources": ["fake"]})

    def test_delivery_only_does_not_read_truth_or_counterfactual_truth(self):
        info = InformationFilter({"M": {}, "F": {}}, delivery_only=True)
        truth = PoliticalState({"x": StateVariable("x", 90)}, {}, {})
        self.assertEqual(info.observe("M", truth, commit=True).beliefs, {})
        info.deliver("M", {"x": {"estimate": 20, "confidence": .8, "source": "rumour"}}, message_id="1")
        truth.apply(PoliticalAction("change", {"immediate": {"x": -80}}))
        self.assertEqual(info.observe("M", truth).beliefs["x"].estimate, 20)
        self.assertIsNone(info.observe("M", truth).beliefs["x"].last_truth)
        self.assertEqual(info.observe("F", truth).beliefs, {})

    def test_zero_personas_still_have_events_and_polling_report(self):
        world, until = self.load(self.autonomous())
        payload = world.run_until(until)
        self.assertEqual(payload["world_state"]["variables"]["pressure"]["value"], 45)
        self.assertEqual(payload["political_decisions"], [])
        self.assertTrue(payload["scenario_report"]["valid"])
        self.assertEqual(payload["scenario_report"]["used_persona_cards"], [])
        self.assertEqual(payload["scenario_report"]["chart_contract"]["pss_pressure"]["status"], "NOT_APPLICABLE_NO_PERSONAS")
        self.assertTrue(payload["scenario_report"]["polling_series"])
        self.assertEqual(payload["trace"][0]["kind"], "world_fact_occurred")

    def test_organization_works_weekend_with_finite_capacity(self):
        raw = self.autonomous()
        raw["tasks"] = [{"key": "monitor", "owner": "GMLZ", "release": raw["start"],
                         "deadline": raw["until"], "duration": 30, "effects": {"pressure": -1}}]
        world, until = self.load(raw)
        payload = world.run_until(until)
        self.assertEqual(payload["tasks"]["monitor"]["status"], "COMPLETED")
        self.assertEqual(sum(payload["capacities"]["GMLZ"]["spent_by_day"].values()), 30)
        self.assertEqual(payload["capacities"]["GMLZ"]["daily_minutes"], 600)  # assumed, NOT a BBK observation

    def test_message_arrival_is_separate_from_fact_and_may_be_wrong(self):
        raw = self.autonomous()
        raw["knowledge"] = {"initial_beliefs": {"Merz": {}, "Frei": {}}, "messages": [
            {"key": "report", "at": "2026-10-17T02:00:00+02:00", "recipients": ["Frei"],
             "visibility": "PRIVATE", "observations": {"pressure": {"estimate": 10, "confidence": .8, "source": "staff"}}}]}
        world, until = self.load(raw)
        before = world.run_until("2026-10-17T01:30:00+02:00")
        self.assertEqual(before["subsystems"]["information"]["beliefs"]["Frei"]["beliefs"], {})
        after = world.run_until(until)
        beliefs = after["subsystems"]["information"]["beliefs"]
        self.assertEqual(beliefs["Frei"]["beliefs"]["pressure"]["estimate"], 10)
        self.assertEqual(beliefs["Merz"]["beliefs"], {})
        self.assertEqual(after["world_state"]["variables"]["pressure"]["value"], 45)

    def test_private_fact_cannot_open_public_media_round(self):
        for visibility in ("PRIVATE", "HIDDEN"):
            raw = self.media()
            raw["events"][0]["visibility"] = visibility
            raw["events"][0]["affected"] = []
            world, until = self.load(raw)
            payload = world.run_until(until)
            self.assertEqual(payload["subsystems"]["media"]["history"], [])

    def test_no_implicit_public_support_multiplier(self):
        raw = self.media()
        raw["media"].pop("opinion_response")
        world, until = self.load(raw)
        payload = world.run_until(until)
        self.assertTrue(payload["subsystems"]["media"]["history"])
        self.assertEqual(payload["subsystems"]["media"]["history"][0]["state_update"]["status"], "COGNITION_ONLY_NO_OPINION_MODEL")
        self.assertEqual(payload["world_state"]["variables"]["Union"]["value"], 24)

    def test_opinion_response_is_delayed_bounded_and_explicitly_assumed(self):
        raw = self.media()
        world, _ = self.load(raw)
        before = world.run_until("2026-10-19T11:01:00+02:00")
        self.assertEqual(before["world_state"]["variables"]["Union"]["value"], 24)
        self.assertEqual(before["subsystems"]["media"]["opinion_history"], [])
        after = world.run_until("2026-10-19T12:01:00+02:00")
        self.assertEqual(len(after["subsystems"]["media"]["opinion_history"]), 1)
        self.assertLessEqual(abs(after["world_state"]["variables"]["Union"]["value"]-24), .25)

    def test_removed_multiplier_and_fake_empirical_response_are_rejected(self):
        raw = self.media()
        raw["media"]["support_points_per_unit"] = 3
        with self.assertRaises(ValueError):
            self.load(raw)
        raw = self.media()
        raw["media"]["opinion_response"]["status"] = "REAL_OBSERVED"
        with self.assertRaises(ValueError):
            self.load(raw)

    def test_provenance_changes_after_simulated_effect_not_still_observed(self):
        raw = self.autonomous()
        raw["variable_provenance"] = {"pressure": {"status": "MODEL_INFERRED", "sources": [], "note": "synthetic"}}
        world, until = self.load(raw)
        payload = world.run_until(until)
        self.assertEqual(payload["variable_provenance"]["pressure"]["status"], "SCENARIO_GENERATED")
        self.assertEqual(payload["variable_provenance"]["pressure"]["initial_status"], "MODEL_INFERRED")
        self.assertEqual(payload["world_state"]["variables"]["pressure"]["evidence"], "SCENARIO_GENERATED")
        self.assertEqual(payload["variable_provenance"]["Union"]["status"], "SIMULATION_ASSUMPTION")

    def test_replay_full_external_trace_is_identical(self):
        first, until = self.load(self.media())
        second, _ = self.load(self.media())
        self.assertEqual(first.run_until(until), second.run_until(until))

    def test_unknown_is_not_a_zero_placeholder_and_access_is_not_receipt(self):
        raw = self.autonomous()
        raw["variable_provenance"] = {"pressure": {"status": "UNKNOWN", "sources": []}}
        with self.assertRaises(ValueError):
            self.load(raw)
        raw = self.autonomous()
        raw["information"] = {"Merz": {"pressure": {"access": .9}}}
        with self.assertRaises(ValueError):
            self.load(raw)

    def test_unknown_resource_does_not_peek_at_world_capital(self):
        raw = self.autonomous()
        raw["knowledge"] = {"initial_beliefs": {"Merz": {}}}
        raw["capital"] = {"secret": 100}
        raw["resource_bindings"] = {"Merz": {"public_capital": "capital:secret"}}
        world, _ = self.load(raw)
        beliefs = world.game.information.observe("Merz", world.game.state)
        resources = world.game._perceived_resources("Merz", beliefs)
        self.assertEqual(resources["public_capital"], world.game.personas.cards["Merz"].initial_resources["public_capital"])
        world.game.information.deliver("Merz", {"capital:secret": {
            "estimate": 10, "confidence": .8, "source": "staff"}}, message_id="known")
        resources = world.game._perceived_resources("Merz", world.game.information.observe("Merz", world.game.state))
        self.assertEqual(resources["public_capital"], .1)


if __name__ == "__main__":
    unittest.main()
