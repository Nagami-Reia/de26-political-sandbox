from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from hakoniwa.living_world_config import load_living_world
from hakoniwa.political_poll_feedback import profile_for
from hakoniwa.persona_v2 import FreeDecision,FreeAgentDecisionEngine
from hakoniwa.information_filter import InformationFilter
from hakoniwa.political_state import PoliticalAction
from hakoniwa.interaction.intents import Intent
from hakoniwa.checks.constitutional import build_gg_check_engine
from hakoniwa.checks.context import CheckContext,BundestagState

ROOT=Path(__file__).resolve().parents[1]
START='2026-10-19T08:00:00+02:00'


def release(identity='baseline',minute=0,value=30.,**kwargs):
    from datetime import datetime,timedelta
    at=(datetime.fromisoformat(START)+timedelta(minutes=minute)).isoformat()
    return {'id':identity,'published_at':at,'fieldwork_start':START,'fieldwork_end':at,
        'series':'synthetic','source':'synthetic_poll','channel':'party_vote','subject':'Union','region':'DE',
        'standard_error_pp':1.,'confidence':1.,'value_percent':value,'evidence_status':'SIMULATION_ASSUMPTION',**kwargs}


def config():
    raw=json.loads((ROOT/'examples/living_world.json').read_text())
    raw['until']='2026-10-19T13:00:00+02:00';raw['events']=[];raw['reactive_rules']=[]
    raw['tasks']=[{'key':'reform','owner':'Merz','release':START,'deadline':raw['until'],'duration':10,
        'lifecycle':'STAGED','node':'reform_agenda','action_timing':{
            'negotiate_text':{'execution_minutes':100},'set_public_deadline':{'execution_minutes':100}}},
        {'key':'followup','owner':'Kanzleramt_staff','release':START,'deadline':raw['until'],
         'duration':10,'dependencies':['reform'],'effects':{'government_capacity':1}}]
    raw['poll_feedback']={'projects':[{'key':'reform_project','owner':'Merz','party':'Union',
        'tasks':['reform','followup'],'policy_value_keys':['reform_achievement'],'policy_merit':.3}],
        'releases':[release(),release('bad',20,10.)]}
    return raw


def load(raw):
    with tempfile.TemporaryDirectory() as d:
        path=Path(d)/'input.json';path.write_text(json.dumps(raw))
        return load_living_world(path)


def force_review(role):
    original=FreeAgentDecisionEngine.decide
    def choose(engine,actor,actions,*args,**kwargs):
        result=original(engine,actor,actions,*args,**kwargs)
        if set(a.key for a in actions)=={'continue','pause','revise','withdraw'}:
            if role not in result.scores or result.scores[role].hard_rejections:raise AssertionError('Cannot force unavailable review action')
            return FreeDecision(actor,role,result.scores,result.turn)
        return result
    return patch.object(FreeAgentDecisionEngine,'decide',choose)


class PollFeedbackTests(unittest.TestCase):
    def test_report_not_latent_truth_and_chart_keeps_released_series(self):
        world,until=load(config());before=world.game.state.variables['Union'].value
        payload=world.run_until(until)
        self.assertEqual(world.game.state.variables['Union'].value,before)
        service=world.services['poll_feedback']
        self.assertEqual(service.history[1]['release']['value_percent'],10.)
        self.assertNotEqual(service.history[1]['delivered_beliefs']['Merz']['estimate'],before)
        self.assertTrue(any(p['measure']=='party_vote_published_release' for p in payload['scenario_report']['polling_series']))

    def test_poll_reopens_real_persona_review_during_execution(self):
        world,until=load(config());world.run_until(until)
        reviews=[r for r in world.trace if r['kind']=='policy_review_settled']
        self.assertEqual(len(reviews),1)
        self.assertEqual(reviews[0]['elapsed_minutes'],35)
        self.assertTrue(any(r['kind']=='task_suspended' for r in world.trace))
        self.assertIn(world.policy_projects['reform_project'].status,{'ACTIVE','PAUSED','WITHDRAWN','WORK_COMPLETED'})
        self.assertEqual(world.game.personas.runtime['Merz'].relationships,
                         world.game.personas.cards['Merz'].runtime.relationships)

    def test_continue_resumes_remaining_work_keeps_cost_and_does_not_recommit(self):
        world,until=load(config())
        with force_review('continue'):world.run_until(until)
        task=world.tasks['reform']
        self.assertEqual(task.committed_at,10)
        self.assertEqual(task.finished,125) # 110 original + 15 attention-costed review
        self.assertEqual(task.status,'COMPLETED')
        self.assertEqual(sum(world.capacities['Merz'].spent_by_day.values()),125)

    def test_pause_invalidates_old_completion_and_preserves_unsettled_effects(self):
        world,until=load(config());before=world.game.state.variables['coordination_quality'].value
        with force_review('pause'):world.run_until(until)
        self.assertEqual(world.tasks['reform'].status,'PAUSED')
        self.assertIn(world.tasks['followup'].status,{'READY','MISSED'})
        self.assertEqual(sum(world.capacities['Kanzleramt_staff'].spent_by_day.values()),0)
        self.assertEqual(world.game.state.variables['coordination_quality'].value,before)
        self.assertEqual(sum(world.capacities['Merz'].spent_by_day.values()),35)

    def test_withdrawal_blocks_project_followup_but_not_cleanup(self):
        raw=config()
        raw['tasks'].append({'key':'cleanup','owner':'Kanzleramt_staff','release':START,
            'deadline':raw['until'],'duration':10,'activation':'conditional','effects':{'government_capacity':1}})
        raw['poll_feedback']['projects'][0]['withdrawal_cleanup_tasks']=['cleanup']
        world,until=load(raw)
        with force_review('withdraw'):world.run_until(until)
        self.assertEqual(world.policy_projects['reform_project'].status,'WITHDRAWN')
        self.assertEqual(world.tasks['reform'].status,'CANCELLED')
        self.assertEqual(world.tasks['followup'].status,'CANCELLED')
        self.assertEqual(world.tasks['cleanup'].status,'COMPLETED')
        self.assertEqual(sum(world.capacities['Merz'].spent_by_day.values()),35)

    def test_revision_is_real_work_and_requires_new_preparation(self):
        raw=config()
        raw['tasks'].append({'key':'revision','owner':'Merz','release':START,'deadline':raw['until'],
            'duration':20,'activation':'conditional','node':'reform_agenda'})
        raw['poll_feedback']['projects'][0]['revision_task']='revision'
        world,until=load(raw)
        with force_review('revise'):world.run_until(until)
        self.assertEqual(world.tasks['revision'].status,'COMPLETED')
        self.assertEqual(world.tasks['reform'].status,'COMPLETED')
        self.assertGreater(world.tasks['reform'].committed_at,world.tasks['revision'].finished)
        self.assertTrue(any(x['kind']=='task_repreparation_required' for x in world.trace))

    def test_small_or_uncertain_change_does_not_trigger_review(self):
        for value,error,confidence in ((29.,1.,1.),(10.,30.,1.),(10.,1.,0.)):
            raw=config();raw['poll_feedback']['releases'][1].update(value_percent=value,standard_error_pp=error,confidence=confidence)
            world,until=load(raw);world.run_until(until)
            self.assertFalse(any(r['kind']=='policy_review_settled' for r in world.trace))

    def test_first_poll_is_anchor_not_fabricated_decline(self):
        raw=config();raw['poll_feedback']['releases']=raw['poll_feedback']['releases'][1:]
        world,until=load(raw);world.run_until(until)
        self.assertEqual(len(world.policy_projects['reform_project'].references),1)
        self.assertFalse(world.services['poll_feedback'].review_nodes)

    def test_different_derived_weights_and_explicit_zero_weight(self):
        engine=FreeAgentDecisionEngine.from_json(ROOT/'data/personas/cards_pss.json')
        self.assertNotEqual(profile_for(engine.cards['Merz'])['channel_weights'],profile_for(engine.cards['Frei'])['channel_weights'])
        raw=config();raw['poll_feedback']['actor_weights']={'Merz':{'party_vote':0.}}
        world,until=load(raw);world.run_until(until)
        self.assertFalse(world.services['poll_feedback'].review_nodes)

    def test_stale_region_and_undelivered_poll_have_no_project_effect(self):
        for change in ({'channel':'state_vote','region':'MV'}, {'recipients':['Frei']}, {'channel':'personal_approval','subject':'Frei'}):
            raw=config();raw['poll_feedback']['releases'][1].update(change)
            world,until=load(raw);world.run_until(until)
            self.assertFalse(world.services['poll_feedback'].review_nodes)

    def test_no_new_choice_from_raw_world_poll_changes_without_release(self):
        raw=config();raw['poll_feedback']['releases']=raw['poll_feedback']['releases'][:1]
        world,until=load(raw)
        world.register_event_handler('hidden_support',lambda w,e:w.game.state.apply(PoliticalAction('hidden',{'immediate':{'Union':-20}})))
        world.clock.schedule(20,'hidden_support',{})
        world.run_until(until)
        self.assertFalse(world.services['poll_feedback'].review_nodes)
        beliefs=world.game.information.states['Merz'].beliefs
        self.assertEqual(beliefs['poll:party_vote:DE:Union:synthetic'].estimate,30.)

    def test_pressure_appraisal_is_once_and_does_not_overwrite_self_efficacy(self):
        world,until=load(config());world.run_until(until)
        rows=[r for r in world.services['poll_feedback'].history if r.get('release',{}).get('id')=='bad']
        self.assertEqual(len(rows),1);self.assertEqual(len(rows[0]['pss_updates']),1)
        deltas=rows[0]['pss_updates'][0]['impact']['state_deltas']
        self.assertGreater(deltas['pressure'],0.)
        self.assertTrue(all(deltas[k]==0 for k in ('energy','confidence','control','identity_integrity')))

    def test_state_feedback_can_be_disabled_without_disabling_review(self):
        raw=config();raw['poll_feedback']['state_feedback_scale']=0.
        world,until=load(raw);world.run_until(until)
        rows=[r for r in world.services['poll_feedback'].history if 'release' in r]
        self.assertTrue(all(not r['pss_updates'] for r in rows))
        self.assertTrue(world.services['poll_feedback'].review_nodes)

    def test_unrelated_public_report_is_not_automatically_read_by_every_actor(self):
        raw=config();raw['poll_feedback']['releases'][1].update(channel='state_vote',region='MV')
        world,until=load(raw);world.run_until(until)
        row=next(r for r in world.services['poll_feedback'].history if r.get('release',{}).get('id')=='bad')
        self.assertEqual(row['release']['recipients'],[])
        self.assertEqual(row['delivered_beliefs'],{})

    def test_project_binding_status_never_claims_feedback_active_without_projects(self):
        raw=config();raw.pop('poll_feedback')
        world,_=load(raw)
        self.assertEqual(world.environment['poll_decision_feedback']['status'],'NO_POLICY_PROJECT_BINDINGS')

    def test_profile_and_release_validation(self):
        for change in ({'confidence':True},{'value_percent':True},{'standard_error_pp':-1},
                       {'fieldwork_end':'2026-10-19T09:00:00+02:00'},
                       {'evidence_status':'OBSERVED','source_ids':['future']}):
            raw=config();raw['poll_feedback']['releases'][1].update(change)
            with self.assertRaises(ValueError):load(raw)
        raw=config();raw['poll_feedback']['releases'].append(deepcopy(raw['poll_feedback']['releases'][0]))
        with self.assertRaises(ValueError):load(raw)

    def test_actor_weight_changes_review_scores_without_forcing_decision(self):
        results=[]
        for weight in (.1,1.):
            raw=config();raw['poll_feedback']['actor_weights']={'Merz':{'party_vote':weight}}
            world,until=load(raw);world.run_until(until)
            review=next(r for r in world.trace if r['kind']=='task_completed' and r['task'].startswith('policy_review:'))
            results.append((review['decision']['chosen_action'],review['decision']['action_evaluations']))
        self.assertNotEqual(results[0][1],results[1][1])
        self.assertNotEqual(results[0][0],results[1][0])

    def test_recovery_release_reopens_paused_project_and_coalesces_pending_reports(self):
        raw=config();raw['poll_feedback']['releases'] += [release('bad_revision',25,8.),release('recovery',100,60.)]
        world,until=load(raw);world.run_until(until)
        reviews=[r for r in world.trace if r['kind']=='policy_review_settled']
        self.assertEqual(len(reviews),2) # Two bad reports while reviewing use one attention slot.
        self.assertEqual(reviews[0]['details']['action'],'pause')
        self.assertEqual(reviews[1]['details']['action'],'continue')
        self.assertEqual(world.tasks['reform'].status,'COMPLETED')

    def test_completed_work_not_undone_by_later_withdrawal(self):
        raw=config();raw['tasks'].append({'key':'early_work','owner':'Kanzleramt_staff','release':START,
            'deadline':raw['until'],'duration':5,'effects':{'government_capacity':1}})
        raw['poll_feedback']['projects'][0]['tasks'].append('early_work')
        world,until=load(raw);before=world.game.state.variables['government_capacity'].value
        with force_review('withdraw'):world.run_until(until)
        self.assertEqual(world.tasks['early_work'].status,'COMPLETED')
        self.assertEqual(world.game.state.variables['government_capacity'].value,before+1)

    def test_modeled_publication_uses_measurement_not_raw_support(self):
        raw=config();baseline=release('measured_baseline');baseline.pop('value_percent')
        later=release('measured_later',20);later.pop('value_percent')
        baseline['variable']=later['variable']='Union'
        raw['poll_feedback']['releases']=[];raw['poll_feedback']['publications']=[baseline,later]
        world,until=load(raw)
        world.register_event_handler('hidden_support',lambda w,e:w.game.state.apply(PoliticalAction('hidden',{'immediate':{'Union':-19}})))
        world.clock.schedule(10,'hidden_support',{})
        world.run_until(until)
        rows=[h['release'] for h in world.services['poll_feedback'].history if 'release' in h]
        self.assertNotEqual(rows[1]['value_percent'],world.game.state.variables['Union'].value)
        self.assertFalse(rows[1]['measurement']['actual_survey'])

    def test_publication_snapshot_does_not_mutate_voter_response_or_observer(self):
        world,_=load(config());observer=world.game.event_observers[0]
        before=deepcopy(observer.to_dict());state=world.game.state.payload()
        one=observer.publication_snapshot(world.game.state,START)
        two=observer.publication_snapshot(world.game.state,START)
        self.assertEqual(one,two)
        self.assertEqual(before,observer.to_dict())
        self.assertEqual(state,world.game.state.payload())

    def test_series_cannot_mix_pollsters(self):
        raw=config();raw['poll_feedback']['releases'][1]['source']='different_house'
        with self.assertRaises(ValueError):load(raw)

    def test_successful_withdrawal_cannot_unlock_unbound_advance_dependency(self):
        raw=config();raw['poll_feedback']['releases']=[]
        node=next(n for n in raw['nodes'] if n['key']=='reform_agenda')
        node['actions']=node['actions'][:1];node['actions'][0]['choice']['key']='withdraw_proposal'
        raw['tasks'][0]['action_timing']={'withdraw_proposal':{'execution_minutes':100}}
        project=raw['poll_feedback']['projects'][0]
        project['tasks']=['reform'];project['task_action_roles']={'reform':{'withdraw_proposal':'withdraw'}}
        raw['tasks'].append({'key':'cleanup_by_completed_work','owner':'AA_staff','release':START,
            'deadline':raw['until'],'duration':10,'dependencies':['reform'],
            'dependency_outcomes':{'reform':'work_complete'},'effects':{'government_capacity':1}})
        world,until=load(raw);world.run_until(until)
        self.assertEqual(world.tasks['reform'].action_outcome,'SUCCEEDED')
        self.assertEqual(world.policy_projects['reform_project'].status,'WITHDRAWN')
        self.assertEqual(world.tasks['followup'].status,'BLOCKED')
        self.assertEqual(world.tasks['cleanup_by_completed_work'].status,'COMPLETED')

    def test_time_partition_does_not_change_decision_or_settlement(self):
        def run(sliced):
            world,until=load(config())
            with force_review('continue'):
                if sliced:
                    for minute in (8,15,22,40,80):world.run_until(world.clock.at(minute).isoformat())
                world.run_until(until)
            return world.tasks['reform'].finished,world.policy_projects['reform_project'].status
        self.assertEqual(run(False),run(True))

    def test_resume_committed_external_work_waits_for_original_procedure_window(self):
        raw=config();raw['tasks'][0]['requires_windows']=[['2026-10-19T09:00:00+02:00','2026-10-19T11:20:00+02:00']]
        for timing in raw['tasks'][0]['action_timing'].values():timing['attention_required']=False
        world,until=load(raw)
        with force_review('continue'):world.run_until(until)
        self.assertEqual(world.tasks['reform'].execution_started,60)
        self.assertEqual(world.tasks['reform'].finished,160)
        self.assertEqual(sum(world.capacities['Merz'].spent_by_day.values()),25)

    def test_review_at_preparation_completion_cannot_launch_external_work_early(self):
        raw=config();raw['poll_feedback']['releases'][1]=release('bad',10,10.)
        for timing in raw['tasks'][0]['action_timing'].values():timing['attention_required']=False
        world,until=load(raw)
        with force_review('pause'):world.run_until(until)
        self.assertEqual(world.tasks['reform'].status,'PAUSED')
        self.assertIsNone(world.tasks['reform'].finished)

    def test_protected_procedure_not_cancelled_directly_by_poll(self):
        raw=config();raw['poll_feedback']['projects'][0]['scope']='legislative'
        world,until=load(raw)
        node=world.game.nodes['reform_agenda']
        world.game.nodes[node.key]=replace(node,actions=tuple(replace(a,intent=Intent('x','Merz','dismiss_chancellor')) for a in node.actions))
        world.game.objective_check_engine=build_gg_check_engine()
        world.game.check_context_provider=lambda state:CheckContext(0,BundestagState(630),{}, {})
        world.run_until(until)
        self.assertNotEqual(world.policy_projects['reform_project'].status,'WITHDRAWN')

    def test_formal_withdrawal_waits_for_configured_objective_procedure(self):
        from hakoniwa.political_poll_feedback import PollFeedbackService
        from hakoniwa.checks.engine import CheckEngine,RuleRegistry
        from hakoniwa.checks.base import CompiledRule,CheckResult,CheckStatus
        for allowed in (False,True):
            raw=config();feedback=raw.pop('poll_feedback')
            feedback['projects'][0].update(scope='legislative',withdrawal_task='formal_withdrawal')
            node=deepcopy(next(n for n in raw['nodes'] if n['key']=='reform_agenda'))
            node['key']='formal_withdrawal_node';node['actions']=node['actions'][:1]
            node['actions'][0]['choice']['key']='formal_withdrawal'
            raw['nodes'].append(node)
            raw['tasks'].append({'key':'formal_withdrawal','owner':'Merz','release':START,
                'deadline':raw['until'],'duration':10,'node':'formal_withdrawal_node','activation':'conditional'})
            world,until=load(raw)
            n=world.game.nodes['formal_withdrawal_node']
            world.game.nodes[n.key]=replace(n,actions=tuple(replace(a,intent=Intent('withdrawal','Merz','withdraw_bill','reform_project')) for a in n.actions))
            # Explicit synthetic procedural rule: test the gate, not German law.
            rule=CompiledRule('SYNTHETIC_PROCEDURE',frozenset({'withdraw_bill'}),
                lambda ctx,intent,ok=allowed:CheckResult(CheckStatus.PASS if ok else CheckStatus.BLOCKED,'SYNTHETIC_PROCEDURE'),
                'synthetic test only','no claim about German law','1')
            world.game.objective_check_engine=CheckEngine({'test':RuleRegistry((rule,))})
            world.game.check_context_provider=lambda state:CheckContext(0,BundestagState(630),{}, {})
            world.services['poll_feedback']=PollFeedbackService(world,feedback)
            with force_review('withdraw'):
                world.run_until(world.clock.at(35).isoformat())
                self.assertEqual(world.policy_projects['reform_project'].status,'WITHDRAWAL_PENDING')
                self.assertEqual(world.tasks['reform'].status,'PAUSED')
                world.run_until(until)
            self.assertEqual(world.policy_projects['reform_project'].status,'WITHDRAWN' if allowed else 'PAUSED')
            self.assertEqual(world.tasks['reform'].status,'CANCELLED' if allowed else 'PAUSED')


if __name__=='__main__':unittest.main()
