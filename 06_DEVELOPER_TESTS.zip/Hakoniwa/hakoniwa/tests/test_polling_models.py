import copy
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import unittest

from hakoniwa.polling.model import BUNDLE, PollingModel, aggregate_groups, dynamic_choice, normalize
from hakoniwa.polling.observation import FieldworkObserver, publication_round
from hakoniwa.polling.electorates import ROOT, STATES, PARTIES, ElectorateAtlas, party_counts, read_csv
from hakoniwa.realtime_polling import RealtimePollingTracker, PollSeriesSpec
from hakoniwa.political_state import PoliticalState, StateVariable


class PollingModelTests(unittest.TestCase):
    def setUp(self):
        self.model=PollingModel()
        self.example=json.loads((BUNDLE/"examples/national_long.json").read_text())

    def test_reference_manifest_and_replay(self):
        self.assertTrue(self.model.verify()["valid"])
        self.assertAlmostEqual(sum(self.model.predict(self.example)["predicted_percent"]),100)

    def test_future_and_refit_leakage(self):
        for changes in ({"latest_predictor_date":self.example["published"]},
                        {"target_date":"2025-12-31","latest_predictor_date":"2025-12-30"}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                self.model.predict({**self.example,**changes})

    def test_party_order_and_missing_nonfinite(self):
        with self.assertRaises(ValueError):
            self.model.predict({**self.example,"party_order":list(reversed(self.example["party_order"]))})
        with self.assertRaises(ValueError): normalize([float("nan"),1])
        with self.assertRaises(ValueError): normalize([-1,3])
        with self.assertRaises(ValueError): normalize([0,0])

    def test_state_inference_matches_reference(self):
        params=json.loads((BUNDLE/self.model.spec["fitted_models"]["state_landtag"]["parameters"]).read_text())
        context={"model":"state_landtag","target":"LANDTAG_VOTE_INTENTION","state":"Bayern",
                 "target_date":"2026-10-22","latest_predictor_date":"2026-10-21",
                 "party_order":params["parties"],"baseline_percent":[28,15,13,4,10,25,5],"series":"unseen",
                 "national_momentum_clr":[.01]*7,"previous_state_residual_clr":[.02]*7,"log_gap":2.0}
        spec=importlib.util.spec_from_file_location("reference_polling",BUNDLE/"model.py")
        vendor=importlib.util.module_from_spec(spec);spec.loader.exec_module(vendor)
        result=self.model.predict(context)
        expected=vendor.fitted_prediction(context)
        for a,b in zip(result["predicted_percent"],expected["predicted_percent"]):self.assertAlmostEqual(a,b,places=10)
        self.assertEqual(result["predicted_percent"],self.model.predict({**context,"state":"BY"})["predicted_percent"])
        with self.assertRaises(ValueError): self.model.predict({**context,"target":"BUNDESTAG_VOTE_INTENTION"})

    def test_undecided_not_other_and_participation(self):
        result=aggregate_groups([100,100],[.5,1],[.5,1],[[1,0],[0,1]])
        self.assertEqual(result["conditional_party_probability"],[.2,.8])
        self.assertEqual(result["undecided_participant_mass"],25)
        self.assertEqual(result["nonparticipant_mass"],50)

    def test_no_baseline_double_counting_or_unavailable_party(self):
        zero=[0,0,0]
        self.assertEqual(dynamic_choice([.6,.4,0],zero,zero,zero,zero),[.6,.4,0])
        result=dynamic_choice([.6,.4,0],zero,[0,1,100],zero,zero)
        self.assertGreater(result[1],.4)
        self.assertEqual(result[2],0)


class ObservationTests(unittest.TestCase):
    def test_composition_rounding(self):
        values=publication_round([1,1,1],.5)
        self.assertEqual(sum(values),100)
        self.assertEqual(values,[33.5,33.5,33.0])
        with self.assertRaises(ValueError): publication_round([1,1],.3)

    def test_time_not_number_of_events(self):
        def trajectory(subdivide):
            observer=FieldworkObserver(["A","Other"],window_minutes=120)
            t=datetime(2026,10,1,tzinfo=timezone.utc)
            observer.observe(t,[40,60])
            if subdivide:
                for m in range(1,60): observer.observe(t+timedelta(minutes=m),[40,60])
            observer.observe(t+timedelta(minutes=60),[60,40])
            return observer.observe(t+timedelta(minutes=120),[60,40])
        a,b=trajectory(False),trajectory(True)
        self.assertEqual(a["fieldwork_mean_percent"],b["fieldwork_mean_percent"])
        self.assertAlmostEqual(a["fieldwork_mean_percent"][0],50)
        self.assertEqual(a["coverage_fraction"],1)

    def test_zero_elapsed_time_does_not_instantly_poll_new_support(self):
        o=FieldworkObserver(["A","B"],window_minutes=60)
        o.observe("2026-10-01T00:00:00+00:00",[40,60])
        result=o.observe("2026-10-01T01:00:00+00:00",[60,40])
        self.assertEqual(result["published_model_percent"],[40,60])
        result=o.observe("2026-10-01T02:00:00+00:00",[60,40])
        self.assertEqual(result["published_model_percent"],[60,40])

    def test_partial_history_and_invalid_times(self):
        o=FieldworkObserver(["A","B"],window_minutes=60)
        self.assertEqual(o.observe("2026-10-01T00:00:00+00:00",[1,1])["coverage_fraction"],0)
        self.assertEqual(o.observe("2026-10-01T00:30:00+00:00",[1,1])["coverage_fraction"],.5)
        with self.assertRaises(ValueError): o.observe("2026-09-30T00:30:00+00:00",[1,1])
        with self.assertRaises(ValueError): o.observe("2026-10-01T00:30:00",[1,1])

    def test_tracker_composition_and_no_world_mutation(self):
        state=PoliticalState({"a":StateVariable("a",40),"other":StateVariable("other",60)},{},{})
        specs=tuple(PollSeriesSpec(v,v,"electorate","vote_intention","DE") for v in ("a","other"))
        tracker=RealtimePollingTracker("r","e",specs,"2026-10-01T00:00:00+00:00",
            {"x":"2026-10-01T01:00:00+00:00"},composition_groups=({"key":"DE","variables":["a","other"],
            "complete_party_universe":True,"window_minutes":60},))
        tracker.record_baseline(state)
        state.variables["a"]=StateVariable("a",60);state.variables["other"]=StateVariable("other",40)
        tracker.record(state,event_id="x",actor="test",action="test",event_kind="test")
        snapshot=tracker.to_dict()["composition_measurements"][-1]
        self.assertEqual(snapshot["published_model_percent"],[40,60])
        self.assertEqual(state.variables["a"].value,60)
        state.variables["other"]=StateVariable("other",20)
        with self.assertRaises(ValueError): tracker.record(state,event_id="x",actor="test",action="test",event_kind="test")


class ElectorateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.atlas=ElectorateAtlas();cls.data=cls.atlas.data

    def test_sixteen_states_and_full_joint_cohorts(self):
        self.assertEqual(set(self.data["regions"]),set(STATES)|{"Bund"})
        for code in STATES:
            region=self.data["regions"][code]
            self.assertEqual(len(region["parties"]),len(PARTIES))
            joint=[g for g in region["groups"] if g["sex"]!="Summe" and g["cohort"]!="Summe"]
            self.assertEqual(len(joint),12)
            for g in joint:
                self.assertAlmostEqual(sum(v for v in g["counts"].values() if v is not None),g["valid_votes_weighted"],delta=4)

    def test_official_national_cross_check(self):
        groups=self.data["regions"]["Bund"]["groups"]
        young=next(g for g in groups if g["sex"]=="Summe" and g["age_2025"]=="18–24")
        old=next(g for g in groups if g["sex"]=="Summe" and g["age_2025"]=="70+")
        self.assertAlmostEqual(young["support_percent"]["Linke"],27.3,delta=.05)
        self.assertAlmostEqual(old["support_percent"]["Union"],41.4,delta=.05)

    def test_subsets_and_source_hashes(self):
        for filename,note in self.data["source_notes"].items():
            self.assertEqual(sha256((ROOT/"raw"/filename).read_bytes()).hexdigest(),note["sha256"])
        row=read_csv(ROOT/"raw/btw25_rws_bst2.csv")[0]
        counts=party_counts(row)
        self.assertAlmostEqual(counts["Other"]+(counts["BSW"] or 0)+(counts["Freie Wähler"] or 0),float(row["Sonstige"]))

    def test_historical_cutoff_and_target(self):
        with self.assertRaises(ValueError):self.atlas.state("NW",as_of="2025-06-22")
        with self.assertRaises(ValueError):self.atlas.state("NW",as_of="2026-07-31",target="LANDTAG_VOTE_INTENTION")
        self.assertEqual(self.atlas.state("BY",as_of="2026-07-31")["parties"]["Union"]["standing_party"],"CSU")

    def test_ecology_covers_all_districts_but_not_small_states(self):
        self.assertEqual(len(self.data["ecology"]["districts"]),299)
        self.assertIsNone(self.data["ecology"]["within_state"]["Bremen"]["AfD"]["density_2023_log1p"]["r"])

    def test_yougov_denominators_and_scope(self):
        source=json.loads((ROOT/"yougov_2026_10.json").read_text())
        total=source["groups"]["total"]
        self.assertEqual(source["sample_size_all_respondents"],2202)
        self.assertEqual(total["unweighted_base_netto"],1773)
        self.assertEqual(total["support_percent"]["AfD"],28)
        self.assertEqual(source["groups"]["age:40-49"]["support_percent"]["AfD"],38)
        self.assertIsNone(source["groups"]["recall_2025:AfD"]["support_percent"]["Grüne"])
        self.assertEqual(source["available_from"],"2026-10-20")
        self.assertFalse(any(k in source["groups"] for k in STATES))


if __name__ == "__main__":unittest.main()
