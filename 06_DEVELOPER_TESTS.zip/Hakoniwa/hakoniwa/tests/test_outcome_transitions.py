"""Outcome branches must not inherit conditional successes from the proposal."""
from pathlib import Path
import unittest

from hakoniwa.decision_space import (
    DecisionEvent, DecisionSpaceGenerator, ResolvedOutcome, StrategyEffectModel,
    OutcomeTransition,
)
from hakoniwa.information_filter import InformationFilter
from hakoniwa.persona_v2 import ActionOption, FreeAgentDecisionEngine
from hakoniwa.free_agent_game import WorldAction
from hakoniwa.political_state import PoliticalAction, PoliticalState, StateVariable
from hakoniwa.scenario_reporting import ScenarioReportingPolicy
from hakoniwa.simulation_orchestrator import (
    LayeredConfiguration, LayeredSimulationOrchestrator, SimulationNodeV3,
)

ROOT=Path(__file__).resolve().parents[1]


def base():
    return PoliticalAction("attempt",{"immediate":{"x":10}},
        locks_add=("bill_adopted",),locks_remove=("proposal_pending",),
        closes_actions=("alternative",),opens_actions=("implementation",),next_node="success_next")


def branches(model=None):
    action=base()
    return {b.key:b for b in DecisionSpaceGenerator._outcomes(
        action.key,action,.500,.500,model or StrategyEffectModel(action.effects))}


class ForceBranch:
    def __init__(self,branch):self.branch=branch

    def resolve(self,action):
        b=next(b for b in action.outcome_branches if b.key==self.branch)
        return ResolvedOutcome(action.world_action.choice.key,b.key,b.conditional_weight,
            b.success_level,b.world_action,False,
            sum(x.conditional_weight*x.success_level for x in action.outcome_branches))


class OutcomeTransitionTests(unittest.TestCase):
    def test_failure_does_not_inherit_success_state_changes(self):
        action=branches()["failure"].world_action
        self.assertEqual(action.locks_add,())
        self.assertEqual(action.locks_remove,())
        self.assertEqual(action.closes_actions,())
        self.assertEqual(action.opens_actions,())
        self.assertIsNone(action.next_node)

    def test_partial_success_does_not_implicitly_adopt_whole_bill(self):
        action=branches()["partial_success"].world_action
        self.assertEqual(action.locks_add,())
        self.assertIsNone(action.next_node)
        self.assertEqual(action.effects["immediate"]["x"],4.5)

    def test_success_keeps_existing_declared_transition(self):
        action=branches()["success"].world_action
        for name in ("locks_add","locks_remove","closes_actions","opens_actions","next_node"):
            self.assertEqual(getattr(action,name),getattr(base(),name))

    def test_failure_can_explicitly_continue_to_recovery(self):
        model=StrategyEffectModel(base().effects,outcome_transitions={
            "failure":OutcomeTransition(next_node="regroup",locks_add=("negotiation_failed",))})
        action=branches(model)["failure"].world_action
        self.assertEqual(action.next_node,"regroup")
        self.assertEqual(action.locks_add,("negotiation_failed",))
        self.assertEqual(action.locks_remove,())
        self.assertNotIn("bill_adopted",action.locks_add)

    def test_partial_transition_is_discrete_and_not_fractional(self):
        model=StrategyEffectModel(base().effects,outcome_transitions={
            "partial_success":OutcomeTransition(next_node="committee",locks_add=("limited_agreement",))})
        action=branches(model)["partial_success"].world_action
        self.assertEqual(action.locks_add,("limited_agreement",))
        self.assertEqual(action.next_node,"committee")
        self.assertEqual(action.effects["immediate"]["x"],4.5)

    def test_json_transition_and_typed_transition_match(self):
        typed=StrategyEffectModel(base().effects,outcome_transitions={"failure":OutcomeTransition(next_node="regroup")})
        raw=StrategyEffectModel(base().effects,outcome_transitions={"failure":{"next_node":"regroup"}})
        self.assertEqual(branches(typed),branches(raw))

    def test_typo_or_conflicting_transitions_are_rejected(self):
        for value in ({"sucess":{}},{"failure":{"next_nod":"regroup"}}, {"failure":None},
                      {"failure":{"locks_add":["x"],"locks_remove":["x"]}},
                      {"failure":{"closes_actions":["x"],"opens_actions":["x"]}},
                      {"failure":{"locks_add":"x"}}):
            with self.subTest(value=value),self.assertRaises(ValueError):
                StrategyEffectModel(base().effects,outcome_transitions=value)

    def test_success_can_explicitly_override_legacy_success_route(self):
        model=StrategyEffectModel(base().effects,outcome_transitions={"success":OutcomeTransition()})
        action=branches(model)["success"].world_action
        self.assertIsNone(action.next_node)
        self.assertEqual(action.locks_add,())

    def test_failed_branch_leaves_existing_pending_lock_in_world(self):
        state=PoliticalState({"x":StateVariable("x",50)},{},{},locks={"proposal_pending"})
        state.apply(branches()["failure"].world_action)
        self.assertEqual(state.locks,{"proposal_pending"})
        self.assertEqual(state.closed_actions,set())
        self.assertEqual(state.variables["x"].value,50)

    def run_generated(self,branch,transitions=None):
        event=DecisionEvent("vote_warning","party",("votes","coalition"),.500,.500,
            {"private_negotiation":StrategyEffectModel({"immediate":{"x":10}},next_node="success_next",
                outcome_transitions=transitions or {})},
            allowed_strategy_keys=("private_negotiation",))
        after=WorldAction(PoliticalAction("after_success",{"immediate":{"x":20}}),ActionOption("after_success"))
        recover=WorldAction(PoliticalAction("regroup",{"immediate":{}}),ActionOption("regroup"))
        game=LayeredSimulationOrchestrator(
            PoliticalState({"x":StateVariable("x",50)},{},{}),
            {"start":SimulationNodeV3("start","Merz",(),decision_event=event),
             "success_next":SimulationNodeV3("success_next","Merz",(after,)),
             "recovery_next":SimulationNodeV3("recovery_next","Merz",(recover,))},
            FreeAgentDecisionEngine.from_json(ROOT/"data/personas/cards_pss.json"),
            InformationFilter({"Merz":{}},delivery_only=True),{},
            LayeredConfiguration.from_environment_json(ROOT/"data/environments/2026-07-31/environment.json"),
            decision_generator=DecisionSpaceGenerator(),outcome_resolver=ForceBranch(branch),
            reporting_policy=ScenarioReportingPolicy.diagnostics_only())
        return game.run("start")

    def test_full_orchestrator_does_not_visit_success_node_on_failure(self):
        result=self.run_generated("failure")
        self.assertEqual([n["node"] for n in result["trace"]],["start"])
        self.assertEqual(result["world_state"]["variables"]["x"]["value"],50)

    def test_full_orchestrator_still_visits_success_node_after_success(self):
        result=self.run_generated("success")
        self.assertEqual([n["node"] for n in result["trace"]],["start","success_next"])

    def test_failure_can_reach_explicit_recovery_without_success_effects(self):
        result=self.run_generated("failure",{"failure":OutcomeTransition(next_node="recovery_next")})
        self.assertEqual([n["node"] for n in result["trace"]],["start","recovery_next"])
        self.assertEqual(result["world_state"]["variables"]["x"]["value"],50)

    def test_generator_and_resolver_trace_include_realized_branch_structure(self):
        result=self.run_generated("failure",{"failure":OutcomeTransition(locks_add=("failed",))})
        outcome=result["trace"][0]["operational_feedback"]["outcome_branch"]
        self.assertEqual(outcome["structural_transition"]["locks_add"],["failed"])
        self.assertIsNone(outcome["structural_transition"]["next_node"])
        self.assertEqual(result["world_state"]["locks"],["failed"])


if __name__=="__main__":unittest.main()
