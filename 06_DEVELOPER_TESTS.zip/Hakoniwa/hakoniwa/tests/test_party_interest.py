import unittest
from pathlib import Path

from hakoniwa.party_interest import PartyInterestEngine, PartyState
from hakoniwa.persona_v2 import ActionOption


ROOT = Path(__file__).resolve().parents[1]
PROFILES = ROOT / "data" / "parties" / "party_interest_profiles.json"


def crisis_actions():
    return (
        ActionOption(
            "bounded_collective_defence",
            objective_feasibility=0.820,
            issue_positions={
                "ukraine_support": 0.750,
                "nato_collective_defence": 0.950,
                "russia_sanctions": 0.700,
                "defence_spending": 0.650,
                "military_escalation": -0.150,
            },
            party_interest_impacts={
                "national_security": 0.750,
                "alliance_reliability": 0.800,
                "ceasefire_diplomacy": 0.100,
                "anti_militarization": -0.550,
                "russia_normalization": -0.650,
            },
            party_strategy_impacts={
                "government_stability": 0.650,
                "coalition_reliability": 0.600,
                "opposition_differentiation": 0.150,
            },
        ),
        ActionOption(
            "maximal_escalation",
            objective_feasibility=0.550,
            issue_positions={
                "ukraine_support": 1.000,
                "nato_collective_defence": 1.000,
                "russia_sanctions": 1.000,
                "defence_spending": 1.000,
                "military_escalation": 0.950,
            },
            party_interest_impacts={
                "national_security": 0.250,
                "alliance_reliability": 0.300,
                "ceasefire_diplomacy": -0.950,
                "anti_militarization": -1.000,
                "russia_normalization": -1.000,
            },
            party_strategy_impacts={
                "government_stability": -0.500,
                "coalition_reliability": -0.250,
                "opposition_differentiation": 0.700,
            },
        ),
        ActionOption(
            "immediate_ceasefire_line",
            objective_feasibility=0.700,
            issue_positions={
                "ukraine_support": -0.750,
                "nato_collective_defence": -0.400,
                "russia_sanctions": -0.900,
                "defence_spending": -0.850,
                "military_escalation": -1.000,
            },
            party_interest_impacts={
                "national_security": -0.550,
                "alliance_reliability": -0.650,
                "ceasefire_diplomacy": 0.950,
                "anti_militarization": 0.950,
                "russia_normalization": 0.850,
            },
            party_strategy_impacts={
                "government_stability": -0.300,
                "coalition_reliability": -0.500,
                "opposition_differentiation": 0.850,
            },
        ),
    )


class PartyInterestTests(unittest.TestCase):
    def setUp(self):
        self.engine = PartyInterestEngine.from_json(PROFILES)

    def test_all_collective_parties_load_without_persona_cards(self):
        self.assertEqual(
            set(self.engine.profiles),
            {"CDU_CSU", "SPD", "GRUENE", "AFD", "LINKE", "BSW", "FDP"},
        )

    def test_crisis_menu_has_real_party_divergence(self):
        actions = crisis_actions()
        self.assertEqual(self.engine.decide("CDU_CSU", actions).chosen_action, "bounded_collective_defence")
        self.assertEqual(self.engine.decide("GRUENE", actions).chosen_action, "bounded_collective_defence")
        self.assertEqual(self.engine.decide("BSW", actions).chosen_action, "immediate_ceasefire_line")
        self.assertEqual(self.engine.decide("LINKE", actions).chosen_action, "immediate_ceasefire_line")

    def test_menu_order_does_not_define_the_winner(self):
        actions = crisis_actions()
        forward = self.engine.decide("CDU_CSU", actions).chosen_action
        reverse = self.engine.decide("CDU_CSU", tuple(reversed(actions))).chosen_action
        self.assertEqual(forward, reverse)

    def test_union_overlay_zero_weight_is_exact_compatibility(self):
        actions = crisis_actions()
        rows = {action.key: self.engine.evaluate("CDU_CSU", action) for action in actions}
        individual = {action.key: value for action, value in zip(actions, (0.610, 0.720, 0.450))}
        self.assertEqual(self.engine.overlay(individual, rows, 0.000), individual)

    def test_current_role_changes_strategy_not_programme(self):
        action = crisis_actions()[0]
        government = self.engine.evaluate(
            "SPD", action, state=PartyState(government_responsibility=1.000, coalition_dependency=0.900)
        )
        opposition = self.engine.evaluate(
            "SPD", action, state=PartyState(government_responsibility=0.000, electoral_pressure=0.900)
        )
        self.assertEqual(government.programmatic_score, opposition.programmatic_score)
        self.assertNotEqual(government.collective_score, opposition.collective_score)

    def test_missing_action_metrics_are_visible_not_silently_filled(self):
        row = self.engine.evaluate("FDP", ActionOption("empty"))
        self.assertEqual(row.common_interest_score, 0.500)
        self.assertEqual(row.organizational_survival_score, 0.500)
        self.assertTrue(row.diagnostics["missing_interest_impacts"])
        self.assertTrue(row.diagnostics["missing_organizational_impacts"])

    def test_non_programmatic_scandal_uses_organizational_survival_track(self):
        denial = ActionOption(
            "deny",
            organizational_impacts={
                "organizational_survival": -0.6,
                "legal_operability": -0.9,
                "electoral_viability": -0.5,
                "reputation_protection": -0.8,
                "internal_cohesion": 0.5,
                "leadership_continuity": 0.6,
                "information_control": -0.4,
            },
        )
        audit = ActionOption(
            "audit",
            organizational_impacts={
                "organizational_survival": 0.7,
                "legal_operability": 0.9,
                "electoral_viability": 0.2,
                "reputation_protection": 0.7,
                "internal_cohesion": -0.2,
                "leadership_continuity": -0.4,
                "information_control": 0.2,
            },
        )
        state = PartyState(organizational_threat=.9, legal_exposure=.9, reputation_pressure=.9)
        decision = self.engine.decide("AFD", (denial, audit), state=state)
        self.assertEqual(decision.chosen_action, "audit")
        row = decision.evaluations["audit"]
        self.assertEqual(row.programmatic_score, .5)
        self.assertEqual(row.diagnostics["programmatic_applicability"], "NOT_APPLICABLE_NON_PROGRAMMATIC_EVENT")
        self.assertEqual(row.diagnostics["event_fit_classification"], "ORGANIZATIONAL")


if __name__ == "__main__":
    unittest.main()
