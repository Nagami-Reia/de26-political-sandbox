from dataclasses import replace, asdict
import tempfile
import json
from pathlib import Path
import unittest

from hakoniwa.organizational_response import (
    OrganizationalBloc, PoliticalOrganization, OrganizationalRequest, OrganizationalResponseEngine,
)
from hakoniwa.scenarios.kfrage_2024_blind_replay.run_scenario import Replay, Scenario
from hakoniwa.living_world import Task, LivingPoliticalWorld, Capacity
from hakoniwa.living_world_config import load_living_world
from hakoniwa.world_clock import WorldClock
from hakoniwa.political_state import PoliticalAction


def engine(support=.2, rate=.5, capacity=1.0, *, seed=7, sigma=0.0):
    bloc = OrganizationalBloc("bloc", 1.0, {"A":support,"B":1-support}, {"fit":1.0},
                              {"Merz":1.0}, rate)
    return OrganizationalResponseEngine({"org":PoliticalOrganization("org", (bloc,),
        decision_capacity=capacity)}, seed=seed, contingency_sigma=sigma)


def request(identity="r", target="A", feature=1.0, effort=1.0, delay=60):
    return OrganizationalRequest(identity,"org","Merz",target,effort,delay,{"fit":feature})


class RecipientResponseTests(unittest.TestCase):
    def test_submit_changes_neither_support_nor_alignment(self):
        e=engine();before=e.payload()["organizations"]
        self.assertEqual(e.submit(request(),0)["status"],"PENDING")
        self.assertEqual(e.payload()["organizations"],before)
        self.assertEqual(e.advance_to(59),[])

    def test_acceptance_requires_recipient_support(self):
        e=engine(rate=1.0);e.submit(request(),0);r=e.advance_to(60)[0]
        self.assertEqual(r.status,"ACCEPTED");self.assertEqual(r.alignment_after,"A")
        self.assertEqual(r.realization_fraction,1.0)

    def test_partial_success_is_not_an_adopted_endorsement(self):
        e=engine(support=.4,rate=.25);e.submit(request(),0);r=e.advance_to(60)[0]
        self.assertEqual(r.status,"PARTIAL");self.assertIsNone(r.alignment_after)
        self.assertGreater(r.realization_fraction,0);self.assertLess(r.realization_fraction,1)

    def test_unfavourable_recipient_can_refuse_and_choose_other_candidate(self):
        e=engine();e.submit(request(feature=-1),0);r=e.advance_to(60)[0]
        self.assertEqual(r.status,"REJECTED");self.assertEqual(r.realization_fraction,0)
        self.assertLess(r.support_after["A"],r.support_before["A"])
        self.assertEqual(r.alignment_after,"B")

    def test_lack_of_capacity_defers_without_inventing_failure_or_support(self):
        e=engine(capacity=0);e.submit(request(),0);r=e.advance_to(60)[0]
        self.assertEqual(r.status,"DEFERRED");self.assertEqual(r.support_after,r.support_before)
        self.assertEqual(r.realization_fraction,0)

    def test_different_blocs_can_disagree_and_support_mass_is_conserved(self):
        org=PoliticalOrganization("org",(
            OrganizationalBloc("one",.5,{"A":.4,"B":.6},{"fit":1.0},{"Merz":1.0},.5),
            OrganizationalBloc("two",.5,{"A":.4,"B":.6},{"opposing_fit":1.0},{"Merz":1.0},.5)))
        e=OrganizationalResponseEngine({"org":org})
        e.submit(replace(request(),features={"fit":1.0,"opposing_fit":-1.0}),0)
        r=e.advance_to(60)[0]
        self.assertGreater(r.bloc_responses[0]["influence"],0)
        self.assertLess(r.bloc_responses[1]["influence"],0)
        self.assertAlmostEqual(sum(r.support_after.values()),1.0)

    def test_response_is_settled_exactly_once_and_submit_is_idempotent(self):
        e=engine();q=request();e.submit(q,0);e.submit(q,0)
        self.assertEqual(len(e.advance_to(60)),1)
        before=e.organizations["org"].support()
        self.assertEqual(e.advance_to(600),[])
        e.submit(q,600)
        self.assertEqual(e.advance_to(600),[])
        self.assertEqual(e.organizations["org"].support(),before)

    def test_request_id_cannot_be_reused_for_another_target(self):
        e=engine();e.submit(request(),0)
        with self.assertRaises(ValueError):e.submit(request(target="B"),0)

    def test_simultaneous_conflicts_have_no_queue_order_winner(self):
        results=[]
        for order in (("A","B"),("B","A")):
            e=engine();before=e.organizations["org"].support()
            for target in order:e.submit(request(target,target),0)
            rows=e.advance_to(60)
            self.assertTrue(all(r.status=="CONTESTED" for r in rows))
            self.assertEqual(e.organizations["org"].support(),before)
            results.append(e.organizations["org"].alignment)
        self.assertEqual(*results)

    def test_recipient_uses_response_time_context_not_actor_score(self):
        e=engine();e.submit(request(feature=1),0)
        r=e.advance_to(60,lambda req:{"fit":-1.0})[0]
        self.assertEqual(r.status,"REJECTED")

    def test_same_seed_replays_contingency(self):
        a,b=engine(sigma=.2),engine(sigma=.2)
        a.submit(request(),0);b.submit(request(),0)
        self.assertEqual(a.advance_to(60),b.advance_to(60))

    def test_invalid_support_and_backwards_time_fail(self):
        with self.assertRaises(ValueError):
            OrganizationalBloc("bad",1.0,{"A":.8,"B":.8},{"fit":1.0})
        e=engine();e.advance_to(60)
        with self.assertRaises(ValueError):e.advance_to(59)


FIXTURE=Path(__file__).resolve().parents[1]/"examples/living_world.json"
START="2026-10-19T08:00:00+02:00"


def build_world(rate=1.0, capacity=1.0):
    original,_=load_living_world(FIXTURE)
    game=original.game
    node=game.nodes["security_coordination"];a=node.actions[0]
    game.organizations=engine(support=.4,rate=rate,capacity=capacity)
    q=request(delay=60)
    world_action=replace(a,world=PoliticalAction(a.world.key,{"immediate":{}}),
        organization_request=q,organization_effects={"coordination_quality":10},
        actor_events={},actor_outcomes={})
    game.nodes["org_request"]=replace(node,key="org_request",actions=(world_action,))
    parent=Task("parent","Merz",0,240,10,node="org_request")
    child=Task("child","staff",0,240,10,dependencies=("parent",),effects={"government_capacity":1})
    w=LivingPoliticalWorld(game,WorldClock(START),{"Merz":Capacity(),"staff":Capacity()},[parent,child])
    return w,parent,child


class WorldResponseIntegrationTests(unittest.TestCase):
    def test_pending_work_cannot_award_goal_or_unlock_success_dependency(self):
        w,parent,child=build_world()
        before=w.game.state.variables["coordination_quality"].value
        confidence=w.game.personas.runtime["Merz"].state.confidence
        w.run_until(w.clock.at(69).isoformat())
        self.assertEqual(parent.work_status,"COMPLETED")
        self.assertEqual(parent.action_outcome,"PENDING_RESPONSE")
        self.assertEqual(w.game.state.variables["coordination_quality"].value,before)
        self.assertEqual(w.game.personas.runtime["Merz"].state.confidence,confidence)
        self.assertIsNone(child.started)
        w.run_until(w.clock.at(100).isoformat())
        self.assertEqual(parent.action_outcome,"SUCCEEDED")
        self.assertEqual(w.game.state.variables["coordination_quality"].value,before+10)
        self.assertEqual(child.status,"COMPLETED")
        self.assertEqual(child.started,70)

    def test_partial_response_cannot_award_full_effect(self):
        w,parent,child=build_world(rate=.25)
        before=w.game.state.variables["coordination_quality"].value
        w.run_until(w.clock.at(100).isoformat())
        self.assertEqual(parent.action_outcome,"PARTIAL")
        self.assertGreater(w.game.state.variables["coordination_quality"].value,before)
        self.assertLess(w.game.state.variables["coordination_quality"].value,before+10)
        self.assertIsNone(child.started)

    def test_zero_capacity_keeps_goal_pending_without_pss_victory(self):
        w,parent,child=build_world(capacity=0)
        before=w.game.state.variables["coordination_quality"].value
        confidence=w.game.personas.runtime["Merz"].state.confidence
        w.run_until(w.clock.at(100).isoformat())
        self.assertEqual(parent.action_outcome,"PENDING_RESPONSE")
        self.assertEqual(w.game.state.variables["coordination_quality"].value,before)
        self.assertEqual(w.game.personas.runtime["Merz"].state.confidence,confidence)
        self.assertIsNone(child.started)

    def test_clock_partition_does_not_change_result(self):
        a,_,_=build_world();b,_,_=build_world()
        a.run_until(a.clock.at(100).isoformat())
        for minute in (5,25,69,71,100):b.run_until(b.clock.at(minute).isoformat())
        self.assertEqual(a.game.organizations.payload(),b.game.organizations.payload())
        self.assertEqual(a.game.state.payload(),b.game.state.payload())


class KfrageRecipientRegressionTests(unittest.TestCase):
    def test_personal_endorsement_does_not_immediately_move_nrw(self):
        r=Replay(Scenario());r.decide("wuest_choice","Wuest",{"preserve_influence":.88})
        self.assertEqual(r.world.alignments["NRW_CDU"],"Uncommitted")
        self.assertTrue(any(row["status"]=="PENDING" for row in r.organizations.requests.values()))
        self.assertFalse(r.world.flags["wuest_active"])

    def test_unsettled_organizations_prevent_invented_joint_closure(self):
        r=Replay(Scenario());r.world.flags.update(wuest_active=False,soeder_conceded=True)
        r.world.values.update(merz_viability=1,merz_fraktion=1,merz_cdu_elite=1,union_unity=1,closure_clarity=1)
        self.assertIsNone(r.resolve_closure()["candidate"])
        self.assertIn("PARTY_ENDORSEMENTS_UNRESOLVED",r.resolve_closure()["blocking_conditions"])

    def test_joint_chair_proposal_does_not_require_or_imply_formal_party_approval(self):
        r=Replay(Scenario())
        r.key_actions.update(merz_final="assert_candidacy_in_bilateral_settlement",
                             soeder_final="bilateral_close_for_merz")
        closure=r.resolve_closure()
        self.assertEqual(closure["candidate"],"Merz")
        self.assertIsNone(closure["organizational_support_closure"])
        self.assertEqual(closure["formal_nomination"]["status"],"NOT_MODELED")
        self.assertIsNone(closure["formal_nomination"]["candidate"])

    def test_frozen_fixture_gains_and_curves_only_at_response_steps(self):
        p=Replay(Scenario()).run()
        events=[row for row in p["trace"] if row.get("event_kind")=="organizational_response"]
        self.assertTrue(events)
        self.assertEqual(len(p["pss_pressure"]),len(p["trace"])+1)
        self.assertEqual(len(p["polling"]),len(p["trace"])+1)
        self.assertTrue(all(row["organization_response"]["resolved_at"]>=row["organization_response"]["due_at"] for row in events))


if __name__=="__main__":unittest.main()
