import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

from hakoniwa.plugins.polling import PollingPlugin
from hakoniwa.plugins.polling.tracker import PollSeriesSpec
from hakoniwa.plugins.polling.party_response import PARTIES
from hakoniwa.plugins.polling.narrative_response import NarrativeVoterBridge
from hakoniwa.political_state import PoliticalState, StateVariable
from hakoniwa.living_world_config import load_living_world


class PollingPluginTests(unittest.TestCase):
    def fixture(self):
        state=PoliticalState({p:StateVariable(p,v) for p,v in zip(PARTIES,(18,14,16,5,10,28,3,6))},{},{})
        specs=tuple(PollSeriesSpec(p,p,"electorate","vote_intention","DE") for p in PARTIES)
        plugin=PollingPlugin("test","test",specs,"2026-10-22T00:00:00+02:00",bindings={p:p for p in PARTIES},
            window_minutes=60,timestamp_by_event_id={"shock":"2026-10-22T01:00:00+02:00","later":"2026-10-22T02:00:00+02:00"})
        return state,plugin

    def response(self):return {"evidence_status":"SIMULATION_ASSUMPTION","source_notes":["Synthetic test, not empirically estimated effect"],
        "group_changes":[{"selector":{"cohorts":["<=1955"]},"party_signals":{"Union":{"delta_competence":-.1}}}]}

    def test_response_precedes_measurement_with_fieldwork_lag(self):
        state,plugin=self.fixture();plugin.record_baseline(state)
        plugin.record(state,event_id="shock",actor="world",action="test",event_kind="test",
            resource_changes={"electorate_response":self.response()})
        self.assertLess(state.variables["Union"].value,18)
        after=plugin.to_dict()
        first_measurement=after["composition_measurements"][-1]
        self.assertAlmostEqual(first_measurement["latent_percent"][0],state.variables["Union"].value)
        self.assertEqual(first_measurement["published_model_percent"][0],18)
        plugin.record(state,event_id="later",actor="world",action="wait",event_kind="test")
        later=plugin.to_dict()["composition_measurements"][-1]
        self.assertLess(later["published_model_percent"][0],18)
        self.assertEqual(len(plugin.telemetry.events),2)
        self.assertEqual(len(plugin.telemetry.points),3*8*2)
        self.assertIn("before",state.history[-1]);self.assertIn("after",state.history[-1])

    def test_no_new_evidence_no_forced_change_and_duplicates_blocked(self):
        state,plugin=self.fixture();plugin.record_baseline(state)
        plugin.record(state,event_id="shock",actor="world",action="test",event_kind="test")
        self.assertTrue(all(abs(v)<1e-10 for v in plugin.voter_response_history[-1]["node_delta_pp"].values()))
        with self.assertRaises(ValueError):plugin.record(state,event_id="shock",actor="world",action="test",event_kind="test")

    def test_direct_support_bypass_is_rejected(self):
        state,plugin=self.fixture();plugin.record_baseline(state)
        state.variables["Union"]=StateVariable("Union",19)
        with self.assertRaises(ValueError):plugin.record(state,event_id="shock",actor="world",action="test",event_kind="test")

    def test_legacy_imports_point_to_one_implementation(self):
        from hakoniwa.realtime_polling import RealtimePollingTracker as old
        from hakoniwa.plugins.polling.tracker import RealtimePollingTracker as new
        self.assertIs(old,new)

    def test_narrative_bridge_uses_adoption_and_strength_not_fixed_points(self):
        bridge=NarrativeVoterBridge({"status":"SIMULATION_ASSUMPTION","rationale":"test","delay_minutes":60,
            "overlap_policy":"explicit_additive_assumption","audience_selectors":{"older":{"cohorts":["<=1955"]}},
            "frame_party_signals":{"failure":{"Union":{"delta_competence":-.1}}}})
        outcome=SimpleNamespace(audience_results=[SimpleNamespace(audience="older",frame_shares={"failure":.5},response_strength=.4)])
        event=bridge.build_event(outcome)
        self.assertAlmostEqual(event["group_changes"][0]["party_signals"]["Union"]["delta_competence"],-.02)

    def test_living_world_hook_and_same_node_provenance(self):
        initial=dict(zip(PARTIES,(18,14,16,5,10,28,3,6)))
        raw={"schema_version":"living-world-config-1.0","start":"2026-10-22T00:00:00+02:00",
            "until":"2026-10-22T03:00:00+02:00","variables":{**initial,"pressure":40},"poll_variables":list(PARTIES),
            "polling_plugin":{"enabled":True,"bindings":{p:p for p in PARTIES},"window_minutes":60,
                "response_by_event_id":{"living:1:information_delivered":self.response()}},
            "events":[{"key":"test_news","at":"2026-10-22T01:00:00+02:00","effects":{"pressure":5}}]}
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/"input.json";path.write_text(json.dumps(raw))
            world,until=load_living_world(path)
            payload=world.run_until(until)
            self.assertTrue(payload["scenario_report"]["valid"])
            self.assertLess(payload["world_state"]["variables"]["Union"]["value"],18)
            self.assertTrue(any(p["variable"]=="Union" for p in payload["trace"][0]["details"]["provenance_updates"]))
            tracker=world.game.event_observers[0]
            tracker.export(Path(temp)/"polling")
            self.assertTrue((Path(temp)/"polling/report.html").is_file())
            self.assertNotIn("voter_response_history",(Path(temp)/"polling/report_trace.json").read_text())


if __name__ == "__main__":unittest.main()
