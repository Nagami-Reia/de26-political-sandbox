"""Verify that the shared environment drives mechanisms rather than a preset plot."""
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import tempfile
import unittest

from hakoniwa.cli import main
from hakoniwa.living_world_config import load_living_world
from hakoniwa.world_environment import DEFAULT_ENVIRONMENT, WorldEnvironment, SchedulingRules


ROOT = Path(__file__).resolve().parents[1]
INPUTS = ROOT/"examples/shared_world_inputs.json"


class SharedEnvironmentTests(unittest.TestCase):
    def inputs(self):
        return json.loads(INPUTS.read_text(encoding="utf-8"))

    def load(self, inputs):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/"inputs.json"
            path.write_text(json.dumps(inputs), encoding="utf-8")
            return load_living_world(path, environment_path=DEFAULT_ENVIRONMENT)

    def test_default_cli_describes_background_without_running_the_demo(self):
        out = io.StringIO()
        with redirect_stdout(out):
            self.assertEqual(main(["world"]), 0)
        payload = json.loads(out.getvalue())
        self.assertEqual(payload["mode"], "SHARED_ENVIRONMENT_NO_SCENARIO_LOADED")
        self.assertNotIn("tasks", payload)
        self.assertFalse(payload["runtime_profile"]["boundaries"]["contains_future_outcomes"])

    def test_environment_inherits_rules_and_preserves_historical_cutoff(self):
        world, _ = self.load(self.inputs())
        environment = WorldEnvironment.load()
        self.assertEqual(world.environment["environment_id"], environment.facts["environment_id"])
        self.assertEqual(world.environment["historical_cutoff"], environment.facts["cutoff"])
        self.assertEqual(world.capacities["Merz"].daily_minutes, 360)
        self.assertEqual(world.capacities["AFD"].slots, 2)
        self.assertEqual(world.capacities["Bundestag"].slots, 1)
        self.assertEqual(world.scheduling, SchedulingRules())

    def test_no_threshold_no_generated_storyline(self):
        raw = self.inputs()
        raw["variables"]["fiscal_pressure"] = 0
        raw.pop("parliament")
        raw["tasks"] = []
        world, until = self.load(raw)
        payload = world.run_until(until)
        self.assertEqual(len(payload["political_decisions"]), 0)
        self.assertTrue(all(row["generated_event"] is None for row in payload["subsystems"]["history"]["history"]))
        self.assertEqual(payload["world_state"]["variables"]["Union"]["value"], 24)

    def test_generated_pressure_uses_existing_decision_space_not_static_triad(self):
        world, until = self.load(self.inputs())
        payload = world.run_until(until)
        generated = [row for row in payload["political_decisions"] if row["decision_space_generation"]]
        self.assertTrue(generated)
        self.assertGreater(len(generated[0]["action_evaluations"]), 3)
        self.assertEqual(payload["subsystems"]["history"]["history"][1]["reason"], "NO_THRESHOLD_CROSSED")

    def test_required_trigger_is_consumed_once_not_reused_after_cooldown(self):
        raw = self.inputs()
        raw["history"]["candidates"][0]["required_trigger_tags"] = ["new_evidence"]
        raw["history"]["trigger_routes"] = {"report": {
            "key": "one_report", "shock": 0.2, "affected_risk_domains": ["reform_conflict"],
            "tags": ["new_evidence"]}}
        raw["events"] = [{"at": "2026-10-19T12:00:00+02:00", "key": "report", "affected": ["Merz"]}]
        world, until = self.load(raw)
        payload = world.run_until(until)
        events = [row["generated_event"] for row in payload["subsystems"]["history"]["history"]]
        self.assertIsNotNone(events[0]["selected_trigger"])
        self.assertIsNone(events[2])
        self.assertEqual(payload["subsystems"]["history"]["pending_triggers"], [])

    def test_vote_uses_live_alignment_and_can_pass_or_fail(self):
        results = []
        for alignment in (0, 100):
            raw = self.inputs()
            raw["variables"]["coalition_alignment"] = alignment
            raw["variables"]["fiscal_pressure"] = 0
            world, until = self.load(raw)
            payload = world.run_until(until)
            result = payload["subsystems"]["parliament"]["history"][0]["vote_result"]
            self.assertEqual(sum(result[k] for k in ("yes", "no", "abstain", "absent")), 10)
            results.append(result["passed"])
        self.assertEqual(results, [False, True])

    def test_support_changes_only_after_media_round_not_fact_delivery(self):
        raw = self.inputs()
        raw.pop("history")
        raw.pop("parliament")
        raw["tasks"] = []
        route = raw["media"]["history_routes"]["reform_coordination_needed"]
        raw["media"]["event_routes"] = {"news": route}
        raw["events"] = [{"at": "2026-10-19T09:00:00+02:00", "key": "news", "affected": ["Merz"], "tags": ["uncertain"]}]
        world, _ = self.load(raw)
        before = world.run_until("2026-10-19T10:59:00+02:00")
        self.assertEqual(before["world_state"]["variables"]["Union"]["value"], 24)
        self.assertEqual(len(before["subsystems"]["media"]["history"]), 0)
        after = world.run_until("2026-10-19T11:01:00+02:00")
        self.assertEqual(len(after["subsystems"]["media"]["history"]), 1)
        self.assertTrue(any(row["kind"] == "media_close" for row in after["trace"]))
        collective = [row for row in after["trace"] if row["task"] == "media:0:AFD" and row["kind"] == "task_completed"]
        self.assertEqual(collective[0]["details"]["operation_result"]["party_id"], "AFD")
        self.assertNotIn("AFD", world.used_personas)

    def test_all_interfaces_share_one_trace_and_reporting_contract(self):
        world, until = self.load(self.inputs())
        payload = world.run_until(until)
        self.assertEqual(set(payload["subsystems"]), {"history", "media", "parliament", "information"})
        self.assertTrue(payload["scenario_report"]["valid"])
        self.assertEqual({row["step"] for row in payload["scenario_report"]["polling_series"]},
                         set(range(len(payload["trace"])+1)))

    def test_replay_is_identical_including_subsystem_seed_streams(self):
        first, until = self.load(self.inputs())
        second, _ = self.load(self.inputs())
        self.assertEqual(first.run_until(until), second.run_until(until))
        self.assertNotEqual(first.services["history"].config["seed"], first.services["media"].config["seed"])

    def test_scenario_cannot_prescribe_completion_or_direct_vote_poll_bonus(self):
        raw = self.inputs()
        raw["tasks"][0]["status"] = "COMPLETED"
        with self.assertRaises(ValueError):
            self.load(raw)
        raw = self.inputs()
        raw["parliament"]["proposals"]["test_reform"]["feedback_by_outcome"]["clear_pass"]["effects"]["Union"] = 5
        with self.assertRaises(ValueError):
            self.load(raw)


if __name__ == "__main__":
    unittest.main()
