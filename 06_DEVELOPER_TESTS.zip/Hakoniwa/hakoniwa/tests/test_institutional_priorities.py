"""Explicit institutional pressure changes beliefs, not facts or personality."""
from dataclasses import asdict, replace
import json
from pathlib import Path
import unittest

from hakoniwa.action_perception import ActionPerceptionFilter
from hakoniwa.action_repertoire import ActionRepertoireFilter
from hakoniwa.cli import _action
from hakoniwa.decision_space import DecisionEvent, DecisionSpaceGenerator, StrategyEffectModel
from hakoniwa.free_agent_game import WorldAction
from hakoniwa.information_filter import BeliefState, InformationFilter
from hakoniwa.institutional_logic import InstitutionalLogic, PRIORITY_FIELDS
from hakoniwa.institutional_matrix import InstitutionalMatrix
from hakoniwa.persona_v2 import ActionOption, FreeAgentDecisionEngine
from hakoniwa.political_agency import AgencyHorizon
from hakoniwa.political_state import PoliticalAction, PoliticalState, StateVariable
from hakoniwa.rationality_evaluation import ActorRationalityProfile
from hakoniwa.scenario_reporting import ScenarioReportingPolicy
from hakoniwa.simulation_orchestrator import LayeredConfiguration, LayeredSimulationOrchestrator, SimulationNodeV3, V3FeatureFlags


ROOT = Path(__file__).resolve().parents[1]
CARDS = ROOT / "data/personas/cards_pss.json"
ENV = ROOT / "data/environments/2026-07-31/environment.json"


class InstitutionalPriorityTests(unittest.TestCase):
    def assess(self, action, logic=None):
        matrix = InstitutionalMatrix("test")
        roles = ActionRepertoireFilter(matrix).apply("M", (action,), {})
        return ActionPerceptionFilter().apply((action,), roles, logic or InstitutionalLogic.neutral(), AgencyHorizon(), {})[action.key]

    def test_each_priority_has_a_live_explicit_pressure_channel(self):
        for channel, field in PRIORITY_FIELDS.items():
            with self.subTest(channel=channel):
                action = ActionOption("test", political_success_expectation=.8,
                    institutional_pressure_exposure={channel: .5})
                row = self.assess(action, replace(InstitutionalLogic.neutral(), **{field: .8}))
                self.assertEqual(row.priority_pressure, .4)
                self.assertEqual(row.political_success_expectation, .48)

    def test_zero_priorities_preserve_existing_expectation(self):
        action = ActionOption("test", political_success_expectation=.8,
            institutional_pressure_exposure={k: 1 for k in PRIORITY_FIELDS})
        self.assertEqual(self.assess(action).political_success_expectation, .8)

    def test_missing_exposure_is_explicitly_unmodeled_not_inferred(self):
        action = ActionOption("test", political_success_expectation=.8,
            value_impacts={"unity": -1}, instrumental_impacts={"government_capacity": -1})
        logic = replace(InstitutionalLogic.neutral(), **{f: 1 for f in PRIORITY_FIELDS.values()})
        row = self.assess(action, logic)
        self.assertEqual(row.political_success_expectation, .8)
        self.assertEqual(row.priority_pressure_status, "UNMODELED_NO_EXPOSURE")

    def test_unrelated_priority_does_not_create_pressure(self):
        action = ActionOption("test", institutional_pressure_exposure={"fiscal_efficiency": 1})
        row = self.assess(action, replace(InstitutionalLogic.neutral(), governability_priority=1))
        self.assertEqual(row.priority_pressure, 0)

    def test_each_priority_is_monotonic_when_its_channel_is_declared(self):
        for channel, field in PRIORITY_FIELDS.items():
            action = ActionOption("test", institutional_pressure_exposure={channel: .5})
            expectations = [self.assess(action, replace(InstitutionalLogic.neutral(), **{field: p})).political_success_expectation
                            for p in (0, .2, .5, 1)]
            with self.subTest(channel=channel):
                self.assertEqual(expectations, [1, .9, .75, .5])

    def test_trace_preserves_inputs_and_marks_model_as_uncalibrated(self):
        row = self.assess(ActionOption("test", institutional_pressure_exposure={"governability": .5}),
            replace(InstitutionalLogic.neutral(), governability_priority=.8)).payload()
        self.assertEqual(row["priority_pressure_exposure"], {"governability": .5})
        self.assertEqual(row["priority_pressure_components"], {"governability": .4})
        self.assertEqual(row["priority_pressure_model"], "DOMINANT_ENVELOPE_V1_UNCALIBRATED")

    def test_pressure_cannot_make_a_possible_action_illegal_or_unconsidered(self):
        action = ActionOption("test", institutional_pressure_exposure={"governability": 1})
        row = self.assess(action, replace(InstitutionalLogic.neutral(), governability_priority=1))
        self.assertEqual(row.political_success_expectation, 0)
        self.assertEqual(row.execution_feasibility, 1)
        self.assertEqual(row.perceived_status, "CONSIDERED")

    def test_correlated_priority_channels_use_envelope_not_sum(self):
        action = ActionOption("test", institutional_pressure_exposure={k: .5 for k in PRIORITY_FIELDS})
        logic = replace(InstitutionalLogic.neutral(), **{f: .8 for f in PRIORITY_FIELDS.values()})
        self.assertEqual(self.assess(action, logic).political_success_expectation, .6)

    def test_overlapping_career_pressure_is_not_multiplied_twice(self):
        logic = replace(InstitutionalLogic.neutral(), necessity_claim_strength=1,
            deviation_career_cost=1, governability_priority=.5)
        action = ActionOption("test", institutional_deviation=1,
            institutional_pressure_exposure={"governability": 1})
        row = self.assess(action, logic)
        self.assertEqual(row.deviation_survivability, .5)
        self.assertEqual(row.institutional_support_survivability, .5)
        self.assertEqual(row.political_success_expectation, .5)

    def test_bad_exposure_channels_and_values_are_rejected(self):
        for value in ({"typo": .5}, {"governability": -.1}, {"governability": 1.1},
                      {"governability": float("nan")}, {"governability": True},
                      {"governability": "0.5"}, None):
            with self.subTest(value=value), self.assertRaises(ValueError):
                ActionOption("test", institutional_pressure_exposure=value)

    def test_input_mapping_is_copied(self):
        raw = {"governability": .5}
        action = ActionOption("test", institutional_pressure_exposure=raw)
        raw["governability"] = 1
        self.assertEqual(action.institutional_pressure_exposure["governability"], .5)

    def test_cli_json_roundtrip_preserves_exposure(self):
        action = ActionOption("test", institutional_pressure_exposure={"fiscal_efficiency": .7})
        self.assertEqual(_action(json.loads(json.dumps(asdict(action)))), action)

    def test_persona_score_is_not_given_a_priority_bonus(self):
        engine = FreeAgentDecisionEngine.from_json(CARDS)
        action = ActionOption("test")
        changed = replace(action, institutional_pressure_exposure={"governability": 1})
        self.assertEqual(engine.score("Merz", action, {}, {}), engine.score("Merz", changed, {}, {}))

    def run_game(self, priority, active):
        actions = tuple(WorldAction(PoliticalAction(key, {"immediate": {"x": delta}}),
            ActionOption(key, political_success_expectation=1, instrumental_impacts={"gain": gain},
                institutional_pressure_exposure=exposure))
            for key, gain, delta, exposure in (
                ("push", .9, 10, {"governability": .8}), ("negotiate", .6, 3, {})))
        config = LayeredConfiguration.from_environment_json(ENV)
        config = replace(config, logic=replace(InstitutionalLogic.neutral(), governability_priority=priority),
            rationality_profiles={"Merz": ActorRationalityProfile(1, 0, 0, 0)},
            flags=V3FeatureFlags(institutional_logic_affects_choice=active))
        game = LayeredSimulationOrchestrator(PoliticalState({"x": StateVariable("x", 50)}, {}, {}),
            {"n": SimulationNodeV3("n", "Merz", actions)}, FreeAgentDecisionEngine.from_json(CARDS),
            InformationFilter({"Merz": {}}, delivery_only=True), {}, config,
            reporting_policy=ScenarioReportingPolicy.diagnostics_only())
        return game.run("n")

    def test_shadow_mode_diagnoses_pressure_without_changing_decision(self):
        neutral, pressured = self.run_game(0, False), self.run_game(1, False)
        a, b = neutral["trace"][0], pressured["trace"][0]
        self.assertEqual(a["chosen_action"], b["chosen_action"])
        self.assertEqual(neutral["world_state"], pressured["world_state"])
        self.assertEqual(b["perceived_action_menu"]["push"]["priority_pressure"], .8)
        self.assertEqual(b["choice_action_menu"]["push"]["priority_pressure"], 0)

    def test_enabled_pressure_can_change_choice_through_expected_instrumental_outcome(self):
        neutral, pressured = self.run_game(0, True), self.run_game(1, True)
        a, b = neutral["trace"][0], pressured["trace"][0]
        self.assertEqual(a["chosen_action"], "push")
        self.assertEqual(b["chosen_action"], "negotiate")
        self.assertEqual(a["action_evaluations"]["push"]["instrumental"], b["action_evaluations"]["push"]["instrumental"])
        self.assertGreater(a["action_evaluations"]["push"]["expected_instrumental"], b["action_evaluations"]["push"]["expected_instrumental"])

    def test_generator_propagates_exposure_without_changing_outcome_branches(self):
        engine = FreeAgentDecisionEngine.from_json(CARDS)
        generated = []
        for exposure in ({}, {"organizational_unity": .6}):
            event = DecisionEvent("test", "party", ("votes",), .5, .5,
                {"private_negotiation": StrategyEffectModel({"immediate": {"x": 1}},
                    institutional_pressure_exposure=exposure)}, allowed_strategy_keys=("private_negotiation",))
            generated.append(DecisionSpaceGenerator().generate("Merz", event, BeliefState("Merz"),
                engine.cards["Merz"], engine.runtime["Merz"], engine.cards["Merz"].initial_resources))
        for before, after in zip(generated[0].actions, generated[1].actions):
            self.assertEqual(after.world_action.choice.institutional_pressure_exposure, {"organizational_unity": .6})
            self.assertEqual(before.outcome_branches, after.outcome_branches)
            self.assertEqual(before.world_action.world, after.world_action.world)


if __name__ == "__main__":
    unittest.main()
