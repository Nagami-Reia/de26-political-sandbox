import unittest

from hakoniwa.decision_cadence import EvidenceUpdate, MaterialDecisionGate


class DecisionCadenceTests(unittest.TestCase):
    def test_routine_messages_are_batched_until_material_change(self):
        gate = MaterialDecisionGate()
        self.assertIsNone(gate.ingest(EvidenceUpdate("m1", "08:00", "media", "funding", .20)))
        self.assertIsNone(gate.ingest(EvidenceUpdate("m2", "08:04", "staff", "funding", .24)))
        node = gate.ingest(EvidenceUpdate(
            "m3", "08:20", "prosecutor", "funding", .66,
            institutional_state_changed=True,
        ))
        self.assertIsNotNone(node)
        self.assertEqual(len(node.evidence), 3)
        self.assertIn("INSTITUTIONAL_STATE_CHANGED", node.trigger_reasons)

    def test_deadline_opens_node_without_inventing_new_evidence(self):
        gate = MaterialDecisionGate()
        node = gate.ingest(EvidenceUpdate(
            "deadline", "10:00", "calendar", "response", .15,
            decision_required=True,
        ))
        self.assertEqual(node.trigger_reasons, ("DECISION_DEADLINE",))

    def test_small_resource_noise_does_not_open_node(self):
        gate = MaterialDecisionGate(resource_threshold=.12)
        self.assertIsNone(gate.ingest(EvidenceUpdate(
            "poll_noise", "12:00", "tracker", "poll", .50, resource_delta=.04
        )))

    def test_low_confidence_band_noise_is_not_a_decision(self):
        gate = MaterialDecisionGate()
        self.assertIsNone(gate.ingest(EvidenceUpdate("rumour", "08:00", "media", "case", .20)))
        self.assertIsNone(gate.ingest(EvidenceUpdate("partial", "08:10", "media", "case", .45)))
        node = gate.ingest(EvidenceUpdate("substantial", "09:00", "investigator", "case", .65))
        self.assertIn("EVIDENCE_CLASSIFICATION_CHANGED", node.trigger_reasons)


if __name__ == "__main__":
    unittest.main()
