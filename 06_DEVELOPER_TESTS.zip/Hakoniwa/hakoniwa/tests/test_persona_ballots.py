import json
import unittest
from copy import deepcopy
from hakoniwa.scenarios.zustrom_2025_vote_replay.first_reading import HERE, load_cards, make_roster, vote_model, run_path
from hakoniwa.scenarios.zustrom_2025_vote_replay.persona_ballots import prepare_protocol, decide_ballot, replacement_plan


class PersonaBallotTests(unittest.TestCase):
    def inputs(self, mode='persona'):
        p=json.loads((HERE/'first_reading_protocol.json').read_text())
        c=json.loads((HERE/'persona_voting_2024.json').read_text())
        return prepare_protocol(p,c,mode)

    def test_seats_and_matched_control(self):
        p=self.inputs(); rows=make_roster(p,123)
        self.assertEqual(len(rows),733)
        self.assertEqual(sum(x['party']=='CDU_CSU' for x in rows),196)
        self.assertEqual(len(set(x['id'] for x in rows)),733)
        self.assertEqual(rows,make_roster(self.inputs('background_control'),123))
        self.assertTrue(set(p['persona_voting']['voters']) <= {x['id'] for x in rows})

    def test_ineligible_rejected(self):
        p=self.inputs(); c=deepcopy(p['persona_voting']);c['voters'].append('Soeder')
        with self.assertRaises(ValueError): prepare_protocol(p,c)

    def test_reordering_or_subset_keeps_same_background_seat(self):
        p=self.inputs(); expected=replacement_plan(p)
        p['persona_voting']['voters'].reverse()
        self.assertEqual(expected,replacement_plan(p))
        p['persona_voting']['voters']=['Merz','Amthor']
        self.assertEqual(replacement_plan(p),{k:expected[k] for k in ['Merz','Amthor']})

    def test_json_key_order_does_not_reassign_policy_axes(self):
        p=self.inputs(); engine,_,_=load_cards(p)
        p['assumptions']['party_ideals']['CDU_CSU']=[.1,.5,.9]
        bill=dict(zip(('limitation_purpose','family_reunion_stop','federal_police_removal'),(.2,.4,.8)))
        a=decide_ballot(p,engine,bill,{},'2024-10-17','test')
        p['facts']['bill_components']=dict(reversed(list(p['facts']['bill_components'].items())))
        self.assertEqual(a,decide_ballot(p,engine,bill,{},'2024-10-17','test'))

    def test_sanitized_resources_and_simultaneous_decisions(self):
        p=self.inputs(); engine,cards,_=load_cards(p)
        for actor,row in cards['actors'].items():
            self.assertFalse(row['event_memory']);self.assertFalse(row['relationship_memory'])
            self.assertEqual(row['initial_resources'],p['assumptions']['resources'][actor])
        args=(p,engine,p['facts']['bill_components'],{'CDU_CSU':{'stance':1.,'intensity':.8}},'2024-10-17','second_reading')
        patches,records=decide_ballot(*args)
        p['persona_voting']['voters'].reverse()
        self.assertEqual(patches,decide_ballot(*args)[0])
        self.assertEqual(len(records),9)
        self.assertTrue(all(r['beliefs']['peer_votes']=='NOT_VISIBLE_BEFORE_BALLOT' for r in records))
        rows=make_roster(p,None)
        next(x for x in rows if x['id']=='Merz')['attendance']=0.
        model=vote_model(p,rows,p['facts']['bill_components'],{},'2024-10-17','second',persona_patches=patches)
        self.assertEqual(model.evaluate_member('Merz')['choice_source'],'EXISTING_PERSONA_DECISION')
        self.assertEqual(model.baseline()['result']['member_ballots']['Merz'],'absent')

    def test_three_fresh_ballots_and_nine_states(self):
        result=run_path(self.inputs())
        self.assertEqual([x['version'] for x in result['persona_ballots']],['agenda','second_reading','third_reading'])
        self.assertTrue(all(len(x['intentions'])==9 for x in result['persona_ballots']))
        self.assertEqual(len(result['initial_pss']),9)


if __name__=='__main__': unittest.main()
