from copy import deepcopy
from types import SimpleNamespace
import unittest

from hakoniwa.plugins.majorities import MajorityModel
from hakoniwa.plugins.majorities.integration import runtime_tie


def request():
    return {'as_of':'2026-10-25','body':{'id':'toy','kind':'faction','secret':False},
        'rule':{'total_weight':1,'quorum':'none'},
        'issue':{'id':'x','version':'v1','proposer':'L'},
        'members':[{'id':'A','party':'P','attendance':1.,'temperature':.2,
                    'weights':{'network':1.,'risk':1.,'discipline':1.}}]}


def network(strength,stance=1.):
    raw=request()
    raw['ties']=[{'from':'A','to':'L','influence':strength,'evidence_kind':'explicit_assumption','issue_scope':'x'}]
    raw['stances']=[{'actor':'L','stance':stance}]
    return raw


def separated_risk(raw,yes=.8,no=.8,abstain=0.):
    raw['issue']['assessments']={'A':{'choice_impacts':{
        'yes':{'risk':yes},'no':{'risk':no},'abstain':{'risk':abstain}}}}
    return raw


class MajorityBehaviorV11Tests(unittest.TestCase):
    def test_weak_contact_no_longer_has_full_influence(self):
        weak=MajorityModel(network(.001)).evaluate_member('A')
        strong=MajorityModel(network(.8)).evaluate_member('A')
        self.assertAlmostEqual(weak['raw_terms']['network'],.001)
        self.assertAlmostEqual(strong['raw_terms']['network'],.8)
        self.assertLess(weak['probabilities']['yes'],strong['probabilities']['yes'])

    def test_zero_contact_matches_unknown_and_negative_contact_respects_sign(self):
        self.assertEqual(MajorityModel(network(0.)).evaluate_member('A')['probabilities'],
                         MajorityModel(request()).evaluate_member('A')['probabilities'])
        self.assertAlmostEqual(MajorityModel(network(.4,-1.)).evaluate_member('A')['raw_terms']['network'],-.4)

    def test_network_is_bounded_and_conflicting_contacts_cancel(self):
        raw=network(1.)
        raw['ties'].append(dict(raw['ties'][0],to='B'))
        raw['stances'].append({'actor':'B','stance':1.})
        self.assertEqual(MajorityModel(raw).evaluate_member('A')['raw_terms']['network'],1.)
        raw['stances'][1]['stance']=-1.
        self.assertEqual(MajorityModel(raw).evaluate_member('A')['raw_terms']['network'],0.)

    def test_explicit_legacy_network_comparison_available(self):
        raw=network(.001);raw['issue']['network_mode']='normalized_direction_legacy'
        self.assertEqual(MajorityModel(raw).evaluate_member('A')['raw_terms']['network'],1.)
        raw['issue']['network_mode']='typo'
        with self.assertRaises(ValueError):MajorityModel(raw)

    def test_two_dangerous_choices_can_produce_abstention(self):
        row=MajorityModel(separated_risk(request())).evaluate_member('A')
        self.assertEqual(row['utilities'],{'yes':-.8,'no':-.8,'abstain':0.})
        self.assertGreater(row['probabilities']['abstain'],row['probabilities']['no'])
        self.assertNotIn('risk',row['unknown'])

    def test_support_cost_does_not_reward_opposition(self):
        row=MajorityModel(separated_risk(request(),yes=.8,no=0.)).evaluate_member('A')
        self.assertEqual(row['utilities']['no'],0.)
        self.assertEqual(row['utilities']['abstain'],0.)

    def test_all_choice_costs_shifted_equally_preserve_preferences(self):
        a=MajorityModel(separated_risk(request(),.2,.4,0.)).evaluate_member('A')
        b=MajorityModel(separated_risk(request(),.5,.7,.3)).evaluate_member('A')
        for key in a['probabilities']:
            self.assertAlmostEqual(a['probabilities'][key],b['probabilities'][key])

    def test_legacy_relative_risk_not_silently_reinterpreted(self):
        raw=request();raw['issue']['assessments']={'A':{'risk':.8}}
        self.assertEqual(MajorityModel(raw).evaluate_member('A')['utilities'],{'yes':-.8,'no':.8,'abstain':0.})

    def test_no_double_counting_or_implicit_missing_action_cost(self):
        raw=separated_risk(request());raw['issue']['assessments']['A']['risk']=.8
        with self.assertRaises(ValueError):MajorityModel(raw)
        raw=separated_risk(request());raw['issue']['assessments']['A']['choice_impacts'].pop('no')
        with self.assertRaises(ValueError):MajorityModel(raw)
        raw=separated_risk(request());raw['issue']['assessments']['A']['choice_impacts']['no']={}
        with self.assertRaises(ValueError):MajorityModel(raw)

    def test_choice_cost_has_same_source_cutoff_protection(self):
        raw=separated_risk(request())
        raw['issue']['assessments']['A'].update(source_status='OBSERVED',source_ids=['future'],available_from='2026-10-26')
        with self.assertRaises(ValueError):MajorityModel(raw)

    def test_secret_vote_removes_sanction_not_declared_coordination(self):
        raw=request();raw['issue']['whips']={'P':{'stance':1.,'coordination':.3,'sanction':.6}}
        public=MajorityModel(raw).evaluate_member('A')
        raw['body']['secret']=True
        secret=MajorityModel(raw).evaluate_member('A')
        self.assertAlmostEqual(public['raw_terms']['discipline'],.9)
        self.assertAlmostEqual(secret['raw_terms']['discipline'],.3)
        self.assertEqual(secret['discipline_diagnostics']['observable_sanction'],0.)
        self.assertIsNone(MajorityModel(raw).ballot(2)['result']['member_ballots'])

    def test_discipline_not_duplicated_and_legacy_observability_preserved(self):
        for instruction in ({'stance':1.,'coordination':.2},
                            {'stance':1.,'coordination':.2,'sanction':.4,'intensity':.7}):
            raw=request();raw['issue']['whips']={'P':instruction}
            with self.assertRaises(ValueError):MajorityModel(raw)
        raw=request();raw['issue']['whips']={'P':{'stance':1.,'intensity':.7}}
        raw['body']['secret']=True
        self.assertEqual(MajorityModel(raw).evaluate_member('A')['raw_terms']['discipline'],0.)

    def test_stale_relationship_scope_rejected(self):
        for fields in ({'issue_version':'v0'},{'valid_until':'2026-10-24'}):
            raw=network(.5);raw['ties'][0].update(fields)
            with self.assertRaises(ValueError):MajorityModel(raw)

    def test_runtime_bridge_requires_explicit_influence(self):
        engine=SimpleNamespace(runtime={'A':SimpleNamespace(relationships={'L':SimpleNamespace(trust=.9)})})
        default=runtime_tie(engine,'A','L',issue_id='x',available_from='2026-10-25')
        explicit=runtime_tie(engine,'A','L',issue_id='x',available_from='2026-10-25',influence=.2,issue_version='v1')
        self.assertEqual(default['influence'],0.)
        self.assertEqual(explicit['influence'],.2)
        with self.assertRaises(ValueError):runtime_tie(engine,'A','L',issue_id='x',available_from='2026-10-25',influence=True)

    def test_persona_vote_stays_authoritative_and_counts_conserve(self):
        raw=separated_risk(network(1.))
        raw['members'][0].update(decided_vote='no',source_status='RUNTIME_MODEL_STATE',
            source_ids=['persona_decision'],available_from='2026-10-25')
        model=MajorityModel(raw)
        for seed in range(10):
            b=model.ballot(seed)
            self.assertEqual(b['result']['member_ballots']['A'],'no')
            self.assertEqual(sum(b['result']['counts'].values()),1)
            self.assertEqual(b,model.ballot(seed))


if __name__=='__main__':unittest.main()
