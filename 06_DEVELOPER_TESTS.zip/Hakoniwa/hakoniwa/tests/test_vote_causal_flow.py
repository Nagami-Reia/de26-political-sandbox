from copy import deepcopy
from collections import Counter
import json
import unittest
from unittest.mock import patch

from hakoniwa.plugins.majorities import MajorityModel
from hakoniwa.plugins.majorities.mechanisms import instruction_components
from hakoniwa.scenarios.zustrom_2025_vote_replay.first_reading import (
    HERE, load_cards, run_path, consultation_context, vote_channels)
from hakoniwa.scenarios.zustrom_2025_vote_replay.persona_ballots import prepare_protocol, decide_ballot


def cyclic_request():
    return {'as_of':'2026-10-25','body':{'id':'test','kind':'faction','secret':False},
        'rule':{'total_weight':2,'quorum':'none'},'issue':{'id':'x','version':'1'},
        'members':[{'id':actor,'attendance':1.,'temperature':.1,'weights':{'network':1.}}
                   for actor in ('A','B')],
        'ties':[{'from':a,'to':b,'influence':1.,'evidence_kind':'synthetic','issue_scope':'x'}
                for a,b in (('A','B'),('B','A'))],
        'stances':[{'actor':'A','stance':1.},{'actor':'B','stance':-1.}]}


class VoteCausalFlowTests(unittest.TestCase):
    def test_zero_or_backwards_clock_rejected_before_running(self):
        p=json.loads((HERE/'first_reading_protocol.json').read_text())
        for value in (0,-1,True,.5):
            q=deepcopy(p);q['assumptions']['round_days']=value
            with self.assertRaises(ValueError):run_path(q)
        for value in (-1,False,.5):
            q=deepcopy(p);q['assumptions']['first_deliberation_days']=value
            with self.assertRaises(ValueError):run_path(q)
        q=deepcopy(p);q['horizon']=q['cutoff'][:10]
        with self.assertRaises(ValueError):run_path(q)

    def test_reciprocal_ties_do_not_recursively_recompute_votes(self):
        model=MajorityModel(cyclic_request());calls=[];original=model.evaluate_member
        def recording(key,shocks=None):
            calls.append(key)
            if len(calls)>2:raise AssertionError('Recursive peer evaluation')
            return original(key,shocks)
        with patch.object(model,'evaluate_member',recording):ballot=model.baseline()
        self.assertEqual(Counter(calls),{'A':1,'B':1})
        self.assertEqual(ballot['result']['member_ballots'],{'A':'no','B':'yes'})
        self.assertEqual(model.stances,{'A':1.,'B':-1.})
        self.assertFalse(ballot['evaluation_contract']['actual_ballots_written_to_stances'])

    def test_repeating_same_ballot_neither_changes_relationships_nor_stances(self):
        raw=cyclic_request();model=MajorityModel(raw);snapshot=deepcopy(model.request)
        first=model.ballot(17)
        for _ in range(5):self.assertEqual(model.ballot(17),first)
        self.assertEqual(model.request,snapshot)
        raw['members'].reverse();raw['stances'].reverse();raw['ties'].reverse()
        self.assertEqual(MajorityModel(raw).ballot(17),first)

    def test_attempt_and_offer_do_not_create_acceptance(self):
        for attempts in ([],[{'actor':'Frei','type':'CONTACT_ATTEMPT'}],
                         [{'actor':'Merz','type':'TEXT_OFFER'}]*10):
            context=consultation_context(attempts)
            self.assertEqual(context['counterparty_acceptance'],'UNKNOWN')
            self.assertEqual(context['cooperation_payoff'],0.)
            self.assertEqual(context['confirmed_deliberation_payoff'],0.)

    def test_named_persona_reads_same_new_instruction_channels(self):
        p=json.loads((HERE/'first_reading_protocol.json').read_text())
        p=prepare_protocol(p,json.loads((HERE/'persona_voting_2024.json').read_text()))
        p['persona_voting']['voters']=['Frei']
        engine,_,_=load_cards(p)
        for instruction in ({'stance':1.,'intensity':.7},
                            {'stance':1.,'coordination':.3,'sanction':.5},
                            {'stance':-1.,'coordination':.3,'sanction':.5}):
            _,records=decide_ballot(p,engine,p['facts']['bill_components'],{'CDU_CSU':instruction},'2024-10-17','test')
            received=records[0]['adapter_assumptions']['perceived_party_instruction']
            self.assertEqual(received,instruction_components(instruction))
        with self.assertRaises(ValueError):
            decide_ballot(p,engine,p['facts']['bill_components'],{'CDU_CSU':{'stance':1.,'coordination':.2}},'2024-10-17','test')

    def test_named_vote_local_diagnostics_are_not_counted_as_active_channels(self):
        raw=cyclic_request()
        for member in raw['members']:
            member.update(decided_vote='yes',source_status='RUNTIME_MODEL_STATE',
                          source_ids=['test_decision'],available_from='2026-10-25')
        summary=vote_channels(MajorityModel(raw).baseline())
        self.assertEqual(summary['active_network_members'],0)
        self.assertEqual(summary['choice_sources'],{'EXISTING_PERSONA_DECISION':2})

    def test_replay_contact_feedback_and_temporal_order_are_explicit(self):
        p=json.loads((HERE/'first_reading_protocol.json').read_text())
        p['horizon']='2024-10-10';b=run_path(p)
        dates=[n['calendar_date'] for n in b['trace']]
        self.assertEqual(dates,sorted(dates))
        self.assertLess(len(b['trace']),100)
        parties=[n for n in b['trace'] if 'consultation_context' in n['feedback']]
        self.assertTrue(parties)
        for node in parties:
            support=node['evaluation']['evaluations']['support']
            self.assertEqual(node['feedback']['consultation_context']['counterparty_acceptance'],'UNKNOWN')
            self.assertEqual(support['diagnostics']['state']['coalition_dependency'],
                .85 if node['actor'] in ('SPD','Greens','FDP') else 0.)
        for node in b['trace']:
            if node['chosen_action']=='audit_commitments':
                self.assertFalse(node['feedback']['forecast_is_actual_vote'])


if __name__=='__main__':unittest.main()
