"""Count real ballots exactly; keep forecast expectations continuous."""
import random
import unittest

from hakoniwa.plugins.majorities.service import BallotGroupPrior, MemberVoteService, VoteRule


def bloc(key="all", seats=10, **kwargs):
    values = dict(attendance=.9, yes_share=.6, no_share=.3, abstain_share=.1)
    values.update(kwargs)
    return BallotGroupPrior(key, seats, **values)


class VoteConservationTests(unittest.TestCase):
    def setUp(self):
        self.model, self.rule = MemberVoteService(), VoteRule("simple_cast", 10)

    def test_more_votes_than_members_are_rejected(self):
        with self.assertRaises(ValueError):
            self.model.settle("test", "vote", self.rule, 999, 0, 0, 0)

    def test_missing_members_must_be_explicitly_absent(self):
        with self.assertRaises(ValueError):
            self.model.settle("test", "vote", self.rule, 6, 3, 0, 0)
        result = self.model.settle("test", "vote", self.rule, 6, 3, 0, 1)
        self.assertEqual(result.absent, 1)

    def test_negative_count_in_any_category_is_rejected(self):
        for index in range(4):
            counts = [5, 3, 1, 1]
            counts[index] = -1
            with self.subTest(index=index), self.assertRaises(ValueError):
                self.model.settle("test", "vote", self.rule, *counts)

    def test_noninteger_counts_are_not_silently_coerced(self):
        for index in range(4):
            for value in (1.0, 1.5, True, False, float("nan"), float("inf"), "1", None):
                counts = [5, 3, 1, 1]
                counts[index] = value
                with self.subTest(index=index, value=value), self.assertRaises(ValueError):
                    self.model.settle("test", "vote", self.rule, *counts)

    def test_membership_is_a_positive_integer(self):
        for value in (0, -1, 10.0, 1.5, True, float("nan"), float("inf"), "10", None):
            with self.subTest(value=value), self.assertRaises(ValueError):
                VoteRule(total_members=value)

    def test_bloc_seats_are_nonnegative_integers(self):
        for value in (-1, 10.0, True, float("nan"), float("inf"), "10", None):
            with self.subTest(value=value), self.assertRaises(ValueError):
                bloc(seats=value)
        self.assertEqual(bloc(seats=0).seats, 0)

    def test_bloc_keys_cannot_be_empty_or_untyped(self):
        for value in ("", "  ", 1, None):
            with self.subTest(value=value), self.assertRaises(ValueError):
                bloc(key=value)

    def test_probabilities_and_shocks_must_be_finite_numbers(self):
        for field in ("attendance", "yes_share", "no_share", "abstain_share", "shared_logit_sigma"):
            for value in (float("nan"), float("inf"), -float("inf"), True, "0.5", None):
                with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                    bloc(**{field: value})

    def test_forecast_roster_must_cover_all_members(self):
        for seats in (9, 11):
            with self.subTest(seats=seats), self.assertRaises(ValueError):
                self.model.forecast("test", "vote", self.rule, (bloc(seats=seats),))

    def test_simulation_roster_must_cover_all_members(self):
        with self.assertRaises(ValueError):
            self.model.simulate(self.rule, (bloc(seats=11),), runs=2)

    def test_direct_sampler_checks_roster_before_drawing(self):
        rng = random.Random(7)
        before = rng.getstate()
        with self.assertRaises(ValueError):
            self.model._sample_once(self.rule, (bloc(seats=9),), rng)
        self.assertEqual(rng.getstate(), before)

    def test_empty_and_duplicate_bloc_rosters_are_rejected(self):
        for blocs in ((), (bloc(seats=5), bloc(seats=5))):
            with self.subTest(blocs=blocs), self.assertRaises(ValueError):
                self.model.forecast("test", "vote", self.rule, blocs)

    def test_forecast_preserves_fractional_expected_votes(self):
        forecast = self.model.forecast("test", "vote", self.rule, (bloc(),))
        self.assertEqual((forecast.expected_yes, forecast.expected_no, forecast.expected_abstain, forecast.expected_absent),
            (5.4, 2.7, .9, 1.0))

    def test_threshold_accepts_fractional_expectations_but_not_invalid_counts(self):
        self.assertEqual(self.rule.required_yes(5.4, 2.7), 5)
        for yes, no in ((-1, 2), (float("nan"), 0), (0, float("inf")), (True, 1), ("1", 1), (6, 5)):
            with self.subTest(yes=yes, no=no), self.assertRaises(ValueError):
                self.rule.required_yes(yes, no)

    def test_run_count_is_a_positive_integer(self):
        for runs in (0, -1, 2.0, True, "2", None):
            with self.subTest(runs=runs), self.assertRaises(ValueError):
                self.model.simulate(self.rule, (bloc(),), runs=runs)

    def test_sampled_ballots_conserve_members_across_seeds(self):
        blocs = (bloc("a", 6, shared_logit_sigma=.2), bloc("b", 4, attendance=.5))
        for seed in range(30):
            counts = self.model._sample_once(self.rule, blocs, random.Random(seed))
            self.assertEqual(sum(counts), 10)
            self.assertTrue(all(type(value) is int and value >= 0 for value in counts))
            self.model.settle("test", "vote", self.rule, *counts)

    def test_simulation_does_not_trust_malformed_sampler_counts(self):
        class InvalidSampler(MemberVoteService):
            def _sample_once(self, rule, blocs, rng):
                return 999, 0, 0, 0
        with self.assertRaises(ValueError):
            InvalidSampler().simulate(self.rule, (bloc(),), runs=1)


if __name__ == "__main__":
    unittest.main()
