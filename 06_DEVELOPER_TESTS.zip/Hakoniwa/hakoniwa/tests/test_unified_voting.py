from copy import deepcopy
import json
from pathlib import Path
import random
import unittest
from unittest.mock import patch

from hakoniwa.plugins.majorities import MajorityModel
from hakoniwa.plugins.majorities.service import MemberVoteService, BallotGroupPrior, VoteRule

ROOT=Path(__file__).resolve().parents[1]


class UnifiedVotingTests(unittest.TestCase):
    def test_legacy_module_removed_and_no_production_imports(self):
        self.assertFalse((ROOT/'parliamentary_vote.py').exists())
        for path in ROOT.rglob('*.py'):
            if path==Path(__file__).resolve():continue
            self.assertNotIn('from hakoniwa.parliamentary_vote import',path.read_text(),str(path))
            self.assertNotIn('from .parliamentary_vote import',path.read_text(),str(path))

    def test_adapter_compiles_one_person_one_vote_with_declared_prior(self):
        service=MemberVoteService();rule=VoteRule(total_members=4)
        groups=(BallotGroupPrior('A',3,.9,.6,.3,.1),BallotGroupPrior('B',1,1.,0.,1.,0.))
        model=service.compile_groups(rule,groups)
        self.assertIsInstance(model,MajorityModel)
        self.assertEqual(len(model.members),4)
        self.assertTrue(all(row['choice_source']=='DECLARED_BALLOT_PRIOR'
            for row in model.baseline()['member_evaluations'].values()))
        for ev in model.baseline()['member_evaluations'].values():
            self.assertAlmostEqual(sum(ev['probabilities'].values()),1.)

    def test_sampling_delegates_to_canonical_member_engine(self):
        observed=[];original=MajorityModel.ballot
        def recording(model,seed):
            result=original(model,seed);observed.append(result);return result
        service=MemberVoteService();rule=VoteRule(total_members=4)
        groups=(BallotGroupPrior('A',4,.9,.6,.3,.1),)
        with patch.object(MajorityModel,'ballot',recording):
            result=service._sample_once(rule,groups,random.Random(3))
        self.assertEqual(len(observed),1)
        self.assertEqual(result,tuple(observed[0]['result']['counts'][k] for k in ('yes','no','abstain','absent')))

    def test_representative_ballot_is_not_rounded_expected_counts(self):
        service=MemberVoteService();rule=VoteRule(total_members=4)
        groups=(BallotGroupPrior('A',4,1.,.6,.4,0.),)
        self.assertEqual(service.representative_counts(rule,groups),(4,0,0,0))
        self.assertEqual(service.forecast('p','s',rule,groups).expected_yes,2.4)

    def test_unsupported_legacy_parameters_fail_loudly(self):
        for field in ('discipline','hidden_defection_sigma'):
            with self.assertRaises(TypeError):
                BallotGroupPrior('A',4,1.,.6,.4,0.,**{field:.9})

    def test_validated_model_is_isolated_from_all_caller_changes(self):
        raw=json.loads((ROOT/'plugins/majorities/examples/committee.json').read_text())
        model=MajorityModel(raw);before=model.ballot(42)
        raw['members'][0]['decided_vote']='no'
        raw['issue']['whip']['stance']=-1.
        raw['ties'][0]['trust']=0.
        raw['contingencies'][0]['sigma']=1.
        self.assertEqual(before,model.ballot(42))
        self.assertNotIn('decided_vote',model.request['members'][0])

    def test_prior_cannot_silently_bypass_utility_or_instruction(self):
        model=MemberVoteService.compile_groups(VoteRule(total_members=1),(BallotGroupPrior('A',1,1.,.6,.3,.1),))
        raw=deepcopy(model.request)
        raw['members'][0]['weights']={'discipline':1.}
        with self.assertRaises(ValueError): MajorityModel(raw)
        raw=deepcopy(model.request)
        raw['issue']['whips']={'A':{'stance':1.,'intensity':1.}}
        with self.assertRaises(ValueError): MajorityModel(raw).baseline()

    def test_invalid_priors_and_provenance_rejected(self):
        base=MemberVoteService.compile_groups(VoteRule(total_members=1),(BallotGroupPrior('A',1,1.,.6,.3,.1),)).request
        for bad in ({'yes':.9,'no':.3,'abstain':.1},
                    {'yes':.6,'no':.3,'abstain':.1,'source_status':'OBSERVED'},
                    {'yes':.6,'no':.3,'abstain':.1,'source_status':'OBSERVED','source_ids':['x'],'available_from':'2026-01-01'}):
            raw=deepcopy(base);raw['members'][0]['ballot_prior']=bad
            with self.assertRaises(ValueError):MajorityModel(raw)


if __name__=='__main__':unittest.main()
