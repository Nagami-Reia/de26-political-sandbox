"""Fraction-of-cast thresholds must never admit adoption with zero yes votes."""
import unittest

from hakoniwa.plugins.majorities.service import BallotGroupPrior, MemberVoteService, VoteFeedback, VoteRule
from hakoniwa.plugins.majorities.rules import BallotRule
from hakoniwa.political_state import PoliticalState, StateVariable


class VoteThresholdTests(unittest.TestCase):
    def setUp(self):
        self.model = MemberVoteService()
        self.rule = VoteRule("two_thirds_cast", 10)

    def test_empty_cast_requires_at_least_one_affirmative_vote(self):
        self.assertEqual(self.rule.required_yes(0, 0), 1)

    def test_all_abstain_is_not_adoption(self):
        result = self.model.settle("test", "ballot", self.rule, 0, 0, 10, 0)
        self.assertFalse(result.passed)
        self.assertEqual(result.required_yes, 1)
        self.assertEqual(result.outcome_class, "narrow_fail")

    def test_all_absent_is_not_adoption(self):
        result = self.model.settle("test", "ballot", self.rule, 0, 0, 0, 10)
        self.assertFalse(result.passed)
        self.assertEqual(result.required_yes, 1)

    def test_zero_cast_forecast_is_not_a_pass(self):
        for attendance in (0, 1):
            with self.subTest(attendance=attendance):
                blocs = (BallotGroupPrior("all", 10, attendance, 0, 0, 1),)
                result = self.model.forecast("test", "ballot", self.rule, blocs)
                self.assertEqual(result.expected_yes, 0)
                self.assertEqual(result.required_yes, 1)
                self.assertLess(result.expected_margin, 0)
                self.assertTrue(result.conclusion.endswith("fail"))

    def test_simulation_cannot_adopt_an_all_abstain_ballot(self):
        blocs = (BallotGroupPrior("all", 10, 1, 0, 0, 1),)
        result = self.model.simulate(self.rule, blocs, runs=100, seed=7)
        self.assertEqual(result.passage_runs, 0)
        self.assertEqual(result.path_counts, {"narrow_fail": 100})

    def test_simulation_cannot_adopt_an_all_absent_ballot(self):
        blocs = (BallotGroupPrior("all", 10, 0, 1, 0, 0),)
        result = self.model.simulate(self.rule, blocs, runs=100, seed=7)
        self.assertEqual(result.passage_runs, 0)

    def test_nonempty_fractional_thresholds_are_unchanged(self):
        for yes, no, required, passed in (
            (1, 0, 1, True), (0, 1, 1, False), (1, 1, 2, False),
            (2, 1, 2, True), (3, 2, 4, False), (4, 2, 4, True),
            (6, 4, 7, False), (7, 3, 7, True),
        ):
            with self.subTest(yes=yes, no=no):
                result = self.model.settle("test", "ballot", self.rule, yes, no, 10-yes-no, 0)
                self.assertEqual(result.required_yes, required)
                self.assertEqual(result.passed, passed)

    def test_abstention_is_not_added_to_fraction_cast_denominator(self):
        result = self.model.settle("test", "ballot", self.rule, 2, 1, 7, 0)
        self.assertEqual(result.required_yes, 2)
        self.assertTrue(result.passed)

    def test_membership_rules_keep_their_own_denominator(self):
        for kind, required in (("absolute_members", 6), ("two_thirds_members", 7)):
            with self.subTest(kind=kind):
                result = self.model.settle("test", "ballot", VoteRule(kind, 10), 2, 1, 7, 0)
                self.assertEqual(result.required_yes, required)
                self.assertFalse(result.passed)

    def test_simple_cast_still_requires_strict_majority(self):
        rule = VoteRule("simple_cast", 10)
        for yes, no, passed in ((0, 0, False), (1, 1, False), (2, 1, True)):
            with self.subTest(yes=yes, no=no):
                self.assertEqual(self.model.settle("test", "ballot", rule, yes, no, 10-yes-no, 0).passed, passed)

    def test_small_valid_ballots_agree_with_plugin_thresholds(self):
        kinds = {"simple_cast": "simple_cast", "absolute_members": "absolute_members",
            "two_thirds_members": "fraction_members", "two_thirds_cast": "fraction_cast"}
        for total in range(1, 9):
            for legacy, modern in kinds.items():
                old, new = VoteRule(legacy, total), BallotRule(total, modern, quorum="none")
                for yes in range(total+1):
                    for no in range(total-yes+1):
                        counts = {"yes": yes, "no": no, "abstain": total-yes-no, "absent": 0, "invalid": 0}
                        a = self.model.settle("test", "ballot", old, yes, no, counts["abstain"], 0)
                        b = new.settle(counts)
                        self.assertEqual((a.required_yes, a.passed), (b["required_yes"], b["passed"]),
                            (legacy, total, counts))

    def test_no_success_feedback_or_lock_for_empty_cast(self):
        state = PoliticalState({"x": StateVariable("x", 50)}, {}, {})
        result = self.model.settle("test", "ballot", self.rule, 0, 0, 10, 0)
        feedback = {
            "narrow_fail": VoteFeedback("narrow_fail", {"x": -2}),
            "narrow_pass": VoteFeedback("narrow_pass", {"x": 10}, locks_add=("adopted",)),
        }
        self.model.apply_feedback(state, result, feedback)
        self.assertEqual(state.variables["x"].value, 48)
        self.assertNotIn("adopted", state.locks)


if __name__ == "__main__":
    unittest.main()
