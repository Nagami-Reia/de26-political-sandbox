"""Unobserved outcome truth must not become an actor's learned experience."""
from dataclasses import asdict
import json
from pathlib import Path
import unittest

from hakoniwa.persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine, _parse_card
from hakoniwa.political_state_system import (
    MemoryNode, PoliticalStateSystem, PSSProfile,
)


CARDS = Path(__file__).resolve().parents[1] / "data/personas/cards_pss.json"


class OutcomeMemoryEvidenceTests(unittest.TestCase):
    def system(self):
        pss = PoliticalStateSystem()
        pss.register("M", PSSProfile(.8, .5, {}))
        return pss

    def test_zero_quality_and_zero_scope_do_not_form_memories(self):
        for quality, scope in ((0, 1), (1, 0), (0, 0)):
            for success in (0, .5, 1):
                with self.subTest(quality=quality, scope=scope, success=success):
                    pss = self.system()
                    before = asdict(pss.actors["M"].state)
                    result = pss.record_outcome("M", "unverified", success,
                        workload=0, evidence_quality=quality, outcome_scope=scope)
                    self.assertEqual(pss.actors["M"].memories, [])
                    self.assertEqual(asdict(pss.actors["M"].state), before)
                    self.assertFalse(result["memory_update"]["formed"])
                    self.assertEqual(len(pss.history), 1)

    def test_workload_is_paid_even_without_outcome_evidence(self):
        pss = self.system()
        before = pss.actors["M"].state.energy
        pss.record_outcome("M", "attempt", 1, workload=.1, evidence_quality=0)
        self.assertAlmostEqual(pss.actors["M"].state.energy, before - .1)
        self.assertEqual(pss.actors["M"].memories, [])

    def test_quality_times_scope_scales_memory_strength(self):
        for success in (0, .5, 1):
            with self.subTest(success=success):
                strong, weak = self.system(), self.system()
                strong.record_outcome("M", "attempt", success, evidence_quality=1)
                weak.record_outcome("M", "attempt", success,
                    evidence_quality=.5, outcome_scope=.5)
                full, partial = strong.actors["M"].memories[0], weak.actors["M"].memories[0]
                self.assertAlmostEqual(partial.severity, full.severity * .25)
                self.assertAlmostEqual(partial.unresolved, full.unresolved * .25)
                self.assertEqual(partial.evidence_weight, .25)

    def test_full_evidence_keeps_previous_learning_strength(self):
        pss = self.system()
        pss.record_outcome("M", "attempt", 1, tags=("delivery",), evidence_quality=1)
        memory = pss.actors["M"].memories[0]
        self.assertAlmostEqual(memory.severity, .8)
        self.assertEqual(memory.valence, 1)
        self.assertEqual(memory.learned_response_tags, ("delivery",))

    def test_weak_positive_memory_only_fractionally_consumes_novelty(self):
        pss = self.system()
        pss.record_outcome("M", "attempt", 1, evidence_quality=.1)
        result = pss.record_outcome("M", "attempt", 1, evidence_quality=1)
        update = result["confidence_update"]
        self.assertAlmostEqual(update["prior_similar_positive_evidence"], .1)
        self.assertAlmostEqual(update["novelty"], 1 / (1 + .45 * .1), places=3)

    def test_zero_evidence_does_not_reduce_later_novelty(self):
        pss = self.system()
        pss.record_outcome("M", "attempt", 1, evidence_quality=0)
        result = pss.record_outcome("M", "attempt", 1, evidence_quality=1)
        self.assertEqual(result["confidence_update"]["novelty"], 1)

    def test_memory_evidence_survives_serialization_and_registration(self):
        pss = self.system()
        pss.record_outcome("M", "attempt", 1, evidence_quality=.2)
        restored = MemoryNode(**asdict(pss.actors["M"].memories[0]))
        clone = PoliticalStateSystem()
        clone.register("M", PSSProfile(.8, .5, {}), memories=(restored,))
        self.assertEqual(clone.actors["M"].memories[0].evidence_weight, .2)

    def test_legacy_memory_defaults_to_existing_evidence_strength(self):
        memory = MemoryNode("outcome:old:1", ("attempt",), .8, 1)
        self.assertEqual(memory.evidence_weight, 1)

    def test_unverified_results_cannot_change_persona_memory_score(self):
        for success in (0, 1):
            with self.subTest(success=success):
                engine = FreeAgentDecisionEngine.from_json(CARDS)
                action = ActionOption("next_probe", event_tags=("unique_evidence_probe",))
                before = engine.score("Merz", action, {}, {}).memory_modifier
                engine.apply_outcome("Merz", ActionOutcome("prior_probe", success,
                    tags=("unique_evidence_probe",), workload=0, evidence_quality=0))
                self.assertEqual(engine.score("Merz", action, {}, {}).memory_modifier, before)

    def test_verified_result_still_changes_persona_memory_score(self):
        engine = FreeAgentDecisionEngine.from_json(CARDS)
        action = ActionOption("next_probe", event_tags=("unique_evidence_probe",))
        before = engine.score("Merz", action, {}, {}).memory_modifier
        engine.apply_outcome("Merz", ActionOutcome("prior_probe", 1,
            tags=("unique_evidence_probe",), workload=0, evidence_quality=1))
        self.assertGreater(engine.score("Merz", action, {}, {}).memory_modifier, before)

    def test_card_loader_keeps_explicit_memory_evidence(self):
        raw = json.loads(CARDS.read_text())["actors"]["Merz"]
        raw["event_memory"] = [{
            "event_id": "outcome:attempt:1", "tags": ["attempt"],
            "severity": .08, "valence": 1, "evidence_weight": .1,
        }]
        card = _parse_card("Merz", raw)
        engine = FreeAgentDecisionEngine({"Merz": card})
        self.assertEqual(engine.runtime["Merz"].memories[0].evidence_weight, .1)

    def test_weak_evidence_has_less_downstream_memory_influence(self):
        for success in (0, 1):
            contributions = []
            for evidence in (.1, 1):
                engine = FreeAgentDecisionEngine.from_json(CARDS)
                action = ActionOption("next_probe", event_tags=("unique_evidence_probe",))
                before = engine.score("Merz", action, {}, {}).memory_modifier
                engine.apply_outcome("Merz", ActionOutcome("prior_probe", success,
                    tags=("unique_evidence_probe",), workload=0, evidence_quality=evidence))
                contributions.append(abs(engine.score("Merz", action, {}, {}).memory_modifier - before))
            with self.subTest(success=success):
                self.assertLess(contributions[0], contributions[1])


if __name__ == "__main__":
    unittest.main()
