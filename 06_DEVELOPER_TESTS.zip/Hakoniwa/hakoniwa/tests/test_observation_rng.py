"""Speculative observations must not advance the real observation stream."""
from copy import deepcopy
import random
import unittest

from hakoniwa.information_filter import AccessRule, InformationFilter
from hakoniwa.political_state import PoliticalAction, PoliticalState, StateVariable
from hakoniwa.strategic_game import ActorDecisionModel, DecisionNode, StrategicGame


def world(value=50):
    return PoliticalState({"x": StateVariable("x", value)}, {}, {})


def information(**kwargs):
    return InformationFilter({
        "A": {"x": AccessRule(.5, noise=10)},
        "B": {"x": AccessRule(.7, noise=8)},
    }, seed=7, stochastic=True, **kwargs)


class ObservationRNGTests(unittest.TestCase):
    def test_preview_preserves_entire_rng_state(self):
        info = information()
        before = info.rng.getstate()
        info.observe("A", world(), commit=False)
        self.assertEqual(info.rng.getstate(), before)

    def test_extra_previews_do_not_change_next_committed_observation(self):
        left, right = information(), information()
        for value in (50, 90, 10, 75):
            left.observe("A", world(value), commit=False)
        self.assertEqual(left.observe("A", world(), commit=True), right.observe("A", world(), commit=True))
        self.assertEqual(left.rng.getstate(), right.rng.getstate())

    def test_repeated_preview_is_identical_until_real_state_changes(self):
        info = information()
        first = info.observe("A", world(), commit=False)
        for _ in range(5):
            self.assertEqual(info.observe("A", world(), commit=False), first)
        self.assertFalse(info.states["A"].beliefs)

    def test_preview_uses_same_draw_as_next_commit(self):
        info = information()
        preview = info.observe("A", world(), commit=False)
        actual = info.observe("A", world(), commit=True)
        self.assertEqual(preview, actual)

    def test_formal_observations_still_advance_noise_stream(self):
        info = information()
        expected = random.Random(7)
        expected.gauss(0, 10)
        info.observe("A", world(), commit=True)
        self.assertEqual(info.rng.getstate(), expected.getstate())
        first = deepcopy(info.states["A"])
        expected.gauss(0, 10)
        second = info.observe("A", world(), commit=True)
        self.assertEqual(info.rng.getstate(), expected.getstate())
        self.assertNotEqual(first.beliefs["x"].estimate, second.beliefs["x"].estimate)

    def test_preview_preserves_gaussian_cached_sample(self):
        left, right = information(), information()
        left.observe("A", world(), commit=True)
        right.observe("A", world(), commit=True)
        self.assertIsNotNone(left.rng.getstate()[2])
        before = left.rng.getstate()
        left.observe("B", world(90), commit=False)
        self.assertEqual(left.rng.getstate(), before)
        self.assertEqual(left.observe("B", world(), commit=True), right.observe("B", world(), commit=True))

    def test_failed_preview_does_not_consume_noise_before_error(self):
        info = information()
        state = world()
        state.variables["bad"] = StateVariable("bad", 50)
        info.rules["A"]["bad"] = AccessRule(.5, bias="invalid", noise=3)
        before_rng, before_beliefs = info.rng.getstate(), deepcopy(info.states)
        with self.assertRaises(TypeError):
            info.observe("A", state, commit=False)
        self.assertEqual(info.rng.getstate(), before_rng)
        self.assertEqual(info.states, before_beliefs)

    def test_other_actors_previews_do_not_affect_real_recipient(self):
        left, right = information(), information()
        for _ in range(4):
            left.observe("B", world(), commit=False)
        self.assertEqual(left.observe("A", world(), commit=True), right.observe("A", world(), commit=True))

    def test_delivered_only_still_uses_no_randomness(self):
        info = information(delivery_only=True)
        info.deliver("A", {"x": {"estimate": 25, "confidence": .8, "source": "staff"}}, message_id="prior")
        before = info.rng.getstate()
        preview = info.observe("A", world(99), commit=False)
        self.assertEqual(info.observe("A", world(99), commit=True), preview)
        self.assertEqual(info.rng.getstate(), before)

    def test_preview_with_existing_beliefs_preserves_all_real_information_state(self):
        info = information()
        info.deliver("A", {"x": {"estimate": 25, "confidence": .8, "source": "staff"}}, message_id="prior")
        info.states["A"].source_trust["staff"] = .6
        before_states, before_deliveries = deepcopy(info.states), deepcopy(info.deliveries)
        before_rng = info.rng.getstate()
        preview = info.observe("A", world(90), commit=False)
        preview.beliefs["x"].estimate = 0
        preview.source_trust["staff"] = 0
        self.assertEqual(info.states, before_states)
        self.assertEqual(info.deliveries, before_deliveries)
        self.assertEqual(info.rng.getstate(), before_rng)

    def game(self):
        actions = (
            PoliticalAction("advance", {"immediate": {"x": 5}}),
            PoliticalAction("retreat", {"immediate": {"x": -3}}),
        )
        node = DecisionNode("n", "A", actions, ("A",))
        model = ActorDecisionModel("A", {"immediate": {"x": 1}}, targets={"x": 70}, planning_depth=0)
        return StrategicGame(world(), {"n": node}, {"A": model}, information())

    def test_candidate_evaluation_order_does_not_change_evaluations(self):
        left, right = self.game(), self.game()
        forward = {a.key: left.evaluate("A", a, left.state) for a in left.nodes["n"].actions}
        backward = {a.key: right.evaluate("A", a, right.state) for a in reversed(right.nodes["n"].actions)}
        self.assertEqual(forward, backward)

    def test_extra_legacy_evaluations_do_not_change_actual_run(self):
        left, right = self.game(), self.game()
        for _ in range(3):
            for action in left.nodes["n"].actions:
                left.evaluate("A", action, left.state)
        self.assertEqual(left.run("n"), right.run("n"))


if __name__ == "__main__":
    unittest.main()
