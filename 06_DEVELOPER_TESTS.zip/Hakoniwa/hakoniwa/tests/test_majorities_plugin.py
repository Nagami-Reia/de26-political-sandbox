from copy import deepcopy
import json
from pathlib import Path
import unittest

from hakoniwa.plugins.majorities import MajorityModel, power_indices, run_request
from hakoniwa.plugins.majorities.rules import BallotRule
from hakoniwa.plugins.majorities.integration import outcome_event, runtime_tie

FIXTURE = Path(__file__).parents[1] / "plugins/majorities/examples/committee.json"


def request():
    raw = json.loads(FIXTURE.read_text())
    raw["runs"] = 20
    return raw


def counts(yes, no, abstain=0, absent=0, invalid=0):
    return dict(yes=yes, no=no, abstain=abstain, absent=absent, invalid=invalid)


class MechanicalRulesTests(unittest.TestCase):
    def test_abstention_does_not_count_as_no_but_counts_for_quorum(self):
        rule = BallotRule(10)
        result = rule.settle(counts(3, 2, 5))
        self.assertTrue(result["passed"])
        self.assertEqual(result["required_yes"], 3)

    def test_tie_rejected_and_empty_ballot_never_passes(self):
        self.assertFalse(BallotRule(2).settle(counts(1, 1))["passed"])
        self.assertFalse(BallotRule(2, kind="fraction_cast").settle(counts(0, 0, 2))["passed"])

    def test_absolute_denominator_keeps_absentees(self):
        result = BallotRule(10, "absolute_members").settle(counts(5, 1, 0, 4))
        self.assertEqual(result["required_yes"], 6)
        self.assertFalse(result["passed"])

    def test_fraction_exact_rounding(self):
        self.assertEqual(BallotRule(7, "fraction_members").settle(counts(5, 2))["required_yes"], 5)

    def test_presumed_and_verified_quorum_are_distinct(self):
        ballot = counts(2, 1, absent=7)
        self.assertEqual(BallotRule(10).settle(ballot)["status"], "NO_QUORUM")
        result = BallotRule(10, quorum="presumed").settle(ballot)
        self.assertEqual(result["status"], "ADOPTED")
        self.assertFalse(result["numerical_quorum_met"])

    def test_procedure_pending_overrides_vote(self):
        self.assertEqual(BallotRule(2, procedure_ready=False).settle(counts(2, 0))["status"], "PENDING_PROCEDURE")

    def test_counts_validate(self):
        for value in (counts(1, 0), counts(-1, 3), counts(True, 1), counts(1.0, 1)):
            with self.assertRaises(ValueError):
                BallotRule(2).settle(value)


class MemberModelTests(unittest.TestCase):
    def test_seeded_replay_and_input_not_mutated(self):
        raw = request()
        before = deepcopy(raw)
        self.assertEqual(run_request(raw), run_request(raw))
        self.assertEqual(raw, before)

    def test_probabilities_and_weight_conserve(self):
        model = MajorityModel(request())
        for ev in model.baseline()["member_evaluations"].values():
            self.assertAlmostEqual(sum(ev["probabilities"].values()), 1)
        self.assertEqual(sum(model._ballot(7)["result"]["counts"].values()), 5)
        self.assertNotIn("GUEST", model._ballot(7)["result"]["member_ballots"])

    def test_membership_and_party_tags_do_not_automatically_create_ties(self):
        raw = request()
        before = MajorityModel(raw).baseline()
        for member in raw["members"]:
            member["groups"] = ["ALL_OWNED_BY_PROPOSER"]
        after = MajorityModel(raw).baseline()
        for key in before["member_evaluations"]:
            self.assertEqual(before["member_evaluations"][key]["probabilities"], after["member_evaluations"][key]["probabilities"])
        self.assertIn("proposer_trust", after["member_evaluations"]["B"]["unknown"])

    def test_employment_not_personal_allegiance(self):
        for kind in ("employment", "appointment", "shared_membership", "shared_region"):
            raw = request()
            raw["ties"][0]["evidence_kind"] = kind
            with self.assertRaises(ValueError):
                MajorityModel(raw)

    def test_issue_revision_changes_member_preferences(self):
        raw = request()
        first = MajorityModel(raw).evaluate_member("B")["probabilities"]["yes"]
        raw["issue"]["position"] = deepcopy(raw["members"][1]["position"])
        raw["issue"]["version"] = "amended_2"
        self.assertGreater(MajorityModel(raw).evaluate_member("B")["probabilities"]["yes"], first)

    def test_secret_votes_remove_individual_observability_not_policy(self):
        raw = request()
        first = MajorityModel(raw).evaluate_member("A")
        raw["body"]["secret"] = True
        model = MajorityModel(raw)
        second = model.evaluate_member("A")
        self.assertEqual(second["weighted_terms"]["discipline"], 0)
        self.assertEqual(second["weighted_terms"]["policy"], first["weighted_terms"]["policy"])
        self.assertIsNone(model._ballot(3)["result"]["member_ballots"])
        event = outcome_event(model, model._ballot(3))
        self.assertIsNone(event["individual_ballots"])
        self.assertIsNone(event["automatic_poll_delta"])
        self.assertFalse(event["automatic_law_in_force"])

    def test_knowledge_cutoff(self):
        raw = request()
        raw["ties"][0].update(source_status="OBSERVED", source_ids=["future_report"], available_from="2026-10-24")
        with self.assertRaises(ValueError):
            MajorityModel(raw)

    def test_observed_requires_sources_and_date(self):
        raw = request()
        raw["members"][0]["source_status"] = "OBSERVED"
        with self.assertRaises(ValueError):
            MajorityModel(raw)

    def test_duplicate_member_and_incomplete_roster_rejected(self):
        raw = request()
        raw["members"].append(deepcopy(raw["members"][0]))
        with self.assertRaises(ValueError):
            MajorityModel(raw)
        raw = request()
        raw["members"].pop(0)
        with self.assertRaises(ValueError):
            MajorityModel(raw)

    def test_no_extra_vote_by_office(self):
        raw = request()
        raw["members"][0]["weight"] = 2
        with self.assertRaises(ValueError):
            MajorityModel(raw)

    def test_input_order_does_not_change_sample(self):
        raw = request()
        before = MajorityModel(raw)._ballot(18)["result"]
        raw["members"].reverse()
        self.assertEqual(before, MajorityModel(raw)._ballot(18)["result"])

    def test_declared_shared_contingency_affects_multiple_members(self):
        model = MajorityModel(request())
        first = model.evaluate_member("B")
        second = model.evaluate_member("B", {"late_financing_report": .5})
        self.assertGreater(second["probabilities"]["yes"], first["probabilities"]["yes"])
        self.assertEqual(model.evaluate_member("A")["probabilities"], model.evaluate_member("A", {"late_financing_report": .5})["probabilities"])

    def test_red_line_not_overridden_by_network(self):
        raw = request()
        raw["members"][1]["max_policy_distance"] = .1
        self.assertEqual(MajorityModel(raw).evaluate_member("B")["probabilities"]["yes"], 0)

    def test_all_abstain_tie_baseline(self):
        raw = request()
        raw["ties"] = []
        for member in raw["members"]:
            member["weights"] = {}
            member["attendance"] = 1
        self.assertEqual(MajorityModel(raw).baseline()["result"]["counts"]["abstain"], 5)

    def test_invalid_numeric_and_unknown_fields(self):
        for value in (float("nan"), float("inf"), True, -1):
            raw = request()
            raw["members"][0]["temperature"] = value
            with self.assertRaises(ValueError):
                MajorityModel(raw)
        raw = request()
        raw["ties"][0]["loyalty_from_appointment"] = 1
        with self.assertRaises(ValueError):
            MajorityModel(raw)

    def test_legacy_entry_point_is_opt_in(self):
        from hakoniwa.plugins.majorities.service import MemberVoteService
        self.assertEqual(MemberVoteService().run_member_vote(request()), run_request(request()))

    def test_no_fabricated_runtime_relationship(self):
        from types import SimpleNamespace
        engine = SimpleNamespace(runtime={"A": SimpleNamespace(relationships={})})
        self.assertIsNone(runtime_tie(engine, "A", "P", issue_id="x", available_from="2026-10-23"))

    def test_existing_persona_choice_not_randomly_overridden(self):
        raw = request()
        raw["members"][1].update(decided_vote="yes", source_status="RUNTIME_MODEL_STATE", source_ids=["persona_decision:B"], available_from="2026-10-23", attendance=1)
        model = MajorityModel(raw)
        for seed in range(20):
            self.assertEqual(model._ballot(seed)["result"]["member_ballots"]["B"], "yes")
        self.assertFalse(model.evaluate_member("B")["local_utilities_used_for_choice"])

    def test_public_pledge_not_accepted_as_decided_vote(self):
        raw = request()
        raw["members"][0]["decided_vote"] = "yes"
        with self.assertRaises(ValueError):
            MajorityModel(raw)

    def test_real_persona_adapter_calls_existing_engine(self):
        from unittest.mock import Mock
        from hakoniwa.persona_v2 import ActionOption, FreeDecision
        from hakoniwa.plugins.majorities.integration import persona_ballot_decision
        engine = Mock()
        engine.decide.return_value = FreeDecision("A", "vote_no", {}, 1)
        actions = {c: ActionOption("vote_" + c) for c in ("yes", "no", "abstain")}
        result = persona_ballot_decision(engine, "A", actions, {}, issue_id="i", available_from="2026-10-23")
        self.assertEqual(result["member_patch"]["decided_vote"], "no")
        engine.decide.assert_called_once()

    def test_expired_future_and_unverified_historical_rules_rejected(self):
        for patch in (
            {"available_from":"2026-10-24"},
            {"valid_until":"2026-10-22"},
            {"source_status":"HISTORICAL_REFERENCE", "available_from":"2018-04-17"},
        ):
            raw = request()
            raw["rule"].update(patch)
            with self.assertRaises(ValueError):
                MajorityModel(raw)

    def test_fixed_actual_ballot_pivotal_switches(self):
        raw = request()
        for i, member in enumerate(raw["members"]):
            member.update(decided_vote="yes" if i < 3 else "no", source_status="RUNTIME_MODEL_STATE", source_ids=["test_runtime"], available_from="2026-10-23", attendance=1)
        ballot = MajorityModel(raw).baseline()["result"]
        self.assertTrue(ballot["passed"])
        self.assertEqual(set(ballot["counting_only_pivotal_switches"]), {"A", "B", "C"})

    def test_main_cli_and_standalone_cli(self):
        import subprocess
        import sys
        for module in ("hakoniwa", "hakoniwa.plugins.majorities"):
            proc = subprocess.run([sys.executable, "-m", module, "majorities", "verify", "--request", str(FIXTURE)] if module == "hakoniwa" else [sys.executable, "-m", module, "verify", "--request", str(FIXTURE)], capture_output=True, text=True)
            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertTrue(json.loads(proc.stdout)["valid"])

    def test_direct_count_cli_contract(self):
        from hakoniwa.plugins.majorities.__main__ import execute
        result = execute("count", {"as_of":"2026-10-23", "rule":{"total_weight":5}, "counts":counts(3, 2)})
        self.assertEqual(result["status"], "ADOPTED")

    def test_canonical_persona_card_can_feed_this_ballot(self):
        from hakoniwa.persona_v2 import ActionOption, FreeAgentDecisionEngine
        from hakoniwa.plugins.majorities.integration import persona_ballot_decision
        engine = FreeAgentDecisionEngine.from_json(Path(__file__).parents[1] / "data/personas/cards_pss.json")
        actions = {c: ActionOption("vote_" + c) for c in ("yes", "no", "abstain")}
        bridged = persona_ballot_decision(engine, "Merz", actions, engine.cards["Merz"].initial_resources,
                                         issue_id="test_ballot", available_from="2026-10-23")
        raw = request()
        raw["members"][0].update(bridged["member_patch"])
        # This member was renamed; remove test-only ties/assessments/loadings.
        raw["ties"] = []
        raw["issue"]["assessments"].pop("A")
        self.assertEqual(MajorityModel(raw).evaluate_member("Merz")["choice_source"], "EXISTING_PERSONA_DECISION")


class PowerTests(unittest.TestCase):
    def test_symmetric_game(self):
        result = power_indices({"A":["a"], "B":["b"], "C":["c"]}, 2)
        for name in ("banzhaf_normalized", "shapley_shubik"):
            for value in result[name].values():
                self.assertAlmostEqual(value, 1 / 3)

    def test_dictator_and_dummy(self):
        result = power_indices({"A":["a","b","c"], "B":["d"]}, 3)
        self.assertEqual(result["shapley_shubik"], {"A":1, "B":0})

    def test_overlap_rejected(self):
        with self.assertRaises(ValueError):
            power_indices({"workers":["a","b"], "middle":["b","c"]}, 2)

    def test_feasibility_separate_from_classical_indices(self):
        players = {"A":["a"], "B":["b"], "C":["c"]}
        first = power_indices(players, 2)
        second = power_indices(players, 2, [("A", "B")])
        self.assertEqual(first["shapley_shubik"], second["shapley_shubik"])
        self.assertLess(sum(second["feasible_swing_counts"].values()), sum(first["feasible_swing_counts"].values()))


if __name__ == "__main__":
    unittest.main()
