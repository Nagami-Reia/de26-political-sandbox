import unittest
import json
from pathlib import Path

from hakoniwa.free_agent_game import FreeAgentGame, FreeAgentNode, WorldAction
from hakoniwa.information_filter import AccessRule, InformationFilter
from hakoniwa.persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine, WorldEvent
from hakoniwa.political_state import PoliticalAction, PoliticalState, StateVariable


CARDS = Path(__file__).resolve().parents[1] / "data" / "personas" / "cards_pss.json"
EXPANSION_RATIONALITY = Path(__file__).resolve().parents[1] / "data" / "personas" / "rationality_profiles_expansion_2026_09.json"


class PersonaV2Tests(unittest.TestCase):
    def engine(self):
        return FreeAgentDecisionEngine.from_json(CARDS)

    def test_all_sixteen_cards_load(self):
        engine = self.engine()
        self.assertEqual(len(engine.cards), 17)
        self.assertIn("Wuest", engine.cards)
        self.assertIn("Evers", engine.cards)

    def test_canonical_deck_contains_merged_revisions_and_additions(self):
        engine = FreeAgentDecisionEngine.from_json(CARDS)
        self.assertEqual(len(engine.cards), 17)
        self.assertIn("Dobrindt", engine.cards)
        self.assertIn("Reiche", engine.cards)
        self.assertEqual(engine.cards["Wadephul"].source_ids[0], "JW1")

    def test_expansion_card_values_and_rationality_profiles_are_normalized(self):
        payload = json.loads(CARDS.read_text(encoding="utf-8"))
        failures = []

        def walk(value, path=()):
            if isinstance(value, dict):
                for key, item in value.items():
                    walk(item, path + (key,))
            elif isinstance(value, list):
                for index, item in enumerate(value):
                    walk(item, path + (str(index),))
            elif isinstance(value, float):
                if path[-1] != "valence" and not 0.0 <= value <= 1.0:
                    failures.append((path, value, "range"))
                if round(value, 3) != value:
                    failures.append((path, value, "precision"))

        walk(payload)
        rationality = json.loads(EXPANSION_RATIONALITY.read_text(encoding="utf-8"))
        for actor, values in rationality["actors"].items():
            self.assertAlmostEqual(sum(values.values()), 1.0, msg=actor)
        self.assertEqual(failures, [])

    def test_card_quantities_are_normalized_and_three_decimal(self):
        payload = json.loads(CARDS.read_text(encoding="utf-8"))
        failures = []

        def walk(value, path=()):
            if isinstance(value, dict):
                for key, item in value.items():
                    walk(item, path + (key,))
            elif isinstance(value, list):
                for index, item in enumerate(value):
                    walk(item, path + (str(index),))
            elif isinstance(value, float):
                # Valence and world deltas are signed directions, not card parameters.
                if path[-1] != "valence" and not 0.0 <= value <= 1.0:
                    failures.append((path, value, "range"))
                if round(value, 3) != value:
                    failures.append((path, value, "precision"))

        walk(payload)
        self.assertEqual(failures, [])

    def test_environment_can_hard_reject_identity_favourite(self):
        engine = self.engine()
        actions = [
            ActionOption(
                "direct_reform",
                value_impacts={"reform_achievement": 0.9, "strategic_direction": 0.8},
                required_resources={"parliamentary_base": 0.75},
                upside=0.9,
                downside=0.4,
                identity_tags=("reform", "agency"),
                control_domains=("direction",),
                restores_control=0.8,
            ),
            ActionOption(
                "build_majority_first",
                value_impacts={"reform_achievement": 0.4, "unity": 0.6},
                required_resources={"parliamentary_base": 0.45},
                upside=0.5,
                downside=0.15,
                identity_tags=("organization",),
                control_domains=("organization",),
                restores_control=0.4,
                conflict_strategy="institutionalize",
            ),
        ]
        decision = engine.decide("Merz", actions, {"parliamentary_base": 0.60})
        self.assertEqual(decision.chosen_action, "build_majority_first")
        self.assertTrue(decision.scores["direct_reform"].hard_rejections)

    def test_objective_environment_fit_can_defeat_identity_favourite(self):
        engine = self.engine()
        actions = [
            ActionOption(
                "grand_reform", value_impacts={"strategic_direction": .90},
                upside=.90, downside=.20, objective_feasibility=.08,
                identity_tags=("agency", "strategic_direction"),
                information_confidence=.80,
            ),
            ActionOption(
                "workable_compromise", value_impacts={"unity": .55},
                upside=.48, downside=.12, objective_feasibility=.92,
                identity_tags=("unity",), information_confidence=.90,
            ),
        ]
        decision = engine.decide("Merz", actions, engine.cards["Merz"].initial_resources)
        self.assertEqual(decision.chosen_action, "workable_compromise")
        self.assertLess(
            decision.scores["grand_reform"].environment_compatibility,
            decision.scores["workable_compromise"].environment_compatibility,
        )

    def test_confidence_uses_prediction_error_and_repeated_success_diminishes(self):
        engine = self.engine()
        state = engine.runtime["Merz"].state
        deltas = []
        for _ in range(4):
            before = state.confidence
            engine.apply_outcome("Merz", ActionOutcome(
                "routine_delivery", .80, expected_success=.75,
                evidence_quality=.80, outcome_scope=.70,
            ))
            deltas.append(state.confidence - before)
        self.assertGreater(deltas[0], deltas[-1])
        self.assertLess(sum(deltas), .080)
        before_failure = state.confidence
        engine.apply_outcome("Merz", ActionOutcome(
            "routine_delivery", .15, expected_success=.80,
            evidence_quality=.90, outcome_scope=.90,
        ))
        self.assertLess(state.confidence, before_failure - .035)

    def test_failed_strategy_repetition_creates_visible_penalty(self):
        engine = self.engine()
        action = ActionOption(
            "node__public_signal__public_pressure", upside=.60, downside=.40,
            uncertainty=.40, objective_feasibility=.75,
            conflict_strategy="attack", identity_tags=("agency",),
        )
        before = engine.score("Merz", action, engine.cards["Merz"].initial_resources, {}).repetition_modifier
        for _ in range(3):
            engine.apply_outcome("Merz", ActionOutcome(action.key, .20, expected_success=.65))
        after = engine.score("Merz", action, engine.cards["Merz"].initial_resources, {}).repetition_modifier
        self.assertEqual(before, 0.0)
        self.assertLess(after, -2.0)

    def test_current_state_can_reverse_same_character_choice(self):
        engine = self.engine()
        actions = [
            ActionOption(
                "public_challenge",
                goal_impacts={"seize_window": 0.9},
                value_impacts={"future_option": 0.8, "governability": -0.1},
                required_resources={"organization_base": 0.60},
                upside=0.95,
                downside=0.25,
                uncertainty=0.12,
                irreversibility=0.25,
                effort=0.45,
                visibility=0.80,
                information_confidence=0.90,
                control_domains=("process",),
                restores_control=0.90,
                conflict_strategy="attack",
                identity_tags=("timing", "process_control", "prepared_structure"),
                risk_tags=("public", "prepared_structure"),
            ),
            ActionOption(
                "coalition_coordination",
                goal_impacts={"seize_window": -0.2},
                value_impacts={"governability": 0.4, "broad_acceptance": 0.4, "future_option": 0.15},
                required_resources={"network_capital": 0.45},
                upside=0.50,
                downside=0.12,
                uncertainty=0.08,
                effort=0.30,
                visibility=0.20,
                information_confidence=0.92,
                control_domains=("coalition", "relationships"),
                restores_control=0.35,
                conflict_strategy="negotiate",
                identity_tags=("coalition", "acceptance", "connection"),
            ),
        ]
        resources = {"organization_base": 0.90, "network_capital": 0.90}
        calm = engine.decide("Wuest", actions, resources)
        self.assertEqual(calm.chosen_action, "coalition_coordination")

        runtime = engine.runtime["Wuest"].state
        runtime.energy = 0.95
        runtime.pressure = 0.05
        runtime.confidence = 0.95
        runtime.control = 0.05
        # The world also changes the live goal. The card remains unchanged.
        urgent = engine.decide("Wuest", actions, resources, current_goals={"seize_window": 1.0})
        self.assertEqual(urgent.chosen_action, "public_challenge")

    def test_sensitivity_map_changes_event_damage(self):
        loss_engine = self.engine()
        media_engine = self.engine()
        loss = loss_engine.apply_event(
            "Wuest", WorldEvent("loss", "control_crisis", 0.700, ("loss_of_control",), surprise=0.800)
        )
        media = media_engine.apply_event(
            "Wuest", WorldEvent("press", "press_crisis", 0.700, ("media_attack",), surprise=0.800)
        )
        self.assertGreater(loss["impact"]["effective_damage"], media["impact"]["effective_damage"])

    def test_pss_formula_uses_normalized_resistance_and_sensitivity(self):
        engine = self.engine()
        event = WorldEvent("failure", "policy_failure", 0.200, ("failure",))
        impact = engine.pss.calculate_impact("Merz", event)
        # Merz resistance .900; failure sensitivity .500 maps to multiplier 1.000.
        self.assertAlmostEqual(impact.effective_damage, 0.020, places=3)

    def test_time_alone_does_not_restore_confidence_control_or_identity(self):
        engine = self.engine()
        before = engine.runtime["Wuest"].state
        frozen = (before.confidence, before.control, before.identity_integrity)
        engine.advance_time("Wuest", 30)
        after = engine.runtime["Wuest"].state
        self.assertEqual((after.confidence, after.control, after.identity_integrity), frozen)

    def test_relationship_memory_affects_negotiation_score(self):
        engine = self.engine()
        action = ActionOption(
            "negotiate_with_merz",
            value_impacts={"governability": 0.5},
            upside=0.4,
            downside=0.1,
            conflict_strategy="negotiate",
            target_actor="Merz",
            identity_tags=("coalition", "connection"),
        )
        resources = {"network_capital": 0.8}
        before = engine.score("Wuest", action, resources, {}, ()).resource_feasibility
        engine.runtime["Wuest"].relationships["Merz"].trust = 0.05
        engine.runtime["Wuest"].relationships["Merz"].operational_reliability = 0.10
        after = engine.score("Wuest", action, resources, {}, ()).resource_feasibility
        self.assertLess(after, before)

    def test_free_agent_game_applies_chosen_world_action(self):
        personas = self.engine()
        state = PoliticalState(
            {"formal_power_view": StateVariable("formal_power_view", 90), "world_stability": StateVariable("world_stability", 50)},
            {},
            {},
        )
        info = InformationFilter({"Merz": {"formal_power_view": AccessRule(0.95), "world_stability": AccessRule(0.80)}})
        act = WorldAction(
            PoliticalAction("stabilize", {"immediate": {"world_stability": 5}, "medium": {}, "long": {}}),
            ActionOption(
                "stabilize",
                value_impacts={"strategic_direction": 0.5, "unity": 0.5},
                required_resources={"formal_power": 0.7},
                upside=0.4,
                downside=0.05,
                identity_tags=("strategic_direction", "authority"),
                control_domains=("direction",),
            ),
        )
        node = FreeAgentNode("n", "Merz", (act,))
        game = FreeAgentGame(
            state,
            {"n": node},
            personas,
            info,
            {"Merz": {"formal_power": "variable:formal_power_view"}},
        )
        out = game.run("n")
        self.assertEqual(out["trace"][0]["chosen_action"], "stabilize")
        self.assertEqual(out["world_state"]["variables"]["world_stability"]["value"], 55)


if __name__ == "__main__":
    unittest.main()
