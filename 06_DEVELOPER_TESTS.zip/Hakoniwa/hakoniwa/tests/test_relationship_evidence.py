"""Relationship feedback requires evidence and explicit causal attribution."""
from dataclasses import asdict
from pathlib import Path
import unittest

from hakoniwa.persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine, RelationshipMemory, WorldEvent


class RelationshipEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.engine = FreeAgentDecisionEngine.from_json(
            Path(__file__).resolve().parents[1] / 'data/personas/cards_pss.json')
        self.rel = RelationshipMemory('Frei', loyalty_injury=.8, structural_unreliability=.6)
        self.engine.runtime['Merz'].relationships['Frei'] = self.rel

    def test_zero_evidence_or_scope_does_not_change_relationship(self):
        before = asdict(self.rel)
        for success in (.2, 1.):
            for evidence, scope in ((0., 1.), (1., 0.)):
                self.engine.apply_outcome('Merz', ActionOutcome('repair', success,
                    target_actor='Frei', relationship_effect='repair',
                    relationship_delta={'trust':.2, 'dependency':{'organizational':.1}},
                    evidence_quality=evidence, outcome_scope=scope))
                self.assertEqual(before, asdict(self.rel))

    def test_successful_attack_and_routine_failure_are_not_repairs(self):
        before = asdict(self.rel)
        for success in (1., .1):
            self.engine.apply_outcome('Merz', ActionOutcome('public_attack', success, target_actor='Frei'))
        self.assertEqual(before, asdict(self.rel))

    def test_explicit_repair_scales_with_evidence(self):
        before = self.rel.loyalty_injury
        row = self.engine.apply_outcome('Merz', ActionOutcome('negotiation', 1.,
            target_actor='Frei', relationship_effect='repair', evidence_quality=.5, outcome_scope=.4))
        self.assertAlmostEqual(before-self.rel.loyalty_injury, .18*.5*.4)
        self.assertEqual(row['relationship_evidence'], .2)

    def test_failed_repair_does_not_force_breakup(self):
        self.engine.apply_outcome('Merz', ActionOutcome('negotiation', .1,
            target_actor='Frei', relationship_effect='repair'))
        self.assertEqual(self.rel.failed_response_count, 1)
        self.assertEqual(self.rel.betrayal_count, 0)
        self.assertEqual(self.rel.loyalty_injury, .8)

    def test_reliability_loss_not_betrayal_but_repeated_evidence_accumulates(self):
        for i in range(3):
            self.engine.apply_event('Merz', WorldEvent(str(i), 'delay', .1, (),
                relationship_deltas={'Frei':{'operational_reliability':-.05}}))
        self.assertEqual(self.rel.betrayal_count, 0)
        self.assertEqual(self.rel.loyalty_injury, .8)
        self.assertGreater(self.rel.structural_unreliability, .6)
        self.assertEqual(self.rel.pattern_exposures['delay'], 3)

    def test_explicit_loyalty_breach_can_injure(self):
        self.engine.apply_event('Merz', WorldEvent('breach', 'broken_pledge', .1, ('loyalty_breach',),
            relationship_deltas={'Frei':{'trust':-.1}}))
        self.assertEqual(self.rel.betrayal_count, 1)
        self.assertGreater(self.rel.loyalty_injury, .8)
        self.assertEqual(self.rel.structural_unreliability, .6)

    def test_duplicate_event_is_fully_idempotent_per_actor(self):
        event = WorldEvent('report', 'delay', .1, (), relationship_deltas={'Frei':{'trust':-.1}})
        self.engine.apply_event('Merz', event)
        before = asdict(self.engine.runtime['Merz'])
        self.assertEqual(self.engine.apply_event('Merz', event)['status'], 'DUPLICATE_IGNORED')
        self.assertEqual(before, asdict(self.engine.runtime['Merz']))
        self.assertNotEqual(self.engine.apply_event('Frei', event).get('status'), 'DUPLICATE_IGNORED')

    def test_outcome_identity_distinguishes_retry_from_new_attempt(self):
        outcome = ActionOutcome('repair', 1., target_actor='Frei', relationship_effect='repair', outcome_id='attempt1')
        self.engine.apply_outcome('Merz', outcome)
        before = asdict(self.engine.runtime['Merz'])
        self.assertEqual(self.engine.apply_outcome('Merz', outcome)['status'], 'DUPLICATE_IGNORED')
        self.assertEqual(before, asdict(self.engine.runtime['Merz']))
        self.engine.apply_outcome('Merz', ActionOutcome('repair', 1., target_actor='Frei',
            relationship_effect='repair', outcome_id='attempt2'))
        self.assertLess(self.rel.loyalty_injury, before['relationships']['Frei']['loyalty_injury'])

    def test_explicit_control_and_identity_restoration_require_evidence(self):
        before = asdict(self.engine.runtime['Merz'].state)
        self.engine.apply_outcome('Merz', ActionOutcome('unseen', 1., workload=0., evidence_quality=0.,
            control_restoration=.2, identity_alignment=.2))
        self.assertEqual(before, asdict(self.engine.runtime['Merz'].state))

    def test_unknown_relationship_has_no_invented_bonus_or_feasibility_penalty(self):
        self.engine.runtime['Merz'].relationships.pop('unknown', None)
        score = self.engine.score('Merz', ActionOption('talk', target_actor='unknown',
            relationship_posture='repair', conflict_strategy='negotiate'), {}, {})
        self.assertEqual(score.relationship_history_modifier, 0.)
        self.assertEqual(score.diagnostics['relationship']['factor'], 1.)
        self.assertEqual(score.diagnostics['relationship']['evidence_status'], 'UNKNOWN_NEUTRAL')
        self.assertNotIn('unknown', self.engine.runtime['Merz'].relationships)

    def test_unverified_failure_cannot_be_learned_as_known_failure(self):
        for success in (0., 1.):
            self.engine.apply_outcome('Merz', ActionOutcome('attempt', success,
                workload=0., evidence_quality=0.))
        score = self.engine.score('Merz', ActionOption('attempt'), {}, {})
        self.assertEqual(score.diagnostics['prior_family_success'], .5)
        self.assertEqual(score.diagnostics['prior_family_evidence_mass'], 0.)
        self.assertEqual(score.diagnostics['recent_family_uses'], 2)
