"""Node count is not institutional time, causal scale, or new evidence."""
from copy import deepcopy
from dataclasses import asdict, replace
import json
from pathlib import Path
import unittest
import tempfile

from hakoniwa.free_agent_game import WorldAction
from hakoniwa.information_filter import InformationFilter
from hakoniwa.institutional_logic import InstitutionalLogic
from hakoniwa.living_world_config import load_living_world
from hakoniwa.organizational_response import OrganizationalBloc, PoliticalOrganization, OrganizationalRequest, OrganizationalResponseEngine
from hakoniwa.persona_v2 import ActionOption, FreeAgentDecisionEngine
from hakoniwa.political_agency import AgencyHorizon
from hakoniwa.political_state import PoliticalAction, PoliticalState, StateVariable
from hakoniwa.rationality_evaluation import ActorRationalityProfile, RationalityEvaluator
from hakoniwa.scenario_reporting import ScenarioReportingPolicy
from hakoniwa.simulation_orchestrator import LayeredConfiguration, LayeredSimulationOrchestrator, SimulationNodeV3, V3FeatureFlags
from hakoniwa.system_feedback import SystemFeedbackAssessor, SystemFeedbackContext, SystemFeedbackLedger

ROOT = Path(__file__).resolve().parents[1]
CARDS = ROOT / "data/personas/cards_pss.json"
ENV = ROOT / "data/environments/2026-07-31/environment.json"


class FeedbackLedgerTests(unittest.TestCase):
    def setUp(self):
        self.logic = InstitutionalLogic.neutral()
        self.agency = AgencyHorizon(.5, .5, .5, .5)
        self.ledger = SystemFeedbackLedger()
        self.choice = ActionOption("attempt", necessity_frame_alignment=1,
            instrumental_impacts={"capacity": .8}, substantive_impacts={"deliberation": .4})
        engine = FreeAgentDecisionEngine.from_json(CARDS)
        evaluation = RationalityEvaluator().evaluate(self.choice, engine.score("Merz", self.choice, {}, {}), ActorRationalityProfile())
        self.feedback = SystemFeedbackAssessor().assess(self.choice, evaluation, self.logic, .8)

    def apply(self, context, *, enabled=True, now=100, actor="Merz", feedback=None):
        self.logic, self.agency, row = self.ledger.apply(feedback or self.feedback,
            context, self.logic, self.agency, actor=actor, enabled=enabled, now_minute=now)
        return row

    def test_repeated_same_event_commits_once(self):
        context = SystemFeedbackContext("reform", 1)
        self.assertTrue(self.apply(context)["applied"])
        before = (self.logic, self.agency)
        for _ in range(9):
            self.assertEqual(self.apply(context)["status"], "ALREADY_SETTLED")
        self.assertEqual((self.logic, self.agency), before)

    def test_distinct_events_can_have_distinct_effects(self):
        self.apply(SystemFeedbackContext("one", 1))
        self.apply(SystemFeedbackContext("two", 1))
        self.assertAlmostEqual(self.logic.necessity_claim_strength, .16)
        self.assertEqual(len(self.ledger.events), 2)

    def test_declared_scale_changes_deltas_not_observed_success(self):
        row = self.apply(SystemFeedbackContext("small", .25))
        self.assertAlmostEqual(self.logic.necessity_claim_strength, .02)
        self.assertEqual(row["scaled_feedback"]["operational_success"], self.feedback.operational_success)
        self.assertAlmostEqual(row["scaled_feedback"]["agency_delta"], .25*self.feedback.agency_delta)

    def test_zero_scope_changes_no_state_but_is_registered(self):
        before = (self.logic, self.agency)
        self.assertEqual(self.apply(SystemFeedbackContext("zero", 0))["status"], "ZERO_SCOPE")
        self.assertEqual((self.logic, self.agency), before)
        self.assertEqual(len(self.ledger.events), 1)

    def test_missing_context_is_not_a_node_sized_default(self):
        before = (self.logic, self.agency)
        for _ in range(10):
            self.assertEqual(self.apply(None)["status"], "MISSING_CAUSAL_CONTEXT")
        self.assertEqual((self.logic, self.agency), before)
        self.assertFalse(self.ledger.events)

    def test_diagnostic_phase_neither_mutates_nor_consumes_event(self):
        context = SystemFeedbackContext("reform", .5, "DIAGNOSTIC")
        self.assertEqual(self.apply(context)["status"], "DIAGNOSTIC_ONLY")
        self.assertFalse(self.ledger.events)
        self.assertTrue(self.apply(replace(context, phase="SETTLED"))["applied"])

    def test_disabled_flag_does_not_consume_event(self):
        context = SystemFeedbackContext("reform", .5)
        self.assertEqual(self.apply(context, enabled=False)["status"], "DISABLED")
        self.assertFalse(self.ledger.events)
        self.assertTrue(self.apply(context)["applied"])

    def test_invalid_contexts_are_rejected(self):
        for key, scale in (("", 1), (" ", 1), ("ok", -.1), ("ok", 1.1), ("ok", True), ("ok", float("nan")), ("ok", "0.5")):
            with self.subTest(key=key, scale=scale), self.assertRaises(ValueError):
                SystemFeedbackContext(key, scale)
        with self.assertRaises(ValueError):
            SystemFeedbackContext("ok", 1, phase="PARTIAL")
        with self.assertRaises(ValueError):
            SystemFeedbackContext("ok", 1, occurred_at_minute=True)

    def test_conflicting_identity_scale_or_timing_cannot_recommit(self):
        context = SystemFeedbackContext("reform", .5, occurred_at_minute=90)
        self.apply(context)
        before = (self.logic, self.agency, self.ledger.payload())
        for altered, actor in ((replace(context, institutional_scale=1), "Merz"),
                               (replace(context, occurred_at_minute=95), "Merz"), (context, "Frei")):
            with self.subTest(altered=altered, actor=actor), self.assertRaises(ValueError):
                self.apply(altered, actor=actor)
        self.assertEqual((self.logic, self.agency, self.ledger.payload()), before)

    def test_future_event_does_not_consume_or_apply(self):
        with self.assertRaisesRegex(ValueError, "future"):
            self.apply(SystemFeedbackContext("future", 1, occurred_at_minute=101))
        self.assertFalse(self.ledger.events)
        self.assertEqual(self.logic, InstitutionalLogic.neutral())

    def test_later_reporting_does_not_reapply_an_earlier_event(self):
        context = SystemFeedbackContext("reform", 1, occurred_at_minute=90)
        self.apply(context)
        before = self.logic
        self.assertEqual(self.apply(context, now=100000)["status"], "ALREADY_SETTLED")
        self.assertEqual(self.logic, before)

    def test_changed_replay_diagnostics_are_visible_not_an_extra_update(self):
        context = SystemFeedbackContext("reform", 1)
        self.apply(context)
        before = self.logic
        row = self.apply(context, feedback=replace(self.feedback, legitimacy_delta=.4))
        self.assertTrue(row["replay_feedback_changed"])
        self.assertFalse(row["applied"])
        self.assertEqual(self.logic, before)

    def test_ledger_json_restore_preserves_deduplication(self):
        context = SystemFeedbackContext("reform", .5)
        self.apply(context)
        self.ledger = SystemFeedbackLedger.from_payload(json.loads(json.dumps(self.ledger.payload())))
        self.assertEqual(self.apply(context)["status"], "ALREADY_SETTLED")

    def test_payload_and_returned_records_do_not_mutate_ledger(self):
        row = self.apply(SystemFeedbackContext("reform", .5))
        before = self.ledger.payload()
        row["raw_feedback"]["agency_delta"] = 999
        exposed = self.ledger.payload()
        exposed["events"]["reform"]["context"]["institutional_scale"] = 0
        self.assertEqual(self.ledger.payload(), before)

    def test_small_independent_effects_are_not_rounded_away_each_step(self):
        for i in range(10):
            self.apply(SystemFeedbackContext(f"small:{i}", .001))
        self.assertAlmostEqual(self.logic.necessity_claim_strength, .0008)
        self.assertEqual(self.logic.payload()["necessity_claim_strength"], .001)

    def game(self, contexts, *, organizations=None, request=None):
        nodes = {}
        for index, context in enumerate(contexts):
            key = f"n{index}"
            pair = WorldAction(PoliticalAction(key, {"immediate": {}},
                next_node=f"n{index+1}" if index+1 < len(contexts) else None),
                replace(self.choice, key=key), organization_request=request,
                organization_effects={"x": 1} if request is not None else {})
            nodes[key] = SimulationNodeV3(key, "Merz", (pair,), system_feedback_context=context)
        config = replace(LayeredConfiguration.from_environment_json(ENV), logic=InstitutionalLogic.neutral(),
            flags=V3FeatureFlags(system_feedback_mutates_world=True))
        state = PoliticalState({"x": StateVariable("x", 50)}, {}, {}, now_minute=0 if request is not None else 100)
        return LayeredSimulationOrchestrator(state, nodes, FreeAgentDecisionEngine.from_json(CARDS),
            InformationFilter({"Merz": {}}, delivery_only=True), {}, config, organizations=organizations,
            reporting_policy=ScenarioReportingPolicy.diagnostics_only())

    def test_one_node_and_ten_diagnostic_nodes_have_same_final_institutions(self):
        settled = SystemFeedbackContext("reform", .4)
        one, ten = self.game([settled]), self.game([replace(settled, phase="DIAGNOSTIC")]*9 + [settled])
        a, b = one.run("n0"), ten.run("n0")
        self.assertEqual(a["institutional_logic"], b["institutional_logic"])
        self.assertEqual(one.agency.payload(), ten.agency.payload())
        self.assertEqual(sum(r["system_feedback_applied"] for r in b["trace"]), 1)

    def test_ten_repeated_settlements_are_also_deduplicated_in_main_pipeline(self):
        context = SystemFeedbackContext("reform", .4)
        one, ten = self.game([context]), self.game([context]*10)
        a, b = one.run("n0"), ten.run("n0")
        self.assertEqual(a["institutional_logic"], b["institutional_logic"])
        self.assertEqual(len(b["system_feedback_ledger"]["events"]), 1)
        self.assertTrue(all(not r["system_feedback_applied"] for r in b["trace"][1:]))

    def test_node_json_context_is_normalized_and_missing_context_is_reported(self):
        context = SystemFeedbackContext("reform", .4)
        game = self.game([asdict(context)])
        self.assertEqual(game.nodes["n0"].system_feedback_context, context)
        result = self.game([None]).run("n0")
        self.assertEqual(result["trace"][0]["system_feedback_application"]["status"], "MISSING_CAUSAL_CONTEXT")
        self.assertFalse(result["trace"][0]["system_feedback_applied"])

    def test_organization_submission_waits_for_real_response_before_feedback(self):
        bloc = OrganizationalBloc("bloc", 1, {"A": .2, "B": .8}, {"fit": 1}, {"Merz": 1}, 1)
        organizations = OrganizationalResponseEngine({"org": PoliticalOrganization("org", (bloc,))})
        request = OrganizationalRequest("request", "org", "Merz", "A", 1, 10, {"fit": 1})
        context = SystemFeedbackContext("endorsement", .2)
        game = self.game([context], organizations=organizations, request=request)
        game.run("n0")
        self.assertFalse(game.system_feedback_ledger.events)
        game.state.now_minute = 10
        rows = game.settle_organizational_responses()
        self.assertEqual(len(rows), 1)
        self.assertTrue(rows[0]["system_feedback_applied"])
        self.assertEqual(len(game.system_feedback_ledger.events), 1)
        self.assertEqual(game.settle_organizational_responses(), [])

    def test_existing_living_world_loader_keeps_context_and_settlement_metadata(self):
        raw = json.loads((ROOT / "examples/living_world.json").read_text())
        node = raw["nodes"][0]
        context = SystemFeedbackContext("synthetic_loader_event", .2)
        node["system_feedback_context"] = asdict(context)
        node["actions"][0]["effect_status"] = "DETERMINISTIC_ASSUMPTION"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "test.json"
            path.write_text(json.dumps(raw))
            world, _ = load_living_world(path)
        loaded = world.game.nodes[node["key"]]
        self.assertEqual(loaded.system_feedback_context, context)
        self.assertEqual(loaded.actions[0].world.effect_status, "DETERMINISTIC_ASSUMPTION")


if __name__ == "__main__":
    unittest.main()
