"""Numerical regressions independent of historical choices and persona cards."""
import math
import unittest

from hakoniwa.persona_v2 import ActionOption, ActionScore
from hakoniwa.rationality_evaluation import (
    ActorRationalityProfile,
    RationalityEvaluator,
    _normalize_persona_score,
)


class PersonaNormalizationTests(unittest.TestCase):
    def test_zero_remains_neutral(self):
        self.assertEqual(_normalize_persona_score(0.0), 0.5)

    def test_existing_scale_is_unchanged_inside_old_clip_bounds(self):
        for score in (-60.0, -36.0, -18.0, 0.0, 18.0, 36.0, 60.0):
            with self.subTest(score=score):
                expected = 1.0 / (1.0 + math.exp(-score / 18.0))
                self.assertAlmostEqual(_normalize_persona_score(score), expected, places=15)

    def test_scores_remain_ordered_across_and_beyond_old_clip_boundaries(self):
        scores = (-120.0, -90.0, -60.001, -60.0, -59.999,
                  59.999, 60.0, 60.001, 90.0, 120.0)
        normalized = [_normalize_persona_score(score) for score in scores]
        self.assertTrue(all(a < b for a, b in zip(normalized, normalized[1:])))

    def test_positive_and_negative_scores_are_symmetric(self):
        for score in (1.0, 18.0, 60.0, 90.0, 120.0):
            with self.subTest(score=score):
                self.assertAlmostEqual(
                    _normalize_persona_score(score) + _normalize_persona_score(-score),
                    1.0, places=15,
                )

    def test_extreme_finite_scores_do_not_overflow(self):
        for score in (-1e308, -1e6, 1e6, 1e308):
            with self.subTest(score=score):
                result = _normalize_persona_score(score)
                self.assertTrue(math.isfinite(result))
                self.assertGreaterEqual(result, 0.0)
                self.assertLessEqual(result, 1.0)

    def test_hard_rejection_sentinel_maps_to_zero(self):
        self.assertEqual(_normalize_persona_score(-1_000_000.0), 0.0)

    def test_persona_difference_reaches_choice_and_three_decimal_trace(self):
        action = ActionOption("same_environment")
        profile = ActorRationalityProfile(
            instrumental_weight=0.0, substantive_weight=0.0,
            persona_weight=1.0, strategic_weight=0.0,
        )
        evaluations = []
        for total in (75.0, 115.0):
            persona = ActionScore(
                action=action.key, total=total, goal_alignment=0.0,
                resource_feasibility=0.0, risk_calculation=0.0,
                current_state_modifier=0.0, memory_modifier=0.0,
                identity_consistency=0.0, hard_rejections=(), diagnostics={},
            )
            evaluations.append(RationalityEvaluator().evaluate(action, persona, profile))
        lower, higher = evaluations
        self.assertLess(lower.persona_score, higher.persona_score)
        self.assertLess(lower.choice_score, higher.choice_score)
        self.assertEqual(lower.persona_score, round(_normalize_persona_score(75.0), 3))
        self.assertEqual(higher.persona_score, round(_normalize_persona_score(115.0), 3))


if __name__ == "__main__":
    unittest.main()
