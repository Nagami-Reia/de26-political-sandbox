import copy
import json
from pathlib import Path
import unittest

from hakoniwa.polling.party_response import PartyResponseModel, PARTIES
from hakoniwa.political_state import PoliticalState, StateVariable


class PartyResponseTests(unittest.TestCase):
    def setUp(self):
        self.model=PartyResponseModel()
        self.base={"as_of":"2026-10-22","calibration":"yougov_2026_10"}
        self.example=json.loads((Path(__file__).resolve().parents[1]/"plugins/polling/examples/party_response.json").read_text())

    def test_national_calibration_and_zero_event_identity(self):
        result=self.model.predict(self.base)
        for p,target in zip(PARTIES,(18,14,16,5,10,28,3,6)):
            self.assertAlmostEqual(result["parties"][p]["before_percent"],target,places=6)
            self.assertAlmostEqual(result["parties"][p]["delta_pp"],0,places=10)
        self.assertEqual(result["calibration"]["method"],"minimum_KL_national_party_intercept_raking")

    def test_party_functions_have_different_electorate_mixes(self):
        result=self.model.predict(self.base)
        union=result["parties"]["Union"]; left=result["parties"]["Linke"]
        self.assertGreater(union["party_electorate_age_composition"]["<=1955"],left["party_electorate_age_composition"]["<=1955"])
        fn=self.model.functions()["AfD"](self.base)
        self.assertEqual(fn["after_percent"],result["parties"]["AfD"]["after_percent"])

    def test_conservation_and_probability_bounds(self):
        result=self.model.predict(self.example)
        self.assertAlmostEqual(sum(p["after_percent"] for p in result["parties"].values()),100,places=8)
        self.assertAlmostEqual(sum(p["delta_pp"] for p in result["parties"].values()),0,places=8)
        for region in result["states"].values():
            self.assertAlmostEqual(sum(region["after_percent"].values()),100,places=8)
            self.assertTrue(all(0<=v<=100 for v in region["after_percent"].values()))
        self.assertEqual(len(result["group_trace"]),192)
        self.assertFalse(result["world_state_mutated"])

    def test_same_all_party_utility_shift_cancels(self):
        request={**self.base,"response_assumptions_acknowledged":True,"events":[{"id":"x","evidence_status":"SIMULATION_ASSUMPTION",
            "source_notes":["Test only"],"group_changes":[{"party_signals":{p:{"delta_competence":.1} for p in PARTIES}}]}]}
        result=self.model.predict(request)
        for p in result["parties"].values():self.assertAlmostEqual(p["delta_pp"],0,places=10)

    def test_no_automatic_government_bonus_or_afd_penalty(self):
        request={**self.base,"response_assumptions_acknowledged":True,"events":[{"id":"attack","evidence_status":"SIMULATION_ASSUMPTION",
            "source_notes":["A label alone implies no vote effect"],"group_changes":[]}]}
        result=self.model.predict(request)
        for p in result["parties"].values():self.assertAlmostEqual(p["delta_pp"],0,places=10)

    def test_selectors_localize_effect_and_turnout_changes_mix(self):
        request=copy.deepcopy(self.example)
        request["events"][0]["group_changes"]=[{"selector":{"states":["ST"],"cohorts":["<=1955"]},"turnout_delta":-.1}]
        result=self.model.predict(request)
        self.assertAlmostEqual(result["states"]["BY"]["delta_pp"]["Union"],0,places=10)
        self.assertNotEqual(result["states"]["ST"]["delta_pp"]["Union"],0)

    def test_block_future_sources_wrong_election_and_unknown_joints(self):
        with self.assertRaises(ValueError):self.model.predict({**self.base,"as_of":"2026-07-31"})
        with self.assertRaises(ValueError):self.model.predict({**self.base,"target":"LANDTAG_VOTE_INTENTION"})
        bad=copy.deepcopy(self.example)
        bad["events"][0]["group_changes"][0]["selector"]={"education":["low"]}
        with self.assertRaises(ValueError):self.model.predict(bad)

    def test_explicit_assumptions_and_no_duplicate_event(self):
        bad=copy.deepcopy(self.example);bad.pop("response_assumptions_acknowledged")
        with self.assertRaises(ValueError):self.model.predict(bad)
        bad=copy.deepcopy(self.example);bad["events"].append(bad["events"][0])
        with self.assertRaises(ValueError):self.model.predict(bad)

    def test_explicit_absolute_settlement_is_idempotent(self):
        result=self.model.predict(self.example)
        bindings={p:p for p in PARTIES}
        state=PoliticalState({p:StateVariable(p,100/8) for p in PARTIES},{},{})
        with self.assertRaises(ValueError):self.model.settle_into_world(result,state,bindings)
        self.model.settle_into_world(result,state,bindings,acknowledge_conditional_model=True)
        again=self.model.settle_into_world(result,state,bindings,acknowledge_conditional_model=True)
        self.assertTrue(all(abs(v)<1e-12 for v in again.values()))
        self.assertAlmostEqual(sum(v.value for v in state.variables.values()),100,places=8)


if __name__ == "__main__":unittest.main()
