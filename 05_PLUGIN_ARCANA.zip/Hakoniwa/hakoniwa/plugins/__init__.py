"""Optional Hakoniwa plugins. Core simulations must run without enabling them."""
