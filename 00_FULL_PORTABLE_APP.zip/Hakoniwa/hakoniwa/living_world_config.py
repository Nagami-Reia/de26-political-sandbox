"""Load a living-world schedule using the project's existing v3 schema/modules."""
from __future__ import annotations

from dataclasses import fields
import hashlib
import json
from pathlib import Path

from .free_agent_game import WorldAction
from .information_filter import AccessRule, InformationFilter
from .living_world import Capacity, LivingPoliticalWorld, Task
from .persona_v2 import ActionOption, FreeAgentDecisionEngine
from .political_state import PoliticalAction, PoliticalState, StateVariable
from .realtime_polling import PollSeriesSpec, RealtimePollingTracker
from .simulation_orchestrator import LayeredConfiguration, LayeredSimulationOrchestrator, SimulationNodeV3
from .world_clock import WorldClock, WorkCalendar
from .world_environment import WorldEnvironment, SchedulingRules, DEFAULT_ENVIRONMENT
from .party_interest import PartyInterestEngine


PACKAGE = Path(__file__).resolve().parent


def load_living_world(path: Path, cards: str | Path | None = None,
                      environment_path: Path | None = None) -> tuple[LivingPoliticalWorld, str]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    if raw.get("schema_version") != "living-world-config-1.0":
        raise ValueError("Expected living-world-config-1.0")
    reference = raw.get("environment")
    environment = WorldEnvironment.load(environment_path or (path.parent/reference if reference else DEFAULT_ENVIRONMENT))
    if environment.rules.get("information_mode") == "DELIVERED_ONLY" and raw.get("information"):
        raise ValueError("AccessRule does not grant receipt: migrate information to knowledge.initial_beliefs/messages")
    clock = WorldClock(raw["start"], raw.get("timezone", environment.rules["clock"]["timezone"]))
    if clock.offset(raw["until"]) < 0:
        raise ValueError("Observation horizon precedes start")
    provenance = raw.get("variable_provenance", {})
    if set(provenance)-set(raw["variables"]):
        raise ValueError("Provenance refers to an unknown variable")
    for row in provenance.values():
        if environment.external is None:
            raise ValueError("Variable provenance requires an evidence-backed environment")
        environment.external.validate_provenance(row)
        if row["status"] == "UNKNOWN":
            raise ValueError("Unknown world values cannot be numeric placeholders; omit them from variables")
    state = PoliticalState({key: StateVariable(key, float(value), evidence=provenance.get(key, {}).get("status", "SIMULATION_ASSUMPTION"))
                            for key, value in raw["variables"].items()}, raw.get("capital", {}), raw.get("pressures", {}))
    personas = FreeAgentDecisionEngine.from_json(cards or PACKAGE/"data/personas/cards_pss.json")
    participants = {row["owner"] for row in raw.get("tasks", [])} | {row["owner"] for row in raw.get("nodes", [])}
    participants.update(actor for event in raw.get("events", []) for actor in event.get("affected", []))
    participants.update(row["route"]["owner"] for row in raw.get("history", {}).get("candidates", []))
    knowledge = raw.get("knowledge", {})
    participants.update(knowledge.get("initial_beliefs", {}))
    participants.update(actor for message in knowledge.get("messages", []) for actor in message["recipients"])
    media = raw.get("media", {})
    participants.update(actor for name in ("event_routes", "decision_routes", "history_routes")
                        for route in media.get(name, {}).values() for actor in route["actors"])
    profiles = environment.capacities_for(list(participants), set(personas.cards), raw.get("capacities", {}))
    capacities = {key: Capacity(daily_minutes=row["daily_minutes"], slots=row["slots"],
                  calendar=WorkCalendar(**row["calendar"])) for key, row in profiles.items()}
    nodes = {}
    poll_vars = set(raw["poll_variables"])
    for node_raw in raw.get("nodes", []):
        key, owner = node_raw["key"], node_raw["owner"]
        if key in nodes:
            raise ValueError("Duplicate decision node key")
        actions = []
        for item in node_raw["actions"]:
            option_raw = dict(item["choice"])
            allowed = {f.name for f in fields(ActionOption)}
            if set(option_raw)-allowed:
                raise ValueError(f"Unknown action fields: {sorted(set(option_raw)-allowed)}")
            for name in ("control_domains", "identity_tags", "event_tags", "risk_tags",
                         "required_offices", "required_institutional_permissions"):
                if name in option_raw:
                    option_raw[name] = tuple(option_raw[name])
            option = ActionOption(**option_raw)
            effects = item.get("effects", {})
            if set(effects)-set(state.variables):
                raise ValueError("Action references unknown variable")
            if poll_vars & set(effects):
                raise ValueError("Direct party-support effects prohibited; connect narrative feedback")
            if option.required_offices or option.required_institutional_permissions:
                raise ValueError("This schedule loader accepts operational decisions only; configure legal intents via the Python v3 API")
            actions.append(WorldAction(PoliticalAction(option.key, {"immediate": effects},
                                       feasibility=option.objective_feasibility), option))
        if not actions or len({a.choice.key for a in actions}) != len(actions):
            raise ValueError("Node actions must be nonempty with unique keys")
        nodes[key] = SimulationNodeV3(key, owner, tuple(actions),
                       node_raw.get("goals", {}), tuple(node_raw.get("tags", ())))
    actors = sorted(set(capacities) & set(personas.cards))
    information = InformationFilter({actor: {key: AccessRule(**rule)
                     for key, rule in raw.get("information", {}).get(actor, {}).items()}
                     for actor in actors}, seed=raw.get("seed", 0), stochastic=raw.get("stochastic_information", False),
                     delivery_only=environment.rules.get("information_mode") == "DELIVERED_ONLY")
    specs = tuple(PollSeriesSpec(key, key, "electorate", "vote_intention", "DE",
                               retention=.60) for key in raw["poll_variables"])
    if not specs or not poll_vars.issubset(state.variables):
        raise ValueError("At least one valid polling series is required")
    tracker = RealtimePollingTracker(raw.get("run_id", "living-world"), environment.facts["environment_id"], specs, raw["start"])
    game = LayeredSimulationOrchestrator(state, nodes, personas, information, raw.get("resource_bindings", {}),
        environment.layered,
        event_observers=(tracker,))
    tasks = []
    for item in raw.get("tasks", []):
        if {"status", "started", "finished", "overdue"} & set(item):
            raise ValueError("Scenario tasks cannot prescribe runtime completion states")
        data = dict(item)
        data["release"] = clock.offset(data["release"])
        data["deadline"] = clock.offset(data["deadline"])
        data["dependencies"] = tuple(data.get("dependencies", ()))
        data["tags"] = tuple(data.get("tags", ()))
        data["requires_windows"] = tuple((clock.offset(start), clock.offset(end))
                                          for start, end in data.get("requires_windows", ()))
        data["followups"] = {key: tuple(value) for key, value in data.get("followups", {}).items()}
        tasks.append(Task(**data))
    scheduling = {**environment.rules["scheduling"], **raw.get("scheduling_overrides", {})}
    world = LivingPoliticalWorld(game, clock, capacities, tasks, tuple(raw.get("reactive_rules", ())), SchedulingRules(**scheduling))
    world.configuration = raw
    world.environment = environment.describe()
    world.environment["mode"] = "SHARED_ENVIRONMENT_WITH_SCENARIO_INPUTS"
    world.external_environment = environment.external
    world.variable_provenance = {key: {"status": "SIMULATION_ASSUMPTION", "sources": [], **provenance.get(key, {})}
                                 for key in state.variables}
    if information.delivery_only:
        from .world_information import KnowledgeClockService
        world.services["information"] = KnowledgeClockService(world, knowledge)
    from .world_services import HistoricalClockService, MediaClockService, ParliamentClockService
    def service_config(name):
        derived = int.from_bytes(hashlib.sha256(f"{raw.get('seed', 0)}:{name}".encode()).digest()[:8], "big")
        return {"seed": derived, **raw[name]}
    if "history" in raw:
        cadence = raw["history"].get("cadence_minutes", environment.rules["services"]["history"]["cadence_minutes"])
        world.services["history"] = HistoricalClockService(world, service_config("history"), cadence)
    if "media" in raw:
        parties = PartyInterestEngine.from_json(PACKAGE/"data/parties/party_interest_profiles.json")
        world.services["media"] = MediaClockService(world, service_config("media"), environment.rules["services"]["media"], parties)
    if "parliament" in raw:
        world.services["parliament"] = ParliamentClockService(world, service_config("parliament"))
    for event in raw.get("events", ()):
        world.add_event(clock.offset(event["at"]), event["key"], tuple(event.get("affected", ())),
                        event.get("severity", .4), tuple(event.get("tags", ())), event.get("effects", {}),
                        visibility=event.get("visibility", "PUBLIC"))
    return world, raw["until"]
