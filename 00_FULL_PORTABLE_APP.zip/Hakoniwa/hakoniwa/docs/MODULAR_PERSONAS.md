# 模块化人物系统 · 2026-10-25

这次是在原项目上拆分。人物仍由同一个确定性Persona引擎选择；新增目录没有
创建第二个投票器、第二个PSS或第二个民调模型，也没有新增人物。

## 权威数据与兼容入口

`data/personas/registry.json` 列出原有17人。每人的 manifest 声明11个JSON组件，
加 analysis.md 和 README.md；每个人物目录14个文件，父目录只有17个子目录。
`persona_repository.py` 按清单组装原卡；`cards_pss.json` 和两个理性配置是兼容导出。

公共接口：

```python
from hakoniwa.persona_v2 import FreeAgentDecisionEngine

# 旧调用继续可用，内部会读取个人目录并检查兼容视图是否一致。
engine = FreeAgentDecisionEngine.from_json("hakoniwa/data/personas/cards_pss.json")
# 也可直接读取目录或registry.json。
engine = FreeAgentDecisionEngine.from_json("hakoniwa/data/personas")
```

```bash
python -m hakoniwa personas list --pretty
python -m hakoniwa personas inspect --actor Merz --pretty
python -m hakoniwa personas inspect --actor Merz --component polling --pretty
python -m hakoniwa personas validate --pretty
python -m hakoniwa personas export
```

独立工具入口也可用 `python -m hakoniwa.persona_tools validate`。
任意其他位置的旧卡、冻结实验卡和显式overlay保持独立。它们没有模块时，
接口沿用旧逻辑，不自动补入最新人格资料。修改人物目录不会就地修改已有运行。

## 每个功能归属

| 组件 | 数据与实际用途 |
| --- | --- |
| behavior | DNA、价值排序、野心、条件风险、控制方式、冲突偏好；原评分器执行 |
| pss | 承压恢复与初始状态；原PSS执行，动态状态另存在runtime |
| resources | 有日期的资源初值；真实可用资源仍由世界与信息过滤决定 |
| memory | 初始历史记忆；回溯冻结须按实验协议过滤 |
| relationships | 方向性关系与依赖；原关系评分/证据反馈执行 |
| voting | 公共投票adapter与逐议题价值映射；资格由世界验证，不能凭卡获得票 |
| polling | 五种民调口径的个人相关性权重；项目复审仍走原人物选择 |
| communication | 明确发送动作、授权通道及接收边界；默认不自动传播 |
| rationality | 原工具/实质/人格/战略权重；不重复叠加一份新权重 |
| influence | 有来源的影响渠道和限制；不能直接加成票数或信息可见性 |
| evidence | 新旧来源、事实/推断/反例/未知；不是人物的认知状态 |

共享代码可以改进数学和制度；个人文件可以修改个人参数。避免为17人复制
17套Python决策器，导致同一种制度规则在不同人物身上实现不一致。

## 已送达民调与信息转发

正常链：发布 → 送达 → 本人的可信度与认知 → 个人民调权重 → 有耗时的政策复审
→ 选择继续/修改/暂停/撤回 → 实际任务反馈。人格不直接变更民意或实际票数。

可选链：本人实际选择发送动作 → 完成发送工作 → 场景授权通道 → 延迟送达
→ 对方自己的信任与认知 → 对方自己的项目复审。转发不自动生成新民调测量，
不自动更新互信，也不强迫收件人赞同发件人。

配置示意（task、node、action、release须在同一世界中真实存在）：

```json
{
  "persona_communication": {
    "channels": [
      {"id":"private_briefing","sender":"Merz","recipient":"Frei",
       "latency_minutes":5,"reliability":0.900,"active":true}
    ],
    "actions": [
      {"task":"poll_briefing","action":"forward_poll",
       "channel":"private_briefing","release_id":"poll_02"}
    ]
  }
}
```

发送任务使用正常注意力预算，不是免费广播。必须开启 poll_feedback；发件人
须实际收到指定那份报告，才可转发当时的接收认知。不能偷读尚未发布的民调，
也不能把后来更新的认知附在早期报告的日期上。延迟期间通道关闭则送达失败。
有社会关系不等于有当前通道；场景必须授权，且可以让人误判通道可用性。

同一期同来源的民调转发不构成独立样本。收件人已收到时不会重复触发；若先
收到间接报告、后收到原始报告，原始来源替换该期间接贡献，不二次累计证据。
同一人物同一期报告最多一个压力暴露；若第一次不足以触发，后续可信报告仍可
进入判断。公开测量值和人物收到的报告不混为同一张曲线。

`reliability`、渠道耗时和个人权重仍是透明先验，不是本轮考据测量出的数字。
关系信任不自动等于报告可信度；当前报告可信度继续使用 InformationFilter
的来源信任。若场景要把私人信任变成来源信任，必须明确接线，不能暗中重复计权。

## 新考据的使用方式

73个可读独立网页覆盖17人及共享制度/学术材料。可读不等于全文：逐条明确
区分正文、摘要、付费导语、音频编辑摘要、PDF相关页和受阻。完整抓取失败也保留。
主要扩展官网、个人网站、所在地媒体、本人采访、议会材料和同行评议研究。

每个人的 analysis 与 evidence 包含条件行为、影响力渠道、反证和未知。
behavior.json 也保存有来源的研究注释，但评分器不将自然语言直接执行成强制动作。
新增研究注释不自动调整DNA数字，也不进入人物记忆。未来参数修订应有单独版本、
证据理由、反例与灵敏度测试。公开自述、记者评价和私人真实动机不能混同。

共享研究区分党忠诚、纪律、意识形态一致和实际倒戈；保留批评不等于投反对票，
共同雇主不等于派系，信息联系不等于控制力。研究结果没有直接迁移为个人权重。

## 验证范围

回归测试比较全部17人在拆分前后的DNA、PSS、资源、关系、记忆，以及两组菜单的
全部评分与最终选择。另测民调权重、投票接口、输入隔离、路径约束、旧overlay、
研究信息隔离、真实任务发送、耗时送达、收件人独立复审与去重。

这是结构兼容和因果接线的检验；不能把它解释为人格或现实政治预测已经准确。
