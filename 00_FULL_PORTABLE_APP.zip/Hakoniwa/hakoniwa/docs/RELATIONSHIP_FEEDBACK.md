# Relationship feedback: evidence and attribution

Updated 2026-10-25. This is an engineering correction, not empirical validation
of personality parameters or a historical replay result.

## Settlement contract

- `ActionOutcome.evidence_quality * outcome_scope` scales explicit relationship
  deltas and repair gains. Zero means no relationship update, including no new
  default relationship or failed-repair count. Actual workload still costs energy.
- Targeting another person and succeeding does not itself repair the relationship.
  Set `relationship_effect="repair"` only when the observed outcome concerns an
  actual repair attempt. The generated-action orchestrator propagates the selected
  action's explicit `relationship_posture="repair"`; authored outcomes must opt in.
- Ordinary failures do not count as failed reconciliation. Failed explicit repair
  can add to response history without requiring rupture or removing dialogue.
- A loss of operational reliability can accumulate structural unreliability,
  while betrayal/loyalty injury requires explicit received-event attribution via
  `betrayal` or `loyalty_breach` tags plus an adverse trust/reliability delta.
  This is the actor's attributed event, not proof of another person's true motive.
- Unknown relationships contribute no relationship bonus or feasibility penalty.
  Diagnostic placeholder values are marked `UNKNOWN_NEUTRAL` and do not create a
  persistent relationship merely through action evaluation.
- An attempted action still enters action history, even when its outcome is unknown.
  Its outcome evidence weight controls learned strategy success; an unobserved
  failure cannot be counted as a known failure. Old history without a weight keeps
  its previous weight of one for compatibility.

## Identity and replay

`PoliticalEvent.event_id` identifies an occurrence, not a category. Redelivery to
the same actor is ignored before both PSS and relationship settlement. The same
report may still reach another actor. Distinct recurring errors need distinct IDs
and may share an `event_type`; habituation does not erase new relationship evidence.

`ActionOutcome.outcome_id` optionally identifies one settlement. Duplicate IDs are
ignored before workload, PSS, relationship and action-history updates. Separate
attempts need separate IDs. Legacy callers without an ID remain non-idempotent:
an action key alone cannot distinguish two legitimate attempts. Generated outcomes
provide a node/trace-occurrence/actor ID. The ledgers are JSON-compatible runtime
fields; callers restoring saved runtime must restore these fields as well.

These guards do not make the world/resource settlement transaction idempotent.
The world must still prevent executing the same operation twice.

## Limits

Repair magnitudes, event attribution and evidence quality remain explicit model
assumptions. Successful repair does not automatically demonstrate operational
reliability. No reciprocal relationship update, vote change, or party support
change is inferred. Relationship propagation to actual ballots still requires the
existing explicit integration. This change does not implement a full agreement
fulfilment ledger or deferred organizational-request retry lifecycle.

Regression coverage: `tests/test_relationship_evidence.py`. Follow-up audit writes
to `outputs/faction_relationship_followup_20261025/`; prior outputs are retained.
