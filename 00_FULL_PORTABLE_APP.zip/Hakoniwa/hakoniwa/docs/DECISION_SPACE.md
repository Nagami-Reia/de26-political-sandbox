# Generated Decision Space

`decision_space.py` replaces large hand-authored branch trees with a bounded,
auditable political action grammar.

Its upstream input may come from `historical_dynamics.py`, which explains why an
event occurred before this module asks what the actor perceives or chooses.

## Five layers

1. **Perception** — `InformationFilter` beliefs, source trust, event ambiguity,
   memory resonance and relationship trust produce a distribution over frames.
   Perception is not an action and cannot be chosen opportunistically.
2. **Goals** — value hierarchy, PSS pressure/confidence, event cues and live goals
   determine which objectives are currently salient.
3. **Strategies** — reusable families such as direct control, private negotiation,
   institutional consultation, public signalling, bounded countermoves and delay
   for verification become available only when the event supplies a consequence
   model and at least one active goal.
4. **Execution styles** — behind-the-scenes coordination, formal procedure,
   public pressure, measured statements and verification pauses combine with the
   strategy. Character conflict and control preferences affect style fit.
5. **Outcomes** — success, partial success and failure are settled only after the
   actor chooses. A seed may alter the outcome, never personality or the choice.

Generated feasibility is explicitly environmental. It combines the strategy's
base feasibility and execution style with currently available external resources
and information support. Strategy value semantics are fixed by the strategy
template; they are not rewritten to mirror the deciding actor's active values.
This prevents the generator from manufacturing a self-confirming option for each
persona. The decision engine separately applies nonlinear environment-fit costs
and recent strategy experience, so an identity-consistent action can still lose
when the world does not support it or when the same approach has repeatedly
failed.

## Scenario authoring

The scenario no longer needs to write every action. It declares one event and one
factual effect model per strategy it wants to make physically possible:

```python
event = DecisionEvent(
    key="coalition_vote_warning",
    domain="legislative",
    tags=("votes", "coalition", "uncertain"),
    severity=.800,
    ambiguity=.600,
    signal_variables={"rebel_pressure": 1.0},
    effect_models={
        "private_negotiation": StrategyEffectModel(
            effects={
                "immediate": {"coalition_stability": 5},
                "medium": {},
                "long": {},
            },
            base_feasibility=.750,
        ),
    },
)
```

Then place it on a generated node:

```python
node = SimulationNodeV3("n1", "Merz", (), decision_event=event)
engine = LayeredSimulationOrchestrator(
    state, {"n1": node}, personas, information, bindings, configuration,
    decision_generator=DecisionSpaceGenerator(),
    outcome_resolver=OutcomeResolver(seed=7, stochastic=True),
)
```

Static `WorldAction` nodes remain valid for archived scenarios.

## Trace contract

Every generated turn preserves:

- the full perception distribution and accessible signals;
- active goals and their value/event/PSS components;
- every generated strategy/style path and generation score;
- rejected generation paths and reasons;
- institutional and perceptual filtering;
- Persona v2's six-component evaluation;
- the chosen action;
- all three conditional outcome weights;
- expected success before settlement and the evidence/scope of the realized result;
- the resolved outcome and resulting world transition.

Conditional weights are model branches, not real-world probabilities.

## Branch-specific structural transitions (2026-10-24)

Discrete outcomes are not scaled percentages. A partial agreement must not
silently set the complete bill-adopted lock. `StrategyEffectModel.next_node`
is now the successful route; failure and partial success do **not** inherit
success locks, lock removals, action openings/closures, or that route.
Existing successful structural semantics remain unchanged. Numeric accounting
is a separate channel, described below.

Use an explicit transition when an unsuccessful attempt should still trigger
another meeting, a recovery task, or its own irreversible political consequence:

```python
from hakoniwa.decision_space import OutcomeTransition, StrategyEffectModel

model = StrategyEffectModel(
    effects={"immediate": {"agreement_progress": 5}},
    outcome_transitions={
        "success": OutcomeTransition(
            locks_add=("endorsement_received",), next_node="submit_request"
        ),
        "partial_success": OutcomeTransition(
            locks_add=("partial_agreement",), next_node="continue_negotiation"
        ),
        "failure": OutcomeTransition(next_node="reassess"),
    },
)
```

JSON configurations accept the same mapping with ordinary objects instead of
`OutcomeTransition` instances. An override replaces the branch's **whole**
structural transition, including omitted fields defaulting to empty/None. Unknown
branch names or fields and contradictory add/remove or open/close declarations
are rejected. Runtime node existence and legal permission remain responsibilities
of the surrounding world/institutional pipeline, not this data class.

Migration: authors who intended a shared continuation after every outcome must
declare that node separately for all three branches. Do not restore unconditional
success locks to preserve an old story. Generated menus and resolved-outcome
traces expose `structural_transition` for audit and replay.

## Attempt expenditure versus conditional payoff (debug step 02)

An executed attempt may consume time, effort or political capital even when it
fails. Account timing is declared, never inferred from the sign of its delta:

```python
model = StrategyEffectModel(
    effects={"immediate": {"agreement_progress": 5}},  # Conditional result.
    attempt_effects={"staff_reserve": -2},            # Immediate, every executed attempt.
    attempt_capital_delta={"Merz": -10},
    attempt_pressure_delta={"crisis": 3},
    outcome_capital_delta={"Merz": 20},
    outcome_pressure_delta={"crisis": -8},
    outcome_account_overrides={
        "failure": {"capital_delta": {"Merz": -4}}, # Additional contingent backlash.
    },
)
```

`attempt_*` is applied once **inside the realized branch's atomic settlement**,
without success scaling. `effects` and `outcome_*` describe conditional results;
absent overrides, their existing success/partial/failure multipliers remain
1.000/0.450/0.000. These multipliers are model assumptions, not calibrated causal
estimates. Thus attempt -10 plus success reward +20 settles at +10; partial
success settles at -1; ordinary failure settles at -10. With the explicit failure
backlash above, failure settles at -14. A positive attempt effect and a negative
conditional effect are both allowed; signs do not determine timing.

`outcome_effect_overrides` replaces conditional variable effects only, never
erases attempt effects. `outcome_account_overrides` can replace the named
capital/pressure channel for one branch; an omitted channel retains its default
conditional result, while an explicit empty object clears it. Combine attempt
and contingent deltas by account/variable before clamping world state, avoiding
order-dependent deductions or gains.

`attempt_effects` is a **flat immediate-variable map**, not a delayed horizon.
Future obligations remain explicit deferred effects in the time system. This
patch does not introduce a new clock-time debit at task start: an aborted or
precheck-blocked action that never reaches outcome settlement is not charged by
this module. Where expenses really arise earlier, use the existing task/time
systems to settle that earlier expense and do not declare it here a second time.

Planning, menu generation and branch sampling do not mutate the world or spend
resources. The usual state settlement applies the combined realized delta.
This is one charge within a single settlement, not a new global idempotency
guarantee for callers that apply the same event twice.

### Legacy input migration

Old nonempty `StrategyEffectModel.capital_delta` or `pressure_delta` is ambiguous
and now raises an error unless the caller explicitly sets
`legacy_account_deltas_are_outcome=True`. That flag preserves their old
conditional-outcome meaning, including failure scaling to zero; it is **not**
appropriate for a sunk attempt cost. Prefer migrating to the new named channels.
The legacy alias and explicit `outcome_*` alias for the same channel cannot both
be configured. No arbitrary old negative delta is silently reinterpreted as an
attempt expense. Existing models with no account deltas need no migration.

Generated menus and resolved-outcome traces expose `accounting.attempt`,
`accounting.contingent` and `accounting.settled`. Diagnostics do not perform
another deduction. This patch repairs settlement only: scene authors still
need to represent perceived costs in actor-visible action evaluation; it does
not infer subjective utility or change persona weights from account names.

## Explicit institutional-priority pressure (debug A10)

`ActionOption` and `StrategyEffectModel` accept an optional
`institutional_pressure_exposure` mapping. Supported keys are `governability`,
`electoral_survival`, `fiscal_efficiency`, `organizational_unity`; each finite
number is in 0..1. The generator forwards the declared mapping unchanged.

```json
{
  "institutional_pressure_exposure": {
    "governability": 0.300,
    "fiscal_efficiency": 0.600
  }
}
```

These are actor-visible **estimates of expected institutional resistance**,
not policy damage, the persona's own value weights, objective legal constraints,
or a percentage-point prediction. A socially costly reform may have low
institutional resistance, and a personally attractive one may have high
resistance. Do not derive this mapping automatically from action names, signed
utility, office holders or hidden world truth. Record its evidence/assumption
in scenario notes, and update it through the actor's information process when
appropriate. Empty mapping is `UNMODELED_NO_EXPOSURE`, not evidence of no real
resistance. Unknown keys, booleans, non-finite and out-of-range values fail.

The perception model computes `component_i = priority_i * exposure_i`, uses
the maximum component as a dominant-pressure envelope, then combines it with
the existing career-cost channel using another maximum rather than assuming
independent penalties. The resulting support-survival factor discounts only
expected political success, alongside the existing carrier-access channel.
It does not alter execution capacity, legality, consideration status, substantive
values, personality weights, or actual outcome distributions.

This is `DOMINANT_ENVELOPE_V1_UNCALIBRATED`: a conservative closure assumption,
not an empirically fitted institutional response law. Independent effects may
be underestimated and correlated carrier/pressure estimates may still overlap;
do not encode the same anticipated resistance in both the supplied baseline
success estimate and the additional exposure.

Trace contains declared exposures, priority components, the pressure envelope,
the resulting `institutional_support_survivability`, and the model label. The
existing `institutional_logic_affects_choice` flag controls whether the priority
channel reaches the actual decision menu; shadow mode still computes diagnostics.
Zero priorities and missing exposures preserve the old numerical behavior.
Old environments are not silently annotated or recalibrated.
