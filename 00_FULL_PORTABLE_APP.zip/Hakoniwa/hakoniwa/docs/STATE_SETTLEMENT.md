# Intent is not settlement (debug A12)

`PoliticalState.apply()` is a deterministic ledger, not a success sampler. It
must receive a resolved transformation or an explicit deterministic assumption.
It never multiplies effects/locks by `feasibility`.

`PoliticalAction.effect_status` accepts:

| Status | Meaning |
|---|---|
| `DECLARED` (default) | Intended transformation; unresolved if feasibility differs from 1.000 |
| `REALIZED` | A selected outcome branch or externally confirmed transformation |
| `DETERMINISTIC_ASSUMPTION` | Scenario author deliberately assumes these effects occur, not an empirical result |

For compatibility, a default `DECLARED` action with feasibility exactly 1.000
is accepted as `DETERMINISTIC_DEFAULT`. This is an input assertion, **not** proof
that the action succeeded. Do not set feasibility to 1 merely to evade a missing
resolver. State history records `settlement_basis` and `declared_feasibility`.

An unresolved action raises `ValueError` before changing variables, accounts,
locks, route availability, delayed effects, sequence numbers or ledger history.
This is a missing settlement/configuration error, not a modeled failed attempt.
No failure probability or distribution is inferred from a lone feasibility value.

## Migration

- Uncertain political outcome: use the existing DecisionSpaceGenerator and
  OutcomeResolver, or an external institutional/operational resolver. The
  generated branch transformations are marked REALIZED; only the selected
  branch should be applied. Attempt costs remain in every executed branch.
- Confirmed world event: construct REALIZED effects and retain their provenance
  in the event/source log. Prior belief that the event was unlikely does not
  erase a fact that actually happened.
- Controlled deterministic experiment: explicitly declare
  DETERMINISTIC_ASSUMPTION. This preserves a stipulated result for that experiment
  and must not be represented as a forecast emerging from the engine.
- A direct action such as publishing a statement may be deterministic while its
  political effect is uncertain. Record the direct fact separately and place
  anticipated acceptance in ActionOption.political_success_expectation. Do not
  use the legacy world feasibility field as both execution and political success.

Old hand-scripted scenarios with fractional feasibility and unqualified effects
now need migration. They are not automatically relabeled REALIZED. Existing
report files are retained; passing regression tests does not certify that every
old scenario has been migrated.

## Driver boundaries

The canonical orchestrator rejects generated actions lacking an outcome resolver
and rejects explicit zero execution capacity even in shadow mode. The older
FreeAgentGame also checks explicit zero execution. Both still preserve the
chosen intention; rejection/configuration errors do not rewrite personality.

Institutional BLOCKED/PENDING/ROUTED/UNASSESSED stops execution: no world ledger
entry, attached success events/outcomes, automatic institutional feedback or
inherited success next_node. Record real preparation costs or a response to
being blocked as separate, explicitly supported events. The current model does
not invent those reactions or an automatic recovery route.

Forecast branches operate on cloned state under explicit conditional assumptions
about declared effects. The canonical forecast trace identifies this as
`CONDITIONAL_ON_DECLARED_EFFECTS_NOT_RESOLVED_OUTCOMES`; it cannot authorize
real-world settlement. Older StrategicGame hypothetical application also uses
the explicit assumption marker. This does not turn either into a full sampled
future-event model.

## Limits

Markers are contracts, not cryptographic evidence or legal permission. The ledger
cannot verify a caller's factual claim. Institutional checks, resource truth,
actual implementation, timing, and evidence delivery remain separate mechanisms.
This guard is not whole-turn rollback: earlier information delivery, ARCANA, or
other already executed operations may have their own state. An error must be
handled using the run's checkpoint/retry policy, not by blindly rerunning a turn.
