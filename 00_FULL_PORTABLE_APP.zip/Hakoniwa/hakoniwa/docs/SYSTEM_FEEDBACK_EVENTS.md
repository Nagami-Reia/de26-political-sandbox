# Causal institutional feedback, not per-node bonuses

`SystemFeedbackAssessor.assess()` remains a pure, repeatable diagnostic. Only
the canonical `SystemFeedbackLedger` commits changes to InstitutionalLogic and
AgencyHorizon. Assessment frequency is not event frequency or elapsed time.

## Declare an actual settlement

Attach an explicit context to the existing `SimulationNodeV3`:

```python
SystemFeedbackContext(
    causal_event_id="pension_package:v2:final_majority_settled",
    institutional_scale=0.200,
    phase="SETTLED",
    occurred_at_minute=1440,
)
```

The equivalent JSON object is accepted as `system_feedback_context`; node
construction normalizes it. Intermediate readings may use `phase="DIAGNOSTIC"`
or omit context entirely. Do not generate a new causal_event_id from every
node number, actor evaluation or report refresh.

- `institutional_scale` is an explicitly supplied 0..1 **model assumption**
  about the institutional scope of this outcome, not its probability or a
  measured fact. Keep rationale/provenance in the scenario's source notes.
- `occurred_at_minute` uses the bound simulation clock, not wall-clock runtime.
  A dated event cannot commit before its occurrence. `None` is permitted for a
  timeless discrete experiment and marked `UNTIMED_DISCRETE`; no date is invented.
- `SETTLED` asserts that this causal outcome is actually ready for institutional
  feedback. It is not inferred from choosing an action, time spent negotiating,
  a checklist completion or an explanatory paragraph.

The existing `system_feedback_mutates_world` flag remains necessary. If it is
on but context is missing, the trace says `MISSING_CAUSAL_CONTEXT` and commits
nothing. Old unannotated scenarios no longer accumulate full-size feedback per
node. Shadow/disabled calls and DIAGNOSTIC calls do not consume event IDs.

## Scaling and deduplication

One settled causal event scales all change channels once: legitimacy, agency,
concentration, reinforcement, alternative legibility and reported autonomy
deltas. Observed operational success and qualitative reproduction classification
are not scaled; the latter remains an uncalibrated diagnostic, not proof of a
worldwide transformation.

Replay of the same event/context/actor returns `ALREADY_SETTLED`. If the new
assessment differs (for example, because the world changed after the first
settlement), it is flagged but does not mutate the world again. Reusing the ID
with conflicting actor, scope or occurrence time is an input error. Genuine
corrections need separately justified correction events, not silently overwriting
the old settlement. A zero-scope settled event is still recorded, without changing
state.

One shared event must have one canonical assessment owner. Other actors can
interpret or discuss it without claiming the same global update again. This
version does not infer an actor-wide distribution of learning from that one
owner's AgencyHorizon update.

## Delayed organizational responses

The request stores the node's context in the existing response binding. Merely
submitting the request does not commit institutional feedback. ACCEPTED/PARTIAL/
REJECTED final responses can commit it; still-pending/contested/deferred responses
cannot. The same ledger handles direct and delayed outcomes.

## Precision, reporting and resume

Internal InstitutionalLogic.evolve and AgencyHorizon.evolve retain floating-point
precision while enforcing bounds, instead of rounding each institutional change
to three decimals. Their public payloads still display three decimals. This
prevents repeated small legitimate effects from vanishing through intermediate
rounding; it does not remove all approximations in the v1 assessor.

Each node has both raw `system_feedback` and `system_feedback_application`,
including applied status, declared context, scope-adjusted changes and timing.
The run payload includes `system_feedback_ledger`. Restore it with
`SystemFeedbackLedger.from_payload()` and pass it to the existing orchestrator's
optional `system_feedback_ledger` argument when restoring the corresponding
world, institutional and agency snapshot. Restoring only the ledger or only the
world is not a consistent checkpoint. The ledger is not an automatic whole-run
persistence or transaction system.

## Explicit limits

This is `DISCRETE_CAUSAL_OUTCOME_V1_UNCALIBRATED`. Time alone creates no reward.
Continuous institutional drift, exposure-duration effects and event hazard rates
are **not** newly modeled. They need an independent, calibrated time mechanism;
do not substitute node count or arbitrarily multiply every reform by its duration.

Deduplication applies only to institutional feedback, not all operational world
effects, resource expenses, PSS updates or polling events. Re-running an action
can still duplicate those other channels unless their own execution contracts
prevent it. Different real causal events may legitimately accumulate; fabricated
unique IDs are not automatically recognized as the same cause. Provenance and
scenario design remain essential. Direct low-level evolve calls can still alter
state; new scenario code should use the canonical commitment path.
