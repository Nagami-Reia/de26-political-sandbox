# 时间、承诺与政治机会窗口

本轮是在原`WorldClock`、`LivingPoliticalWorld`与v3人物引擎上扩展，不是另一个模拟器。未添加新的德国法律解释，原有制度检查仍在实际执行时独立运行。

## 正常运行链

准备占用注意力 → 使用当时收到的信息选择并承诺 → 根据所选行动排执行时间 → 再检查实际条件和制度权限 → 结算行动结果 → 到期／按进度兑现有条件的后续效果。

窗口、承诺、程序是否成功与选民反应是不同层次。本模块不能直接增减党派支持率；整场报告仍通过现有民调插件记录每个节点，并生成使用人物的PSS及民调折线图。

## 任务结果不再混为一谈

每项任务分别记录`work_status`、`action_outcome`、`institutional_outcome`和`world_outcome`。`COMPLETED`仍可表示准备／操作工作完成，但不再自动满足政治成功依赖。

`dependencies`默认要求`action_success`。用`dependency_outcomes`可逐项明确要求：

- `work_complete`：工作产物已完成，适用于失败后的审阅。
- `action_success`：直接行动成功，制度阻止不能满足。
- `institution_executable`：实际制度检查为EXECUTABLE；不等于整个立法流程已经通过或生效。
- `world_change`：世界变量确实发生变化，不只是行动被执行。

不能从“法案一读工作完成”推断“法案生效”。机构操作如果具有更细程序结果，仍由已有程序状态机及服务显式返回，不能用任务状态替代。

## 软、硬与衰减截止

`deadline_policy`可选`SOFT`、`HARD`、`DECAY`。软截止保留旧的迟到完成行为；硬截止会中止未兑现执行，释放未使用的注意力预留，已经花掉的准备与执行时间不返还。衰减使用显式`late_decay_per_hour`与真实迟到分钟：`exp(-rate × late_minutes/60)`，不是每个节点扣一次。

分钟精度下截止端点包含：同分钟完成先于截止检查；条件关闭事件若在信息／事实阶段发生，则后续执行读取改变后的真实条件。政治窗口的明确物理中断与一般政治失效分别处理。

操作服务与法律行为不能被任意乘成“0.6次任命／0.7次表决”。衰减只适用于明确数值化的操作收益，有制度intent的任务不接受这种数值缩放。

## 分阶段选择

配置1.1的个人决策任务默认`STAGED`；旧1.0仍默认`LEGACY_COMPLETION`，并在输出列出旧个人任务。1.1不会从effort或人格猜耗时：每个行动必须提供`action_timing`。

```json
{
  "lifecycle":"STAGED",
  "duration":30,
  "action_timing": {
    "limited_reply":{"execution_minutes":10},
    "further_negotiation":{"execution_minutes":90,"estimated_execution_minutes":60,"attention_required":true}
  }
}
```

`duration`是准备阶段。`estimated_execution_minutes`是人物估计，省略时明确约定人物知道配置的执行时长；可以与实际时长不同。`attention_required:false`表示承诺后等待外部组织执行，不继续占用本人工作槽。

承诺时调用已有的人格、信息、制度感知与可选ARCANA进行一次选择，冻结选择、当时信念及评价；执行时不重新挑选“现在最优”的别的行动，也不重抽建议。实际制度检查和结果结算仍发生在执行时。

`cancel_task(key, reason)`允许主动撤回，不赋予免费重选；已用成本保留，已接受的组织承诺也不自动解除。额外信誉／关系代价由对应人物／组织的反应模型处理，不硬编码人人撤回都受同样惩罚。

## 延迟效果：只执行明确的因果合同

`PoliticalAction.effect_timing`为每个medium/long效果明确给出delay、duration和持续条件。JSON节点使用`deferred_effects`及`effect_timing`。

```json
{
  "deferred_effects":{"medium":{"implementation_progress":6}},
  "effect_timing":{"medium":{
    "delay_minutes":30,
    "duration_minutes":60,
    "on_condition_loss":"PAUSE",
    "conditions":[{"variable":"funding_authorized","operator":"ge","value":1}]
  }}
}
```

duration为0时在到期时一次兑现；duration大于0时在固定区间按时间累积。`CANCEL`遇到条件失效终止后续；`PAUSE`跳过不可执行的时间，不补发错过部分。已实现效果不因后来撤销而自动倒扣；若现实机制要求偿还或逆转，需要另一个明确效果。

没有到期时间的旧medium/long记录标为`UNSCHEDULED`并列入审计，不擅自规定“中期等于30天”。预期改革会增加信任，不构成已经产生的未来世界债务，不能自动注册为保证收益。

同批到期效果读取同一批前置状态，并先合并再作变量边界截断，避免数组顺序决定结果。明确的因果先后需要后一个时间／条件阶段，不靠偶然入队顺序制造。

## 客观窗口与人物认知

`OpportunityWindow`保存`opens_when`、`closes_when`、`required_resources`、时间边界、容量和可选收益衰减。各条件列表为ALL；缺失事实返回UNKNOWN，不把缺失当成0或许可。

人物不从此对象获取知识。`TimingReport`通过明确的来源、消息ID、观测时间和接收时间进入单独的`TimingBeliefs`；同一渠道重复消息不累加成多个独立证据。报告可以过时、错误或互相矛盾；当前实现按渠道信任与置信度合并，是可审计的建模约定，不是现实认知的已校准规律。

时机只通过一次“感知到的正向目标兑现空间”进入行动评价，不再把同一窗口同时变成身份、风险、可行性和得分的多重好坏标签。未收到报告时，不读取真实窗口来替人物优化选择。

`running_policy`默认`FINISH_WITHOUT_PAYOFF`：政治窗口暗中失效时，人可能继续白忙，直到实际尝试结算才失败；不能因为隐藏事实自动空出他的注意力。确实发生即时物理／程序中断时，环境可明确配置`INTERRUPT`，或通过已实现的中断事件取消任务。这个开关不是自动通知所有人物真相。

## 竞争与延期

有限容量的同分钟请求成批结算：容量足够则接受；超额则CONTESTED，不按名字或队列顺序挑赢家。需要支持方／组织自己的真实决定，通过配置的`allocation_authority`调用`resolve_opportunity`。本模块不自动生成这个支持方的人格或替其决策。

已经先接受的承诺占用容量。取消任务不会擅自退回支持；`release_opportunity_claim`需要对应组织的实际解除。`extend_opportunity`需要对应组织的已验证同意及原因，且不改变独立法律／程序截止。这里是受信的世界层结算API，人物单方面声称“已经延期”或收到延期传闻都不能调用它来改变真相。

`preserve_expiry_after_commit`仅可明确保护已接受承诺免受该窗口时间到期影响，不覆盖资源丧失、条件失效或宪法检查。

## 主动等待

`waiting_policies`按人物启用，需报告主题、review_minutes和max_wait_minutes。人物把“现在开始”与“等待信息”交给原人格评分器比较；依据为已收到的预期信息收益、可用性及剩余时间判断，而不是世界未来事件队列。

等待不预留本人注意力，真实时间继续流动，竞争者仍可行动。普通知识消息到达可唤醒重新评估；是否继续等仍由人物模型判断。等待有有限预算，不通过每分钟轮询制造无限事件。机会损失的计算是明确的启发式，不冒充实证发生率；没有剩余时间报告时，不能声称已经识别真实的等待风险。

## 使用与验证

```bash
python3 -m hakoniwa world --config hakoniwa/examples/temporal_opportunities.json --output outputs/temporal_opportunities
python3 -m unittest hakoniwa.tests.test_temporal_opportunities -v
```

示例是合成的机制实验，所有时间、支持与融资条件都是测试假设，不是现实新闻或政治预测。民调没有明确群体反应信号时保持平线是正常结果，不能为了画曲线而添加固定涨跌。

输出包含任务四层结果、承诺时评价、实际结算、延迟效果请求与实际变化、窗口条件诊断、报告来源、等待评价及旧数据迁移提示。支持按相同输入重跑；本轮没有承诺从任意中间JSON完整恢复所有内部承诺对象或时钟回调。

后续仍需分别校准实际行动耗时、信息收益、组织支持／撤回机制和窗口衰减。测试通过证明边界和因果顺序受到约束，不证明现实人物一定作出准确判断，也不证明未来政治预测准确。
