# 民调插件文档入口

实现、基本盘资料、校准和完整使用说明已统一收进：

[plugins/polling/README.md](../plugins/polling/README.md)

唯一流水线：事件／叙事 → 选民反应 → 支持率汇总 → 民调测量 → 每节点快照与折线图。

`hakoniwa/polling/`与`realtime_polling.py`仅保留旧代码的兼容导入，不再各自维护计算逻辑。
