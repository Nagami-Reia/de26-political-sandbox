"""Time/agenda scheduling around the existing v3 orchestrator and persona engine."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, replace
from copy import copy
from datetime import timedelta
from html import escape
import json
from pathlib import Path
from typing import Mapping, Callable

from .persona_v2 import ActionOption, WorldEvent
from .political_state import PoliticalAction
from .political_state_system import quantize3
from .scenario_reporting import ScenarioReportCompiler, render_arcana_embed
from .simulation_orchestrator import LayeredSimulationOrchestrator
from .world_clock import WorldClock, WorkCalendar, ScheduledEvent, COMPLETION, DEADLINE, DISPATCH
from .world_environment import SchedulingRules


@dataclass
class Task:
    key: str
    owner: str
    release: int
    deadline: int
    duration: int
    importance: float = .5
    value_impacts: dict[str, float] = field(default_factory=dict)
    tags: tuple[str, ...] = ()
    node: str | None = None
    effects: dict[str, float] = field(default_factory=dict)
    dependencies: tuple[str, ...] = ()
    requires_windows: tuple[tuple[int, int], ...] = ()
    followups: dict[str, tuple[str, ...]] = field(default_factory=dict)
    activation: str = "scheduled"
    operation: str | None = None
    operation_data: dict = field(default_factory=dict)
    status: str = "UNRELEASED"
    started: int | None = None
    finished: int | None = None
    overdue: bool = False

    def __post_init__(self) -> None:
        if any(type(value) is not int for value in (self.release, self.deadline, self.duration)):
            raise ValueError("Task times and durations must be integer minutes")
        if not 0 <= self.importance <= 1 or self.duration <= 0:
            raise ValueError("Task importance must be 0..1 and duration positive")
        if self.deadline < self.release:
            raise ValueError("Task deadline precedes release")
        if self.activation not in {"scheduled", "conditional"}:
            raise ValueError("Task activation must be scheduled or conditional")


@dataclass
class Capacity:
    daily_minutes: int = 360
    slots: int = 1
    calendar: WorkCalendar = field(default_factory=WorkCalendar)
    busy: set[str] = field(default_factory=set)
    spent_by_day: dict[str, int] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if type(self.daily_minutes) is not int or type(self.slots) is not int or self.daily_minutes <= 0 or self.slots <= 0:
            raise ValueError("Capacity must be positive")


class LivingPoliticalWorld:
    """The clock owns timing; existing orchestrator owns political decisions/outcomes.

    A task reserves deliberation or execution time. Political choice occurs at
    completion, using information available at that timestamp. It is not settled
    in advance. Personal tasks are non-preemptive in this first implementation.
    """

    def __init__(self, game: LayeredSimulationOrchestrator, clock: WorldClock,
                 capacities: Mapping[str, Capacity], tasks: list[Task],
                 reactive_rules: tuple[dict, ...] = (), scheduling: SchedulingRules | None = None):
        self.game, self.clock = game, clock
        self.capacities = dict(capacities)
        if len({t.key for t in tasks}) != len(tasks):
            raise ValueError("Duplicate task keys")
        self.tasks = {task.key: task for task in tasks}
        self.reactive_rules = reactive_rules
        self.fired_rules: set[str] = set()
        self.configuration: dict = {}
        self.environment: dict = {}
        self.scheduling = scheduling or SchedulingRules()
        self.event_handlers: dict[str, Callable] = {}
        self.operation_handlers: dict[str, Callable] = {}
        self.listeners: list[Callable] = []
        self.services: dict[str, object] = {}
        self.trace: list[dict] = []
        self._dispatch_pending: set[tuple[str, int]] = set()
        self.used_personas = sorted(set(self.capacities) & set(game.personas.cards))
        self.initial_pss = {a: asdict(game.personas.runtime[a].state) for a in self.used_personas}
        self.variable_provenance = {}
        self.external_environment = None
        self._audited_history = 0
        if game.check_context_provider is not None:
            original_provider = game.check_context_provider
            base_hours = original_provider(game.state).now_hours
            def timed_context(state):
                context = copy(original_provider(state))
                context.now_hours = base_hours + self.clock.minute // 60
                return context
            game.check_context_provider = timed_context
        for owner, capacity in self.capacities.items():
            if owner in game.personas.cards and capacity.slots != 1:
                raise ValueError("A person can occupy only one attention slot")
        for task in tasks:
            self._validate_task(task)
        self._validate_dependencies()
        for task in tasks:
            if task.activation == "scheduled":
                clock.schedule(task.release, "release", {"task": task.key})
                clock.schedule(task.deadline, "deadline", {"task": task.key}, phase=DEADLINE)
        for rule in reactive_rules:
            if rule.get("direction", "above") not in {"above", "below"}:
                raise ValueError("Rule direction must be above or below")
            if rule["variable"] not in game.state.variables:
                raise ValueError("Rule references unknown variable")
            if any(key not in self.tasks for key in rule["release_tasks"]):
                raise ValueError("Rule references unknown task")
        for observer in game.event_observers:
            if hasattr(observer, "telemetry") and not observer.telemetry.points:
                observer.record_baseline(game.state)
        self._check_reactive_rules()

    def _validate_task(self, task: Task) -> None:
        if task.owner not in self.capacities:
            raise ValueError(f"No capacity for {task.owner}")
        cap = self.capacities[task.owner]
        if task.duration > cap.daily_minutes:
            raise ValueError(f"{task.key} exceeds daily capacity; split it into stages")
        cap.calendar.next_slot(self.clock, max(self.clock.minute, task.release), task.duration)
        if task.node is not None:
            if task.node not in self.game.nodes or self.game.nodes[task.node].owner != task.owner:
                raise ValueError(f"Task/node owner mismatch at {task.key}")
            if task.owner not in self.game.personas.cards:
                raise ValueError("Political nodes require an existing persona")
        elif task.owner in self.game.personas.cards:
            raise ValueError("Personal tasks require a v3 decision node")
        if task.node is not None and task.effects:
            raise ValueError("Personal effects belong to existing WorldActions")
        if task.operation and (task.node or task.effects):
            raise ValueError("A service operation must own its settlement, without duplicate node/effects")
        if task.operation == "parliamentary_vote" and not task.requires_windows:
            raise ValueError("A parliamentary vote needs an explicit procedure window")
        missing = set(task.effects) - set(self.game.state.variables)
        if missing:
            raise ValueError(f"Unknown operational variables: {sorted(missing)}")
        # Organisational jobs are operational only, never a shortcut around legal intent checks.
        poll_vars = {spec.state_variable for observer in self.game.event_observers
                     for spec in getattr(observer, "specs", ())}
        if poll_vars & set(task.effects):
            raise ValueError("Organisational work cannot directly change party support; use media feedback")
        for start, end in task.requires_windows:
            if start >= end:
                raise ValueError("Invalid procedure window")

    def _validate_dependencies(self) -> None:
        visited, active = set(), set()
        def visit(key):
            if key in active:
                raise ValueError("Cyclic task dependencies")
            if key in visited:
                return
            active.add(key)
            for dependency in self.tasks[key].dependencies:
                if dependency not in self.tasks:
                    raise ValueError(f"Unknown dependency {dependency}")
                visit(dependency)
            active.remove(key)
            visited.add(key)
        for key in self.tasks:
            visit(key)
            for targets in self.tasks[key].followups.values():
                if any(target not in self.tasks for target in targets):
                    raise ValueError("Unknown followup task")

    def add_event(self, at: int, key: str, affected: tuple[str, ...],
                  severity: float = .4, tags: tuple[str, ...] = (),
                  effects: dict[str, float] | None = None, *, visibility: str = "PUBLIC") -> None:
        if visibility not in {"PUBLIC", "PRIVATE", "HIDDEN"}:
            raise ValueError("Invalid event visibility")
        if visibility == "HIDDEN" and affected:
            raise ValueError("Hidden event cannot notify personas; schedule later knowledge delivery")
        if any(a not in self.used_personas for a in affected):
            raise ValueError("Event recipients must be participating personas")
        poll_vars = {spec.state_variable for observer in self.game.event_observers
                     for spec in getattr(observer, "specs", ())}
        if poll_vars & set(effects or {}):
            raise ValueError("Facts cannot directly change party support")
        if set(effects or {}) - set(self.game.state.variables):
            raise ValueError("Unknown event variables")
        self.clock.schedule(at, "external_event", {"key": key, "affected": affected,
                            "severity": severity, "tags": tags, "effects": effects or {}, "visibility": visibility})

    def submit_task(self, task: Task) -> None:
        """Add an actor/organisation's new agenda item while a world is running."""
        if task.key in self.tasks or task.release < self.clock.minute:
            raise ValueError("New tasks need a unique key and a release time in the present/future")
        self._validate_task(task)
        self.tasks[task.key] = task
        try:
            self._validate_dependencies()
        except Exception:
            del self.tasks[task.key]
            raise
        if task.activation == "scheduled":
            self.clock.schedule(task.release, "release", {"task": task.key})
            self.clock.schedule(task.deadline, "deadline", {"task": task.key}, phase=DEADLINE)

    def register_event_handler(self, kind: str, handler: Callable) -> None:
        if kind in {"dispatch", "release", "complete", "deadline", "external_event"} or kind in self.event_handlers:
            raise ValueError(f"Reserved or duplicate clock handler: {kind}")
        self.event_handlers[kind] = handler

    def register_operation(self, kind: str, handler: Callable) -> None:
        if kind in self.operation_handlers:
            raise ValueError(f"Duplicate operation: {kind}")
        self.operation_handlers[kind] = handler

    def _elapse(self, minutes: int) -> None:
        for actor in self.used_personas:
            self.game.personas.elapse_minutes(actor, minutes)

    def _record(self, kind: str, *, task: Task | None = None, details: dict | None = None,
                decision: dict | None = None) -> None:
        provenance_updates = []
        for update in self.game.state.history[self._audited_history:]:
            for key, value in update["after"].items():
                if value != update["before"].get(key):
                    prior = self.variable_provenance.get(key, {"status": "SIMULATION_ASSUMPTION", "sources": []})
                    self.variable_provenance[key] = {"status": "SCENARIO_GENERATED",
                        "initial_status": prior.get("initial_status", prior["status"]),
                        "sources": prior.get("sources", []), "last_action": update["action"]}
                    self.game.state.variables[key] = replace(self.game.state.variables[key], evidence="SCENARIO_GENERATED")
                    provenance_updates.append({"variable": key, "before_status": prior["status"],
                                               "after_status": "SCENARIO_GENERATED", "action": update["action"]})
        self._audited_history = len(self.game.state.history)
        details = {**(details or {}), "provenance_updates": provenance_updates}
        index = len(self.trace) + 1
        event_id = f"living:{index}:{kind}"
        timestamp = self.clock.at().isoformat()
        if decision is None:  # political nodes have already recorded one polling snapshot
            for observer in self.game.event_observers:
                if hasattr(observer, "timestamp_by_event_id"):
                    observer.timestamp_by_event_id[event_id] = timestamp
                observer.record(self.game.state, event_id=event_id,
                                actor=task.owner if task else "world", action=kind,
                                event_kind=kind, resource_changes=details or {})
        row = {"node": event_id, "calendar_date": timestamp, "elapsed_minutes": self.clock.minute,
               "kind": kind, "task": task.key if task else None,
               "actors_used": self.used_personas, "details": details or {},
               "decision": decision,
               "all_actor_pss_after": {a: asdict(self.game.personas.runtime[a].state)
                                       for a in self.used_personas}}
        if decision:
            for key in ("arcana", "chosen_action", "decision_maker", "operational_feedback"):
                row[key] = decision[key]
        self.trace.append(row)
        self._check_reactive_rules()
        for listener in self.listeners:
            listener(self, row)

    def _check_reactive_rules(self) -> None:
        for rule in self.reactive_rules:
            if rule["key"] in self.fired_rules:
                continue
            value = self.game.state.variables[rule["variable"]].value
            met = value >= rule["threshold"] if rule.get("direction", "above") == "above" else value <= rule["threshold"]
            if met:
                self.fired_rules.add(rule["key"])
                for target in rule["release_tasks"]:
                    task = self.tasks[target]
                    if task.status == "UNRELEASED":
                        self.clock.schedule(max(self.clock.minute+1, task.release), "release", {"task": target})

    def _dispatch_at(self, owner: str, minute: int) -> None:
        key = (owner, minute)
        if key not in self._dispatch_pending:
            self._dispatch_pending.add(key)
            self.clock.schedule(minute, "dispatch", {"owner": owner}, phase=DISPATCH)

    def _next_slot(self, task: Task) -> int:
        cap = self.capacities[task.owner]
        earliest = self.clock.minute
        for _ in range(370):
            slot = cap.calendar.next_slot(self.clock, earliest, task.duration)
            day = self.clock.at(slot).date().isoformat()
            if cap.spent_by_day.get(day, 0) + task.duration > cap.daily_minutes:
                next_day = self.clock.at(slot).replace(hour=0, minute=0) + timedelta(days=1)
                earliest = self.clock.offset(next_day.isoformat())
                continue
            if task.requires_windows:
                slots = [max(slot, start) for start, end in task.requires_windows
                         if max(slot, start)+task.duration <= end]
                if not slots:
                    return task.deadline+1
                if min(slots) != slot:
                    earliest = min(slots)
                    continue
            return slot
        return task.deadline+1

    def _priority(self, task: Task) -> dict:
        remaining = task.deadline-self.clock.minute
        slack = remaining-task.duration
        urgency = 1.0 if slack <= 0 else task.duration / (task.duration+slack)
        if task.owner in self.used_personas:
            option = ActionOption(
                task.key, goal_impacts={"agenda": task.importance}, value_impacts=task.value_impacts,
                effort=min(1, task.duration/self.capacities[task.owner].daily_minutes),
                upside=task.importance, downside=.1, event_tags=task.tags,
            )
            score = self.game.personas.score(task.owner, option,
                self.game.personas.cards[task.owner].initial_resources,
                {"agenda": 1.0}, task.tags, soft_resource_constraints=True)
            persona_value = score.total / 100.0  # existing persona score units; no per-menu rescaling
            diagnosis = asdict(score)
        else:
            persona_value, diagnosis = task.importance, {"rule": "organizational importance"}
        return {"task": task.key, "persona": diagnosis, "slack_minutes": slack,
                "urgency": round(urgency, 3),
                "priority": round(self.scheduling.persona_weight*persona_value
                    + self.scheduling.urgency_weight*urgency
                    + self.scheduling.importance_weight*task.importance, 6)}

    def _dispatch(self, owner: str) -> None:
        cap = self.capacities[owner]
        while len(cap.busy) < cap.slots:
            candidates, wakes = [], []
            for task in self.tasks.values():
                if task.owner != owner or task.status != "READY":
                    continue
                if any(self.tasks[key].status in {"MISSED", "BLOCKED"} for key in task.dependencies):
                    task.status = "BLOCKED"
                    self._record("dependency_blocked", task=task,
                                 details={"dependencies": list(task.dependencies)})
                    continue
                if not all(self.tasks[key].status in {"COMPLETED", "COMPLETED_LATE"}
                           for key in task.dependencies):
                    continue
                slot = self._next_slot(task)
                if slot == self.clock.minute:
                    candidates.append(task)
                elif slot <= task.deadline:
                    wakes.append(slot)
            if not candidates:
                if wakes:
                    self._dispatch_at(owner, min(wakes))
                return
            evaluations = [self._priority(t) for t in candidates]
            winner = max(evaluations, key=lambda row: (row["priority"],
                         -self.tasks[row["task"]].deadline, row["task"]))
            task = self.tasks[winner["task"]]
            task.status, task.started = "RUNNING", self.clock.minute
            cap.busy.add(task.key)
            day = self.clock.at().date().isoformat()
            cap.spent_by_day[day] = cap.spent_by_day.get(day, 0)+task.duration
            if owner in self.used_personas:
                # Charge attention once; completion outcomes carry no duplicate duration debit.
                state = self.game.personas.runtime[owner].state
                state.energy = max(0, state.energy-self.scheduling.energy_cost_per_daily_budget*task.duration/cap.daily_minutes)
            self.clock.schedule(self.clock.minute+task.duration, "complete", {"task": task.key}, phase=COMPLETION)
            self._record("task_started", task=task, details={"agenda_evaluations": evaluations,
                         "reserved_minutes": task.duration, "non_preemptive": True})

    def _handle(self, event: ScheduledEvent) -> None:
        if event.kind in self.event_handlers:
            details = self.event_handlers[event.kind](self, event)
            self._record(event.kind, details=details or {})
            return
        if event.kind == "dispatch":
            self._dispatch_pending.discard((event.data["owner"], self.clock.minute))
            self._dispatch(event.data["owner"])
            return
        if event.kind == "external_event":
            data = event.data
            updates = [self.game.personas.apply_event(a, WorldEvent(data["key"], "scheduled_information",
                       data["severity"], tuple(data["tags"]))) for a in data["affected"]]
            if data["effects"]:
                self.game.state.apply(PoliticalAction(data["key"], {"immediate": data["effects"]}))
            self._record("world_fact_occurred" if data["visibility"] == "HIDDEN" else "information_delivered",
                         details={**data, "pss_updates": updates})
            return
        task = self.tasks[event.data["task"]]
        if event.kind == "release":
            if task.status != "UNRELEASED":
                return
            task.status = "READY"
            if task.activation == "conditional":
                self.clock.schedule(max(self.clock.minute, task.deadline), "deadline",
                                    {"task": task.key}, phase=DEADLINE)
            self._record("task_released", task=task)
            self._dispatch_at(task.owner, self.clock.minute)
        elif event.kind == "deadline":
            if task.status in {"COMPLETED", "COMPLETED_LATE", "BLOCKED"} or task.overdue:
                return
            task.overdue = True
            if task.status != "RUNNING":
                task.status = "MISSED"
            update = None
            if task.owner in self.used_personas:
                update = self.game.personas.apply_event(task.owner, WorldEvent(
                    f"deadline:{task.key}", "missed_deadline",
                    self.scheduling.deadline_severity_base+self.scheduling.deadline_severity_importance*task.importance,
                    ("loss_of_control", "policy_failure"), surprise=.1))
            self._record("deadline_missed", task=task, details={"pss_update": update})
            for owner in self.capacities:
                self._dispatch_at(owner, self.clock.minute)
        elif event.kind == "complete":
            if task.status != "RUNNING":
                return
            decision = None
            operation_result = None
            if task.node:
                instance_key = f"living_task:{task.key}"
                self.game.nodes[instance_key] = replace(self.game.nodes[task.node], key=instance_key)
                decision = self.game.run(instance_key, max_steps=1,
                    timestamp=self.clock.at().isoformat(), compile_report=False)
            elif task.operation:
                if task.operation not in self.operation_handlers:
                    raise ValueError(f"No registered operation: {task.operation}")
                operation_result = self.operation_handlers[task.operation](self, task)
            elif task.effects:
                self.game.state.apply(PoliticalAction(f"implementation:{task.key}",
                                                      {"immediate": task.effects}))
            task.status = "COMPLETED_LATE" if task.overdue else "COMPLETED"
            task.finished = self.clock.minute
            self.capacities[task.owner].busy.remove(task.key)
            self._record("task_completed", task=task, decision=decision,
                         details={"late": task.overdue, "implementation_effects": task.effects,
                                  "operation_result": operation_result})
            if decision is not None:
                resolution = decision["institutional_resolution"]["resolution"]
                if resolution in {"not_invoked", "executable"}:
                    for key in task.followups.get(decision["chosen_action"], ()):
                        self.clock.schedule(max(self.clock.minute+1, self.tasks[key].release),
                                            "release", {"task": key})
            for owner in self.capacities:
                self._dispatch_at(owner, self.clock.minute)

    def run_until(self, timestamp: str) -> dict:
        if any(task.operation and task.operation not in self.operation_handlers for task in self.tasks.values()):
            raise ValueError("A task references an unconfigured world service")
        self.clock.advance(self.clock.offset(timestamp), self._handle, self._elapse)
        self._record("observation_horizon")
        policy = replace(self.game.reporting_policy, allow_no_personas=True)
        report = ScenarioReportCompiler(self.initial_pss, policy).compile(
            self.trace, self.game.event_observers)
        return quantize3({"schema_version": "living-political-world-1.0", "clock": self.clock.payload(),
                "tasks": {key: asdict(task) for key, task in self.tasks.items()},
                "configuration": self.configuration,
                "variable_provenance": self.variable_provenance,
                "environment": self.environment,
                "scheduling_rules": asdict(self.scheduling),
                "subsystems": {key: service.payload() for key, service in self.services.items()},
                "capacities": {key: {"daily_minutes": cap.daily_minutes, "slots": cap.slots,
                    "calendar": asdict(cap.calendar),
                    "busy": sorted(cap.busy), "spent_by_day": cap.spent_by_day}
                    for key, cap in self.capacities.items()},
                "trace": self.trace, "political_decisions": self.game.trace,
                "world_state": self.game.state.payload(), "persona_runtime": self.game.personas.payload(),
                "fired_rules": sorted(self.fired_rules), "scenario_report": report})

    @staticmethod
    def save(payload: dict, output: Path) -> None:
        output.mkdir(parents=True, exist_ok=True)
        (output/"full_trace.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        charts = payload["scenario_report"]["charts"]
        environment = payload.get("environment", {})
        environment_text = (f'<p>公共环境：{escape(environment.get("environment_id", "Python API"))}；'
            f'历史快照截止：{escape(environment.get("historical_cutoff", "未指定"))}。'
            '时间与容量系数为模型假设；本报告中的测试输入不代表现实预测。</p>')
        subsystem_details = "".join(f'<details><summary>{escape(name)} · 子系统运行记录</summary>'
            f'<pre>{escape(json.dumps(data, ensure_ascii=False, indent=2))}</pre></details>'
            for name, data in payload.get("subsystems", {}).items())
        for key, filename in (("pss_pressure_svg", "pss_pressure.svg"), ("polling_svg", "polling.svg")):
            (output/filename).write_text(charts[key], encoding="utf-8")
        rows = "".join(f'<tr><td>{escape(row["calendar_date"])}</td><td>{escape(row["kind"])}</td>'
                       f'<td>{escape(row["task"] or "—")}</td><td>{escape((row["decision"] or {}).get("chosen_action", "—"))}</td></tr>'
                       for row in payload["trace"])
        decisions = "".join(f'<details><summary>{escape(row["decision_maker"])} · {escape(row["chosen_action"])}</summary>'
                            f'<pre>{escape(json.dumps(row, ensure_ascii=False, indent=2))}</pre></details>'
                            for row in payload["political_decisions"])
        document = ('<!doctype html><html lang="zh"><meta charset="utf-8"><title>Living Political World</title>'
                    '<style>body{max-width:1100px;margin:40px auto;padding:0 20px;font:15px/1.6 system-ui;background:#f7f4ef;color:#272522}'
                    'td,th{padding:7px;border-bottom:1px solid #ccc;text-align:left}table{width:100%;border-collapse:collapse}svg{max-width:100%;height:auto}pre{white-space:pre-wrap;overflow-wrap:anywhere}</style>'
                    '<h1>Living Political World · 持续政治世界</h1><p>时间、容量、截止期限与程序队列的机制验证。所有情景数值均为合成假设。</p>'
                    f'<p>运行到：{escape(payload["clock"]["timestamp"])}</p>'
                    + environment_text +
                    '<h2>人物压力</h2>'+charts["pss_pressure_svg"]+'<h2>民调观察</h2>'+charts["polling_svg"]+
                    '<h2>时间线</h2><table><tr><th>时间</th><th>事件</th><th>任务</th><th>政治选择</th></tr>'+rows+'</table>'
                    '<h2>逐节点人物评价与决定</h2>'+decisions+
                    '<h2>公共环境反馈链</h2>'+subsystem_details+
                    render_arcana_embed(payload["scenario_report"])+ '</html>')
        (output/"report.html").write_text(document, encoding="utf-8")
