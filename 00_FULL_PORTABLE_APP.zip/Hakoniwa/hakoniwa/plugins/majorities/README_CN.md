# 组织多数与党团投票插件 v1

这是原项目里的独立插件，不是另一套箱庭。标准库即可运行。主 CLI 和 `MemberVoteService.run_member_vote()` 均调用此插件。2026-10-25已删除旧`parliamentary_vote.py`，世界时钟、立法周期和十月场景已改用本插件的同一成员抽票与计票实现；既有历史报告不重写。

## 它计算什么

`版本化提案 + 有表决资格的成员 → 逐人议题评价／现有人格决策 → 出席和共同信息冲击 → 赞成／反对／弃权／缺席 → 客观计票规则 → 表决事实`

正式组织、个人关系、政策合作分别输入。`groups` 只是成员身份标签：不会自动产生亲信、支持、党纪压力或同向随机变化。输入同一成员两次会报错。党团、党组织及 Bundestag 都必须各自提供选民册，不能从另一机构继承票权。

### 两种人物精度

1. **已有完整人物卡的核心角色**：使用 `integration.persona_ballot_decision()`，把当前可见环境转成 yes/no/abstain 三个 `ActionOption`，调用原 `FreeAgentDecisionEngine`。其 PSS、记忆和关系仍由原引擎处理。返回的 `member_patch` 合并到本次选民册。该选择不会被插件另一套效用公式重复计算或随机改写；出席仍单独结算。信息发生变化时，应重新调用人物决策，而不是永久锁票。
2. **未做完整 Persona 的背景成员**：用逐人、逐议题效用近似。每人保留独立偏好、选区利益及已取证的关系，绝不是某领袖的固定票仓。

公开支持承诺不是已经作出的投票决定，不可填入 `decided_vote`。未知关系不创建默认 tie；`runtime_tie()` 也只读取已经存在的关系，并标为模型运行状态，不伪装成现实测量。

## 行为近似与不确定性

对背景成员：政策接近、选区收益、对提案者信任、交换收益、支持风险、角色／使命一致性、已知公开立场的网络影响和可观察的纪律压力，分别保存原始值、权重与贡献。

政策项默认是 `与否决基线的距离 − 与提案的距离`；两边使用相同的可比较维度及议题显著性。它是相对支持指数，仍作为净效用的一个贡献，不是效用或真实投票概率的经验估计。信任项仍为 `2 × trust − 1`。未知项不贡献正负分，另外列入 `unknown`，不能把“未知”解释为实际中立。网络只读取显式给出的有向关系和已向人物提供的立场，不递归读取他人真实投票；插件自身不验证消息交付，须由上游信息系统保证。

## 行为版本1.1：关系强度、逐行动成本与纪律分量

输出记录`behavior_version=majorities-behavior-1.1`，输入schema仍兼容1.0。

网络默认`network_mode=bounded_strength`：`方向=sum(influence×stance)/sum(influence)`，`强度=min(1,sum(influence))`，二者相乘。单个0.001强度联系人不再与1.000联系人等效。强度是显式模型参数，不能从共同雇主、党团身份或任命推断；仍需个人network权重才进入选择。旧方向平均值算法可显式选择`normalized_direction_legacy`作对照。

原assessment顶层constituency/exchange/risk/mandate保持“相对支持指数”解释，会在yes/no之间镜像；如果要描述各行动自身的代价，应使用：

```json
"assessments": {
  "A": {
    "choice_impacts": {
      "yes": {"risk": 0.800},
      "no": {"risk": 0.800},
      "abstain": {"risk": 0.000}
    },
    "source_status": "MODEL_ASSUMPTION"
  }
}
```

三个选择必须完整、使用相同指标；risk是该行动的非负成本，其他指标是有符号收益。每项仍乘成员对应权重。不能在同一assessment顶层再填risk，否则重复计分会报错。作用于背景效用，不改写已有Persona的decided_vote。未知个人权重不会偷偷补满。

党团指令可以使用旧intensity，或显式填写`coordination`和`sanction`；不得混用。纪律原值为`stance×min(1,coordination+sanction×observability)`，再乘个人discipline权重。秘密投票令observability=0，保留已声明的协调项。它是输入假设，不表示对个别秘密投票的观测，也不自动执行制裁。缺少其中一项会报错，避免默认补入服从。

每位成员的诊断保留network_diagnostics、discipline_diagnostics、utility_components以及choice_impacts的适用语义。ties可额外指定issue_version和valid_until，阻止把旧版本/已过期的关系判断带入本次法案。runtime_tie支持显式influence和issue_version；默认influence仍为0，不从私人信任推导组织动员力。

### 现状／否决基线（A11修复）

```json
"issue": {
  "id": "toy", "version": "v1",
  "position": {"x": 0.800},
  "status_quo": {
    "position": {"x": 0.500},
    "source_status": "MODEL_ASSUMPTION"
  }
}
```

上面只是虚构输入示例，不是现实数据。`status_quo`单独接受source_status/source_ids/available_from；非假设数据须有来源及截止日前可用日期。它表示本节点否决后的比较基线，不自动意味着世界永远不变。涉及日落条款、其他谈判方案或后续预算风险时，需要重新构造相应基线或使用更完整的战略树，不能一概复制当前数值。

省略status_quo时，政策项为未知、贡献0，不猜0.500，也不退回旧距离公式。仅在提案、成员偏好和基线三者都有的维度比较；缺少部分维度标PARTIAL_COMPARISON，无共同正显著性维度则标未知。个人提案红线仍使用原提案距离，不能因为现状更差就自动突破。

逐人`policy_comparison`记录两种距离、维度、缺失维度、相对优势及基线来源；原`policy_distance`保留为提案绝对距离。实际Personа的decided_vote仍优先，诊断不重复替其投票。

确需检查旧算法时可显式设置`issue.policy_mode="legacy_proposal_distance"`，输出标为LEGACY_NONCOMPARATIVE，使用旧`1 − 2 × distance`。不得同时提供status_quo，避免静默忽略新输入。该模式仅为复查旧实验，不是A11修复后的推荐预测逻辑。默认模式为comparative_status_quo；兼容模式与默认模式的票数不应混报。

附带的五人委员会示例已补明确的虚构现状假设。历史协议没有自动补录，也没有用真实票数倒推现状或成员偏好。

背景模型的净效用为各项贡献之和。赞成／反对效用分别为净效用及其相反数；弃权有独立效用。softmax 得到条件选择分布，再乘出席率。该对称效用是 **v1 假设**，不是已经估计出的德国议员行为规律。复杂的不对称取舍优先交给完整 Persona。

参数使用 0–1；有方向的影响与载荷使用 −1–1；效用和贡献是派生分值，不强制限制为支持率。终端显示三位小数，文件保留计算精度。

- `temperature`：未观测信息与执行偏差的尺度，不能理解为人格随机波动。
- `contingencies`：每项共同冲击须明确成员载荷、因果理由和来源状态；同州、同组织不自动共享冲击。
- 人物权重固定。每次 ensemble 重新抽信息／协调偶然性、潜在选择偏差和出席，不重新抽人格。
- baseline 是逐人众数构成的代表性表决；期望票数另列，**不会对四舍五入后的期望数进行法律结算**。
- 同 seed、同输入可复现；调整 JSON 名单顺序不会改变抽签结果。

## 客观制度层

`BallotRule` 与人物认知完全分开，支持有效赞反票简单多数、全体成员绝对多数、指定分数的成员／有效赞反票多数。弃权、无效票、缺席分开计数；已知实际计票可直接传入 `count`，不必先预测。

法定人数分为显式清点 `verified`、程序上推定 `presumed`、此规则不要求人数门槛 `none`。推定模式也保留数值上是否达标的诊断，不伪造实际出席。程序未准备好时返回 `PENDING_PROCEDURE`，不因赞成多就执行。

**不能仅凭机构名字自动选择规则。** 每次请求必须给出规则及依据。`VERIFIED_RULE` 需要可用日期；过期、未来规则拒绝运行。`HISTORICAL_REFERENCE` 不允许直接当成现行规则执行。历史规则的实验性复用必须改为明确的 `MODEL_ASSUMPTION`。

当前 v1 不自动执行：党团罢免／除名的双门槛、候选人多轮竞选、Bundesrat 州票统一投票、修宪实质界限、法律公布生效。它们需要单独的程序状态机和既有客观检查层。普通议案通过也不是整部法律自动生效。

### 秘密表决

秘密表决把个人投票的可观察纪律项设为零，但不会删除政策、信任、共同目标。**这是显式行为假设，不是史料中的心理定律**；现实中的间接压力、预先协调等可通过独立取证的风险／角色项表达，不与“知道谁投了什么”混淆。

默认不输出秘密表决的逐人实际票和实际关键票名单。`reveal_forensic_ballots` 仅供引擎调试，不能传给人物或用于识别、惩罚秘密倒戈者。公开事件适配器始终过滤秘密个人票。

## 多数、组织控制、关键性不是同一个指标

`power` 计算小规模互斥玩家集合的标准化 Banzhaf 和 Shapley–Shubik；另外给出排除禁配组合后的可行关键组合计数。后者不冒称“受约束的 Shapley 值”。

此处玩家必须是**显式假设共同投票、且不重叠的集合**；MIT／CDA、州组织、年龄组这类交叉身份不能直接各自带票相加。重复成员会报错。最多 18 个玩家，超过时拒绝指数级枚举，不能偷偷截断。

标准指数是席位／程序结构的诊断，不是现实谈判权、忠诚或通过概率。实际公开表决还提供“一人改投哪个选项会改变结果”的计票反事实；它不声称当事人愿意改投。

议程控制、职位分配、提名资源、真实谈判和承诺兑现不能从指数直接推出。本版只接收已评估的交换收益，不自动签约或兑现；完整承诺账本和多轮谈判仍待实现。

## 使用

在项目根目录运行：

```sh
python3 -m hakoniwa majorities verify --request hakoniwa/plugins/majorities/examples/committee.json
python3 -m hakoniwa majorities run --request hakoniwa/plugins/majorities/examples/committee.json --output outputs/majorities_plugin_smoke/result.json
python3 -m hakoniwa.plugins.majorities run --request hakoniwa/plugins/majorities/examples/committee.json --pretty
```

`power` 请求格式：

```json
{"players":{"A":["a1","a2"],"B":["b1"],"C":["c1"]},"quota":3,"forbidden_pairs":[["A","C"]]}
```

`count` 请求格式：

```json
{"as_of":"2026-10-23","rule":{"total_weight":5,"kind":"simple_cast","quorum":"verified"},"counts":{"yes":3,"no":1,"abstain":1,"absent":0,"invalid":0}}
```

示例全部为虚构五人委员会和一名无票权来宾，不是德国议员的测量数据，也不是对现实法案的预测。

## 接入原世界

1. 世界时钟／信息系统形成该节点的人物可见信息；不能把未送达的内部立场直接放入公开 `stances`。
2. 核心人物使用原 Persona 作出本次选择；背景成员使用明确标注的议题假设。
3. 用完整选民册、实际程序和版本化规则运行插件。
4. 预测不改变世界。只有选定执行路径中的一次实际表决才产生 `outcome_event()`，交给既有世界／程序 resolver。
5. `apply_persona_outcomes()` 可显式调用原 PSS 更新；不预设“赢了回血”“输了都背叛”。影响归因由真实事件与人物职责决定。
6. 投票事实进入媒体／叙事→选民反应→民调插件。这里没有预设支持率奖励。完整情景报告仍由原报告流记录每节点民调及所有实际使用人物的 PSS 折线；本插件单元测试不伪造这些时间序列。

`LegislativeCycle.run()`与`ParliamentClockService`现通过`plugins/majorities/service.py`接入。只有集团比例的输入经`BallotGroupPrior`展开为匿名成员的显式`ballot_prior`；这只是低精度输入转换，不表示这些人的政策立场、人际关系或纪律已经完成研究。原生完整成员请求仍直接使用MajorityModel。

`ballot_prior`必须给出yes/no/abstain三个加总为1的条件先验，出席另算；不能与人物已决定投票、个人效用权重、政策位置、党团指令或关系输入悄悄叠加。需要这些机制时应迁为原生成员效用/Persona。集团输入不再接受无效的`discipline`，旧`hidden_defection_sigma`也不再接受；新字段`shared_logit_sigma`明确是共同信息的logit扰动，不是原来的支持率百分点扰动。禁止据此宣称历史系数已校准。

确定性结算使用逐人众数代表票，不再取整期望总票数；二者均不是联合分布众数。随机抽票统一走MajorityModel.ballot，实际门槛统一由BallotRule.settle判断。保留的VoteRule.required_yes只用于显示分数期望下的诊断门槛。具体迁移及行为差异见`MIGRATION_20261025.md`。

## 考据与校准状态

细节见 `SOURCE_NOTES_CN.md` 和 `evidence_catalog.json`，并链接前一批组织／关系考据。形式计票、未知输入隔离、复现性已有工程测试；议员效用权重、温度、共同冲击载荷、出席率 **均未完成现实数据估计**。输出频率只描述这些输入条件下的模型，不是现实通过概率。
# 不同党团的独立指令

`issue.whips` 可按党团分别指定 `stance`（−1..1）、`intensity`（0..1）以及可选来源信息。不得与旧的 `issue.whip` 同时使用。成员仅在显式设置 `weights.discipline` 时受到该指令影响；党团标签本身不会自动生成忠诚。秘密投票仍去除个人可观察纪律项。公开 `model.ballot(seed)` 返回一次可复现联合表决；原来的 `baseline()` 仍为逐人众数诊断，不能把它视为联合票数分布的众数。

