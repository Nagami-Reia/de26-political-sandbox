# 单一投票引擎迁移 · 2026-10-25

`hakoniwa/parliamentary_vote.py`已删除，没有保留旧模块转发入口。原`ParliamentaryVoteModel`和`BlocVotePrior`不再存在。

唯一抽票与成员评价引擎：`plugins/majorities/model.py`的MajorityModel。

唯一实际计票门槛：`plugins/majorities/rules.py`的BallotRule.settle。

世界输入、摘要和反馈适配器：`plugins/majorities/service.py`的MemberVoteService。这里保留VoteRule、VoteForecast、VoteResult、VoteFeedback等显示/传输对象；没有保留旧独立随机抽票算法。

## 已迁移调用者

- 世界时钟ParliamentClockService；操作名parliamentary_vote保持不变。
- LegislativeCycle：期望票数只作预测展示，实际结算不再将它取整。
- october_2026_three_state的条件性表决实验。
- 阈值、守恒、世界服务和插件接线测试。
- 历史debug审计脚本的可执行引用；历史输出保留当时的代码与结论。

## 两种输入精度

1. 完整选民册和逐议题效用/Persona：直接调用MajorityModel或MemberVoteService.run_member_vote，保持现有政策、纪律、关系、出席逻辑。
2. 只有集团席位和yes/no/abstain比例：用BallotGroupPrior编译为每人一票的显式ballot_prior，所有实际抽票仍用同一MajorityModel。它没有创造个人政策位置、人物卡、真实关系或组织忠诚。

第二种模式是数据精度有限，不是另一套投票器。未知个人机制明确列入unknown。不能把先验比例再叠加纪律、信任或政策效用；要提高精度，须提供原生成员输入。

## 明确的行为变化

- 删除未生效的discipline参数；提供它会报错，不会静默忽略。
- hidden_defection_sigma删除；新shared_logit_sigma以共同logit倾斜表达信息扰动。数值单位不同，旧系数不得视为已校准的新系数。
- 旧整团概率偏移/重新归一化算法删除；原随机种子的票数不保证一致。
- 确定性代表票按逐人众数产生，不再将分数期望取整。保留分数期望摘要，两者不混用。
- 原集团调用只作计票实验，quorum=none，不因此声称已核准法定人数、授权或法案生效。真实制度检查仍需配置客观程序层。
- 仅有MODEL_ASSUMPTION地位的集团比例可用简化适配器；不能用无日期、无逐人来源的集团数据声称观察到了每个人的真实投票偏好。

## 同时修复的输入隔离

MajorityModel现从深复制后的同一个快照完成校验和运行。外部修改原输入，不再改变已经构造的表决或绕过来源校验。

## 尚未解决

移除双引擎不会自动修复关系归因、零证据关系学习、网络强度归一化、协商尝试自动获益等审计问题。那些仍需分别修复、分别对照，不能用本次迁移宣称整机历史复现已成功。
