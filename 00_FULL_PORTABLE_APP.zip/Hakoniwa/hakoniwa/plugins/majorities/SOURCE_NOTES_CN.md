# 投票与组织多数：规则考据及实现边界

核对日期：2026-10-23。原始法律／组织规则、研究解释、行为假设分开。以下“已读”仅指指定正文，不包括所有链接或全部期刊文献。

## 1. 自由授权与党团协调

[GG Art.38](https://www.gesetze-im-internet.de/gg/art_38.html) 的议员自由授权，与[党团官方组织说明](https://www.cducsu.de/fraktion/organisation)所述的集体讨论、预先通报分歧同时存在。不能编码为“主席决定→成员依法必须投赞成”。实现中纪律只是独立的行为项，不是制度硬约束；每位议员有自己的 yes/no/abstain。

党团说明也区分工作组、社会群体组及州组。一个人的多重身份不是多张票；工作组准备和主席安排议程，也不等于全体会议已经通过。

## 2. Bundestag：先确定分母，再确定法定人数的程序状态

[GO-BT §48](https://www.gesetze-im-internet.de/btgo_2025/__48.html)：普通规则下比较赞反有效票，平票不通过；弃权和无效票不加入简单多数分母。它们仍可能计入出席数。插件把“弃权”“无效”“缺席”分开，普通表决简单多数与全体成员多数使用不同门槛。

[GG Art.121](https://www.gesetze-im-internet.de/gg/art_121.html)：涉及宪法所称成员多数时，应以法定成员数为分母，不随缺席缩小。

[GO-BT §45](https://www.gesetze-im-internet.de/btgo_2025/__45.html)及[Bundestag 官方解释第 VII 节](https://www.bundestag.de/parlament/aufgaben/rechtsgrundlagen/erlaeuterungen_geschaeftsordnung/)：法定人数的数值条件与正式质疑、清点程序须分开。`presumed` 不声称实际出席足够；`verified` 则检查是否超过全体的一半。本版不自行判断一项质疑是否满足提起资格，须由既有程序层确定后传入。

[GG Art.79(2)](https://www.gesetze-im-internet.de/gg/art_79.html)同时要求 Bundestag 成员与 Bundesrat 票的特定多数。插件的成员分数多数只计算这次 Bundestag 表决，不据此宣告修宪完成。

## 3. 2018 党团工作条例：确实取得并读到全文，但不是现行版本证明

[官方 PDF：19. Wahlperiode，2018-04-17](https://www.cducsu.de/sites/default/files/2018-05/WP19%20Arbeitsordnung_17.04.2018_0.pdf)，13 页正文已读。

它给出了比普通官网介绍更具体的程序差异：§12 的会议有效条件不等于 Bundestag 的过半出席规则；§13 规定秘密选举及多轮程序；§14 罢免和 §15 除名门槛不同；§17 区分自由投票与事先告知分歧。

因此本版没有把这份条例自动装成“2026 党团规则”。目录标为 `HISTORICAL_REFERENCE`，执行器拒绝把此状态当作可用规则。一般二元投票、完整人事选举、罢免和除名也不能混为同一个函数。

**尚未取得经过核对的第 21 届完整工作条例。** 不是因为“旧条文看起来合理”就默认仍生效。当前党团内部实验规则必须明确标为假设，或另提供适用版本。

## 4. CDU 党内组织：成员资格、席位与投票方法分开

[现行 CDU 章程](https://www.cdu.de/app/uploads/2026/03/Statutenbroschuere-der-CDU-Deutschlands.pdf)的 §§28–34 处理不同联邦机构的组成和权限，§§40–43 另规定会议及表决。主席团的咨询参与者不能与有表决权成员合并。

同一人兼任多个职位，也不能在同一个按人表决机构重复计票。党代会代表权不等于 Bundestag 席位，组织会员人数也不直接等于该组织掌握的议员票。

插件通过独立选民册、`eligible` 和唯一成员 ID 避免这些错误；按人表决禁止额外权重。确要做代表组汇总，必须选择 `weighted_assembly` 并承认整体共同投票假设，不得冒充逐人模型。

章程只读了组织、会员和表决相关章节，不宣称 142 页法律汇编全部完成阅读。细目及冲突见[上一批研究笔记](../../data/research/cdu_organization_2026_10_23/README_CN.md)。

## 5. 交叉组织与人际关系：哪些能直接录入

- [雇员组名册](https://www.cducsu.de/fraktion/gruppen/arbeitnehmergruppe)与[PKM 名册](https://www.cducsu.de/fraktion/gruppen/parlamentskreis-mittelstand)：可记录 Frei、Gramling 的交叉组织身份，不能据此将这两组视为他们的私人阵营。
- [MIT 章程 §4(4)](https://www.mit-bund.de/content/satzung)：排除 MIT 与 CDA 双重会员。它不排除党团雇员组与 PKM 交叉加入。四个实体不得混用。
- [CDA 2026-10-16 的共同署名介绍](https://www.cda-bund.de/aktuelles/arbeit-entlasten-und-aufstieg-ermoeglichen/)：可录一次社会政策合作，不能外推为稳定领袖派系。
- [Höhne/Koch 原始研究](https://mip.pruf.hhu.de/article/download/634/643/2522)，研究正文已读：职位与支持关系须分别取证；其 2018 年分析不提供 2026 年议员忠诚度参数。

本版明确拒绝把 `employment`、`appointment`、`shared_membership`、`shared_region` 当作个人信任／影响的 tie 证据。真实依赖可以另作资源约束，但不能自动改名为忠诚。

## 6. 权力指数：数学诊断不等于实测政治权力

Shapley–Shubik（1954，DOI 10.2307/1951053）的重印 PDF 找到但读取超时，**不计为全文已读**。[作者研究库中的 Gelman/Katz/Bafumi 论文](https://sites.stat.columbia.edu/gelman/research/published/banzhaf_bjps_final.pdf)已读摘要及第 1–2 节：其讨论强调经典指数依赖先验投票结构，不能跳过真实投票模式的经验核查。该研究是选举制度研究，不能直接作为 CDU 党团行为参数。

所以本版将席位结构指数与逐人议题模型分开；禁配约束后的可行关键组合另列，避免把不现实联盟混进现实谈判能力结论。本文献阅读状态与工程正确性测试也分开：算出正确的对称指数，不代表预测正确。

## 7. 尚缺的实证工作

需要按议题收集正式记名表决、解释性发言、联合署名、公开背书、实际修改案、缺席原因和时间一致的名录。秘密表决只可用总数校准，不能反推并声称知道某个人投了什么。

尚未估计：成员效用权重、真实温度、派系共同冲击、网络影响强度、秘密投票的压力变化。历史规章与现行名册也不能把这些未知行为参数“考据出来”。例子中的数值全部是测试假设。
