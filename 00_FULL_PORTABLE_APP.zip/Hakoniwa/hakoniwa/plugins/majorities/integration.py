"""Explicit bridges to the existing persona and political-world systems."""
from dataclasses import asdict
from collections.abc import Mapping


def persona_ballot_decision(engine, actor, actions, resources, *, issue_id, available_from, goals=None):
    """Run the real persona engine, not a new leader-loyalty formula.

    Caller supplies three context-specific ActionOptions: yes/no/abstain.
    The returned decision applies to this ballot only; new information requires
    a new persona decision. Public promises must not use this adapter.
    """
    if set(actions) != {"yes", "no", "abstain"}:
        raise ValueError("persona ballot requires yes/no/abstain actions")
    if len({action.key for action in actions.values()}) != 3:
        raise ValueError("persona ballot action keys must be distinct")
    cards = getattr(engine, 'cards', {})
    profile = cards[actor].components.get("voting", {}) if isinstance(cards, Mapping) else {}
    if profile and set(profile["legal_vote_options"]) != set(actions):
        raise ValueError("Ballot choices do not match this persona's voting adapter")
    decision = engine.decide(actor, tuple(actions.values()), resources, current_goals=goals or {})
    choice = next(label for label, action in actions.items() if action.key == decision.chosen_action)
    return {
        "member_patch": {
            "id": actor, "decided_vote": choice, "source_status": "RUNTIME_MODEL_STATE",
            "source_ids": [f"persona_decision:{actor}:{issue_id}:{decision.turn}"],
            "available_from": available_from,
        },
        "persona_trace": asdict(decision),
        "persona_component": {"source": "voting.json" if profile else "LEGACY_CONTEXT_ONLY",
            "eligibility": profile.get("eligibility", "WORLD_MUST_VERIFY"),
            "seat_granted": False},
    }


def runtime_tie(engine, member_actor, counterpart, *, issue_id, available_from, influence=0., issue_version=None):
    """Read only an existing directed relationship. Never create a default tie.

    The runtime's 0.5 values remain MODEL STATE, not historical measurement.
    The caller chooses which relationship is relevant and visible at this node.
    """
    if member_actor not in engine.runtime:
        raise ValueError("unknown persona actor")
    from .model import unit
    unit(influence,'runtime_tie.influence')
    relation = engine.runtime[member_actor].relationships.get(counterpart)
    if relation is None:
        return None
    row = {
        "from": member_actor, "to": counterpart, "trust": relation.trust,
        "influence": influence, "evidence_kind": "existing_runtime_relationship",
        "issue_scope": issue_id, "source_status": "RUNTIME_MODEL_STATE",
        "source_ids": [f"persona_runtime:{member_actor}:{counterpart}"],
        "available_from": available_from,
    }
    if issue_version is not None:
        row['issue_version']=issue_version
    return row


def outcome_event(model, ballot):
    """Emit objective aggregate fact, not polls, actor beliefs or legislation."""
    result = ballot["result"]
    return {
        "event_kind": "organizational_ballot_settled",
        "body": model.body["id"], "issue": model.issue["id"],
        "issue_version": model.issue["version"],
        "counts": dict(result["counts"]), "status": result["status"],
        "source_status": "SIMULATED_OUTCOME",
        "rule_source_status": model.rule.source_status,
        "individual_ballots": None if model.secret else result["member_ballots"],
        "requires_next_stage": True,
        "automatic_poll_delta": None,
        "automatic_law_in_force": False,
    }


def apply_persona_outcomes(engine, outcomes):
    """Use existing PSS/memory logic; caller must justify impact attribution.

    Deliberately no generic winner-reward and no secret-defector punishment.
    This function is opt-in, separate from forecasting and vote counting.
    """
    from ...persona_v2 import ActionOutcome
    prepared = {}
    for actor, raw in outcomes.items():
        if actor not in engine.runtime:
            raise ValueError("unknown outcome actor")
        prepared[actor] = ActionOutcome(**raw)
    return {actor: engine.apply_outcome(actor, outcome) for actor, outcome in prepared.items()}
