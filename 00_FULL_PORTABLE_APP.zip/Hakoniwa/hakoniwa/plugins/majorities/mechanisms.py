"""Shared instruction semantics for background utilities and persona adapters.

This only interprets an explicitly supplied instruction. It neither infers
loyalty nor confers authority, votes, information delivery or an agreement.
"""
import math


def validate_instruction(row):
    def bounded(value,name,signed=False):
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not (-1 if signed else 0)<=value<=1:
            raise ValueError(f'{name} must be finite in the declared unit range')
    bounded(row.get('stance',0),'stance',True)
    separated='coordination' in row or 'sanction' in row
    if separated:
        if 'intensity' in row or not {'coordination','sanction'}<=set(row):
            raise ValueError('Use intensity OR both coordination and sanction')
        bounded(row['coordination'],'coordination');bounded(row['sanction'],'sanction')
    else:
        bounded(row.get('intensity',0),'intensity')


def instruction_components(row, *, secret=False, observability=1.):
    validate_instruction(row)
    if type(secret) is not bool:
        raise ValueError('secret must be boolean')
    if isinstance(observability,bool) or not isinstance(observability,(int,float)) or not math.isfinite(observability) or not 0<=observability<=1:
        raise ValueError('observability must be in 0..1')
    observed=0. if secret else observability
    coordination=row.get('coordination',0.)
    sanction=row.get('sanction',row.get('intensity',0.))*observed
    return {'mode':'SEPARATED' if 'coordination' in row else 'LEGACY_OBSERVABLE_INTENSITY',
        'signal':row.get('stance',0)*min(1.,coordination+sanction),
        'coordination':coordination,'observable_sanction':sanction,'observability':observed,
        'instruction_does_not_confer_legal_authority':True}
