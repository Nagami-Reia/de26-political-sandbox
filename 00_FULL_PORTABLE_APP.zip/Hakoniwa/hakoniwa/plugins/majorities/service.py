"""World-facing input/feedback adapter for the single member-level voting engine.

Group shares compile to explicitly assumed individual ballot priors; this module
has no independent vote sampler or actual-ballot majority predicate. Raw shares
are not reconstructed ideology, discipline, personal loyalty or real probabilities.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from math import ceil, floor, isfinite
import random
from functools import lru_cache
from .model import MajorityModel
from .rules import BallotRule
from typing import Mapping

from ...political_state import PoliticalAction, PoliticalState, PressureRule


VOTE_RULES = {
    "simple_cast",
    "absolute_members",
    "two_thirds_members",
    "two_thirds_cast",
}


def _integer(value, name: str, minimum: int = 0) -> None:
    if type(value) is not int or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")


def _finite_nonnegative(value, name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value) or value < 0:
        raise ValueError(f"{name} must be a finite nonnegative number")


def _validate_counts(rule: "VoteRule", yes, no, abstain, absent) -> None:
    for name, value in (("yes", yes), ("no", no), ("abstain", abstain), ("absent", absent)):
        _integer(value, name)
    if yes + no + abstain + absent != rule.total_members:
        raise ValueError("ballot counts must sum to total_members (record nonparticipants as absent)")


def _validate_blocs(rule: "VoteRule", blocs: tuple["BallotGroupPrior", ...]) -> None:
    if any(not isinstance(bloc, BallotGroupPrior) for bloc in blocs):
        raise ValueError("blocs must contain BallotGroupPrior records")
    keys = [bloc.key for bloc in blocs]
    if len(keys) != len(set(keys)):
        raise ValueError("bloc keys must be unique; overlapping memberships are not separate seat blocs")
    if sum(bloc.seats for bloc in blocs) != rule.total_members:
        raise ValueError("bloc seats must sum to total_members; include all eligible members")


@dataclass(frozen=True)
class VoteRule:
    kind: str = "simple_cast"
    total_members: int = 630

    def __post_init__(self) -> None:
        if self.kind not in VOTE_RULES:
            raise ValueError(f"unknown vote rule: {self.kind}")
        _integer(self.total_members, "total_members", 1)

    def required_yes(self, yes: float, no: float) -> int:
        # Forecast display only. All actual counts settle via BallotRule below.
        _finite_nonnegative(yes, "yes")
        _finite_nonnegative(no, "no")
        if yes + no > self.total_members + 1e-9:
            raise ValueError("yes + no exceeds total_members")
        if self.kind == "simple_cast":
            return floor(yes + no) // 2 + 1
        if self.kind == "absolute_members":
            return self.total_members // 2 + 1
        if self.kind == "two_thirds_members":
            return ceil(2 * self.total_members / 3)
        # A zero cast denominator cannot confer adoption by zero affirmative
        # votes. Shared by forecast, simulation and settlement, as in the
        # member-level plugin's fraction_cast predicate. Not a quorum check.
        return max(1, ceil(2 * (yes + no) / 3))


@dataclass(frozen=True)
class BallotGroupPrior:
    key: str
    seats: int
    attendance: float
    yes_share: float
    no_share: float
    abstain_share: float
    shared_logit_sigma: float = 0.0
    source_status: str = "MODEL_ASSUMPTION"
    linked_actor: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.key, str) or not self.key.strip():
            raise ValueError("bloc key must be a nonempty string")
        _integer(self.seats, "seats")
        for name in ("attendance", "yes_share", "no_share", "abstain_share"):
            _finite_nonnegative(getattr(self, name), name)
            if not 0 <= getattr(self, name) <= 1:
                raise ValueError(f"{name} must be within 0..1")
        if abs(self.yes_share + self.no_share + self.abstain_share - 1.0) > 1e-6:
            raise ValueError(f"vote shares for {self.key} must sum to 1")
        _finite_nonnegative(self.shared_logit_sigma, "shared_logit_sigma")
        if self.shared_logit_sigma>1:
            raise ValueError('shared_logit_sigma must be within 0..1')
        if self.source_status != 'MODEL_ASSUMPTION':
            raise ValueError('Group-only priors cannot claim sourced individual preferences; use a dated native member request')


@dataclass(frozen=True)
class VoteForecast:
    proposal: str
    stage: str
    rule: VoteRule
    expected_yes: float
    expected_no: float
    expected_abstain: float
    expected_absent: float
    required_yes: int
    expected_margin: float
    conclusion: str
    pivotal_blocs: tuple[str, ...]
    assumptions: tuple[str, ...]
    source_status: str = "MODEL_FORECAST"


@dataclass(frozen=True)
class VoteSimulation:
    runs: int
    seed: int
    passage_runs: int
    path_counts: Mapping[str, int]
    yes_interval_80: tuple[int, int]
    no_interval_80: tuple[int, int]
    warning: str = "Run shares are conditional model frequencies, not real-world probabilities."


@dataclass(frozen=True)
class VoteResult:
    proposal: str
    stage: str
    yes: int
    no: int
    abstain: int
    absent: int
    required_yes: int
    passed: bool
    outcome_class: str
    source_status: str


@dataclass(frozen=True)
class VoteFeedback:
    outcome_class: str
    effects: Mapping[str, float] = field(default_factory=dict)
    capital_delta: Mapping[str, float] = field(default_factory=dict)
    pressure_delta: Mapping[str, float] = field(default_factory=dict)
    locks_add: tuple[str, ...] = ()
    tags: tuple[str, ...] = ("parliamentary_feedback",)


class MemberVoteService:
    def run_member_vote(self, request: Mapping) -> dict:
        """Run a native member request using the canonical engine.

        Requires a complete eligible roster and an explicit rule.
        Returns forecasts and a sampled ballot, without mutating the world.
        """
        from .model import run_request
        return run_request(dict(request))

    def forecast(
        self,
        proposal: str,
        stage: str,
        rule: VoteRule,
        blocs: tuple[BallotGroupPrior, ...],
        assumptions: tuple[str, ...] = (),
    ) -> VoteForecast:
        _validate_blocs(rule, blocs)
        yes = sum(b.seats * b.attendance * b.yes_share for b in blocs)
        no = sum(b.seats * b.attendance * b.no_share for b in blocs)
        abstain = sum(b.seats * b.attendance * b.abstain_share for b in blocs)
        absent = sum(b.seats * (1 - b.attendance) for b in blocs)
        required = rule.required_yes(yes, no)
        margin = yes - required
        if margin >= 15:
            conclusion = "clear_pass"
        elif margin >= 3:
            conclusion = "lean_pass"
        elif margin >= 0:
            conclusion = "knife_edge_pass"
        elif margin > -3:
            conclusion = "knife_edge_fail"
        elif margin > -15:
            conclusion = "lean_fail"
        else:
            conclusion = "clear_fail"
        pivotal = tuple(
            b.key for b in blocs
            if .15 <= b.yes_share <= .85
            and b.seats * b.attendance * (2 * b.shared_logit_sigma) >= 1.0
        )
        return VoteForecast(
            proposal, stage, rule, round(yes, 2), round(no, 2),
            round(abstain, 2), round(absent, 2), required, round(margin, 2),
            conclusion, pivotal, assumptions,
        )

    @staticmethod
    @lru_cache(maxsize=32)
    def compile_groups(rule, blocs):
        """Input migration only. All draws and settlement run in MajorityModel."""
        _validate_blocs(rule, blocs)
        if any(b.source_status != "MODEL_ASSUMPTION" for b in blocs):
            raise ValueError("Group-only adapter cannot assert observed individual priors without dated evidence; supply a full member request")
        members, contingencies = [], []
        for bloc in blocs:
            ids = []
            for i in range(bloc.seats):
                key = f"{bloc.key}:{i:04d}"
                ids.append(key)
                members.append({"id":key, "party":bloc.key,
                    "attendance":bloc.attendance, "source_status":"MODEL_ASSUMPTION",
                    "ballot_prior":{"yes":bloc.yes_share, "no":bloc.no_share,
                        "abstain":bloc.abstain_share, "source_status":"MODEL_ASSUMPTION"}})
            if bloc.shared_logit_sigma:
                contingencies.append({"id":bloc.key, "sigma":bloc.shared_logit_sigma,
                    "loadings":dict.fromkeys(ids,1.),
                    "reason":"Declared group-level missing information; logit units, not legacy share-point shock",
                    "source_status":"MODEL_ASSUMPTION"})
        mapping={"simple_cast":"simple_cast","absolute_members":"absolute_members",
                 "two_thirds_members":"fraction_members","two_thirds_cast":"fraction_cast"}
        return MajorityModel({"schema_version":"hakoniwa-majorities-1.0",
            "as_of":"1970-01-01",
            "body":{"id":"DECLARED_PRIOR_ROSTER","kind":"bundestag","secret":False},
            "rule":{"total_weight":rule.total_members,"kind":mapping[rule.kind],
                "quorum":"none","source_status":"MODEL_ASSUMPTION",
                "authority":"Count-only group-input adapter; no quorum/legal readiness claim"},
            "issue":{"id":"declared_prior","version":"1","source_status":"MODEL_ASSUMPTION"},
            "members":members,"contingencies":contingencies})

    def _sample_once(self, rule, blocs, rng):
        model=self.compile_groups(rule,blocs)
        counts=model.ballot(rng.getrandbits(128))["result"]["counts"]
        return tuple(counts[k] for k in ("yes","no","abstain","absent"))

    def representative_counts(self, rule, blocs):
        """Per-member modal diagnostic, never rounded expected aggregate votes."""
        counts=self.compile_groups(rule,blocs).baseline()["result"]["counts"]
        return tuple(counts[k] for k in ("yes","no","abstain","absent"))

    @staticmethod
    def _outcome_class(passed: bool, margin: int) -> str:
        if passed and margin >= 15:
            return "clear_pass"
        if passed:
            return "narrow_pass"
        if margin > -15:
            return "narrow_fail"
        return "clear_fail"

    def simulate(
        self,
        rule: VoteRule,
        blocs: tuple[BallotGroupPrior, ...],
        runs: int = 5000,
        seed: int = 0,
    ) -> VoteSimulation:
        _integer(runs, "runs", 1)
        _validate_blocs(rule, blocs)
        rng = random.Random(seed); counts: dict[str, int] = {}; yes_values = []; no_values = []; passage = 0
        for _ in range(runs):
            yes, no, abstain, absent = self._sample_once(rule, blocs, rng)
            result=self.settle('declared_prior','ensemble',rule,yes,no,abstain,absent)
            passed=result.passed;label=result.outcome_class
            counts[label] = counts.get(label, 0) + 1; passage += int(passed)
            yes_values.append(yes); no_values.append(no)
        yes_values.sort(); no_values.sort()
        lo = floor((runs - 1) * .10); hi = ceil((runs - 1) * .90)
        return VoteSimulation(runs, seed, passage, counts, (yes_values[lo], yes_values[hi]), (no_values[lo], no_values[hi]))

    def settle(
        self,
        proposal: str,
        stage: str,
        rule: VoteRule,
        yes: int,
        no: int,
        abstain: int,
        absent: int,
        source_status: str = "SIMULATED_OUTCOME",
    ) -> VoteResult:
        _validate_counts(rule, yes, no, abstain, absent)
        mapping={"simple_cast":"simple_cast","absolute_members":"absolute_members",
                 "two_thirds_members":"fraction_members","two_thirds_cast":"fraction_cast"}
        result=BallotRule(rule.total_members,mapping[rule.kind],quorum="none").settle(
            dict(yes=yes,no=no,abstain=abstain,absent=absent,invalid=0))
        required=result["required_yes"];margin=result["margin"];passed=result["passed"]
        return VoteResult(proposal, stage, yes, no, abstain, absent, required, passed, self._outcome_class(passed, margin), source_status)

    def apply_feedback(
        self,
        state: PoliticalState,
        result: VoteResult,
        feedback_by_outcome: Mapping[str, VoteFeedback],
        pressure_rules: tuple[PressureRule, ...] = (),
    ) -> dict:
        if result.outcome_class not in feedback_by_outcome:
            raise KeyError(f"missing feedback for {result.outcome_class}")
        feedback = feedback_by_outcome[result.outcome_class]
        unknown = set(feedback.effects) - set(state.variables)
        if unknown:
            raise KeyError(f"vote feedback references unknown variables: {sorted(unknown)}")
        action = PoliticalAction(
            key=f"vote:{result.proposal}:{result.outcome_class}",
            effects={"immediate": feedback.effects, "medium": {}, "long": {}},
            capital_delta=feedback.capital_delta,
            pressure_delta=feedback.pressure_delta,
            locks_add=feedback.locks_add,
            tags=feedback.tags,
        )
        update = state.apply(action, pressure_rules)
        update["vote_result"] = asdict(result)
        return update

