"""Issue-dependent preferences -> correlated contingencies -> mechanical count.

All behavioral coefficients are explicit assumptions, not empirical estimates.
Membership tags alone have zero effect on utilities or correlation. Directed
ties must be supplied separately and never inferred from employment/appointment.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date
from hashlib import sha256
import math
import random

from .rules import BallotRule, integer
from .mechanisms import validate_instruction, instruction_components

CHOICES = ("yes", "no", "abstain")
TERMS = ("policy", "constituency", "trust", "exchange", "risk", "mandate", "network", "discipline")
WARNING = "Conditional model frequencies, not calibrated real-world passage probabilities."
BEHAVIOR_VERSION = 'majorities-behavior-1.1'


def unit(value, name, signed=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} must be finite numeric")
    if not (-1 if signed else 0) <= value <= 1:
        raise ValueError(f"{name} outside {'-1..1' if signed else '0..1'}")
    return float(value)


def rng_for(seed, *keys):
    digest = sha256(repr((seed, keys)).encode()).digest()
    return random.Random(int.from_bytes(digest, "big"))


def strict_keys(value, allowed, context):
    if not isinstance(value, dict) or set(value) - set(allowed):
        raise ValueError(f"unknown keys or invalid object in {context}: {set(value) - set(allowed) if isinstance(value, dict) else value}")


def provenance(raw, as_of):
    status = raw.get("source_status", "MODEL_ASSUMPTION")
    if status not in {"MODEL_ASSUMPTION", "OBSERVED", "REPORTED", "RUNTIME_MODEL_STATE", "HISTORICAL"}:
        raise ValueError("unknown source_status")
    if status != "MODEL_ASSUMPTION" and not raw.get("source_ids"):
        raise ValueError("non-assumption input needs source_ids")
    available = raw.get("available_from")
    if status != "MODEL_ASSUMPTION" and available is None:
        raise ValueError("non-assumption input needs available_from")
    if available and date.fromisoformat(available) > as_of:
        raise ValueError("evidence not available at cutoff")
    return {"source_status": status, "source_ids": raw.get("source_ids", []), "available_from": available}


class MajorityModel:
    """One fixed issue/version and one complete eligible roster per instance."""

    def __init__(self, request):
        self.request = deepcopy(request)
        # Every validated runtime field must come from the same isolated snapshot.
        request = self.request
        strict_keys(request, {"schema_version", "as_of", "body", "rule", "members", "issue", "ties", "stances", "contingencies", "seed", "runs", "reveal_forensic_ballots"}, "request")
        self.as_of = date.fromisoformat(request["as_of"])
        if request.get("schema_version", "hakoniwa-majorities-1.0") != "hakoniwa-majorities-1.0":
            raise ValueError("unsupported request schema_version")
        self.body = request["body"]
        strict_keys(self.body, {"id", "kind", "secret", "public_observability"}, "body")
        if self.body.get("kind") not in {"bundestag", "faction", "party_body", "weighted_assembly"}:
            raise ValueError("unknown body kind")
        if not isinstance(self.body.get("id"), str) or not self.body["id"]:
            raise ValueError("nonempty body id required")
        if type(self.body.get("secret", False)) is not bool:
            raise ValueError("secret must be boolean")
        self.secret = self.body.get("secret", False)
        self.observability = unit(self.body.get("public_observability", 1.0), "public_observability")
        self.rule = BallotRule(**request["rule"])
        self.rule.check_cutoff(self.as_of)
        self.issue = request["issue"]
        strict_keys(self.issue, {"id", "version", "proposer", "position", "assessments", "whip", "whips", "source_status", "source_ids", "available_from", "status_quo", "policy_mode", "network_mode"}, "issue")
        self.issue_provenance = provenance(self.issue, self.as_of)
        if not self.issue.get("id") or not self.issue.get("version"):
            raise ValueError("issue id and version required")
        self.position = {k: unit(v, "issue.position") for k, v in self.issue.get("position", {}).items()}
        self.policy_mode = self.issue.get("policy_mode", "comparative_status_quo")
        if self.policy_mode not in {"comparative_status_quo", "legacy_proposal_distance"}:
            raise ValueError("unknown policy_mode")
        self.network_mode = self.issue.get('network_mode','bounded_strength')
        if self.network_mode not in {'bounded_strength','normalized_direction_legacy'}:
            raise ValueError('Unknown network_mode')
        self.status_quo_position = {}
        self.status_quo_provenance = None
        if "status_quo" in self.issue:
            if self.policy_mode == "legacy_proposal_distance":
                raise ValueError("status_quo cannot be silently ignored in legacy policy mode")
            baseline = self.issue["status_quo"]
            strict_keys(baseline, {"position", "source_status", "source_ids", "available_from"}, "status_quo")
            if not isinstance(baseline.get("position"), dict) or not baseline["position"]:
                raise ValueError("status_quo requires a nonempty position mapping")
            self.status_quo_provenance = provenance(baseline, self.as_of)
            self.status_quo_position = {k: unit(v, "status_quo.position") for k, v in baseline["position"].items()}
        self.members = {}
        for member in request["members"]:
            strict_keys(member, {"id", "party", "eligible", "weight", "groups", "position", "salience", "weights", "attendance", "temperature", "abstain_utility", "max_policy_distance", "decided_vote", "ballot_prior", "source_status", "source_ids", "available_from"}, "member")
            key = member["id"]
            if not isinstance(key, str) or not key or key in self.members:
                raise ValueError("member IDs must be nonempty and unique")
            if type(member.get("eligible", True)) is not bool:
                raise ValueError("eligible must be boolean")
            weight = integer(member.get("weight", 1), "member.weight", 1)
            if self.body["kind"] != "weighted_assembly" and weight != 1:
                raise ValueError("one person one vote; aggregates require weighted_assembly")
            if len(set(member.get("groups", []))) != len(member.get("groups", [])):
                raise ValueError("duplicate organization membership")
            for name in ("position", "salience", "weights"):
                for value in member.get(name, {}).values():
                    unit(value, "member." + name)
            if set(member.get("weights", {})) - set(TERMS):
                raise ValueError("unknown member utility weight")
            for name, default in (("attendance", 1), ("temperature", .2), ("max_policy_distance", 1)):
                unit(member.get(name, default), name)
            if member.get("temperature", .2) == 0:
                raise ValueError("temperature must be positive; use baseline for deterministic choice")
            unit(member.get("abstain_utility", 0), "abstain_utility", True)
            provenance(member, self.as_of)
            if 'ballot_prior' in member:
                prior=member['ballot_prior']
                strict_keys(prior, {*CHOICES, 'source_status', 'source_ids', 'available_from'}, 'ballot_prior')
                if not set(CHOICES) <= set(prior):
                    raise ValueError('ballot_prior must declare all three choices')
                for choice in CHOICES: unit(prior[choice], 'ballot_prior.'+choice)
                if abs(math.fsum(prior[c] for c in CHOICES)-1.)>1e-9:
                    raise ValueError('ballot_prior must sum to one')
                provenance(prior,self.as_of)
                if any(member.get(k) for k in ('weights','position','salience')) or 'decided_vote' in member:
                    raise ValueError('Declared ballot prior cannot silently replace a persona or utility model')
            if "decided_vote" in member:
                if member["decided_vote"] not in CHOICES or member.get("source_status") != "RUNTIME_MODEL_STATE":
                    raise ValueError("decided_vote requires explicit persona runtime decision, not a public pledge or assumed loyalty")
            self.members[key] = member
        total = sum(m.get("weight", 1) for m in self.members.values() if m.get("eligible", True))
        if total != self.rule.total_weight:
            raise ValueError("complete eligible roster must match rule.total_weight")
        assessments = self.issue.get("assessments", {})
        if set(assessments) - set(self.members):
            raise ValueError("unknown assessed member")
        for assessment in assessments.values():
            strict_keys(assessment, {"constituency", "exchange", "risk", "mandate", "choice_impacts", "source_status", "source_ids", "available_from"}, "assessment")
            for name in ("constituency", "exchange", "mandate"):
                unit(assessment.get(name, 0), name, True)
            unit(assessment.get("risk", 0), "risk")
            provenance(assessment, self.as_of)
            if 'choice_impacts' in assessment:
                choices=assessment['choice_impacts']
                strict_keys(choices,CHOICES,'choice_impacts')
                if set(choices)!=set(CHOICES):
                    raise ValueError('Declare yes/no/abstain impacts together; missing is not neutral')
                metrics=None
                for choice, impacts in choices.items():
                    strict_keys(impacts,{'constituency','exchange','risk','mandate'},'choice_impacts.'+choice)
                    if not impacts or (metrics is not None and set(impacts)!=metrics):
                        raise ValueError('Every choice must explicitly describe the same nonempty impact metrics')
                    metrics=set(impacts)
                    for term,value in impacts.items():
                        unit(value,'choice_impacts.'+term,signed=term!='risk')
                if metrics & set(assessment):
                    raise ValueError('Do not count the same metric as both a relative-support index and a choice-specific effect')
        self.stances = {}
        for stance in request.get("stances", []):
            strict_keys(stance, {"actor", "stance", "source_status", "source_ids", "available_from"}, "stance")
            if stance["actor"] in self.stances:
                raise ValueError("duplicate stance; reconcile contradictory reports upstream")
            provenance(stance, self.as_of)
            self.stances[stance["actor"]] = unit(stance["stance"], "stance", True)
        self.ties = {}
        for tie in request.get("ties", []):
            strict_keys(tie, {"from", "to", "trust", "influence", "evidence_kind", "issue_scope", "issue_version", "valid_until", "source_status", "source_ids", "available_from"}, "tie")
            if tie["from"] not in self.members or tie["from"] == tie["to"]:
                raise ValueError("tie requires known sender and distinct recipient")
            pair = (tie["from"], tie["to"])
            if pair in self.ties:
                raise ValueError("duplicate directed tie")
            if not tie.get("evidence_kind"):
                raise ValueError("tie requires evidence_kind; unknown relationship must be omitted")
            if tie["evidence_kind"].lower() in {"employment", "appointment", "shared_membership", "shared_region"}:
                raise ValueError("organizational facts cannot be used as personal trust/influence evidence")
            if tie.get("issue_scope") not in {self.issue["id"], "general"}:
                raise ValueError("tie not applicable to this issue")
            if tie.get('issue_version',self.issue['version']) != self.issue['version']:
                raise ValueError('Relationship assessment is for another proposal version')
            if tie.get('valid_until') and date.fromisoformat(tie['valid_until'])<self.as_of:
                raise ValueError('Relationship assessment expired')
            provenance(tie, self.as_of)
            if tie.get("trust") is not None:
                unit(tie["trust"], "trust")
            unit(tie.get("influence", 0), "influence")
            self.ties[pair] = tie
        self.whip = self.issue.get("whip", {})
        strict_keys(self.whip, {"stance", "intensity", "coordination", "sanction", "parties", "source_status", "source_ids", "available_from"}, "whip")
        self._validate_instruction(self.whip)
        provenance(self.whip,self.as_of)
        # Explicit per-party coordination; a party label alone still adds none.
        self.whips = self.issue.get("whips", {})
        if not isinstance(self.whips, dict):
            raise ValueError("whips must map party IDs to explicit instructions")
        if self.whips and self.whip:
            raise ValueError("use whip or whips, not both")
        for party, row in self.whips.items():
            if party not in {m.get("party") for m in self.members.values()}:
                raise ValueError("whip references unknown party")
            strict_keys(row, {"stance", "intensity", "coordination", "sanction", "source_status", "source_ids", "available_from"}, "party whip")
            self._validate_instruction(row)
            provenance(row, self.as_of)
        self.contingencies = {}
        for contingency in request.get("contingencies", []):
            strict_keys(contingency, {"id", "sigma", "loadings", "reason", "source_status", "source_ids", "available_from"}, "contingency")
            key = contingency["id"]
            if key in self.contingencies or not contingency.get("reason"):
                raise ValueError("unique contingency ID and causal reason required")
            unit(contingency["sigma"], "sigma")
            for member, value in contingency["loadings"].items():
                if member not in self.members:
                    raise ValueError("unknown contingency member")
                unit(value, "contingency.loading", True)
            provenance(contingency, self.as_of)
            self.contingencies[key] = contingency

    _validate_instruction = staticmethod(validate_instruction)

    @staticmethod
    def _distance(position, member, dimensions):
        salience = member.get("salience", {})
        denominator = math.fsum(salience.get(k, 1) for k in dimensions)
        return (math.fsum(abs(position[k]-member["position"][k])*salience.get(k, 1)
                          for k in dimensions)/denominator if denominator else None)

    def _policy_comparison(self, member, proposal_distance):
        requested = sorted(k for k in set(self.position) & set(member.get("position", {}))
                           if member.get("salience", {}).get(k, 1) > 0)
        dimensions = [k for k in requested if k in self.status_quo_position]
        proposal = self._distance(self.position, member, dimensions)
        baseline = self._distance(self.status_quo_position, member, dimensions)
        if self.policy_mode == "legacy_proposal_distance":
            status = "LEGACY_NONCOMPARATIVE"
            advantage = 1-2*proposal_distance if proposal_distance is not None else 0
        elif not self.status_quo_position:
            status, advantage = "UNKNOWN_STATUS_QUO", 0
        elif baseline is None:
            status, advantage = "NO_COMPARABLE_DIMENSIONS", 0
        else:
            status = "PARTIAL_COMPARISON" if len(dimensions) < len(requested) else "COMPARATIVE"
            advantage = baseline-proposal
            # An arithmetic epsilon is not a genuine directional preference.
            if abs(advantage) <= 1e-12:
                advantage = 0.0
        return {"mode": self.policy_mode, "status": status, "dimensions": dimensions,
                "missing_status_quo_dimensions": [k for k in requested if k not in self.status_quo_position],
                "proposal_distance": proposal, "status_quo_distance": baseline,
                "relative_advantage": advantage,
                "status_quo_provenance": deepcopy(self.status_quo_provenance),
                "formula": "1 - 2 * proposal_distance" if self.policy_mode == "legacy_proposal_distance"
                           else "status_quo_distance - proposal_distance"}

    def evaluate_member(self, key, shocks=None):
        member = self.members[key]
        if 'ballot_prior' in member:
            if (key in self.issue.get('assessments', {}) or
                any(sender==key for sender,_ in self.ties) or
                member.get('party') in self.whips or member.get('party') in self.whip.get('parties', [])):
                raise ValueError('Declared ballot prior cannot absorb discipline, ties or assessments; use issue utilities/persona')
            prior=member['ballot_prior']
            shock=sum((shocks or {}).get(c,0)*v['loadings'].get(key,0) for c,v in self.contingencies.items())
            logits={c: math.log(prior[c])+({'yes':1.,'no':-1.,'abstain':0.}[c])*shock
                    for c in CHOICES if prior[c]>0}
            peak=max(logits.values())
            mass={c:math.exp(logits[c]-peak) if c in logits else 0. for c in CHOICES}
            total=sum(mass.values());attendance=member.get('attendance',1.)
            probabilities={c:attendance*mass[c]/total for c in CHOICES}
            probabilities['absent']=1-attendance
            return {'member':key,'eligible':member.get('eligible',True),
                'probabilities':probabilities,'choice_source':'DECLARED_BALLOT_PRIOR',
                'local_utilities_used_for_choice':False,'raw_terms':{},'weighted_terms':{},'utilities':{},
                'unknown':['individual_policy','relationships','discipline'],
                'input_source_status':member.get('source_status','MODEL_ASSUMPTION'),
                'utility_parameters_status':'UNVALIDATED_DECLARED_PRIOR',
                'prior_provenance':provenance(prior,self.as_of),
                'interpretation':'Low-resolution supplied prior, not researched individual preferences; shared shocks are logit tilts'}
        weights = member.get("weights", {})
        assessment = self.issue.get("assessments", {}).get(key, {})
        dimensions = sorted(set(self.position) & set(member.get("position", {})))
        distance = self._distance(self.position, member, dimensions)
        comparison = self._policy_comparison(member, distance)
        policy_unknown = (distance is None if self.policy_mode == "legacy_proposal_distance"
                          else comparison["status"] in {"UNKNOWN_STATUS_QUO", "NO_COMPARABLE_DIMENSIONS"})
        tie = self.ties.get((key, self.issue.get("proposer")))
        trust = tie.get("trust") if tie else None
        influence = [(t.get("influence", 0), self.stances[t["to"]]) for (sender, _), t in self.ties.items() if sender == key and t["to"] in self.stances and t.get("influence", 0)]
        norm = sum(w for w, _ in influence)
        direction = sum(w * s for w, s in influence) / norm if norm else 0
        strength = min(1.,norm)
        network = direction if self.network_mode=='normalized_direction_legacy' else direction*strength
        instruction = self.whips.get(member.get("party"), self.whip)
        disciplined = member.get("party") in self.whips or member.get("party") in self.whip.get("parties", [])
        # Secret-ballot observability is zero: a known aggregate cannot identify
        # an individual's vote. Conscience/trust/collective objectives remain.
        instruction_state=instruction_components(instruction if disciplined else {},secret=self.secret,observability=self.observability)
        discipline=instruction_state['signal']
        raw = {
            "policy": comparison["relative_advantage"],
            "constituency": assessment.get("constituency", 0),
            "trust": 2 * trust - 1 if trust is not None else 0,
            "exchange": assessment.get("exchange", 0),
            "risk": -assessment.get("risk", 0),
            "mandate": assessment.get("mandate", 0), "network": network,
            "discipline": discipline,
        }
        contributions = {name: raw[name] * weights.get(name, 0) for name in TERMS}
        net = sum(contributions.values())
        shock = sum((shocks or {}).get(c, 0) * v["loadings"].get(key, 0) for c, v in self.contingencies.items())
        relative = {'yes':net,'no':-net,'abstain':member.get('abstain_utility',0)}
        choice_terms={c:{term:(-value if term=='risk' else value)*weights.get(term,0)
                         for term,value in assessment.get('choice_impacts',{}).get(c,{}).items()}
                      for c in CHOICES}
        shock_terms={'yes':shock,'no':-shock,'abstain':0.}
        utilities = {c:relative[c]+math.fsum(choice_terms[c].values())+shock_terms[c] for c in CHOICES}
        blocked = distance is not None and distance > member.get("max_policy_distance", 1)
        available = [c for c in CHOICES if not (blocked and c == "yes")]
        peak = max(utilities[c] for c in available)
        exp = {c: math.exp((utilities[c] - peak) / member.get("temperature", .2)) if c in available else 0 for c in CHOICES}
        total = sum(exp.values())
        attendance = member.get("attendance", 1)
        probabilities = {c: attendance * exp[c] / total for c in CHOICES}
        probabilities["absent"] = 1 - attendance
        if "decided_vote" in member:
            # The existing persona engine already chose. Do not randomly
            # override that choice or count these diagnostic utilities twice.
            probabilities = {c: attendance if c == member["decided_vote"] else 0.0 for c in CHOICES}
            probabilities["absent"] = 1 - attendance
        return {
            "member": key, "eligible": member.get("eligible", True),
            "organization_tags": member.get("groups", []), "policy_distance": distance,
            "policy_comparison": comparison,
            "raw_terms": raw, "weighted_terms": contributions, "utilities": utilities,
            "utility_components":{"relative_support":relative,"choice_specific":choice_terms,"shared_information":shock_terms},
            "assessment_semantics":{"legacy_terms":"Relative support indices, mirrored between yes and no; not absolute action costs",
                                    "choice_impacts":"Per-action effects; risk is a cost only for the declared action"},
            "network_diagnostics":{"mode":self.network_mode,"direction":direction,"strength":strength,
                "total_influence":norm,"contacts":len(influence),'input_visibility':'CALLER_MUST_DELIVER_STANCES'},
            "discipline_diagnostics":{**instruction_state,"weighted_contribution":contributions['discipline']},
            "probabilities": probabilities, "yes_excluded_by_personal_red_line": blocked and "decided_vote" not in member,
            "unknown": [name for name, missing in (("policy", policy_unknown),
                        ("status_quo", self.policy_mode == "comparative_status_quo" and not self.status_quo_position),
                        ("proposer_trust", trust is None),
                        *((name, name not in assessment and name not in assessment.get('choice_impacts',{}).get('yes',{})) for name in ("constituency", "exchange", "risk", "mandate")),
                        ("network_influence", not influence)) if missing],
            "input_source_status": member.get("source_status", "MODEL_ASSUMPTION"),
            "utility_parameters_status": "UNVALIDATED_MODEL_PARAMETERS",
            "choice_source": "EXISTING_PERSONA_DECISION" if "decided_vote" in member else "ISSUE_UTILITY_MODEL",
            "local_utilities_used_for_choice": "decided_vote" not in member,
        }

    def _ballot(self, seed=None, *, identify_pivotal=True):
        shocks = {key: rng_for(seed, "contingency", key).gauss(0, c["sigma"]) for key, c in sorted(self.contingencies.items())} if seed is not None else {}
        counts = dict.fromkeys((*CHOICES, "absent", "invalid"), 0)
        evaluations, ballots = {}, {}
        for key, member in sorted(self.members.items()):
            evaluation = self.evaluate_member(key, shocks)
            evaluations[key] = evaluation
            if not member.get("eligible", True):
                continue
            probabilities = evaluation["probabilities"]
            if seed is None:
                # Tie means no decisive preference: abstain before yes/no. This
                # order is explicit and does not depend on input menu ordering.
                choice = max(("abstain", "absent", "yes", "no"), key=probabilities.get)
            else:
                draw = rng_for(seed, "ballot", key).random()
                cumulative = 0.0
                choice = "absent"
                for candidate in (*CHOICES, "absent"):
                    cumulative += probabilities[candidate]
                    if draw < cumulative:
                        choice = candidate
                        break
            counts[choice] += member.get("weight", 1)
            ballots[key] = choice
        result = self.rule.settle(counts)
        result["member_ballots"] = ballots if not self.secret else None
        pivotal = {}
        for key, choice in (ballots.items() if identify_pivotal else ()):
            changes = []
            for alternative in CHOICES:
                if choice == alternative or choice == "absent":
                    continue
                # A legal vote choice need not be psychologically acceptable;
                # this is counting-only pivotality, not a behavioral prediction.
                counterfactual = dict(counts)
                weight = self.members[key].get("weight", 1)
                counterfactual[choice] -= weight
                counterfactual[alternative] += weight
                if self.rule.settle(counterfactual)["passed"] != result["passed"]:
                    changes.append(alternative)
            if changes:
                pivotal[key] = changes
        result["counting_only_pivotal_switches"] = pivotal if not self.secret else None
        if self.request.get("reveal_forensic_ballots", False):
            result["forensic_hidden_ballots"] = ballots
            result["forensic_warning"] = "ENGINE TRUTH ONLY; must not be delivered to actors or used for secret-vote sanctions."
        return {"result": result, "member_evaluations": evaluations, "contingency_draws": shocks,
                "behavior_version":BEHAVIOR_VERSION,
                "evaluation_contract":{"stance_source":"FIXED_REQUEST_SNAPSHOT","update_schedule":"SINGLE_PASS",
                    "recursive_peer_evaluation":False,"actual_ballots_written_to_stances":False}}

    def ballot(self, seed):
        """Settle one seeded joint ballot, with no modal or expected rounding."""
        integer(seed, "seed")
        return self._ballot(seed, identify_pivotal=False)

    def baseline(self):
        payload = self._ballot()
        expected = dict.fromkeys((*CHOICES, "absent"), 0.0)
        for key, member in self.members.items():
            if member.get("eligible", True):
                for c, p in payload["member_evaluations"][key]["probabilities"].items():
                    expected[c] += member.get("weight", 1) * p
        payload["expected_counts_without_shared_shocks"] = expected
        payload["interpretation"] = "Representative per-member modal ballot, not a vote on rounded expected counts; expected counts have no institutional effect."
        return payload

    def simulate(self, runs=1000, seed=0):
        integer(runs, "runs", 1)
        integer(seed, "seed")
        if runs > 100000:
            raise ValueError("runs limit is 100000")
        paths, yes_values, member_yes = {}, [], {k: 0 for k, m in self.members.items() if m.get("eligible", True)}
        for index in range(runs):
            ballot = self._ballot(rng_for(seed, "run", index).getrandbits(128), identify_pivotal=False)
            status = ballot["result"]["status"]
            paths[status] = paths.get(status, 0) + 1
            yes_values.append(ballot["result"]["counts"]["yes"])
            # Aggregate epistemic model diagnostics, never actual secret ballots.
            for key, ev in ballot["member_evaluations"].items():
                if key in member_yes:
                    member_yes[key] += ev["probabilities"]["yes"]
        yes_values.sort()
        return {
            "runs": runs, "seed": seed, "outcome_counts": paths,
            "outcome_frequencies": {k: v / runs for k, v in paths.items()},
            "yes_interval_80": [yes_values[math.floor((runs - 1) * .1)], yes_values[math.ceil((runs - 1) * .9)]],
            "mean_member_yes_probabilities": {k: v / runs for k, v in member_yes.items()},
            "warning": WARNING,
            "randomness_scope": "Unobserved utilities, shared coordination contingencies and attendance; preference parameters stay fixed.",
        }


def run_request(request):
    model = MajorityModel(request)
    seed = request.get("seed", 0)
    integer(seed, "seed")
    return {
        "schema_version": "hakoniwa-majorities-1.0", "as_of": request["as_of"],
        "behavior_version":BEHAVIOR_VERSION,
        "body": model.body, "issue_id": model.issue["id"], "issue_version": model.issue["version"],
        "baseline": model.baseline(),
        "sampled_ballot": model._ballot(seed),
        "ensemble": model.simulate(request.get("runs", 1000), seed),
        "input_provenance": deepcopy(request),
        "warning": WARNING, "world_mutated": False,
        "behavioral_calibration": "NOT_VALIDATED",
        "empirical_relation_strengths_inferred_from_office": False,
    }
