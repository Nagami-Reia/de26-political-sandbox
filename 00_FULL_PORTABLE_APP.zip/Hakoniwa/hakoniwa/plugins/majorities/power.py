"""Exact small-game power diagnostics; overlapping factions are not players."""
from math import factorial

from .rules import integer


def power_indices(players, quota, forbidden_pairs=()):
    """Players are disjoint sets of equal-weight voter IDs, not leader-owned seats.

    Classical indices assume an unrestricted monotonic weighted game. Feasible
    swings are reported separately, not mislabeled a constrained Shapley value.
    This coalition arithmetic says nothing about observed loyalty or agreement.
    """
    integer(quota, "quota", 1)
    if not 1 <= len(players) <= 18:
        raise ValueError("exact power calculation requires 1..18 disjoint players")
    keys = sorted(players)
    owner = {}
    for key in keys:
        if not players[key] or len(set(players[key])) != len(players[key]):
            raise ValueError("players require nonempty unique member IDs")
        for member in players[key]:
            if member in owner:
                raise ValueError("overlapping memberships cannot be counted as separate voting blocs")
            owner[member] = key
    if quota > len(owner):
        raise ValueError("quota exceeds total votes")
    n = len(keys)
    weights = [len(players[k]) for k in keys]
    pairs = []
    for pair in forbidden_pairs:
        if len(pair) != 2 or pair[0] == pair[1] or any(k not in players for k in pair):
            raise ValueError("forbidden pair requires two distinct known players")
        pairs.append((1 << keys.index(pair[0])) | (1 << keys.index(pair[1])))
    totals = [0] * (1 << n)
    for mask in range(1, 1 << n):
        bit = mask & -mask
        totals[mask] = totals[mask ^ bit] + weights[bit.bit_length() - 1]
    swings, shapley, feasible_swings = [0] * n, [0.0] * n, [0] * n
    for mask in range(1 << n):
        if totals[mask] >= quota:
            continue
        size = mask.bit_count()
        for i in range(n):
            bit = 1 << i
            if mask & bit or totals[mask] + weights[i] < quota:
                continue
            swings[i] += 1
            shapley[i] += factorial(size) * factorial(n - size - 1) / factorial(n)
            enlarged = mask | bit
            if not any(enlarged & pair == pair for pair in pairs):
                feasible_swings[i] += 1
    total_swings = sum(swings)
    total_feasible = sum(feasible_swings)
    return {
        "weights": dict(zip(keys, weights)), "quota": quota,
        "banzhaf_normalized": {k: swings[i] / total_swings if total_swings else 0 for i, k in enumerate(keys)},
        "shapley_shubik": dict(zip(keys, shapley)),
        "feasible_swing_counts": dict(zip(keys, feasible_swings)),
        "feasible_positive_swing_share": {k: feasible_swings[i] / total_feasible if total_feasible else 0 for i, k in enumerate(keys)},
        "warning": "Classical indices include all coalitions. Feasible positive swings exclude declared forbidden combinations and are a separate diagnostic, not a Shapley value or forecast. Disjoint-player cohesion is an assumption.",
    }
