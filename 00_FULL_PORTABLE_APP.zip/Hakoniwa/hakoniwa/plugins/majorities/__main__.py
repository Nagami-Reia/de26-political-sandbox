"""Standalone stdlib JSON interface; three-decimal display, full-precision file."""
import argparse
import json
from pathlib import Path
import sys

from .model import run_request
from .power import power_indices


def display(value):
    if isinstance(value, float):
        return round(value, 3)
    if isinstance(value, dict):
        return {k: display(v) for k, v in value.items()}
    if isinstance(value, list):
        return [display(v) for v in value]
    return value


def execute(operation, request):
    if operation == "count":
        from datetime import date
        from .rules import BallotRule
        rule = BallotRule(**request["rule"])
        rule.check_cutoff(date.fromisoformat(request["as_of"]))
        return rule.settle(request["counts"])
    if operation == "power":
        return power_indices(**request)
    if operation == "verify":
        from .model import MajorityModel
        model = MajorityModel(request)
        return {"valid": True, "eligible_weight": model.rule.total_weight,
                "rule_status": model.rule.source_status, "behavioral_calibration": "NOT_VALIDATED"}
    return run_request(request)


def main(argv=None):
    parser = argparse.ArgumentParser(prog="majorities")
    parser.add_argument("operation", choices=("run", "verify", "power", "count"))
    parser.add_argument("--request", required=True, help="JSON file or - for stdin")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--pretty", action="store_true")
    args = parser.parse_args(argv)
    try:
        request = json.load(sys.stdin) if args.request == "-" else json.loads(Path(args.request).read_text())
        result = execute(args.operation, request)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
            print(json.dumps({"saved": str(args.output)}, ensure_ascii=False))
        else:
            print(json.dumps(display(result), ensure_ascii=False, indent=2 if args.pretty else None, allow_nan=False))
        return 0
    except (ValueError, KeyError, TypeError, OSError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
