"""Mechanical vote counting, separate from beliefs, preferences and forecasts.

These predicates settle one ballot only, not appointment, enactment or legality
of the underlying proposal. No automatic German-law preset is inferred from a
body's name. Callers must supply the applicable, versioned rule.
"""
from dataclasses import asdict, dataclass
from fractions import Fraction
from math import ceil
from datetime import date


def integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


@dataclass(frozen=True)
class BallotRule:
    total_weight: int
    kind: str = "simple_cast"
    fraction_numerator: int = 2
    fraction_denominator: int = 3
    quorum: str = "verified"
    procedure_ready: bool = True
    source_status: str = "MODEL_ASSUMPTION"
    authority: str = "Explicit scenario rule, not verified legal advice"
    available_from: str | None = None
    valid_until: str | None = None

    def __post_init__(self):
        integer(self.total_weight, "total_weight", 1)
        if self.kind not in {"simple_cast", "absolute_members", "fraction_members", "fraction_cast"}:
            raise ValueError("unsupported ballot kind")
        integer(self.fraction_numerator, "fraction_numerator", 1)
        integer(self.fraction_denominator, "fraction_denominator", 1)
        if self.fraction_numerator > self.fraction_denominator:
            raise ValueError("fraction must be <= 1")
        if self.quorum not in {"verified", "presumed", "none"}:
            raise ValueError("quorum must be verified/presumed/none")
        if type(self.procedure_ready) is not bool:
            raise ValueError("procedure_ready must be boolean")
        if not self.authority or not self.source_status:
            raise ValueError("rule provenance required")
        if self.source_status not in {"MODEL_ASSUMPTION", "VERIFIED_RULE", "HISTORICAL_REFERENCE"}:
            raise ValueError("unknown rule source_status")
        if self.source_status != "MODEL_ASSUMPTION" and not self.available_from:
            raise ValueError("sourced rule requires available_from")
        for value in (self.available_from, self.valid_until):
            if value is not None:
                date.fromisoformat(value)

    def check_cutoff(self, as_of):
        if self.available_from and date.fromisoformat(self.available_from) > as_of:
            raise ValueError("rule unavailable at cutoff")
        if self.valid_until and date.fromisoformat(self.valid_until) < as_of:
            raise ValueError("rule expired at cutoff")
        if self.source_status == "HISTORICAL_REFERENCE":
            raise ValueError("historical reference is not an executable current rule; declare any experimental reuse as MODEL_ASSUMPTION")

    def settle(self, counts):
        if set(counts) != {"yes", "no", "abstain", "absent", "invalid"}:
            raise ValueError("counts require yes/no/abstain/absent/invalid")
        for name, value in counts.items():
            integer(value, name)
        if sum(counts.values()) != self.total_weight:
            raise ValueError("ballot counts do not conserve eligible voting weight")
        cast = counts["yes"] + counts["no"]
        present = self.total_weight - counts["absent"]
        if self.kind == "simple_cast":
            threshold = cast // 2 + 1
        elif self.kind == "absolute_members":
            threshold = self.total_weight // 2 + 1
        else:
            denominator = self.total_weight if self.kind == "fraction_members" else cast
            threshold = max(1, ceil(Fraction(self.fraction_numerator * denominator, self.fraction_denominator)))
        enough_present = present > self.total_weight / 2
        if not self.procedure_ready:
            status = "PENDING_PROCEDURE"
        elif self.quorum == "verified" and not enough_present:
            status = "NO_QUORUM"
        else:
            status = "ADOPTED" if counts["yes"] >= threshold else "REJECTED"
        return {
            "status": status, "passed": status == "ADOPTED",
            "counts": dict(counts), "required_yes": threshold,
            "margin": counts["yes"] - threshold, "present_weight": present,
            "numerical_quorum_met": enough_present,
            "quorum_treatment": self.quorum,
            "rule": asdict(self), "institutional_scope": "THIS_BALLOT_ONLY",
        }
