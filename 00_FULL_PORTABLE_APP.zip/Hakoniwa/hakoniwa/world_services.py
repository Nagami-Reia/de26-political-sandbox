"""Clock adapters for existing history, narrative and parliamentary modules.

Adapters route inputs and outcomes. They do not encode a winning actor, a vote
result, an event date or an obligatory political response.
"""
from __future__ import annotations

from dataclasses import asdict
import math
import random

from .decision_space import DecisionSpaceGenerator, OutcomeResolver, StrategyEffectModel
from .free_agent_game import WorldAction
from .historical_dynamics import (
    HistoricalWorldState, HistoricalWorldEngine, HistoricalEventGenerator,
    HistoricalEventCandidate, LongTermFactor, MediumTermChange, ShortTermPressure,
    TriggerEvent,
)
from .living_world import Task
from .narrative_media import NarrativeArena, NarrativeMoveGenerator, NarrativeFact, NarrativeFrame, MediaChannel, AudienceSegment
from .parliamentary_vote import ParliamentaryVoteModel, VoteRule, BlocVotePrior, VoteFeedback
from .party_interest import PartyInterestEngine
from .political_state import PoliticalAction
from .simulation_orchestrator import SimulationNodeV3
from .world_clock import DEADLINE


class HistoricalClockService:
    def __init__(self, world, config: dict, cadence: int):
        if type(cadence) is not int or cadence <= 0:
            raise ValueError("History cadence must be positive integer minutes")
        self.cadence, self.config = cadence, config
        self.state = HistoricalWorldState(config.get("systems", {}), config.get("base_risk", {}))
        for name, factory in (("long_term", LongTermFactor), ("medium_term", MediumTermChange), ("short_term", ShortTermPressure)):
            for raw in config.get(name, []):
                data = dict(raw)
                for field in ("affected_systems", "affected_risk_domains"):
                    data[field] = tuple(data[field])
                getattr(self.state, "add_"+name)(factory(**data))
        candidates = []
        self.routes = {}
        for raw in config.get("candidates", []):
            data = dict(raw)
            route = data.pop("route")
            cooldown = data.pop("cooldown_minutes", cadence)
            if type(cooldown) is not int or cooldown < cadence:
                raise ValueError("Candidate cooldown must be at least one history interval")
            self.routes[data["key"]] = {**route, "cooldown_minutes": cooldown}
            for field in ("tags", "allowed_strategy_keys", "required_trigger_tags"):
                data[field] = tuple(data.get(field, ()))
            data["effect_models"] = {key: StrategyEffectModel(**value) for key, value in data["effect_models"].items()}
            candidates.append(HistoricalEventCandidate(**data))
        self.all_candidates = tuple(candidates)
        self.engine = HistoricalWorldEngine(self.state, HistoricalEventGenerator(
            candidates, seed=config.get("seed", 0), stochastic=config.get("stochastic", False)))
        self.cooldowns, self.history = {}, []
        self.pending_triggers = []
        self.bindings = config.get("system_bindings", {})
        self.risk_bindings = config.get("risk_bindings", {})
        if any(value not in world.game.state.variables for value in self.bindings.values()):
            raise ValueError("Unknown historical system binding")
        poll_variables = {spec.state_variable for observer in world.game.event_observers for spec in getattr(observer, "specs", ())}
        if poll_variables & set(self.bindings.values()):
            raise ValueError("History cannot directly drive party support")
        if set(self.risk_bindings.values())-set(world.game.state.variables) or poll_variables & set(self.risk_bindings.values()):
            raise ValueError("Risk bindings need valid non-poll variables")
        for candidate in candidates:
            if self.routes[candidate.key]["owner"] not in world.used_personas:
                raise ValueError("Historical event route needs a participating persona")
            for model in candidate.effect_models.values():
                keys = {key for effects in model.effects.values() for key in effects}
                if keys-set(world.game.state.variables) or keys & poll_variables:
                    raise ValueError("Historical action effects need valid non-poll world variables")
        world.game.decision_generator = world.game.decision_generator or DecisionSpaceGenerator()
        world.game.outcome_resolver = world.game.outcome_resolver or OutcomeResolver(
            seed=config.get("seed", 0), stochastic=config.get("stochastic", False))
        world.register_event_handler("history_tick", self.tick)
        world.listeners.append(self.observe)
        world.clock.schedule(world.clock.minute+cadence, "history_tick")

    def observe(self, world, row):
        if row["kind"] != "information_delivered":
            return
        template = self.config.get("trigger_routes", {}).get(row["details"]["key"])
        if template:
            data = dict(template)
            data["affected_risk_domains"] = tuple(data["affected_risk_domains"])
            data["tags"] = tuple(data["tags"])
            self.pending_triggers.append(TriggerEvent(**data))

    def tick(self, world, event):
        for domain, variable in self.risk_bindings.items():
            self.state.base_risk[domain] = world.game.state.variables[variable].value/100.0
        for key, variable in self.bindings.items():
            self.state.systems[key] = world.game.state.variables[variable].value/100.0
        self.engine.event_generator.candidates = tuple(c for c in self.all_candidates
            if self.cooldowns.get(c.key, -1) <= world.clock.minute)
        triggers, self.pending_triggers = tuple(self.pending_triggers), []
        result = self.engine.step(triggers)
        for key, variable in self.bindings.items():
            old = world.game.state.variables[variable].value
            world.game.state.apply(PoliticalAction(f"history_sync:{key}",
                {"immediate": {variable: self.state.systems[key]*100-old}}))
        generated = result.generated_event
        if generated is not None:
            route = self.routes[generated.candidate.key]
            owner = route["owner"]
            node_key = f"history:{generated.candidate.key}:{self.state.turn}"
            self.cooldowns[generated.candidate.key] = world.clock.minute+route["cooldown_minutes"]
            world.game.nodes[node_key] = SimulationNodeV3(node_key, owner, (),
                decision_event=generated.to_decision_event())
            world.game.personas.apply_event(owner, generated.to_pss_event())
            world.submit_task(Task(node_key, owner, world.clock.minute+1,
                world.clock.minute+route.get("response_minutes", 1440),
                route.get("deliberation_minutes", 60), importance=generated.assessment[generated.candidate.risk_domain].total,
                node=node_key, tags=generated.candidate.tags))
        row = result.payload()
        self.history.append(row)
        world.clock.schedule(world.clock.minute+self.cadence, "history_tick")
        return row

    def payload(self):
        return {"seed": self.config.get("seed", 0), "cadence_minutes": self.cadence, "state": self.state.payload(), "history": self.history,
                "pending_triggers": [asdict(row) for row in self.pending_triggers],
                "next_eligible_minutes": self.cooldowns}


class MediaClockService:
    def __init__(self, world, config: dict, defaults: dict, parties: PartyInterestEngine):
        self.config, self.defaults, self.parties = config, defaults, parties
        frames = [NarrativeFrame(**{**row, **{key: tuple(row.get(key, ())) for key in (
            "sponsors", "claim_tags", "contradicted_by_tags", "target_audiences", "identity_tags")}})
            for row in config.get("frames", [])]
        channels = [MediaChannel(**row) for row in config.get("channels", [])]
        audiences = [AudienceSegment(**{**row, "identity_tags": tuple(row.get("identity_tags", ()))})
                     for row in config.get("audiences", [])]
        if not frames or not channels or not audiences:
            raise ValueError("Media requires explicit frames, channels and audience assumptions")
        self.arena = NarrativeArena(frames, channels, audiences,
             seed=config.get("seed", 0), stochastic=config.get("stochastic", False))
        self.generator = NarrativeMoveGenerator(frames, channels)
        self.rounds, self.history = {}, []
        self.support_variables = config.get("support_variables", {})
        if "support_points_per_unit" in config:
            raise ValueError("Universal support multiplier removed; supply an explicit assumed opinion_response")
        self.response = config.get("opinion_response")
        self.response_history = []
        if self.response is not None:
            response = self.response
            if response.get("status") != "SIMULATION_ASSUMPTION" or not response.get("rationale"):
                raise ValueError("Opinion response is uncalibrated: label the assumption and give its rationale")
            gains = response.get("gains", {})
            cap = response["max_abs_change_pp"]
            if set(gains)-set(self.support_variables) or any(not math.isfinite(v) or v < 0 for v in gains.values()):
                raise ValueError("Invalid opinion response gains")
            if not math.isfinite(cap) or not 0 < cap <= 100:
                raise ValueError("Invalid per-response support cap")
            if type(response["delay_minutes"]) is not int or response["delay_minutes"] < 1:
                raise ValueError("Opinion response requires an explicit positive delay")
        if set(self.support_variables.values())-set(world.game.state.variables):
            raise ValueError("Unknown media support binding")
        if len(set(self.support_variables.values())) != len(self.support_variables):
            raise ValueError("Support targets must not alias the same state variable")
        duration = config.get("deliberation_minutes", defaults["deliberation_minutes"])
        window = config.get("collection_minutes", defaults["collection_minutes"])
        if type(duration) is not int or type(window) is not int or not 0 < duration < window:
            raise ValueError("Media collection must allow at least one deliberation stage")
        self.duration, self.window = duration, window
        world.listeners.append(self.observe)
        world.register_event_handler("media_close", self.close)
        world.register_event_handler("opinion_response", self.apply_response)
        world.register_operation("media_collective_choice", self.collective_choice)

    def observe(self, world, row):
        if row["kind"] == "information_delivered":
            template = (self.config.get("event_routes", {}).get(row["details"]["key"])
                        if row["details"].get("visibility", "PUBLIC") == "PUBLIC" else None)
        elif row["kind"] == "task_completed" and row["task"] not in self.rounds:
            template = self.config.get("decision_routes", {}).get(row["task"])
        elif row["kind"] == "history_tick" and row["details"].get("generated_event"):
            template = self.config.get("history_routes", {}).get(row["details"]["generated_event"]["candidate"])
        else:
            template = None
        if template:
            self.open(world, template, row["node"])
        if row["kind"] == "task_completed":
            for current in self.rounds.values():
                if not current.get("closed") and row["task"] in current["tasks"] and row["decision"]:
                    action = row["decision"]["chosen_action"]
                    current["moves"][row["task"]] = current["options"][row["task"]][action]

    def open(self, world, template: dict, source: str):
        key = f"media:{len(self.rounds)}"
        actors = tuple(template["actors"])
        if any(actor not in world.capacities for actor in actors):
            raise ValueError("Every media participant needs an attention/organization capacity")
        data = {k: v for k, v in template.items() if k != "actors"}
        data["key"], data["tags"] = key, tuple(data.get("tags", ()))
        fact = NarrativeFact(**data)
        current = {"fact": fact, "tasks": [], "options": {}, "moves": {}, "source": source}
        self.rounds[key] = current
        close = world.clock.minute+self.window
        for actor in actors:
            options = self.generator.generate(actor, fact)
            task_key = f"{key}:{actor}"
            current["tasks"].append(task_key)
            current["options"][task_key] = {option.choice.key: option.move for option in options}
            if actor in world.used_personas:
                world.game.nodes[task_key] = SimulationNodeV3(task_key, actor, tuple(
                    WorldAction(PoliticalAction(option.choice.key, {"immediate": {}}), option.choice)
                    for option in options), scene_tags=fact.tags)
                task = Task(task_key, actor, world.clock.minute+1, close, self.duration,
                            importance=fact.salience, node=task_key, tags=fact.tags)
            else:
                if actor not in self.parties.profiles:
                    raise ValueError("Collective media actor needs a party-interest profile")
                task = Task(task_key, actor, world.clock.minute+1, close, self.duration,
                            importance=fact.salience, operation="media_collective_choice",
                            operation_data={"round": key, "actor": actor})
            world.submit_task(task)
        # Close after task completion and deadline checks in this minute.
        world.clock.schedule(close, "media_close", {"round": key}, phase=DEADLINE+5)

    def collective_choice(self, world, task):
        current = self.rounds[task.operation_data["round"]]
        if current.get("closed"):
            return {"status": "LATE_MESSAGE_NOT_IN_ROUND", "party_id": task.operation_data["actor"]}
        actor = task.operation_data["actor"]
        options = self.generator.generate(actor, current["fact"])
        decision = self.parties.decide(actor, tuple(option.choice for option in options))
        current["moves"][task.key] = current["options"][task.key][decision.chosen_action]
        return decision.payload()

    def close(self, world, event):
        key = event.data["round"]
        current = self.rounds[key]
        current["closed"] = True
        outcome = self.arena.resolve_round(current["fact"], tuple(current["moves"].values()))
        update = {"status": "COGNITION_ONLY_NO_OPINION_MODEL", "effects": {}}
        if self.response:
            cap = self.response["max_abs_change_pp"]
            effects = {}
            for target, delta in outcome.support_deltas.items():
                variable = self.support_variables.get(target)
                if variable is not None:
                    change = delta*self.response["gains"].get(target, 0)
                    effects[variable] = effects.get(variable, 0)+max(-cap, min(cap, change))
            world.clock.schedule(world.clock.minute+self.response["delay_minutes"], "opinion_response",
                                 {"round": key, "effects": effects})
            update = {"status": "ASSUMED_RESPONSE_SCHEDULED", "effects": effects,
                      "delay_minutes": self.response["delay_minutes"]}
        row = {"round_key": key, "source": current["source"], "outcome": outcome.payload(),
               "unheard_tasks": [task for task in current["tasks"] if task not in current["moves"]],
               "state_update": update}
        self.history.append(row)
        return row

    def apply_response(self, world, event):
        update = world.game.state.apply(PoliticalAction(f"opinion:{event.data['round']}",
                                                       {"immediate": event.data["effects"]}))
        row = {"round": event.data["round"], "status": "SIMULATION_ASSUMPTION",
               "response_model": self.response, "state_update": update}
        self.response_history.append(row)
        return row

    def payload(self):
        return {"seed": self.config.get("seed", 0), "state": self.arena.state.payload(), "history": self.history,
                "opinion_response_model": self.response, "opinion_history": self.response_history}


class ParliamentClockService:
    def __init__(self, world, config: dict):
        self.config, self.history = config, []
        self.model = ParliamentaryVoteModel()
        world.register_operation("parliamentary_vote", self.vote)
        poll_variables = {spec.state_variable for observer in world.game.event_observers for spec in getattr(observer, "specs", ())}
        for key, proposal in config.get("proposals", {}).items():
            rule = VoteRule(**proposal["rule"])
            blocs = tuple(BlocVotePrior(**row) for row in proposal["blocs"])
            if sum(bloc.seats for bloc in blocs) != rule.total_members:
                raise ValueError("Vote bloc seats must match the statutory membership")
            for row in proposal["feedback_by_outcome"].values():
                if set(row.get("effects", {})) & poll_variables:
                    raise ValueError("Vote results reach public support through media feedback")
                if set(row.get("effects", {}))-set(world.game.state.variables):
                    raise ValueError("Unknown parliamentary feedback variable")
            if set(proposal.get("alignment_bindings", {}).values())-set(world.game.state.variables):
                raise ValueError("Unknown parliamentary alignment binding")
            if set(proposal["feedback_by_outcome"]) != {"clear_pass", "narrow_pass", "narrow_fail", "clear_fail"}:
                raise ValueError("Parliament feedback must describe all four possible outcomes")

    def vote(self, world, task):
        if not task.requires_windows:
            raise ValueError("Parliamentary votes require an explicit procedure window")
        proposal_key = task.operation_data["proposal"]
        proposal = self.config["proposals"][proposal_key]
        rule = VoteRule(**proposal["rule"])
        blocs = []
        for raw in proposal["blocs"]:
            row = dict(raw)
            binding = proposal.get("alignment_bindings", {}).get(row["key"])
            if binding:
                yes = max(0, min(1, world.game.state.variables[binding].value/100))
                remaining = row["no_share"]+row["abstain_share"]
                row["no_share"] = (1-yes)*row["no_share"]/remaining if remaining else 1-yes
                row["yes_share"], row["abstain_share"] = yes, max(0, 1-yes-row["no_share"])
            blocs.append(BlocVotePrior(**row))
        blocs = tuple(blocs)
        forecast = self.model.forecast(proposal_key, proposal.get("stage", "vote"), rule, blocs)
        if proposal.get("stochastic", False):
            seed = proposal.get("seed", self.config.get("seed", 0))
            counts = self.model._sample_once(rule, blocs, random.Random(f"{seed}:{task.key}"))
        else:
            # Largest remainder preserves seat totals without impossible negative absences.
            expected = [forecast.expected_yes, forecast.expected_no, forecast.expected_abstain, forecast.expected_absent]
            counts = [int(value) for value in expected]
            for index in sorted(range(4), key=lambda i: (expected[i]-counts[i], -i), reverse=True)[:rule.total_members-sum(counts)]:
                counts[index] += 1
        result = self.model.settle(proposal_key, proposal.get("stage", "vote"), rule, *counts)
        feedback = {key: VoteFeedback(outcome_class=key, **row)
                    for key, row in proposal["feedback_by_outcome"].items()}
        update = self.model.apply_feedback(world.game.state, result, feedback)
        row = {"forecast": asdict(forecast), "vote_result": asdict(result), "state_update": update}
        external = world.environment.get("external_environment")
        if external:
            # Context only; actual procedure still needs an explicit window and legal intent.
            row["calendar_context"] = world.external_environment.calendar_context(
                task.owner, world.clock.at().date().isoformat()) if world.external_environment else None
        self.history.append(row)
        for key in proposal.get("followups_by_outcome", {}).get(result.outcome_class, ()):
            target = world.tasks[key]
            if target.status == "UNRELEASED":
                world.clock.schedule(max(world.clock.minute+1, target.release), "release", {"task": key})
        return row

    def payload(self):
        return {"seed": self.config.get("seed", 0), "history": self.history}
