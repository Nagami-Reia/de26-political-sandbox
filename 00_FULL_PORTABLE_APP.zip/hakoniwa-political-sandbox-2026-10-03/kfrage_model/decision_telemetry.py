#!/usr/bin/env python3
"""Decision-by-decision support telemetry for scenario simulations.

Observed percentages and model-generated indices intentionally live in different
series.  The module never converts one into the other and never infers causality
from a measurement that happens after a decision.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Iterable, Mapping


VALID_STATUSES = {"OBSERVED", "MODEL_ESTIMATE"}
VALID_UNITS = {"percent", "index_0_100"}
RECOMMENDED_MODEL_MEASURES = {
    "party_elite": "party_elite_support",
    "member_organization": "member_organization_support",
    "public": "public_acceptance",
    "poll_momentum": "electoral_momentum",
}


@dataclass(frozen=True)
class SupportPoint:
    step: int
    timestamp: str
    event_id: str
    subject: str
    constituency: str
    measure: str
    scope: str
    value: float
    unit: str
    evidence_status: str
    source_id: str | None = None
    note: str = ""

    def validate(self) -> None:
        if self.step < 0:
            raise ValueError("step must be non-negative so the chart stays in quadrant I")
        if self.unit not in VALID_UNITS:
            raise ValueError(f"invalid unit: {self.unit}")
        if self.evidence_status not in VALID_STATUSES:
            raise ValueError(f"invalid evidence status: {self.evidence_status}")
        if not 0 <= self.value <= 100:
            raise ValueError("support values must be within 0..100")
        if self.evidence_status == "OBSERVED" and not self.source_id:
            raise ValueError("observed support points require source_id")
        datetime.fromisoformat(self.timestamp)

    @property
    def series_key(self) -> str:
        return "|".join((
            self.subject, self.constituency, self.measure, self.scope,
            self.unit, self.evidence_status,
        ))


@dataclass(frozen=True)
class DecisionEvent:
    step: int
    event_id: str
    timestamp: str
    actor: str
    action: str
    information_update: Mapping[str, object] = field(default_factory=dict)
    resource_changes: Mapping[str, object] = field(default_factory=dict)
    source_ids: tuple[str, ...] = ()


class DecisionTelemetry:
    """Append-only log used by simulations and post-hoc observed updates."""

    def __init__(self, run_id: str, environment_id: str):
        self.run_id = run_id
        self.environment_id = environment_id
        self.events: list[DecisionEvent] = []
        self.points: list[SupportPoint] = []

    @property
    def next_step(self) -> int:
        return len(self.events) + 1

    def record_event(
        self,
        *,
        event_id: str,
        timestamp: str,
        actor: str,
        action: str,
        information_update: Mapping[str, object] | None = None,
        resource_changes: Mapping[str, object] | None = None,
        source_ids: Iterable[str] = (),
    ) -> int:
        if any(event.event_id == event_id for event in self.events):
            raise ValueError(f"duplicate event_id: {event_id}")
        datetime.fromisoformat(timestamp)
        step = self.next_step
        self.events.append(DecisionEvent(
            step=step,
            event_id=event_id,
            timestamp=timestamp,
            actor=actor,
            action=action,
            information_update=dict(information_update or {}),
            resource_changes=dict(resource_changes or {}),
            source_ids=tuple(source_ids),
        ))
        return step

    def record_support(self, point: SupportPoint) -> None:
        point.validate()
        if point.step and not any(event.step == point.step for event in self.events):
            raise ValueError(f"support point references missing step {point.step}")
        self.points.append(point)

    def latest_value(
        self, *, subject: str, constituency: str, measure: str, scope: str,
        unit: str, evidence_status: str,
    ) -> float | None:
        matches = [p for p in self.points if (
            p.subject == subject and p.constituency == constituency
            and p.measure == measure and p.scope == scope and p.unit == unit
            and p.evidence_status == evidence_status
        )]
        return matches[-1].value if matches else None

    def record_model_delta(
        self,
        *,
        step: int,
        timestamp: str,
        event_id: str,
        subject: str,
        constituency: str,
        measure: str,
        scope: str,
        delta: float,
        baseline: float | None = None,
        note: str = "",
    ) -> SupportPoint:
        previous = self.latest_value(
            subject=subject, constituency=constituency, measure=measure,
            scope=scope, unit="index_0_100", evidence_status="MODEL_ESTIMATE",
        )
        if previous is None:
            if baseline is None:
                raise ValueError("the first model delta in a series requires a baseline")
            previous = baseline
            self.record_support(SupportPoint(
                step=0,
                timestamp=timestamp,
                event_id="baseline",
                subject=subject,
                constituency=constituency,
                measure=measure,
                scope=scope,
                value=max(0.0, min(100.0, baseline)),
                unit="index_0_100",
                evidence_status="MODEL_ESTIMATE",
                note="pre-decision baseline",
            ))
        point = SupportPoint(
            step=step,
            timestamp=timestamp,
            event_id=event_id,
            subject=subject,
            constituency=constituency,
            measure=measure,
            scope=scope,
            value=max(0.0, min(100.0, previous + delta)),
            unit="index_0_100",
            evidence_status="MODEL_ESTIMATE",
            note=note,
        )
        self.record_support(point)
        return point

    def record_decision_with_impacts(
        self,
        *,
        event_id: str,
        timestamp: str,
        actor: str,
        action: str,
        impacts: Mapping[str, Mapping[str, object]],
        information_update: Mapping[str, object] | None = None,
        resource_changes: Mapping[str, object] | None = None,
        require_complete: bool = True,
    ) -> int:
        """Atomically add a decision and its model-estimated support effects.

        `impacts` is keyed by party_elite, member_organization, public and
        poll_momentum.  Each value supplies subject, scope, delta and optionally
        baseline/note.  Requiring all four prevents a simulator from silently
        omitting an affected audience; use a zero delta when the rule predicts no
        change, or set require_complete=False for a deliberately partial model.
        """
        if require_complete:
            missing = set(RECOMMENDED_MODEL_MEASURES) - set(impacts)
            if missing:
                raise ValueError(f"decision is missing telemetry constituencies: {sorted(missing)}")
        step = self.record_event(
            event_id=event_id,
            timestamp=timestamp,
            actor=actor,
            action=action,
            information_update=information_update,
            resource_changes=resource_changes,
        )
        for constituency, spec in impacts.items():
            measure = str(spec.get("measure", RECOMMENDED_MODEL_MEASURES.get(constituency, constituency)))
            self.record_model_delta(
                step=step,
                timestamp=timestamp,
                event_id=event_id,
                subject=str(spec.get("subject", actor)),
                constituency=constituency,
                measure=measure,
                scope=str(spec["scope"]),
                delta=float(spec["delta"]),
                baseline=float(spec["baseline"]) if "baseline" in spec else None,
                note=str(spec.get("note", "")),
            )
        return step

    def validate(self) -> None:
        expected = list(range(1, len(self.events) + 1))
        actual = [event.step for event in self.events]
        if actual != expected:
            raise ValueError(f"event steps are not contiguous: {actual}")
        for point in self.points:
            point.validate()
        units_by_identity: dict[tuple[str, str, str, str, str], set[str]] = {}
        for point in self.points:
            identity = (
                point.subject, point.constituency, point.measure,
                point.scope, point.evidence_status,
            )
            units_by_identity.setdefault(identity, set()).add(point.unit)
        mixed = [identity for identity, units in units_by_identity.items() if len(units) > 1]
        if mixed:
            raise ValueError(f"series mix percent and index units: {mixed}")

    def to_dict(self) -> dict[str, object]:
        self.validate()
        return {
            "schema_version": "1.0",
            "run_id": self.run_id,
            "environment_id": self.environment_id,
            "chart_contract": {
                "x_axis": "decision/event step, minimum 0",
                "y_axis": "0..100, separate panels for percent and model index",
                "observed_style": "solid line and filled marker",
                "model_style": "dashed line and hollow marker",
                "causality_warning": "temporal adjacency is not causal attribution"
            },
            "events": [asdict(event) for event in self.events],
            "support_points": [asdict(point) | {"series_key": point.series_key} for point in self.points],
        }

    def write_json(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def from_observed_update_stream(path: Path) -> DecisionTelemetry:
    payload = json.loads(path.read_text(encoding="utf-8"))
    log = DecisionTelemetry(
        run_id=payload["stream_id"],
        environment_id=payload["origin_environment_id"],
    )
    for item in payload["events"]:
        source_ids = set(item.get("source_ids", []))
        source_ids.update(metric["source_id"] for metric in item.get("observed_metrics", []))
        step = log.record_event(
            event_id=item["event_id"],
            timestamp=f'{item["date"]}T12:00:00+02:00',
            actor=item["actors"][0],
            action=item["kind"],
            information_update={"summary": item["summary"], "actors": item["actors"]},
            resource_changes=item.get("resource_effects", {}),
            source_ids=sorted(source_ids),
        )
        for metric in item.get("observed_metrics", []):
            log.record_support(SupportPoint(
                step=step,
                timestamp=f'{item["date"]}T12:00:00+02:00',
                event_id=item["event_id"],
                subject=metric["subject"],
                constituency="public_or_electorate",
                measure=metric["measure"],
                scope=metric["scope"],
                value=float(metric["value"]),
                unit=metric["unit"],
                evidence_status="OBSERVED",
                source_id=metric["source_id"],
            ))
    return log


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a telemetry log from observed events")
    parser.add_argument("--updates", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    from_observed_update_stream(args.updates).write_json(args.output)


if __name__ == "__main__":
    main()
