import unittest
from pathlib import Path

from kfrage_model.decision_space import DecisionSpaceGenerator, StrategyEffectModel
from kfrage_model.historical_dynamics import (
    CommitmentTrapMechanism,
    HistoricalEventCandidate,
    HistoricalEventGenerator,
    HistoricalMechanismLibrary,
    HistoricalRiskModel,
    HistoricalWorldEngine,
    HistoricalWorldState,
    LongTermFactor,
    MediumTermChange,
    MiscalculationMechanism,
    SecurityDilemmaMechanism,
    ShortTermPressure,
    TriggerEvent,
)
from kfrage_model.information_filter import AccessRule, InformationFilter
from kfrage_model.persona_v2 import FreeAgentDecisionEngine
from kfrage_model.political_state import PoliticalState


ROOT = Path(__file__).parent
CARDS = ROOT / "personality_cards_2026" / "cards_pss.json"


def effects(**immediate):
    return {"immediate": immediate, "medium": {}, "long": {}}


def event_candidate(key="high_tension_incident", weight=1.0):
    return HistoricalEventCandidate(
        key=key,
        risk_domain="security_crisis",
        threshold=.750,
        selection_weight=weight,
        decision_domain="crisis",
        tags=("security", "uncertain", "alliance"),
        allowed_strategy_keys=("private_negotiation", "public_signal", "delay_verify"),
        signal_variables={"threat_perception": 1.0},
        required_trigger_tags=("incident",),
        effect_models={
            "private_negotiation": StrategyEffectModel(effects(crisis_stability=6), base_feasibility=.72),
            "public_signal": StrategyEffectModel(effects(crisis_stability=2), base_feasibility=.58),
            "delay_verify": StrategyEffectModel(effects(crisis_stability=1), base_feasibility=.84),
        },
    )


def layered_state():
    state = HistoricalWorldState(
        systems={
            "military_buildup": .40,
            "threat_perception": .45,
            "mutual_trust": .60,
            "alliance_commitment": .50,
            "reputation_cost": .50,
            "information_uncertainty": .40,
            "decision_urgency": .40,
            "decision_quality": .70,
            "exit_cost": .30,
            "crisis_stability": .55,
        },
        base_risk={"security_crisis": .050, "political_crisis": .050},
    )
    state.add_long_term(LongTermFactor(
        "structural_security_competition", .800, 80,
        ("military_buildup", "threat_perception", "mutual_trust"),
        ("security_crisis",),
    ))
    state.add_medium_term(MediumTermChange(
        "accelerating_armament", .700, 12,
        ("military_buildup",), ("security_crisis",),
    ))
    state.add_short_term(ShortTermPressure(
        "failed_negotiation", .700, 4,
        ("mutual_trust", "decision_urgency"), ("security_crisis",),
    ))
    return state


class HistoricalDynamicsTests(unittest.TestCase):
    def test_trigger_alone_is_not_treated_as_sufficient_cause(self):
        state = HistoricalWorldState(
            systems={}, base_risk={"security_crisis": .050}
        )
        trigger = TriggerEvent("border_incident", .800, ("security_crisis",), ("incident",))
        result = HistoricalEventGenerator((event_candidate(),)).generate(state, (), (trigger,))
        self.assertIsNone(result.generated_event)
        risk = result.assessment["security_crisis"]
        self.assertAlmostEqual(risk.base, .050)
        self.assertAlmostEqual(risk.triggers, .336)
        self.assertEqual(result.reason, "NO_THRESHOLD_CROSSED")

    def test_structure_pressure_and_trigger_are_separate_contributions(self):
        state = layered_state()
        trigger = TriggerEvent("border_incident", .800, ("security_crisis",), ("incident",))
        result = HistoricalEventGenerator((event_candidate(),)).generate(state, (), (trigger,))
        self.assertIsNotNone(result.generated_event)
        risk = result.assessment["security_crisis"]
        self.assertGreater(risk.long_term, 0.0)
        self.assertGreater(risk.medium_term, 0.0)
        self.assertGreater(risk.short_term, 0.0)
        self.assertGreater(risk.triggers, 0.0)
        self.assertEqual(risk.total, 1.0)
        self.assertEqual(
            {row.category for row in risk.contributions},
            {"long_term", "medium_term", "short_term", "trigger"},
        )

    def test_security_dilemma_changes_trust_and_risk_without_event_choice(self):
        state = HistoricalWorldState(
            systems={"military_buildup": .810, "threat_perception": .640, "mutual_trust": .600},
            base_risk={"security_crisis": .100},
        )
        library = HistoricalMechanismLibrary((SecurityDilemmaMechanism(),))
        effect = library.evaluate(state, apply=True)[0]
        self.assertAlmostEqual(effect.activation, .720, places=3)
        self.assertLess(state.systems["mutual_trust"], .600)
        assessed = HistoricalRiskModel().assess(state, (effect,), ())
        self.assertGreater(assessed["security_crisis"].mechanisms, 0.0)

    def test_miscalculation_is_uncertainty_times_urgency(self):
        state = HistoricalWorldState(
            systems={"information_uncertainty": .800, "decision_urgency": .750},
            base_risk={},
        )
        effect = MiscalculationMechanism().evaluate(state)
        self.assertAlmostEqual(effect.activation, .600)
        self.assertLess(effect.system_deltas["decision_quality"], 0.0)

    def test_short_pressure_decays_faster_than_long_structure(self):
        state = layered_state()
        long_before = state.long_term[0].effective_intensity()
        short_before = state.short_term[0].effective_intensity()
        state.advance(2)
        self.assertGreater(state.long_term[0].effective_intensity(), long_before * .95)
        self.assertLess(state.short_term[0].effective_intensity(), short_before * .60)

    def test_generated_historical_event_enters_decision_space(self):
        state = layered_state()
        trigger = TriggerEvent(
            "border_incident", .800, ("security_crisis",), ("incident", "warning"),
            ambiguity=.650, source_actor="Wadephul", target_actor="Merz",
        )
        generated = HistoricalEventGenerator((event_candidate(),)).generate(
            state, (), (trigger,)
        ).generated_event
        self.assertIsNotNone(generated)
        decision_event = generated.to_decision_event()
        self.assertEqual(decision_event.source_actor, "Wadephul")
        self.assertEqual(decision_event.target_actor, "Merz")
        self.assertIn("warning", decision_event.tags)
        pss_event = generated.to_pss_event()
        self.assertEqual(pss_event.event_id, decision_event.key)
        self.assertEqual(pss_event.severity, decision_event.severity)
        self.assertIn("warning", pss_event.tags)

        political_state = PoliticalState(state.as_political_variables(), {}, {})
        information = InformationFilter({
            "Wadephul": {
                key: AccessRule(.850) for key in political_state.variables
            }
        })
        personas = FreeAgentDecisionEngine.from_json(CARDS)
        decision_space = DecisionSpaceGenerator().generate(
            "Wadephul",
            decision_event,
            information.observe("Wadephul", political_state, commit=False),
            personas.cards["Wadephul"],
            personas.runtime["Wadephul"],
            personas.cards["Wadephul"].initial_resources,
        )
        self.assertGreaterEqual(len(decision_space.actions), 3)
        self.assertTrue(all(row.path.perception for row in decision_space.actions))

    def test_seed_changes_event_selection_only_when_stochastic(self):
        state = layered_state()
        trigger = TriggerEvent("border_incident", .800, ("security_crisis",), ("incident",))
        candidates = (event_candidate("incident_a", 1.0), event_candidate("incident_b", .9))
        deterministic = HistoricalEventGenerator(candidates, stochastic=False)
        self.assertEqual(
            deterministic.generate(state, (), (trigger,)).generated_event.candidate.key,
            "incident_a",
        )
        first = HistoricalEventGenerator(candidates, seed=4, stochastic=True).generate(state, (), (trigger,))
        second = HistoricalEventGenerator(candidates, seed=4, stochastic=True).generate(state, (), (trigger,))
        self.assertEqual(
            first.generated_event.candidate.key,
            second.generated_event.candidate.key,
        )

    def test_outcome_feedback_can_create_new_historical_pressure(self):
        state = layered_state()
        engine = HistoricalWorldEngine(
            state,
            HistoricalEventGenerator((event_candidate(),)),
            HistoricalMechanismLibrary((CommitmentTrapMechanism(),)),
        )
        engine.record_outcome(
            "failed_private_channel",
            "failure",
            {"mutual_trust": -.100, "decision_urgency": .120},
            short_term=(ShortTermPressure(
                "failed_channel_aftershock", .650, 3,
                ("mutual_trust",), ("security_crisis",),
            ),),
        )
        self.assertEqual(state.short_term[-1].factor.key, "failed_channel_aftershock")
        self.assertLess(state.systems["mutual_trust"], .600)


if __name__ == "__main__":
    unittest.main()
