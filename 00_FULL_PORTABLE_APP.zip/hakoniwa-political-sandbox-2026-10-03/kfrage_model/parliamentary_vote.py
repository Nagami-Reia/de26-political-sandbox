"""Transparent parliamentary vote forecasts and post-vote settlement.

The forecast is conditional on declared seat, attendance and voting-alignment
assumptions.  Stochastic runs vary only unobserved attendance, defections and
late contingencies; they do not randomise actor preferences or personalities.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from math import ceil, floor
import random
from typing import Mapping

from .political_state import PoliticalAction, PoliticalState, PressureRule


VOTE_RULES = {
    "simple_cast",
    "absolute_members",
    "two_thirds_members",
    "two_thirds_cast",
}


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


@dataclass(frozen=True)
class VoteRule:
    kind: str = "simple_cast"
    total_members: int = 630

    def __post_init__(self) -> None:
        if self.kind not in VOTE_RULES:
            raise ValueError(f"unknown vote rule: {self.kind}")
        if self.total_members <= 0:
            raise ValueError("total_members must be positive")

    def required_yes(self, yes: float, no: float) -> int:
        if self.kind == "simple_cast":
            return floor(yes + no) // 2 + 1
        if self.kind == "absolute_members":
            return self.total_members // 2 + 1
        if self.kind == "two_thirds_members":
            return ceil(2 * self.total_members / 3)
        return ceil(2 * (yes + no) / 3)


@dataclass(frozen=True)
class BlocVotePrior:
    key: str
    seats: int
    attendance: float
    yes_share: float
    no_share: float
    abstain_share: float
    discipline: float = 1.0
    hidden_defection_sigma: float = 0.0
    source_status: str = "MODEL_ASSUMPTION"
    linked_actor: str | None = None

    def __post_init__(self) -> None:
        if self.seats < 0:
            raise ValueError("seats cannot be negative")
        for name in ("attendance", "yes_share", "no_share", "abstain_share", "discipline"):
            if not 0 <= getattr(self, name) <= 1:
                raise ValueError(f"{name} must be within 0..1")
        if abs(self.yes_share + self.no_share + self.abstain_share - 1.0) > 1e-6:
            raise ValueError(f"vote shares for {self.key} must sum to 1")
        if self.hidden_defection_sigma < 0:
            raise ValueError("hidden_defection_sigma cannot be negative")


@dataclass(frozen=True)
class VoteForecast:
    proposal: str
    stage: str
    rule: VoteRule
    expected_yes: float
    expected_no: float
    expected_abstain: float
    expected_absent: float
    required_yes: int
    expected_margin: float
    conclusion: str
    pivotal_blocs: tuple[str, ...]
    assumptions: tuple[str, ...]
    source_status: str = "MODEL_FORECAST"


@dataclass(frozen=True)
class VoteSimulation:
    runs: int
    seed: int
    passage_runs: int
    path_counts: Mapping[str, int]
    yes_interval_80: tuple[int, int]
    no_interval_80: tuple[int, int]
    warning: str = "Run shares are conditional model frequencies, not real-world probabilities."


@dataclass(frozen=True)
class VoteResult:
    proposal: str
    stage: str
    yes: int
    no: int
    abstain: int
    absent: int
    required_yes: int
    passed: bool
    outcome_class: str
    source_status: str


@dataclass(frozen=True)
class VoteFeedback:
    outcome_class: str
    effects: Mapping[str, float] = field(default_factory=dict)
    capital_delta: Mapping[str, float] = field(default_factory=dict)
    pressure_delta: Mapping[str, float] = field(default_factory=dict)
    locks_add: tuple[str, ...] = ()
    tags: tuple[str, ...] = ("parliamentary_feedback",)


class ParliamentaryVoteModel:
    def forecast(
        self,
        proposal: str,
        stage: str,
        rule: VoteRule,
        blocs: tuple[BlocVotePrior, ...],
        assumptions: tuple[str, ...] = (),
    ) -> VoteForecast:
        yes = sum(b.seats * b.attendance * b.yes_share for b in blocs)
        no = sum(b.seats * b.attendance * b.no_share for b in blocs)
        abstain = sum(b.seats * b.attendance * b.abstain_share for b in blocs)
        absent = sum(b.seats * (1 - b.attendance) for b in blocs)
        required = rule.required_yes(yes, no)
        margin = yes - required
        if margin >= 15:
            conclusion = "clear_pass"
        elif margin >= 3:
            conclusion = "lean_pass"
        elif margin >= 0:
            conclusion = "knife_edge_pass"
        elif margin > -3:
            conclusion = "knife_edge_fail"
        elif margin > -15:
            conclusion = "lean_fail"
        else:
            conclusion = "clear_fail"
        pivotal = tuple(
            b.key for b in blocs
            if .15 <= b.yes_share <= .85
            and b.seats * b.attendance * ((1 - b.discipline) + 2 * b.hidden_defection_sigma) >= 1.0
        )
        return VoteForecast(
            proposal, stage, rule, round(yes, 2), round(no, 2),
            round(abstain, 2), round(absent, 2), required, round(margin, 2),
            conclusion, pivotal, assumptions,
        )

    def _sample_once(
        self, rule: VoteRule, blocs: tuple[BlocVotePrior, ...], rng: random.Random
    ) -> tuple[int, int, int, int]:
        yes = no = abstain = absent = 0
        for bloc in blocs:
            # One shared late-whip shock creates within-bloc correlation.  It is
            # an information/coordination contingency, not a personality draw.
            shock = rng.gauss(0.0, bloc.hidden_defection_sigma)
            effective_yes = _clamp(bloc.yes_share + shock)
            effective_no = _clamp(bloc.no_share - shock * .75)
            effective_abstain = max(0.0, 1.0 - effective_yes - effective_no)
            total = effective_yes + effective_no + effective_abstain
            effective_yes /= total; effective_no /= total
            for _ in range(bloc.seats):
                if rng.random() > bloc.attendance:
                    absent += 1; continue
                u = rng.random()
                if u < effective_yes:
                    yes += 1
                elif u < effective_yes + effective_no:
                    no += 1
                else:
                    abstain += 1
        return yes, no, abstain, absent

    @staticmethod
    def _outcome_class(passed: bool, margin: int) -> str:
        if passed and margin >= 15:
            return "clear_pass"
        if passed:
            return "narrow_pass"
        if margin > -15:
            return "narrow_fail"
        return "clear_fail"

    def simulate(
        self,
        rule: VoteRule,
        blocs: tuple[BlocVotePrior, ...],
        runs: int = 5000,
        seed: int = 0,
    ) -> VoteSimulation:
        if runs <= 0:
            raise ValueError("runs must be positive")
        rng = random.Random(seed); counts: dict[str, int] = {}; yes_values = []; no_values = []; passage = 0
        for _ in range(runs):
            yes, no, abstain, absent = self._sample_once(rule, blocs, rng)
            required = rule.required_yes(yes, no); margin = yes - required; passed = yes >= required
            label = self._outcome_class(passed, margin)
            counts[label] = counts.get(label, 0) + 1; passage += int(passed)
            yes_values.append(yes); no_values.append(no)
        yes_values.sort(); no_values.sort()
        lo = floor((runs - 1) * .10); hi = ceil((runs - 1) * .90)
        return VoteSimulation(runs, seed, passage, counts, (yes_values[lo], yes_values[hi]), (no_values[lo], no_values[hi]))

    def settle(
        self,
        proposal: str,
        stage: str,
        rule: VoteRule,
        yes: int,
        no: int,
        abstain: int,
        absent: int,
        source_status: str = "SIMULATED_OUTCOME",
    ) -> VoteResult:
        required = rule.required_yes(yes, no); margin = yes - required; passed = yes >= required
        return VoteResult(proposal, stage, yes, no, abstain, absent, required, passed, self._outcome_class(passed, margin), source_status)

    def apply_feedback(
        self,
        state: PoliticalState,
        result: VoteResult,
        feedback_by_outcome: Mapping[str, VoteFeedback],
        pressure_rules: tuple[PressureRule, ...] = (),
    ) -> dict:
        if result.outcome_class not in feedback_by_outcome:
            raise KeyError(f"missing feedback for {result.outcome_class}")
        feedback = feedback_by_outcome[result.outcome_class]
        unknown = set(feedback.effects) - set(state.variables)
        if unknown:
            raise KeyError(f"vote feedback references unknown variables: {sorted(unknown)}")
        action = PoliticalAction(
            key=f"vote:{result.proposal}:{result.outcome_class}",
            effects={"immediate": feedback.effects, "medium": {}, "long": {}},
            capital_delta=feedback.capital_delta,
            pressure_delta=feedback.pressure_delta,
            locks_add=feedback.locks_add,
            tags=feedback.tags,
        )
        update = state.apply(action, pressure_rules)
        update["vote_result"] = asdict(result)
        return update
