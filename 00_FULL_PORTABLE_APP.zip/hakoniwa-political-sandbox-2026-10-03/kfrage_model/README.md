# Reproducible 2024 CDU/CSU K-Frage process model

This directory contains a retrospective calibration experiment. It does **not** forecast an election, rate politicians, or interpret simulation shares as real-world probabilities.

## Party collectives

`party_profiles_2026/party_interest_profiles.json` provides programme-grounded
collective actors for CDU/CSU, SPD, Greens, AfD, Die Linke, BSW and FDP. Union
personas can combine their individual evaluation with the CDU/CSU layer; the
other parties run directly through `PartyInterestEngine` without invented leader
personalities. The neutral validation menu is available as:

```bash
python3 -m kfrage_model.party_profiles_2026.demo_party_round
```

## Optional ARCANA adviser

ARCANA v0.1 is an opt-in, seeded Petit Etteilla adviser. It runs after the
ordinary political evaluation and can affect only a viable near-tie through an
actor's risk threshold and current PSS. It is off by default:

```bash
python3 -m kfrage_model --arcana --arcana-seed 1773 \
  decide Merz --request request.json --pretty
```

Add `conflict_actor` to a decision request to run two independent readings and
emit their PSS-mediated interaction. Every enabled reading retains its complete
draw, historical resolution, custom interpretation, adoption decision and
replay seed. Full boundaries and source notes are in `ARCANA.md`.

The architecture now separates a shared historical **environment** from replaceable **personality policies**:

```text
environment.json
  facts + initial resources + organizations + constraints + node order
       ↓ stage-specific visible context
personality_api.py / selected actor policy
  decision rule only
       ↓ chosen allowed action
kfrage_sim.py
  action effects + resource redistribution + next node
```

A personality cannot silently change its office, invent information, reorder the timeline, or directly edit resources. It chooses from the actions exposed by the environment at that stage.

## Run

From the project root:

```bash
python3 kfrage_model/kfrage_sim.py --runs 5000 --out kfrage_model/outputs
python3 -m unittest kfrage_model/test_model.py
```

Blind mode remains available in the retrospective engine, but generated run
artifacts are not retained in the source tree.

The model uses only the Python standard library. If the system `python3` is unavailable in Codex Desktop, use the bundled runtime shown by the workspace dependencies tool.

## Files

- `kfrage_sim.py` — simulation and CLI.
- `environment.json` — the shared historical background, initial resources, organization nodes, global constraints, and timeline.
- `personality_api.py` — plug-in contract and the current Merz/Wüst/Söder policies.
- `ARCHITECTURE.md` — ownership boundary, stage/action contract, and extension rules.
- `example_custom_personality.py` — a deliberately simple replacement-policy example.
- `assumptions.json` — numeric encodings, actor rules, black boxes, and anti-leakage contract.
- `source_notes.md` — contemporaneous source calibration and evidence labels.
- `test_model.py` — reproducibility and anti-leakage checks.

Run outputs belong in an explicit caller-selected path and are disposable. The
repository intentionally retains no previous hypothetical traces or reports.

## Process

Each node is explicitly decomposed as:

`information update → perceived resource state → actor-specific threshold/risk logic → action → resource redistribution → next node`

The seven resource dimensions are:

1. `formal_office_default`
2. `landesverband_hausmacht`
3. `fraktion`
4. `party_apparatus`
5. `public_visibility`
6. `union_acceptability`
7. `future_option_value`

The observed 16/17 September sequence exists only in `OBSERVED_COMPARATOR`, which is called after a run. Decision functions cannot read it.

## Insert a different personality model

Create a class derived from `PersonalityPolicy`. It receives a `DecisionContext` containing:

- `actor` and `stage`;
- `allowed_actions` supplied by the environment;
- `features`, meaning the actor's stage-specific perceived inputs;
- `visible_world`, excluding declared black boxes;
- optional sensitivity `parameters`.

It returns `PolicyDecision(action, utilities, rule, diagnostics)`.

Replace only Wüst while leaving the environment and other actor models unchanged:

```bash
python3 kfrage_model/kfrage_sim.py \
  --runs 5000 \
  --out kfrage_model/outputs_custom \
  --policy Wuest=kfrage_model.example_custom_personality:AlwaysWaitWuest
```

Multiple policies can be replaced in the same run:

```bash
python3 kfrage_model/kfrage_sim.py \
  --policy Wuest=my_models:AlternativeWuest \
  --policy Merz=my_models:AlternativeMerz \
  --policy Soeder=my_models:AlternativeSoeder
```

The class must have a zero-argument constructor. The trace records `policy_id` at every decision node, and the JSON output records the complete active policy set.

## Replace the background

Use another environment JSON with the same engine schema:

```bash
python3 kfrage_model/kfrage_sim.py --environment path/to/environment.json
```

The allowlisted timeline prevents a configuration file from invoking arbitrary methods. Changes to background facts should be versioned separately from personality changes so their effects remain distinguishable.

## Monte Carlo interpretation

The Monte Carlo layer perturbs perceived resources and one bounded negotiation contingency. Actor rule weights remain fixed. Therefore output shares mean only:

> the proportion of model runs following each path under the declared perturbation design.

They are not claims about historical chance, electoral probability, or which actor “would have won.”

## Current forward-simulation engine

The 2026 forward environment uses the POMDG v2 modules while retaining the 2024
engine for retrospective calibration:

- `decision_space.py` — event-driven perception → goal → strategy → execution
  style action generation, followed by post-choice outcome settlement.
- `historical_dynamics.py` — long/medium/short causal layers, historical
  mechanisms, decomposed risk and threshold-based event generation.
- `narrative_media.py` — simultaneous frame/channel competition, audience
  interpretation, agenda ownership and public-legitimacy feedback.
- `political_state.py` — reality, time horizons, scoped political capital, pressure
  tracks and route locks.
- `information_filter.py` — actor-specific access, bias, confidence and belief state.
- `strategic_game.py` — hard thresholds, nonlinear risk and bounded game-tree search.
- `roguelike_engine.py` — the lower-level transparent variable settlement layer.
- `parliamentary_vote.py` — explicit vote rules, bloc-level forecasts, sensitivity
  runs and outcome-dependent feedback.
- `political_activity.py` — seeded routine speeches, interviews, endorsements,
  faction meetings and visits with attention-limited effects.
- `legislative_cycle.py` — debate → forecast → vote → feedback orchestration.
- `realtime_polling.py` — a latent poll state and rounded model-nowcast snapshot
  after every decision or event.

## Free-agent personality cards v2

`persona_v2.py` and `personality_cards_2026/cards_pss.json` replace scripted
stage policies with a roguelike free-choice layer. The environment supplies an
action menu; each actor scores every legal action using goal alignment, perceived
resource feasibility, risk, mutable current state, memories/relationships and
identity consistency. Event shocks and action outcomes update state and memory,
so the same character can choose differently without randomising personality.

`political_state_system.py` is the formal Political State System (PSS). All
quantitative card/state inputs use the `0.000..1.000` scale and traces round to
three decimals. Events are transformed into actor-specific impacts before state
mutation; time alone restores only energy and pressure.

See `personality_cards_2026/PERSONA_V2.md` and
`personality_cards_2026/POLITICAL_STATE_SYSTEM.md`. The v1 cards and policies remain in
place solely for reproducibility of earlier runs.

New hypothetical scenarios should be supplied at runtime or kept outside the
source tree. The repository intentionally ships no previously run scenario.
