# Germany–Russia: from hybrid confrontation to Verteidigungsfall and continued war

This is a conditional stress scenario, not a forecast that war will occur. It
starts from the observed September 2026 hybrid confrontation, adds the user's
counterfactual attacks, enforces a formally promulgated defence case as an
intermediate condition, and continues the simulation through 15 October.

```bash
python -m kfrage_model.scenarios.germany_russia_defence_case.run_scenario
```

