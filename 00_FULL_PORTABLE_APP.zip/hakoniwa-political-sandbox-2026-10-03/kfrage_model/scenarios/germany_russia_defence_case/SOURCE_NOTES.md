# Germany–Russia defence-case scenario — source notes

As of: 2026-09-23

## Observed T-1 anchors

- Germany attributed the attempted explosive-drone attack at Leipzig/Halle
  Airport to Russia and responded diplomatically. The device was discovered and
  defused; it did not create the direct armed-conflict state assumed later here.
- Russia rejected responsibility and imposed reciprocal diplomatic measures.
- NATO Article 4 provides consultation where a member considers its security
  threatened. Article 5 is collective defence after an armed attack, but Article
  4 is not a mandatory prerequisite and each ally acts through its constitutional
  processes.
- Under GG Art. 115a, the Bundestag determines that federal territory is under
  armed attack or immediately threatened, on application of the Federal
  Government, with Bundesrat consent and the specified qualified Bundestag
  majority. Under Art. 115b, Bundeswehr command authority transfers to the
  Chancellor only upon promulgation of the defence case.
- Under GG Art. 80a, a state of tension is distinct and requires its own
  Bundestag determination. Under Art. 87a(3), protection of civilian objects by
  the armed forces is tied to the state of tension or defence and cooperation
  with competent authorities.
- Armed Bundeswehr deployments abroad remain subject to the Parliamentary
  Participation Act unless its emergency provisions apply; NATO Article 5 does
  not erase German parliamentary requirements.

## Explicit counterfactual premises

- 2026-09-27: a second explosive-drone attack succeeds against a Bundeswehr
  logistics facility and causes German military casualties.
- 2026-10-01: an attributable Russian missile strikes German federal territory.
  This is the scenario's unambiguous armed-attack threshold.
- The run must reach a formally determined and promulgated Verteidigungsfall.
- Fighting continues after promulgation; the defence case is not the terminal
  outcome.

## Unknown black boxes

- Kremlin authorization chain and factional control inside Russia.
- Classified attribution confidence and allied intelligence differences.
- Exact Bundestag attendance, Bundesrat instructions and NATO Council positions.
- Russian follow-on-strike intensity, operational error and off-ramp credibility.
- Casualties, infrastructure effects and public opinion response.

## Sources

- GG Art. 115a: https://www.gesetze-im-internet.de/gg/art_115a.html
- GG Art. 115b: https://www.gesetze-im-internet.de/gg/art_115b.html
- GG Art. 80a: https://www.gesetze-im-internet.de/gg/art_80a.html
- GG Art. 87a: https://www.gesetze-im-internet.de/gg/art_87a.html
- Parliamentary Participation Act:
  https://www.gesetze-im-internet.de/parlbg/BJNR077500005.html
- NATO, Article 4 consultation:
  https://www.nato.int/en/what-we-do/introduction-to-nato/the-consultation-process-and-article-4
- NATO, collective defence and Article 5:
  https://www.nato.int/en/what-we-do/introduction-to-nato/collective-defence-and-article-5
- Tagesschau, Leipzig/Halle attribution:
  https://www.tagesschau.de/inland/innenpolitik/leipzig-drohnenvorfall-russischer-geheimdienst-100.html

