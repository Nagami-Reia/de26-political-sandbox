#!/usr/bin/env python3
"""Conditional German–Russian conflict reaching and continuing beyond Art. 115a."""
from __future__ import annotations

import json
import random
from dataclasses import asdict, replace
from html import escape
from pathlib import Path

from kfrage_model.checks.constitutional import build_gg_check_engine
from kfrage_model.checks.context import BundestagState, CheckContext
from kfrage_model.free_agent_game import WorldAction
from kfrage_model.information_filter import AccessRule, InformationFilter
from kfrage_model.institutional_matrix import InstitutionalMatrix
from kfrage_model.interaction.intents import Intent
from kfrage_model.persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine
from kfrage_model.political_state import PoliticalAction, PoliticalState, StateVariable
from kfrage_model.political_state_system import PoliticalEvent
from kfrage_model.procedures.state import ProcedureBook, ProcedureState
from kfrage_model.rationality_evaluation import ActorRationalityProfile
from kfrage_model.realtime_polling import PollSeriesSpec, RealtimePollingTracker
from kfrage_model.scenario_reporting import ScenarioReportCompiler, render_arcana_embed
from kfrage_model.simulation_orchestrator import (
    LayeredConfiguration, LayeredSimulationOrchestrator, SimulationNodeV3, V3FeatureFlags,
)


ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = HERE / "output"
LABELS: dict[str, str] = {}

DATES = {
    "first_address": "2026-09-27T06:30:00+02:00",
    "attribution": "2026-09-27T12:30:00+02:00",
    "domestic_protection": "2026-09-27T20:00:00+02:00",
    "nato_consultation": "2026-09-28T11:00:00+02:00",
    "parliament_prestrike": "2026-09-29T14:00:00+02:00",
    "laender_readiness": "2026-09-30T16:00:00+02:00",
    "russian_missile_attack": "2026-10-01T03:42:00+02:00",
    "defence_application": "2026-10-01T07:15:00+02:00",
    "qualified_majority": "2026-10-01T12:30:00+02:00",
    "defence_case_promulgated": "2026-10-01T16:00:00+02:00",
    "wartime_direction": "2026-10-01T18:00:00+02:00",
    "nato_collective_defence": "2026-10-02T10:00:00+02:00",
    "domestic_defence": "2026-10-02T18:00:00+02:00",
    "federal_state_execution": "2026-10-03T14:00:00+02:00",
    "russian_follow_on": "2026-10-05T04:10:00+02:00",
    "direct_exchange": "2026-10-07T09:20:00+02:00",
    "parliamentary_control": "2026-10-07T18:00:00+02:00",
    "logistics_energy": "2026-10-08T16:00:00+02:00",
    "ports_civil_defence": "2026-10-09T15:00:00+02:00",
    "union_narrative": "2026-10-10T17:00:00+02:00",
    "military_strategy": "2026-10-12T10:00:00+02:00",
    "diplomatic_offramp": "2026-10-13T19:00:00+02:00",
    "october_posture": "2026-10-15T18:00:00+02:00",
}

PROMPTS = {
    "first_address": "证据尚未闭合时，Merz如何首次向全国讲话？",
    "attribution": "Wadephul如何把技术、网络和国家责任分层公开？",
    "domestic_protection": "Dobrindt如何保护国内设施而不越过基本法边界？",
    "nato_consultation": "德国是否请求NATO Article 4磋商？",
    "parliament_prestrike": "Frei如何在归责尚未完全公开时组织Bundestag？",
    "laender_readiness": "Wüst如何组织州警察、民防、交通和关键设施协调？",
    "defence_application": "俄罗斯导弹命中德国后，Merz如何提出Verteidigungsfall申请？",
    "qualified_majority": "Frei如何组织Art.115a所需议会多数？",
    "wartime_direction": "公布Verteidigungsfall后，Merz如何使用Art.115b指挥权？",
    "nato_collective_defence": "Wadephul如何把德国防御与NATO Article 5结合？",
    "domestic_defence": "Dobrindt如何在防御状态下组织军警与民用设施保护？",
    "federal_state_execution": "Wüst如何把联邦防御决策转换成州级执行？",
    "parliamentary_control": "直接交火后，Frei如何保留议会授权和监督？",
    "logistics_energy": "Rhein如何处理交通、能源与盟军后勤压力？",
    "ports_civil_defence": "Günther如何管理港口、海岸和民防任务？",
    "union_narrative": "Söder如何争夺战争叙事而不破坏统一指挥？",
    "military_strategy": "Merz选择怎样的持续作战边界？",
    "diplomatic_offramp": "Wadephul是否保留可信的降级与停火渠道？",
    "october_posture": "10月15日，Merz如何在战争仍持续时确定下一阶段？",
}


def event(event_id: str, severity: float, tags: tuple[str, ...]) -> PoliticalEvent:
    return PoliticalEvent(event_id, "armed_conflict_shock", severity, tags,
                          valence=-1.0, surprise=.85, workload=.10)


def action(key: str, label: str, next_node: str | None, *, owner: str,
           effects: dict[str, float], values: dict[str, float], goal: str,
           good: bool, success: float, strategy: str = "institutionalize",
           intent: Intent | None = None, affected: tuple[str, ...] = ()) -> WorldAction:
    LABELS[key] = label
    identity = tuple(values) + (("defence",) if good else ("escalation_risk",))
    actor_events = {
        actor: (event(f"{key}:{actor}", .30 if good else .58,
                      ("war", "loss_of_control" if not good else "institutional_control")),)
        for actor in affected
    }
    return WorldAction(
        PoliticalAction(key, {"immediate": effects, "medium": {}, "long": {}},
                        feasibility=.84 if good else .66, next_node=next_node,
                        tags=("germany_russia_conflict",)),
        ActionOption(
            key=key, goal_impacts={goal: .90 if good else .34}, value_impacts=values,
            upside=.76 if good else .62, downside=.34 if good else .74,
            uncertainty=.45 if good else .66, irreversibility=.42 if good else .74,
            effort=.78 if good else .68, visibility=.76 if good else .90,
            information_confidence=.74, control_domains=("security", "organization"),
            restores_control=.66 if good else .28, conflict_strategy=strategy,
            identity_tags=identity, event_tags=("armed_attack", "war"),
            risk_tags=("miscalculation",) if not good else ("allied_coordination",),
            objective_feasibility=.84 if good else .66,
            instrumental_impacts={goal: .88 if good else .38,
                                  "allied_cohesion": .80 if good else .34},
            substantive_impacts={"constitutional_legitimacy": .88 if good else .24,
                                 "escalation_control": .78 if good else .22},
            necessity_frame_alignment=.76,
        ), actor_events,
        {owner: ActionOutcome(action=key, success=success, surprise=.20,
                              tags=identity, workload=.07,
                              control_restoration=.05 * success,
                              identity_alignment=.05 * (success - .5))},
        intent,
    )


def triad(node: str, owner: str, next_node: str | None, goal: str,
          rows: tuple[tuple[str, str, dict[str, float]], ...],
          values: tuple[str, str], intents: tuple[Intent | None, ...] = ()) -> SimulationNodeV3:
    built = []
    for index, (key, label, effects) in enumerate(rows):
        good = index == 0
        built.append(action(
            key, label, next_node, owner=owner, effects=effects,
            values={values[0]: .90 if good else .42,
                    values[1]: .84 if good else .34}, goal=goal, good=good,
            success=.68 if good else .40, strategy="institutionalize" if good else
            ("attack" if index == 1 else "avoid"),
            intent=intents[index] if intents else None,
        ))
    return SimulationNodeV3(node, owner, tuple(built), {goal: .96},
                            ("armed_attack", "war", goal))


def build_nodes() -> dict[str, SimulationNodeV3]:
    n: dict[str, SimulationNodeV3] = {}
    n["first_address"] = triad("first_address", "Merz", "attribution", "public_control", (
        ("merz_factual_address", "确认伤亡和调查，说明防御措施，但暂不作超出证据的国家归责",
         {"union_de": .20, "gov_trust": .65, "attribution_confidence": 2,
          "escalation_pressure": -2, "defence_consensus": 3}),
        ("merz_immediate_russia_blame", "立即宣布俄罗斯发动攻击并承诺军事回应",
         {"union_de": .08, "gov_trust": -.20, "attribution_confidence": -4,
          "escalation_pressure": 8, "defence_consensus": 2}),
        ("merz_silence", "等待全部情报闭合后再公开讲话",
         {"union_de": -.28, "gov_trust": -.70, "attribution_confidence": 1,
          "escalation_pressure": 2, "defence_consensus": -3}),
    ), ("strategic_direction", "political_authority"))
    n["attribution"] = triad("attribution", "Wadephul", "domestic_protection", "credible_attribution", (
        ("wadephul_evidence_ladder", "与盟友同步，分开公布技术同源、行动网络和国家机构联系的置信度",
         {"gov_trust": .40, "attribution_confidence": 14, "nato_cohesion": 6,
          "escalation_pressure": 1, "offramp_space": 2}),
        ("wadephul_maximal_attribution", "把国家机构联系直接表述为克里姆林宫授权",
         {"gov_trust": -.12, "attribution_confidence": 6, "nato_cohesion": -2,
          "escalation_pressure": 9, "offramp_space": -8}),
        ("wadephul_private_only", "只向盟友通报，暂不公开归责结构",
         {"gov_trust": -.25, "attribution_confidence": 8, "nato_cohesion": 2,
          "escalation_pressure": -2, "offramp_space": 4}),
    ), ("alliance_reliability", "diplomatic_control"))
    n["domestic_protection"] = triad("domestic_protection", "Dobrindt", "nato_consultation", "protect_home_front", (
        ("dobrindt_police_led_protection", "BKA与州警察主导民用设施保护，Bundeswehr强化自身设施，准备依法升级",
         {"gov_trust": .28, "readiness": 6, "civil_resilience": 5,
          "escalation_pressure": -1, "defence_consensus": 2}),
        ("dobrindt_blanket_military_patrols", "在尚无Spannungsfall时要求Bundeswehr全面武装保护民用设施",
         {"gov_trust": -.42, "readiness": 3, "civil_resilience": 2,
          "escalation_pressure": 5, "defence_consensus": -4}),
        ("dobrindt_investigation_only", "只扩大刑事调查，不改变设施保护层级",
         {"gov_trust": -.24, "readiness": -2, "civil_resilience": -3,
          "escalation_pressure": -2, "defence_consensus": -2}),
    ), ("policy_control", "state_capacity"), intents=(
        None,
        Intent("predef_blanket", "Bundesregierung",
               "deploy_armed_forces_to_protect_civilian_objects"),
        None,
    ))
    n["nato_consultation"] = triad("nato_consultation", "Wadephul", "parliament_prestrike", "allied_consultation", (
        ("wadephul_article4", "请求北约第四条磋商并建立共同归责与预警小组",
         {"nato_cohesion": 8, "gov_trust": .22, "readiness": 3,
          "escalation_pressure": 1, "offramp_space": 2}),
        ("wadephul_article5_early", "在armed attack定性前即要求宣布第五条",
         {"nato_cohesion": -6, "gov_trust": -.20, "readiness": 2,
          "escalation_pressure": 8, "offramp_space": -6}),
        ("wadephul_bilateral_only", "只进行美法英波双边协调，不启动正式北约磋商",
         {"nato_cohesion": -2, "gov_trust": -.10, "readiness": 1,
          "escalation_pressure": -1, "offramp_space": 3}),
    ), ("alliance_reliability", "diplomatic_control"))
    n["parliament_prestrike"] = triad("parliament_prestrike", "Frei", "laender_readiness", "parliamentary_legitimacy", (
        ("frei_classified_crossparty_briefing", "组织机密跨党派简报、委员会连续值班和升级门槛决议",
         {"defence_consensus": 8, "gov_trust": .25, "readiness": 2,
          "nato_cohesion": 1, "escalation_pressure": -1}),
        ("frei_union_only_line", "把危机作为政府信任问题，只整合Union多数",
         {"defence_consensus": -3, "gov_trust": -.18, "readiness": 1,
          "nato_cohesion": 0, "escalation_pressure": 3}),
        ("frei_delay_bundestag", "以保护情报为由推迟议会实质参与",
         {"defence_consensus": -7, "gov_trust": -.42, "readiness": 0,
          "nato_cohesion": -1, "escalation_pressure": 1}),
    ), ("organization_success", "political_stability"))
    n["laender_readiness"] = triad("laender_readiness", "Wuest", None, "federal_state_readiness", (
        ("wuest_joint_readiness_cell", "建立联邦—州联合态势单元，统一警察、医院、交通和能源预案",
         {"civil_resilience": 8, "readiness": 4, "gov_trust": .22,
          "defence_consensus": 3, "escalation_pressure": -1}),
        ("wuest_state_first", "NRW单独提高警戒并公开要求联邦补足资源",
         {"civil_resilience": 4, "readiness": 2, "gov_trust": -.12,
          "defence_consensus": 0, "escalation_pressure": 2}),
        ("wuest_wait_federal_order", "等待联邦形成完整法律定性后再启动州级措施",
         {"civil_resilience": -3, "readiness": -2, "gov_trust": -.18,
          "defence_consensus": -1, "escalation_pressure": 0}),
    ), ("coalition_stability", "procedural_control"))

    n["defence_application"] = triad("defence_application", "Merz", "qualified_majority", "constitutional_defence", (
        ("merz_apply_art115a", "确认俄罗斯导弹为对德国领土的武装攻击，向Bundestag申请确定Verteidigungsfall",
         {"defence_consensus": 10, "gov_trust": .65, "readiness": 5,
          "nato_cohesion": 4, "escalation_pressure": 5}),
        ("merz_command_without_process", "不等议会和公布程序，直接宣布本人接管军队指挥",
         {"defence_consensus": -12, "gov_trust": -.90, "readiness": 1,
          "nato_cohesion": -5, "escalation_pressure": 10}),
        ("merz_keep_hybrid_label", "继续以混合袭击处理，暂不启动Art.115a",
         {"defence_consensus": -8, "gov_trust": -.55, "readiness": -4,
          "nato_cohesion": -4, "escalation_pressure": -2}),
    ), ("strategic_direction", "political_authority"))
    n["qualified_majority"] = triad("qualified_majority", "Frei", None, "qualified_majority", (
        ("frei_supermajority_compact", "以证据、期限、监督和复审条款组织跨党派合格多数及Bundesrat同步",
         {"defence_consensus": 12, "gov_trust": .48, "readiness": 3,
          "nato_cohesion": 2, "escalation_pressure": -1}),
        ("frei_party_discipline_only", "只按政府阵营纪律推动表决",
         {"defence_consensus": -6, "gov_trust": -.28, "readiness": 1,
          "nato_cohesion": -2, "escalation_pressure": 2}),
        ("frei_open_ended_resolution", "通过宽泛政治声明但不处理Art.115a程序条件",
         {"defence_consensus": -9, "gov_trust": -.36, "readiness": -1,
          "nato_cohesion": -2, "escalation_pressure": 0}),
    ), ("organization_success", "political_stability"))

    n["wartime_direction"] = triad("wartime_direction", "Merz", "nato_collective_defence", "wartime_command", (
        ("merz_integrated_command", "依Art.115b接掌指挥权，设定防御目标、NATO接口和每日文官—军事复审",
         {"readiness": 7, "nato_cohesion": 4, "gov_trust": .55,
          "escalation_pressure": -2, "offramp_space": 2}),
        ("merz_personalized_command", "把作战沟通和多数关键决定集中到总理个人办公室",
         {"readiness": 2, "nato_cohesion": -2, "gov_trust": -.18,
          "escalation_pressure": 5, "offramp_space": -4}),
        ("merz_delegate_without_guidance", "形式接掌指挥权但不设清晰政治目标，由军事系统自行推进",
         {"readiness": 1, "nato_cohesion": -1, "gov_trust": -.24,
          "escalation_pressure": 6, "offramp_space": -5}),
    ), ("strategic_direction", "political_authority"), intents=(
        Intent("merz_115b", "Merz", "assume_defence_command"), None, None,
    ))
    n["nato_collective_defence"] = triad("nato_collective_defence", "Wadephul", "domestic_defence", "collective_defence", (
        ("wadephul_article5_bounded", "推动NAC确认第五条，同时明确防御目标、交战边界和持续外交通道",
         {"nato_cohesion": 10, "readiness": 5, "gov_trust": .25,
          "escalation_pressure": 3, "offramp_space": 3}),
        ("wadephul_maximum_war_aims", "把第五条与迫使俄罗斯全面战略失败绑定",
         {"nato_cohesion": -5, "readiness": 3, "gov_trust": -.15,
          "escalation_pressure": 12, "offramp_space": -12}),
        ("wadephul_german_only", "避免正式第五条路线，主要保留德国双边回应",
         {"nato_cohesion": -10, "readiness": -4, "gov_trust": -.32,
          "escalation_pressure": -1, "offramp_space": 2}),
    ), ("alliance_reliability", "diplomatic_control"))
    n["domestic_defence"] = triad("domestic_defence", "Dobrindt", "federal_state_execution", "home_defence", (
        ("dobrindt_layered_home_defence", "依法组织Bundeswehr保护关键民用节点，并由警察维持执法主导和州级协作",
         {"civil_resilience": 9, "readiness": 4, "gov_trust": .30,
          "escalation_pressure": 0, "offramp_space": 0}),
        ("dobrindt_federal_security_centralization", "把多数警察和民防决策集中到联邦内政线",
         {"civil_resilience": 4, "readiness": 3, "gov_trust": -.22,
          "escalation_pressure": 2, "offramp_space": -1}),
        ("dobrindt_military_first_domestic", "让军方替代州警察成为国内安全主要执行者",
         {"civil_resilience": 1, "readiness": 2, "gov_trust": -.55,
          "escalation_pressure": 4, "offramp_space": -2}),
    ), ("policy_control", "state_capacity"), intents=(
        Intent("postdef_protection", "Bundesregierung",
               "deploy_armed_forces_to_protect_civilian_objects"), None, None,
    ))
    n["federal_state_execution"] = triad("federal_state_execution", "Wuest", None, "civil_execution", (
        ("wuest_distributed_execution", "用统一标准分散执行医院、警察、运输和通信韧性任务",
         {"civil_resilience": 8, "readiness": 3, "gov_trust": .20,
          "escalation_pressure": -1, "offramp_space": 1}),
        ("wuest_public_resource_conflict", "公开与联邦争夺装备和权限优先级",
         {"civil_resilience": 2, "readiness": 0, "gov_trust": -.25,
          "escalation_pressure": 2, "offramp_space": 0}),
        ("wuest_central_deference", "把州级执行完全交给联邦逐项指令",
         {"civil_resilience": -2, "readiness": -1, "gov_trust": -.20,
          "escalation_pressure": 0, "offramp_space": 0}),
    ), ("coalition_stability", "procedural_control"))

    n["parliamentary_control"] = triad("parliamentary_control", "Frei", "logistics_energy", "wartime_oversight", (
        ("frei_wartime_oversight", "建立机密监督小组、定期续期窗口和海外武装行动授权程序",
         {"defence_consensus": 6, "gov_trust": .35, "readiness": 2,
          "nato_cohesion": 1, "escalation_pressure": -2}),
        ("frei_blank_cheque", "要求议会给政府开放式授权并暂停多数实质审查",
         {"defence_consensus": -8, "gov_trust": -.45, "readiness": 2,
          "nato_cohesion": -1, "escalation_pressure": 5}),
        ("frei_normal_calendar", "按普通议程速度处理所有战争授权和监督",
         {"defence_consensus": -4, "gov_trust": -.18, "readiness": -4,
          "nato_cohesion": -2, "escalation_pressure": 1}),
    ), ("organization_success", "political_stability"))
    n["logistics_energy"] = triad("logistics_energy", "Rhein", "ports_civil_defence", "logistics_resilience", (
        ("rhein_logistics_compact", "整合机场、铁路、能源、医院和盟军运输并保留民用最低服务",
         {"civil_resilience": 7, "readiness": 5, "gov_trust": .18,
          "escalation_pressure": 0, "offramp_space": 0}),
        ("rhein_military_priority_only", "对军运实行绝对优先，不建立民用服务保护阈值",
         {"civil_resilience": -4, "readiness": 5, "gov_trust": -.34,
          "escalation_pressure": 2, "offramp_space": -1}),
        ("rhein_land_protectionism", "限制跨州资源调用以优先保障本州",
         {"civil_resilience": -3, "readiness": -3, "gov_trust": -.28,
          "escalation_pressure": 1, "offramp_space": 0}),
    ), ("state_governance", "coalition_management"))
    n["ports_civil_defence"] = triad("ports_civil_defence", "Guenther", "union_narrative", "coastal_resilience", (
        ("guenther_port_consensus", "以港口运行、疏散、盟军运输和地方政府协商形成沿海执行联盟",
         {"civil_resilience": 7, "readiness": 4, "gov_trust": .20,
          "escalation_pressure": -1, "offramp_space": 1}),
        ("guenther_public_federal_critique", "在执行同时公开批评联邦沟通不足",
         {"civil_resilience": 3, "readiness": 2, "gov_trust": -.18,
          "escalation_pressure": 1, "offramp_space": 0}),
        ("guenther_delay_ports", "等待所有军事运输风险完全厘清后再扩大港口任务",
         {"civil_resilience": -1, "readiness": -4, "gov_trust": -.14,
          "escalation_pressure": 0, "offramp_space": 1}),
    ), ("majority_viability", "consensus"))
    n["union_narrative"] = triad("union_narrative", "Soeder", "military_strategy", "political_unity", (
        ("soeder_unity_with_metrics", "支持统一指挥，同时要求政府公开防御目标、物资指标和复审期限",
         {"defence_consensus": 4, "gov_trust": .18, "union_de": .10,
          "escalation_pressure": -1, "offramp_space": 1}),
        ("soeder_outbid_war_line", "公开要求比联邦政府更强的战争目标和报复规模",
         {"defence_consensus": -4, "gov_trust": -.20, "union_de": -.05,
          "escalation_pressure": 8, "offramp_space": -6}),
        ("soeder_regional_silence", "只处理巴伐利亚执行问题，不参与全国叙事",
         {"defence_consensus": -1, "gov_trust": -.08, "union_de": -.04,
          "escalation_pressure": 0, "offramp_space": 0}),
    ), ("bavarian_delivery", "union_leadership"))
    n["military_strategy"] = triad("military_strategy", "Merz", "diplomatic_offramp", "bounded_war", (
        ("merz_denial_and_defence", "以防空、基地防护、NATO东翼增援和阻止后续攻击为有限战争目标",
         {"readiness": 7, "nato_cohesion": 5, "gov_trust": .30,
          "escalation_pressure": -3, "offramp_space": 4}),
        ("merz_coercive_expansion", "把目标扩大为迫使俄罗斯全面后退并接受更广泛政治条件",
         {"readiness": 3, "nato_cohesion": -3, "gov_trust": -.12,
          "escalation_pressure": 12, "offramp_space": -12}),
        ("merz_unilateral_pause", "在盟友尚未同意时单方面暂停多数军事行动",
         {"readiness": -7, "nato_cohesion": -8, "gov_trust": -.22,
          "escalation_pressure": -5, "offramp_space": 7}),
    ), ("strategic_direction", "reform_achievement"))
    n["diplomatic_offramp"] = triad("diplomatic_offramp", "Wadephul", "october_posture", "credible_offramp", (
        ("wadephul_parallel_backchannel", "维持威慑和作战，同时通过盟友与秘密渠道测试停止打击的可核验条件",
         {"offramp_space": 10, "nato_cohesion": 3, "gov_trust": .16,
          "escalation_pressure": -5, "readiness": 0}),
        ("wadephul_no_contact", "在俄罗斯公开认责前拒绝任何秘密或公开沟通",
         {"offramp_space": -10, "nato_cohesion": -1, "gov_trust": -.08,
          "escalation_pressure": 8, "readiness": 1}),
        ("wadephul_public_ceasefire_offer", "在未与盟友协调前公开提出立即停火",
         {"offramp_space": 5, "nato_cohesion": -7, "gov_trust": -.18,
          "escalation_pressure": -2, "readiness": -3}),
    ), ("alliance_reliability", "diplomatic_control"))
    n["october_posture"] = triad("october_posture", "Merz", None, "sustained_defence", (
        ("merz_sustained_bounded_defence", "维持Verteidigungsfall和有限防御目标，每72小时复审升级与停火条件",
         {"readiness": 4, "nato_cohesion": 3, "gov_trust": .20,
          "escalation_pressure": -3, "offramp_space": 3}),
        ("merz_expand_campaign", "把有限防御转为长期扩大军事行动",
         {"readiness": 1, "nato_cohesion": -4, "gov_trust": -.16,
          "escalation_pressure": 10, "offramp_space": -8}),
        ("merz_seek_immediate_end", "无论俄方后续行动如何，优先尽快结束防御状态",
         {"readiness": -6, "nato_cohesion": -6, "gov_trust": -.12,
          "escalation_pressure": -5, "offramp_space": 8}),
    ), ("strategic_direction", "political_authority"))
    return n


def initial_state() -> PoliticalState:
    values = {
        "union_de": 20.0, "afd_de": 29.0, "spd_de": 13.0,
        "gov_trust": 18.0, "attribution_confidence": 42.0, "nato_cohesion": 66.0,
        "defence_consensus": 45.0, "readiness": 58.0, "civil_resilience": 52.0,
        "escalation_pressure": 48.0, "offramp_space": 46.0,
        "military_casualties": 6.0, "infrastructure_damage": 8.0,
    }
    return PoliticalState(
        {k: StateVariable(k, v, uncertainty=.10) for k, v in values.items()},
        capital={"government": 58, "bundestag": 70, "nato": 74, "laender": 67},
        pressures={"armed_conflict": 70, "miscalculation": 62, "civil_defence": 55},
        locks={"hybrid_confrontation", "second_drone_attack"},
    )


def configuration() -> LayeredConfiguration:
    base = LayeredConfiguration.from_environment_json(
        ROOT / "kfrage_model/environments/2026-07-31/environment.json",
        ROOT / "kfrage_model/personality_cards_2026/rationality_profiles_v3.json")
    expansion = json.loads((ROOT / "kfrage_model/personality_cards_2026/"
                            "rationality_profiles_expansion_2026_09.json").read_text())
    profiles = dict(base.rationality_profiles)
    profiles.update({k: ActorRationalityProfile(**v) for k, v in expansion["actors"].items()})
    offices = dict(base.matrix.actor_offices)
    offices.update({
        "Merz": ("federal_chancellor",), "Wadephul": ("federal_foreign_minister",),
        "Dobrindt": ("federal_interior_minister",), "Frei": ("union_faction_chair",),
        "Wuest": ("nrw_minister_president",), "Rhein": ("hessen_minister_president",),
        "Guenther": ("sh_minister_president",), "Soeder": ("bavaria_minister_president", "csu_chair"),
    })
    return LayeredConfiguration(
        InstitutionalMatrix(base.matrix.matrix_id + "_defence_case", offices,
                            base.matrix.office_permissions, base.matrix.rules),
        replace(base.logic, governability_priority=.96, organizational_unity_priority=.94,
                necessity_claim_strength=.88, alternative_legibility=.28,
                control_concentration=.76), base.agency, profiles,
        V3FeatureFlags(True, True, True, False),
    )


def check_context(world: PoliticalState, procedures: ProcedureBook | None = None) -> CheckContext:
    return CheckContext(
        now_hours=1000, bundestag=BundestagState(630),
        actor_roles={
            "Merz": frozenset({"federal_chancellor"}),
            "Steinmeier": frozenset({"federal_president"}),
            "Bundestag": frozenset({"bundestag"}),
            "Bundesregierung": frozenset({"federal_government"}),
            "DefenceMinister": frozenset({"federal_minister", "federal_minister:defence"}),
        },
        office_holders={"federal_chancellor": "Merz", "federal_president": "Steinmeier"},
        procedures=procedures or ProcedureBook(),
        facts={
            "federal_territory_attacked_by_armed_force": "missile_attack_confirmed" in world.locks,
            "defence_case_promulgated": "defence_case_promulgated" in world.locks,
            "state_of_tension_determined": "state_of_tension" in world.locks,
        },
    )


def polling() -> RealtimePollingTracker:
    specs = tuple(PollSeriesSpec(*row, retention=.60, publication_grid=.5) for row in (
        ("union_de", "CDU/CSU", "federal_electorate", "vote_intention", "Germany"),
        ("afd_de", "AfD", "federal_electorate", "vote_intention", "Germany"),
        ("spd_de", "SPD", "federal_electorate", "vote_intention", "Germany"),
        ("gov_trust", "Federal government", "federal_electorate", "crisis_trust", "Germany"),
        ("defence_consensus", "Defence case", "federal_electorate", "political_support", "Germany"),
    ))
    mapping = {f"layered_decision:{k}": v for k, v in DATES.items()}
    mapping.update({k: DATES[k] for k in ("russian_missile_attack", "defence_case_promulgated",
                                         "russian_follow_on", "direct_exchange")})
    return RealtimePollingTracker("de-ru-defence-case", "germany-2026-09-23",
                                  specs, "2026-09-27T04:18:00+02:00", mapping)


def apply_shock(orchestrator, polls, key: str, effects: dict[str, float],
                locks: tuple[str, ...], severity: float) -> None:
    update = orchestrator.state.apply(PoliticalAction(
        key, {"immediate": effects, "medium": {}, "long": {}},
        locks_add=locks, tags=("exogenous_armed_attack",)))
    for actor in {node.owner for node in orchestrator.nodes.values()}:
        orchestrator.personas.apply_event(actor, event(f"{key}:{actor}", severity,
                                                       ("war", "casualties", "loss_of_control")))
    polls.record(orchestrator.state, event_id=key, actor="EXOGENOUS",
                 action=key, event_kind="armed_conflict_event", resource_changes=update)


def establish_defence_case(orchestrator, polls) -> dict:
    consensus = orchestrator.state.variables["defence_consensus"].value
    yes = min(560, max(316, int(round(330 + 2.15 * consensus))))
    no = max(0, 610 - yes)
    procedure = ProcedureState(
        "gg115a_2026_10_01", "GG115A_DEFENCE_CASE", "VOTE_COMPLETED", 990,
        votes_yes=yes, votes_no=no, metadata={
            "vote_completed": True, "federal_government_application": True,
            "bundesrat_consent": True,
        })
    book = ProcedureBook({procedure.procedure_id: procedure})
    engine = build_gg_check_engine()
    determination = engine.check(
        check_context(orchestrator.state, book),
        Intent("determine_115a", "Bundestag", "determine_state_of_defence",
               payload={"procedure_id": procedure.procedure_id}))
    if determination.resolution.value != "executable":
        raise RuntimeError("Required defence-case terminal condition was not legally reached")
    book.update(procedure.procedure_id, metadata={**procedure.metadata,
                                                 "determination_passed": True})
    promulgation = engine.check(
        check_context(orchestrator.state, book),
        Intent("promulgate_115a", "Steinmeier", "promulgate_state_of_defence",
               payload={"procedure_id": procedure.procedure_id}))
    if promulgation.resolution.value != "executable":
        raise RuntimeError("Defence case was determined but not promulgated")
    update = orchestrator.state.apply(PoliticalAction(
        "defence_case_promulgated", {"immediate": {
            "gov_trust": .45, "defence_consensus": 2, "readiness": 6,
        }, "medium": {}, "long": {}}, locks_add=("defence_case_promulgated",),
        locks_remove=("hybrid_confrontation",), tags=("constitutional_transition",)))
    polls.record(orchestrator.state, event_id="defence_case_promulgated", actor="INSTITUTION",
                 action="promulgate_art115a", event_kind="constitutional_transition",
                 resource_changes=update)
    command = engine.check(check_context(orchestrator.state),
                           Intent("check_115b", "Merz", "assume_defence_command"))
    return {
        "bundestag_yes": yes, "bundestag_no": no,
        "determination": determination.payload(), "promulgation": promulgation.payload(),
        "command_transfer_check": command.payload(),
        "status": "VERTEIDIGUNGSFALL_PROMULGATED",
    }


def post_defence_ensemble(payload: dict, runs: int = 5000, seed: int = 15102026) -> dict:
    rng = random.Random(seed)
    v = payload["world_state"]["variables"]
    escalation = v["escalation_pressure"]["value"] / 100
    offramp = v["offramp_space"]["value"] / 100
    nato = v["nato_cohesion"]["value"] / 100
    readiness = v["readiness"]["value"] / 100
    counts = {"NEGOTIATED_PAUSE_UNDER_DEFENCE_CASE": 0, "CONTAINED_CONVENTIONAL_WAR": 0,
              "EXPANDED_NATO_RUSSIA_CONVENTIONAL_WAR": 0, "ESCALATION_CONTROL_FAILURE": 0}
    for _ in range(runs):
        strike_persistence = min(1, max(0, rng.gauss(.58, .18)))
        miscalculation = min(1, max(0, rng.gauss(escalation, .16)))
        channel = min(1, max(0, rng.gauss(offramp, .15)))
        allied_control = min(1, max(0, rng.gauss((nato + readiness) / 2, .12)))
        if miscalculation > .78 and strike_persistence > .62:
            outcome = "ESCALATION_CONTROL_FAILURE"
        elif strike_persistence > .66 and allied_control > .56:
            outcome = "EXPANDED_NATO_RUSSIA_CONVENTIONAL_WAR"
        elif channel > .68 and strike_persistence < .55:
            outcome = "NEGOTIATED_PAUSE_UNDER_DEFENCE_CASE"
        else:
            outcome = "CONTAINED_CONVENTIONAL_WAR"
        counts[outcome] += 1
    return {"runs": runs, "seed": seed, "path_frequencies": counts,
            "condition": "All runs start after a promulgated German defence case and direct armed conflict.",
            "warning": "Model-path frequencies under unobserved contingencies; not real-world war probabilities."}


def legal_diagnostics() -> list[dict]:
    engine = build_gg_check_engine()
    pre = initial_state()
    after_missile = pre.clone()
    after_missile.locks.add("missile_attack_confirmed")
    after_defence = after_missile.clone()
    after_defence.locks.add("defence_case_promulgated")
    probes = (
        ("危机但尚未公布防御状态", pre,
         Intent("probe1", "Merz", "assume_defence_command")),
        ("危机但尚无Spannungsfall/Verteidigungsfall", pre,
         Intent("probe2", "Bundesregierung", "deploy_armed_forces_to_protect_civilian_objects")),
        ("导弹命中德国、尚未启动议会程序", after_missile,
         Intent("probe3", "Bundestag", "determine_state_of_defence")),
        ("防御状态已经正式公布", after_defence,
         Intent("probe4", "Merz", "assume_defence_command")),
        ("防御状态已经正式公布", after_defence,
         Intent("probe5", "Bundesregierung", "deploy_armed_forces_to_protect_civilian_objects")),
    )
    return [{"stage": stage, "intent": intent.intent_type,
             "result": engine.check(check_context(world), intent).payload()}
            for stage, world, intent in probes]


def render(payload: dict) -> str:
    rows = []
    for turn in payload["trace"]:
        for index, (key, score) in enumerate(sorted(
                turn["action_evaluations"].items(), key=lambda x: -x[1]["choice_score"])):
            rows.append("<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td>"
                        "<td>{:.3f}</td><td>{:.3f}</td><td>{:.3f}</td></tr>".format(
                escape(turn["calendar_date"][:16]) if index == 0 else "",
                escape(turn["decision_maker"]) if index == 0 else "",
                escape(turn["scenario_prompt"]) if index == 0 else "",
                "✓" if key == turn["chosen_action"] else "", escape(LABELS[key]),
                score["instrumental"], score["substantive"], score["choice_score"]))
    report = payload["scenario_report"]
    law = payload["constitutional_transition"]
    paths = "".join(f"<tr><td>{escape(k)}</td><td>{v}</td></tr>"
                    for k, v in payload["post_defence_ensemble"]["path_frequencies"].items())
    legal_rows = []
    for row in payload["legal_diagnostics"]:
        bundle = row["result"]
        reasons = [result.get("reason") for layer in bundle["layers"]
                   for result in layer["results"] if result.get("reason")]
        legal_rows.append(f"<tr><td>{escape(row['stage'])}</td><td>{escape(row['intent'])}</td>"
                          f"<td>{escape(bundle['resolution'])}</td>"
                          f"<td>{escape(', '.join(reasons))}</td></tr>")
    return f"""<!doctype html><html lang='zh-CN'><head><meta charset='utf-8'><title>德俄武装冲突与Verteidigungsfall</title><style>body{{font:15px/1.55 system-ui,sans-serif;max-width:1240px;margin:30px auto;padding:0 18px;color:#182033}}table{{border-collapse:collapse;width:100%;margin:12px 0 28px}}th,td{{border:1px solid #d9dee8;padding:7px;vertical-align:top}}th{{background:#eef2f7}}.note{{background:#f3f6fb;padding:14px;border-left:4px solid #5271b8}}svg{{max-width:100%;height:auto;border:1px solid #e2e6ed}}</style></head><body>
<h1>德俄：从混合对抗到防御状态，再到持续作战</h1>
<p class='note'>用户指定的条件性战争路径，不是“德国一定会开战”的现实预测。导弹命中德国领土是Art.115a门槛事件；防御状态是中段制度切换，模拟继续运行至10月15日。</p>
<h2>宪法切换</h2><p>Bundestag模型票数：{law['bundestag_yes']}赞成 / {law['bundestag_no']}反对；状态：{law['status']}。公布后Art.115b指挥权检查：{law['command_transfer_check']['resolution']}。</p>
<table><tr><th>阶段</th><th>Intent</th><th>结果</th><th>原因</th></tr>{''.join(legal_rows)}</table>
<h2>逐节点全部评估</h2><table><tr><th>时间</th><th>人物</th><th>问题</th><th>选中</th><th>行动</th><th>工具性</th><th>实质性</th><th>总分</th></tr>{''.join(rows)}</table>
<h2>全部使用人物的实时压力</h2>{report['charts']['pss_pressure_svg']}
<h2>每个节点后的民调/危机信任</h2>{report['charts']['polling_svg']}
{render_arcana_embed(report)}
<h2>防御状态后的路线敏感性</h2><table>{paths}</table>
</body></html>"""


def run() -> dict:
    world = initial_state()
    cards = FreeAgentDecisionEngine.from_json(ROOT / "kfrage_model/personality_cards_2026/cards_pss.json")
    graph = build_nodes()
    actors = {node.owner for node in graph.values()}
    info = {actor: {key: AccessRule(.76, noise=2.4, source="crisis_briefing")
                    for key in world.variables} for actor in actors}
    polls = polling()
    orchestrator = LayeredSimulationOrchestrator(
        world, graph, cards, InformationFilter(info, seed=20260927, stochastic=False),
        {}, configuration(), event_observers=(polls,),
        objective_check_engine=build_gg_check_engine(),
        check_context_provider=lambda state: check_context(state),
    )

    orchestrator.run("first_address", max_steps=6)
    apply_shock(orchestrator, polls, "russian_missile_attack", {
        "union_de": .55, "afd_de": -.25, "gov_trust": 4.5,
        "defence_consensus": 34, "readiness": -7, "civil_resilience": -4,
        "escalation_pressure": 18, "offramp_space": -9,
        "military_casualties": 12, "infrastructure_damage": 18,
        "attribution_confidence": 22, "nato_cohesion": 10,
    }, ("missile_attack_confirmed", "direct_armed_attack"), .94)

    orchestrator.run("defence_application", max_steps=2)
    constitutional = establish_defence_case(orchestrator, polls)

    orchestrator.run("wartime_direction", max_steps=4)
    apply_shock(orchestrator, polls, "russian_follow_on", {
        "gov_trust": -1.2, "readiness": -4, "civil_resilience": -3,
        "escalation_pressure": 10, "offramp_space": -5,
        "military_casualties": 6, "infrastructure_damage": 9,
    }, ("follow_on_strikes",), .78)
    apply_shock(orchestrator, polls, "direct_exchange", {
        "gov_trust": .8, "defence_consensus": 5, "nato_cohesion": 5,
        "readiness": -2, "escalation_pressure": 9, "offramp_space": -3,
        "military_casualties": 5,
    }, ("nato_russia_direct_exchange",), .86)
    orchestrator.run("parliamentary_control", max_steps=7)

    for turn in orchestrator.trace:
        turn["calendar_date"] = DATES[turn["node"]]
        turn["scenario_prompt"] = PROMPTS[turn["node"]]
        turn["action_labels"] = {key: LABELS[key] for key in turn["action_evaluations"]}
    payload = {
        "world_state": orchestrator.state.payload(),
        "trace": orchestrator.trace,
        "persona_runtime": cards.payload(),
    }
    payload["scenario_report"] = ScenarioReportCompiler(
        orchestrator._initial_pss, orchestrator.reporting_policy).compile(
            payload["trace"], orchestrator.event_observers)
    payload["constitutional_transition"] = constitutional
    payload["legal_diagnostics"] = legal_diagnostics()
    payload["post_defence_ensemble"] = post_defence_ensemble(payload)
    payload["scenario_metadata"] = {
        "as_of": "2026-09-23", "time_window": "2026-09-27/2026-10-15",
        "status": "EXPLICIT_COUNTERFACTUAL_WAR_PATH",
        "required_intermediate_state": "VERTEIDIGUNGSFALL_PROMULGATED",
        "observed_anchor": "Leipzig/Halle attempted explosive-drone attack and German attribution to Russia",
        "counterfactuals": ["successful 27 September drone attack with military deaths",
                            "1 October Russian missile strike on German federal territory",
                            "follow-on strikes and direct NATO-Russia personnel exchange"],
        "warning": "Path distribution is diagnostic, not a real-world probability forecast.",
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "baseline.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "report.html").write_text(render(payload), encoding="utf-8")
    (OUT / "pss_pressure.svg").write_text(payload["scenario_report"]["charts"]["pss_pressure_svg"], encoding="utf-8")
    (OUT / "polling.svg").write_text(payload["scenario_report"]["charts"]["polling_svg"], encoding="utf-8")
    return payload


if __name__ == "__main__":
    p = run()
    print(json.dumps({
        "valid": p["scenario_report"]["valid"], "nodes": len(p["trace"]),
        "used_personas": p["scenario_report"]["used_persona_cards"],
        "constitutional_status": p["constitutional_transition"]["status"],
        "bundestag_vote": [p["constitutional_transition"]["bundestag_yes"],
                            p["constitutional_transition"]["bundestag_no"]],
        "chosen_actions": [t["chosen_action"] for t in p["trace"]],
        "final_state": {k: round(v["value"], 3) for k, v in p["world_state"]["variables"].items()},
        "post_defence_paths": p["post_defence_ensemble"]["path_frequencies"],
        "output": str(OUT),
    }, ensure_ascii=False, indent=2))
