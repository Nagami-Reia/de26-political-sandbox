#!/usr/bin/env python3
"""Conditional aftermath of the 2026 CDU-MV leadership collapse."""
from __future__ import annotations

import json
import random
from dataclasses import asdict, replace
from html import escape
from pathlib import Path

from kfrage_model.free_agent_game import WorldAction
from kfrage_model.information_filter import AccessRule, InformationFilter
from kfrage_model.institutional_matrix import InstitutionalMatrix
from kfrage_model.persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine
from kfrage_model.political_state import PoliticalAction, PoliticalState, StateVariable
from kfrage_model.political_state_system import PoliticalEvent
from kfrage_model.rationality_evaluation import ActorRationalityProfile
from kfrage_model.realtime_polling import PollSeriesSpec, RealtimePollingTracker
from kfrage_model.scenario_reporting import ScenarioReportCompiler, render_arcana_embed
from kfrage_model.simulation_orchestrator import (
    LayeredConfiguration, LayeredSimulationOrchestrator, SimulationNodeV3, V3FeatureFlags,
)
from kfrage_model.temporary_offices import TemporaryOfficeAssignment, TemporaryOfficeRegistry


ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = HERE / "output"

DATES = {
    "handover": "2026-09-22T18:00:00+02:00",
    "federal_support": "2026-09-24T16:00:00+02:00",
    "dual_role": "2026-09-28T12:00:00+02:00",
    "lost_faction": "2026-10-05T18:00:00+02:00",
    "east_cdu_network": "2026-10-19T17:00:00+02:00",
    "extra_parliamentary_opposition": "2026-11-02T18:00:00+01:00",
    "succession_process": "2026-11-15T16:00:00+01:00",
}
PROMPTS = {
    "handover": "三人辞职、CDU跌出州议会后，代理主席第一步做什么？",
    "federal_support": "联邦党组织如何支援而不把州党变成柏林分部？",
    "dual_role": "Merz如何处理Amthor的总理府—州党双重职责？",
    "lost_faction": "没有Landtag党团后，CDU-MV用什么替代政策与监督能力？",
    "east_cdu_network": "东部CDU伙伴如何介入MV重建？",
    "extra_parliamentary_opposition": "新州政府形成后，议会外反对党采取什么路线？",
    "succession_process": "代理期如何通向正式继任程序？",
}
LABELS: dict[str, str] = {}


def option(key: str, label: str, next_node: str | None, *, owner: str,
           effects: dict[str, float], values: dict[str, float], goals: dict[str, float],
           instrumental: dict[str, float], substantive: dict[str, float],
           identity: tuple[str, ...], strategy: str, upside: float, downside: float,
           uncertainty: float, effort: float, visibility: float, feasibility: float,
           success: float, risk_tags: tuple[str, ...] = (),
           affected: dict[str, tuple[PoliticalEvent, ...]] | None = None) -> WorldAction:
    LABELS[key] = label
    return WorldAction(
        PoliticalAction(key, {"immediate": effects, "medium": {}, "long": {}},
                        feasibility=feasibility, next_node=next_node,
                        tags=("mv_cdu_aftermath",)),
        ActionOption(
            key=key, goal_impacts=goals, value_impacts=values, upside=upside,
            downside=downside, uncertainty=uncertainty,
            irreversibility=.18 + .42 * visibility, effort=effort, visibility=visibility,
            information_confidence=.76, control_domains=("party_organization", "message"),
            restores_control=.58, conflict_strategy=strategy, identity_tags=identity,
            event_tags=("organization_collapse", "regional_irrelevance"),
            risk_tags=risk_tags, objective_feasibility=feasibility,
            instrumental_impacts=instrumental, substantive_impacts=substantive,
            necessity_frame_alignment=.58,
        ),
        affected or {},
        {owner: ActionOutcome(
            action=key, success=success, surprise=.20, tags=identity,
            workload=.04 + effort * .05, control_restoration=.05 * success,
            identity_alignment=.04 * (success - .5),
        )},
    )


def nodes() -> dict[str, SimulationNodeV3]:
    n: dict[str, SimulationNodeV3] = {}
    n["handover"] = SimulationNodeV3("handover", "Amthor", (
        option("amthor_audit_tour", "公开承担代理责任，同时启动组织审计、基层巡回和继任标准", "federal_support",
               owner="Amthor", effects={"cdu_mv": .34, "afd_mv": -.06, "amthor_mv": .42,
               "union_de": .03, "organization_capacity": 5, "narrative_control": 3},
               values={"organizational_reconstruction": .96, "democratic_differentiation": .78,
                       "implementation_credibility": .88, "regional_representation": .90},
               goals={"credible_handover": .94}, instrumental={"triage": .86, "local_access": .82},
               substantive={"party_autonomy": .88, "democratic_self_efficacy": .80},
               identity=("party_rebuilding", "implementation", "regional_representation"),
               strategy="institutionalize", upside=.78, downside=.34, uncertainty=.52,
               effort=.88, visibility=.74, feasibility=.76, success=.64,
               risk_tags=("organization_collapse",)),
        option("amthor_media_counterattack", "以全国媒体攻势把崩盘主要解释为AfD动员和前任失误", "federal_support",
               owner="Amthor", effects={"cdu_mv": -.10, "afd_mv": .10, "amthor_mv": .18,
               "union_de": .02, "organization_capacity": -2, "narrative_control": 5},
               values={"organizational_reconstruction": .30, "democratic_differentiation": .72,
                       "implementation_credibility": .22, "regional_representation": .25},
               goals={"credible_handover": .38}, instrumental={"triage": .28, "media_reach": .88},
               substantive={"party_autonomy": .20, "democratic_self_efficacy": .32},
               identity=("public_debate", "attack"), strategy="attack", upside=.65,
               downside=.76, uncertainty=.62, effort=.70, visibility=.98, feasibility=.86,
               success=.38, risk_tags=("personal_credibility",)),
        option("amthor_claim_permanent", "立即宣布竞选正式州主席，把重建与个人领导绑定", "federal_support",
               owner="Amthor", effects={"cdu_mv": -.16, "afd_mv": .08, "amthor_mv": .12,
               "union_de": -.03, "organization_capacity": -3, "narrative_control": 4},
               values={"organizational_reconstruction": .28, "democratic_differentiation": .50,
                       "implementation_credibility": .18, "regional_representation": .46},
               goals={"credible_handover": .24}, instrumental={"triage": .20, "delegate_control": .44},
               substantive={"party_autonomy": .34, "democratic_self_efficacy": .22},
               identity=("leadership_claim",), strategy="attack", upside=.68, downside=.82,
               uncertainty=.70, effort=.80, visibility=1.0, feasibility=.64, success=.31,
               risk_tags=("personal_credibility", "organization_collapse")),
    ), {"credible_handover": .98}, ("organization_collapse", "acting_leadership"))

    n["federal_support"] = SimulationNodeV3("federal_support", "Hoppermann", (
        option("hoppermann_quiet_scaffold", "提供会员数据、培训、筹款和组织人员，州内决策权留在MV", "dual_role",
               owner="Hoppermann", effects={"cdu_mv": .18, "afd_mv": -.03, "amthor_mv": .08,
               "organization_capacity": 7, "local_autonomy": 5},
               values={"organizational_trust": .94, "state_capability": .86,
                       "fiscal_accountability": .70, "party_inclusion": .90},
               goals={"support_without_takeover": .94}, instrumental={"organization": .90,
               "staff_continuity": .82}, substantive={"local_autonomy": .91, "member_voice": .86},
               identity=("organizational_trust", "party_base", "administration"),
               strategy="institutionalize", upside=.74, downside=.26, uncertainty=.40,
               effort=.76, visibility=.32, feasibility=.86, success=.73),
        option("hoppermann_federal_taskforce", "由联邦总部接管传播、候选储备和政策供给", "dual_role",
               owner="Hoppermann", effects={"cdu_mv": -.08, "afd_mv": .05, "amthor_mv": .10,
               "organization_capacity": 4, "local_autonomy": -7},
               values={"organizational_trust": .42, "state_capability": .74,
                       "fiscal_accountability": .55, "party_inclusion": .18},
               goals={"support_without_takeover": .36}, instrumental={"organization": .68,
               "staff_continuity": .70}, substantive={"local_autonomy": -.72, "member_voice": -.48},
               identity=("administration", "centralization"), strategy="institutionalize",
               upside=.66, downside=.70, uncertainty=.55, effort=.82, visibility=.70,
               feasibility=.78, success=.44, risk_tags=("federalization",)),
        option("hoppermann_distance", "把危机定义为州党责任，联邦总部只作最低限度协助", "dual_role",
               owner="Hoppermann", effects={"cdu_mv": -.22, "afd_mv": .10, "amthor_mv": -.12,
               "organization_capacity": -4, "local_autonomy": 1},
               values={"organizational_trust": -.50, "state_capability": -.36,
                       "fiscal_accountability": .42, "party_inclusion": -.44},
               goals={"support_without_takeover": -.52}, instrumental={"organization": -.45,
               "staff_continuity": -.52}, substantive={"local_autonomy": .44, "member_voice": -.40},
               identity=("distance",), strategy="avoid", upside=.20, downside=.66,
               uncertainty=.32, effort=.18, visibility=.28, feasibility=.94, success=.28),
    ), {"support_without_takeover": .96}, ("party_base", "federal_state_boundary"))

    n["dual_role"] = SimulationNodeV3("dual_role", "Merz", (
        option("merz_protected_dual_mandate", "保留Amthor总理府职务但设工作量护栏、周报与利益边界", "lost_faction",
               owner="Merz", effects={"cdu_mv": .12, "amthor_mv": .12, "union_de": .04,
               "organization_capacity": 3, "chancellery_capacity": -1},
               values={"strategic_direction": .84, "reform_achievement": .66,
                       "political_authority": .78, "unity": .82},
               goals={"preserve_both_machines": .90}, instrumental={"role_clarity": .88,
               "chancellery_delivery": .76}, substantive={"regional_autonomy": .78,
               "loyalty_reciprocity": .84}, identity=("strategic_direction", "authority", "unity"),
               strategy="institutionalize", upside=.72, downside=.32, uncertainty=.42,
               effort=.54, visibility=.38, feasibility=.90, success=.72),
        option("merz_full_federal_deployment", "把总理府平台全面用于MV救援，要求Amthor兼任联邦代言人", "lost_faction",
               owner="Merz", effects={"cdu_mv": -.05, "amthor_mv": .16, "union_de": .03,
               "organization_capacity": 1, "chancellery_capacity": -5},
               values={"strategic_direction": .80, "reform_achievement": .38,
                       "political_authority": .86, "unity": .48},
               goals={"preserve_both_machines": .44}, instrumental={"role_clarity": .30,
               "chancellery_delivery": .36}, substantive={"regional_autonomy": -.42,
               "loyalty_reciprocity": .48}, identity=("authority", "agency"), strategy="attack",
               upside=.70, downside=.72, uncertainty=.58, effort=.84, visibility=.82,
               feasibility=.72, success=.40, risk_tags=("role_overload",)),
        option("merz_force_choice", "要求Amthor在总理府和州党代理职务之间二选一", "lost_faction",
               owner="Merz", effects={"cdu_mv": -.14, "amthor_mv": -.20, "union_de": -.03,
               "organization_capacity": -2, "chancellery_capacity": 3},
               values={"strategic_direction": .68, "reform_achievement": .72,
                       "political_authority": .76, "unity": -.55},
               goals={"preserve_both_machines": .20}, instrumental={"role_clarity": .92,
               "chancellery_delivery": .84}, substantive={"regional_autonomy": .12,
               "loyalty_reciprocity": -.68}, identity=("authority", "loyalty_break"),
               strategy="attack", upside=.52, downside=.76, uncertainty=.45, effort=.35,
               visibility=.70, feasibility=.86, success=.36, risk_tags=("loyalty_break",)),
    ), {"preserve_both_machines": .92}, ("role_overload", "loyalty"))

    def amthor_node(key: str, next_key: str | None, goal: str,
                    rows: tuple[tuple[str, str, float, float], ...]) -> SimulationNodeV3:
        actions = []
        for index, (action_key, label, mv_delta, success) in enumerate(rows):
            good = index == 0
            actions.append(option(
                action_key, label, next_key, owner="Amthor",
                effects={"cdu_mv": mv_delta, "afd_mv": -.20 * mv_delta,
                         "amthor_mv": .55 * mv_delta, "union_de": .04 * mv_delta,
                         "organization_capacity": 5 if good else -2,
                         "narrative_control": 3 if good else 1},
                values={"organizational_reconstruction": .90 if good else .30,
                        "democratic_differentiation": .84 if good else .46,
                        "implementation_credibility": .86 if good else .28,
                        "regional_representation": .88 if good else .40},
                goals={goal: .91 if good else .32},
                instrumental={goal: .84 if good else .34, "local_capacity": .82 if good else .28},
                substantive={"party_autonomy": .84 if good else .24,
                             "democratic_self_efficacy": .82 if good else .30},
                identity=("party_rebuilding", "regional_representation", "implementation")
                         if good else ("public_debate",),
                strategy="institutionalize" if good else ("attack" if index == 1 else "avoid"),
                upside=.75 if good else .52, downside=.34 if good else .67,
                uncertainty=.48 if good else .60, effort=.78 if good else .54,
                visibility=.66 if good else .86, feasibility=.78 if good else .72,
                success=success, risk_tags=("organization_collapse",)),
            )
        return SimulationNodeV3(key, "Amthor", tuple(actions), {goal: .95},
                                ("organization_collapse", "regional_irrelevance"))

    n["lost_faction"] = amthor_node("lost_faction", "east_cdu_network", "replace_faction_capacity", (
        ("amthor_municipal_shadow_network", "用市县干部、前党团专家和联邦议员建立公开影子政策网络", .30, .66),
        ("amthor_media_opposition", "以个人媒体曝光替代政策和监督基础设施", -.10, .39),
        ("amthor_wait_for_return", "缩小州党政策工作，等待下次选举再恢复能力", -.24, .26),
    ))

    n["east_cdu_network"] = SimulationNodeV3("east_cdu_network", "Kretschmer", (
        option("kretschmer_regional_mentoring", "建立东部州党同伴评审和基层竞选辅导，但不接管MV路线", "extra_parliamentary_opposition",
               owner="Kretschmer", effects={"cdu_mv": .16, "afd_mv": -.04, "amthor_mv": .04,
               "organization_capacity": 4, "local_autonomy": 3},
               values={"state_governability": .86, "territorial_representation": .94,
                       "electoral_containment": .90, "economic_base": .60},
               goals={"eastern_recovery": .92}, instrumental={"transfer_learning": .84,
               "electoral_containment": .78}, substantive={"territorial_voice": .90,
               "local_autonomy": .82}, identity=("territorial_representation", "brokerage"),
               strategy="negotiate", upside=.70, downside=.28, uncertainty=.44,
               effort=.62, visibility=.42, feasibility=.84, success=.68),
        option("kretschmer_public_warning", "把MV失败用于公开警告联邦党路线，但不投入组织资源", "extra_parliamentary_opposition",
               owner="Kretschmer", effects={"cdu_mv": -.05, "afd_mv": .05, "amthor_mv": -.05,
               "union_de": -.04, "organization_capacity": 0, "local_autonomy": 2},
               values={"state_governability": .42, "territorial_representation": .72,
                       "electoral_containment": .30, "economic_base": .46},
               goals={"eastern_recovery": .34}, instrumental={"transfer_learning": .18,
               "electoral_containment": .25}, substantive={"territorial_voice": .76,
               "local_autonomy": .48}, identity=("territorial_representation", "public_pressure"),
               strategy="attack", upside=.55, downside=.62, uncertainty=.52,
               effort=.42, visibility=.84, feasibility=.90, success=.38),
        option("kretschmer_distance", "保持距离，避免把萨克森资源卷入MV危机", "extra_parliamentary_opposition",
               owner="Kretschmer", effects={"cdu_mv": -.08, "afd_mv": .05, "amthor_mv": -.04,
               "organization_capacity": -1, "local_autonomy": 1},
               values={"state_governability": .55, "territorial_representation": -.30,
                       "electoral_containment": -.36, "economic_base": .40},
               goals={"eastern_recovery": -.30}, instrumental={"transfer_learning": -.44,
               "electoral_containment": -.30}, substantive={"territorial_voice": -.48,
               "local_autonomy": .48}, identity=("state_first",), strategy="avoid",
               upside=.24, downside=.46, uncertainty=.30, effort=.12, visibility=.16,
               feasibility=.96, success=.30),
    ), {"eastern_recovery": .90}, ("territorial_representation", "electoral_containment"))

    n["extra_parliamentary_opposition"] = amthor_node(
        "extra_parliamentary_opposition", "succession_process", "credible_opposition", (
            ("amthor_issue_observatory", "建立州政府承诺追踪、地方提案和月度执行审计，形成议会外可验证反对党", .26, .65),
            ("amthor_culture_war", "以高频文化冲突和全国节目维持可见度", -.12, .40),
            ("amthor_low_profile", "保持低调，只做内部组织修复", -.06, .46),
        ))
    n["succession_process"] = amthor_node("succession_process", None, "legitimate_succession", (
        ("amthor_open_successor_search", "公布资格、提名和基层听证规则；代理期不预先绑定某个候选人", .24, .69),
        ("amthor_enter_race_now", "在组织恢复初期宣布本人竞选正式州主席", -.09, .43),
        ("amthor_install_federal_ally", "由联邦网络快速整合代表，推动单一继任人选", -.16, .36),
    ))
    return n


def state() -> PoliticalState:
    values = {
        "cdu_mv": 4.9, "afd_mv": 38.2, "spd_mv": 35.5, "amthor_mv": 16.0,
        "union_de": 20.0, "afd_de": 29.0, "organization_capacity": 24.0,
        "local_autonomy": 48.0, "narrative_control": 32.0, "chancellery_capacity": 72.0,
    }
    return PoliticalState(
        {key: StateVariable(key, value, uncertainty=.10 if key.endswith(("_mv", "_de")) else .14)
         for key, value in values.items()},
        capital={"cdu_mv": 18, "amthor": 62, "cdu_federal": 69},
        pressures={"organization_collapse": 94, "regional_irrelevance": 90,
                   "dual_role_overload": 72},
        locks={"no_landtag_faction", "acting_chair_only"},
    )


def registry() -> TemporaryOfficeRegistry:
    return TemporaryOfficeRegistry((TemporaryOfficeAssignment(
        assignment_id="cdu_mv_2026_interim_chair", actor="Amthor",
        office="acting_cdu_mv_chair", begins_at="2026-09-22",
        ends_when="SUCCESSOR_FORMALLY_ELECTED",
        authority_scope=("state_board_coordination", "state_party_representation",
                         "convene_successor_process"),
    ),))


def configuration(temp: TemporaryOfficeRegistry) -> LayeredConfiguration:
    base = LayeredConfiguration.from_environment_json(
        ROOT / "kfrage_model/environments/2026-07-31/environment.json",
        ROOT / "kfrage_model/personality_cards_2026/rationality_profiles_v3.json")
    expansion = json.loads((ROOT / "kfrage_model/personality_cards_2026/"
                            "rationality_profiles_expansion_2026_09.json").read_text())
    profiles = dict(base.rationality_profiles)
    profiles.update({key: ActorRationalityProfile(**row) for key, row in expansion["actors"].items()})
    offices = dict(base.matrix.actor_offices)
    offices["Amthor"] = ("chancellery_state_minister", "bundestag_member",
                         "cdu_federal_members_officer")
    offices = temp.apply_to_offices(offices)
    matrix = InstitutionalMatrix(base.matrix.matrix_id + "_mv_aftermath", offices,
                                 base.matrix.office_permissions, base.matrix.rules)
    return LayeredConfiguration(
        matrix, replace(base.logic, alternative_legibility=.43, legitimacy=.38,
                        control_concentration=.51), base.agency, profiles,
        V3FeatureFlags(True, True, True, False))


def polling() -> RealtimePollingTracker:
    specs = tuple(PollSeriesSpec(*row, retention=.58, publication_grid=.5) for row in (
        ("cdu_mv", "CDU", "state_electorate", "vote_intention", "Mecklenburg-Vorpommern"),
        ("afd_mv", "AfD", "state_electorate", "vote_intention", "Mecklenburg-Vorpommern"),
        ("spd_mv", "SPD", "state_electorate", "vote_intention", "Mecklenburg-Vorpommern"),
        ("amthor_mv", "Amthor", "state_electorate", "personal_support", "Mecklenburg-Vorpommern"),
        ("union_de", "CDU/CSU", "federal_electorate", "vote_intention", "Germany"),
        ("afd_de", "AfD", "federal_electorate", "vote_intention", "Germany"),
    ))
    return RealtimePollingTracker("mv-amthor-aftermath", "mv-cdu-collapse-2026-09",
                                  specs, "2026-09-22T12:00:00+02:00",
                                  {f"layered_decision:{k}": v for k, v in DATES.items()})


def succession_outlook(payload: dict, runs: int = 3000, seed: int = 22092026) -> dict:
    """Unobserved delegate/candidate contingencies, not election probabilities."""
    rng = random.Random(seed)
    final = payload["world_state"]["variables"]
    org = final["organization_capacity"]["value"] / 100
    autonomy = final["local_autonomy"]["value"] / 100
    chosen = payload["trace"][-1]["chosen_action"]
    counts = {"regional_organizational_successor": 0, "amthor_confirmed": 0,
              "federal_bridge_candidate": 0, "process_delayed": 0}
    for _ in range(runs):
        delegate_localism = min(1, max(0, rng.gauss(autonomy, .14)))
        candidate_supply = min(1, max(0, rng.gauss(org, .16)))
        amthor_willingness = min(1, max(0, rng.gauss(.42, .20)))
        if chosen == "amthor_enter_race_now":
            amthor_willingness += .30
        if candidate_supply < .20:
            route = "process_delayed"
        elif amthor_willingness > .70 and delegate_localism < .62:
            route = "amthor_confirmed"
        elif delegate_localism > .58:
            route = "regional_organizational_successor"
        else:
            route = "federal_bridge_candidate"
        counts[route] += 1
    return {
        "runs": runs, "seed": seed, "route_frequencies": counts,
        "warning": "Frequencies describe model route stability under unknown delegate and candidate inputs; they are not real-world election probabilities.",
        "named_successor_predicted": False,
    }


def render(payload: dict) -> str:
    rows = []
    for turn in payload["trace"]:
        ordered = sorted(turn["action_evaluations"].items(),
                         key=lambda item: item[1]["choice_score"], reverse=True)
        for index, (key, score) in enumerate(ordered):
            rows.append("<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td>"
                        "<td>{:.3f}</td><td>{:.3f}</td><td>{:.3f}</td></tr>".format(
                escape(turn["calendar_date"][:10]) if index == 0 else "",
                escape(turn["decision_maker"]) if index == 0 else "",
                escape(turn["scenario_prompt"]) if index == 0 else "",
                "✓" if key == turn["chosen_action"] else "", escape(LABELS[key]),
                score["instrumental"], score["substantive"], score["choice_score"]))
    report = payload["scenario_report"]
    final = payload["world_state"]["variables"]
    state_rows = "".join(f"<tr><td>{escape(k)}</td><td>{v['value']:.2f}</td></tr>"
                         for k, v in final.items())
    routes = payload["succession_outlook"]["route_frequencies"]
    route_rows = "".join(f"<tr><td>{escape(k)}</td><td>{v}</td></tr>" for k, v in routes.items())
    office = payload["temporary_offices"]["assignments"][0]
    return f"""<!doctype html><html lang='zh-CN'><head><meta charset='utf-8'><title>CDU-MV / Amthor aftermath</title>
<style>body{{font:15px/1.55 system-ui,sans-serif;max-width:1180px;margin:32px auto;padding:0 20px;color:#182033}}table{{border-collapse:collapse;width:100%;margin:12px 0 28px}}th,td{{border:1px solid #d9dee8;padding:7px;vertical-align:top}}th{{background:#eef2f7}}.note{{background:#f3f6fb;padding:14px;border-left:4px solid #5271b8}}svg{{max-width:100%;height:auto;border:1px solid #e2e6ed}}</style></head><body>
<h1>CDU-MV 领导层崩塌后的 Amthor 代理期</h1>
<p class='note'>条件性模拟，不是现实选举概率。代理职务当前 active={office['active']}；终止条件：{escape(office['ends_when'])}。没有虚构或指定现实继任者。</p>
<h2>逐节点评估</h2><table><tr><th>日期</th><th>人物</th><th>问题</th><th>选中</th><th>行动</th><th>工具性</th><th>实质性</th><th>总分</th></tr>{''.join(rows)}</table>
<h2>11月15日世界状态</h2><table>{state_rows}</table>
<h2>人物实时压力</h2>{report['charts']['pss_pressure_svg']}
<h2>实时民调/模型即时估计</h2>{report['charts']['polling_svg']}
{render_arcana_embed(report)}
<h2>继任路线敏感性</h2><p>下表只测试未知代表排列与候选供给对路线的影响，不可解释为现实概率。</p><table>{route_rows}</table>
</body></html>"""


def run() -> dict:
    temp = registry()
    world = state()
    cards = FreeAgentDecisionEngine.from_json(ROOT / "kfrage_model/personality_cards_2026/cards_pss.json")
    graph = nodes()
    actors = {node.owner for node in graph.values()}
    info = {actor: {key: AccessRule(.78, noise=1.6, source="mixed_party_network")
                    for key in world.variables} for actor in actors}
    polls = polling()
    orchestrator = LayeredSimulationOrchestrator(
        world, graph, cards, InformationFilter(info, seed=20260922, stochastic=False),
        resource_bindings={}, configuration=configuration(temp), event_observers=(polls,))
    payload = orchestrator.run("handover", max_steps=len(graph) + 1)
    for turn in payload["trace"]:
        turn["calendar_date"] = DATES[turn["node"]]
        turn["scenario_prompt"] = PROMPTS[turn["node"]]
        turn["action_labels"] = {key: LABELS[key] for key in turn["action_evaluations"]}
    payload["scenario_report"] = ScenarioReportCompiler(
        orchestrator._initial_pss, orchestrator.reporting_policy).compile(
            payload["trace"], orchestrator.event_observers)
    payload["temporary_offices"] = temp.payload()
    payload["succession_outlook"] = succession_outlook(payload)
    payload["scenario_metadata"] = {
        "as_of": "2026-09-22", "time_window": "2026-09-22/2026-11-15",
        "observed_facts": [
            "Peters, Hoffmeister and von Allwoerden resigned from their respective CDU-MV leadership roles.",
            "Amthor is acting CDU-MV chair while retaining his Federal Chancellery state-minister role.",
            "CDU-MV won 4.9 percent and has no Landtag faction.",
        ],
        "model_assumptions": [
            "No permanent successor is assumed.",
            "Federal access cannot substitute one-for-one for local organization.",
            "Poll movements are small model reactions, not newly fielded surveys.",
        ],
        "unknown_black_boxes": [
            "delegate alignments", "candidate field", "Amthor's private intention",
            "state-party-congress date", "retention of former faction staff",
        ],
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "baseline.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "report.html").write_text(render(payload), encoding="utf-8")
    (OUT / "pss_pressure.svg").write_text(payload["scenario_report"]["charts"]["pss_pressure_svg"], encoding="utf-8")
    (OUT / "polling.svg").write_text(payload["scenario_report"]["charts"]["polling_svg"], encoding="utf-8")
    return payload


if __name__ == "__main__":
    result = run()
    print(json.dumps({
        "valid": result["scenario_report"]["valid"],
        "nodes": len(result["trace"]),
        "used_personas": result["scenario_report"]["used_persona_cards"],
        "chosen_actions": [row["chosen_action"] for row in result["trace"]],
        "temporary_office": result["temporary_offices"]["assignments"][0],
        "final_values": {k: v["value"] for k, v in result["world_state"]["variables"].items()},
        "output": str(OUT),
    }, ensure_ascii=False, indent=2))
