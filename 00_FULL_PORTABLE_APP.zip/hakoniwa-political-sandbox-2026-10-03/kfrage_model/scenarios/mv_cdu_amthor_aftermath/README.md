# CDU-MV / Amthor aftermath scenario

Focused conditional simulation from the 2026-09-22 leadership collapse through
2026-11-15. It does not name or predict a real successor. The acting office
remains active at the end of the baseline and a separate succession outlook
describes conditional routes toward the future state party congress.

Run:

```bash
python -m kfrage_model.scenarios.mv_cdu_amthor_aftermath.run_scenario
```

Outputs are written to `output/` and always include the full trace, a pressure
chart for every used persona and a live polling/nowcast chart.

