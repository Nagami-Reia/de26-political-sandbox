#!/usr/bin/env python3
"""Run the 1 October–15 November 2026 LSA/Berlin/MV scenario.

The three coalition outcomes are explicit counterfactual initial conditions.
Actor choices are produced by the current persona/PSS engine.  Poll changes are
small latent model responses; the pollster-like series applies retention and
rounding, so many political activities remain invisible in the published line.
"""
from __future__ import annotations

import json
import random
from dataclasses import asdict, replace
from html import escape
from pathlib import Path

from kfrage_model.free_agent_game import WorldAction
from kfrage_model.information_filter import AccessRule, InformationFilter
from kfrage_model.institutional_matrix import InstitutionalMatrix
from kfrage_model.parliamentary_vote import BlocVotePrior, ParliamentaryVoteModel, VoteRule
from kfrage_model.persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine
from kfrage_model.political_state import PoliticalAction, PoliticalState, StateVariable
from kfrage_model.political_state_system import PoliticalEvent
from kfrage_model.rationality_evaluation import ActorRationalityProfile
from kfrage_model.realtime_polling import PollSeriesSpec, RealtimePollingTracker
from kfrage_model.scenario_reporting import ScenarioReportCompiler, render_arcana_embed
from kfrage_model.simulation_orchestrator import (
    LayeredConfiguration,
    LayeredSimulationOrchestrator,
    SimulationNodeV3,
    V3FeatureFlags,
)
from kfrage_model.temporary_offices import TemporaryOfficeAssignment, TemporaryOfficeRegistry


ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = HERE / "output"

NODE_DATES = {
    "fuel_launch": "2026-10-01T10:00:00+02:00",
    "federal_election_response": "2026-10-02T12:00:00+02:00",
    "amthor_mv_rebuild": "2026-10-03T15:00:00+02:00",
    "lsa_opposition": "2026-10-15T12:00:00+02:00",
    "first_week_control": "2026-10-05T09:00:00+02:00",
    "ko_hearing": "2026-10-05T16:30:00+02:00",
    "intelligence_design": "2026-10-06T18:00:00+02:00",
    "forced_measures": "2026-10-07T18:00:00+02:00",
    "early_pension_committee": "2026-10-09T13:00:00+02:00",
    "budget_hearing": "2026-10-12T18:00:00+02:00",
    "berlin_coalition": "2026-10-13T19:00:00+02:00",
    "vwgo_hearing": "2026-10-14T18:00:00+02:00",
    "sitting_close": "2026-10-16T17:00:00+02:00",
    "fuel_pass_through": "2026-10-23T12:00:00+02:00",
    "quiet_period_strategy": "2026-10-29T18:00:00+01:00",
    "november_security": "2026-11-04T17:00:00+01:00",
    "floor_scheduling": "2026-11-10T12:00:00+01:00",
    "midnovember_direction": "2026-11-13T16:00:00+01:00",
}

NODE_PROMPTS = {
    "fuel_launch": "燃油税削减在10月1日启动：如何管理传导与叙事？",
    "federal_election_response": "三州选举冲击后，联邦政府如何定调？",
    "amthor_mv_rebuild": "临时州主席Amthor如何在没有州议会党团的情况下重建MV CDU？",
    "first_week_control": "只有两段连续会期，党团如何配置稀缺议程容量？",
    "ko_hearing": "K.O.-Tropfen 刑法听证后如何处理两个文本？",
    "intelligence_design": "情报法改革的权限、技术与监督边界如何组合？",
    "forced_measures": "强制医疗措施如何兼顾 ultima ratio 与执行性？",
    "early_pension_committee": "Frühstartrente 在委员会阶段采用何种扩围路径？",
    "budget_hearing": "2027预算伴随法听证后如何形成联盟交易？",
    "berlin_coalition": "Evers 如何把黑红绿写成可运行的柏林政府？",
    "vwgo_hearing": "州执行者如何回应 VwGO 加速改革？",
    "lsa_opposition": "LSA AfD–BSW/Siegmund 与MV SPD政府成立后，Schulze如何组织反对党？",
    "sitting_close": "连续会期结束后，CSU如何重新定位？",
    "fuel_pass_through": "降税三周后出现地区传导差异，Reiche如何回应？",
    "quiet_period_strategy": "十月下半月无常规全会，Merz如何使用空窗？",
    "november_security": "境外主动情报措施需要哪些外交与法律护栏？",
    "floor_scheduling": "11月上半月哪些项目真正进入表决排程？",
    "midnovember_direction": "到11月中旬，Merz选择哪条联邦路线？",
}

ACTION_LABELS: dict[str, str] = {}


def event(event_id: str, event_type: str, severity: float, tags: tuple[str, ...], *,
          valence: float = -1.0, workload: float = .025) -> PoliticalEvent:
    return PoliticalEvent(event_id, event_type, severity, tags, valence=valence,
                          surprise=.35, workload=workload)


def option(
    key: str,
    label: str,
    next_node: str | None,
    *,
    effects: dict[str, float],
    values: dict[str, float],
    goals: dict[str, float],
    instrumental: dict[str, float],
    substantive: dict[str, float],
    identity: tuple[str, ...],
    control: tuple[str, ...],
    strategy: str,
    upside: float,
    downside: float,
    uncertainty: float,
    effort: float,
    visibility: float,
    feasibility: float,
    owner: str,
    success: float,
    risk_tags: tuple[str, ...] = (),
    affected: dict[str, tuple[PoliticalEvent, ...]] | None = None,
) -> WorldAction:
    ACTION_LABELS[key] = label
    return WorldAction(
        world=PoliticalAction(
            key=key,
            effects={"immediate": effects, "medium": {}, "long": {}},
            feasibility=feasibility,
            next_node=next_node,
            tags=("scenario_2026_october",),
        ),
        choice=ActionOption(
            key=key,
            goal_impacts=goals,
            value_impacts=values,
            upside=upside,
            downside=downside,
            uncertainty=uncertainty,
            irreversibility=.25 + .45 * visibility,
            effort=effort,
            visibility=visibility,
            information_confidence=.82,
            control_domains=control,
            restores_control=.62,
            conflict_strategy=strategy,
            identity_tags=identity,
            event_tags=("state_election_shock", "governability"),
            risk_tags=risk_tags,
            objective_feasibility=feasibility,
            instrumental_impacts=instrumental,
            substantive_impacts=substantive,
            necessity_frame_alignment=.65,
        ),
        actor_events=affected or {},
        actor_outcomes={owner: ActionOutcome(
            action=key,
            success=success,
            surprise=.18,
            tags=identity,
            workload=.035 + .055 * effort,
            control_restoration=.06 * success,
            identity_alignment=.05 * (success - .5),
        )},
    )


def build_nodes() -> dict[str, SimulationNodeV3]:
    nodes: dict[str, SimulationNodeV3] = {}

    nodes["fuel_launch"] = SimulationNodeV3("fuel_launch", "Reiche", (
        option("reiche_dashboard", "按期降税并公布逐日价格传导仪表板", "federal_election_response",
               effects={"union_de": .18, "afd_de": -.08, "gov_satisfaction": .35,
                        "fuel_pass_through": 8, "gov_narrative": 2},
               values={"economic_growth": .72, "market_order": .78, "executive_control": .82},
               goals={"visible_relief": .82}, instrumental={"implementation": .82, "credibility": .68},
               substantive={"consumer_relief": .72, "transparency": .84},
               identity=("implementation", "market_signal", "executive_direction"),
               control=("implementation", "data_and_briefing"), strategy="institutionalize",
               upside=.74, downside=.30, uncertainty=.34, effort=.62, visibility=.78,
               feasibility=.88, owner="Reiche", success=.73, risk_tags=("market_signal",)),
        option("reiche_victory_lap", "把降税包装成政府已经解决油价问题", "federal_election_response",
               effects={"union_de": .12, "afd_de": -.03, "gov_satisfaction": .15,
                        "fuel_pass_through": 3, "gov_narrative": 3},
               values={"economic_growth": .55, "executive_control": .78, "market_order": .22},
               goals={"visible_relief": .72}, instrumental={"implementation": .38, "credibility": .24},
               substantive={"consumer_relief": .40, "transparency": -.35},
               identity=("executive_direction", "public_message"), control=("strategic_direction",),
               strategy="reframe", upside=.66, downside=.58, uncertainty=.52, effort=.36,
               visibility=.95, feasibility=.90, owner="Reiche", success=.46,
               risk_tags=("internal_dissent",)),
        option("reiche_delay", "因传导和州财政争议延后全面启动", "federal_election_response",
               effects={"union_de": -.42, "afd_de": .28, "gov_satisfaction": -.65,
                        "fuel_pass_through": -4, "gov_narrative": -4},
               values={"economic_growth": -.42, "market_order": .38, "executive_control": -.35},
               goals={"visible_relief": -.68}, instrumental={"implementation": -.60, "credibility": -.52},
               substantive={"consumer_relief": -.74, "legal_caution": .55},
               identity=("coalition_veto",), control=("coalition",), strategy="avoid",
               upside=.20, downside=.82, uncertainty=.30, effort=.28, visibility=.70,
               feasibility=.72, owner="Reiche", success=.28, risk_tags=("coalition_veto",)),
    ), {"visible_relief": .92}, ("industrial_emergency", "implementation"))

    nodes["federal_election_response"] = SimulationNodeV3("federal_election_response", "Merz", (
        option("merz_delivery_reset", "承认三州警讯，转向经济交付并坚持不与AfD合作", "amthor_mv_rebuild",
               effects={"union_de": .22, "afd_de": -.05, "spd_de": .05, "gov_satisfaction": .30,
                        "merz_approval": .25, "gov_narrative": 2},
               values={"strategic_direction": .82, "reform_achievement": .76,
                       "political_authority": .65, "unity": .62},
               goals={"recover_governability": .86}, instrumental={"government_capacity": .72,
                       "coalition_stability": .62, "electoral_recovery": .55},
               substantive={"democratic_boundary": .82, "policy_agency": .74},
               identity=("strategic_direction", "reform", "agency"), control=("direction",),
               strategy="reframe", upside=.82, downside=.43, uncertainty=.48, effort=.72,
               visibility=.92, feasibility=.82, owner="Merz", success=.61,
               risk_tags=("systemic_crisis",), affected={
                   "Schulze": (event("lsa_loss_followthrough", "loss_of_office", .74,
                                     ("loss_of_office", "decline_narrative")),),
                   "Evers": (event("berlin_coalition_burden", "leader_vacancy", .48,
                                   ("leader_vacancy", "assigned_responsibility")),),
               }),
        option("merz_national_confrontation", "把败选解释为路线不够强硬并发动全国对抗", "amthor_mv_rebuild",
               effects={"union_de": -.10, "afd_de": .18, "spd_de": -.05, "gov_satisfaction": -.22,
                        "merz_approval": -.12, "gov_narrative": 1},
               values={"strategic_direction": .78, "political_authority": .82, "unity": -.35},
               goals={"recover_governability": .45}, instrumental={"government_capacity": -.22,
                       "coalition_stability": -.62, "electoral_recovery": .22},
               substantive={"democratic_boundary": .42, "policy_agency": .58},
               identity=("authority", "attack"), control=("direction",), strategy="attack",
               upside=.74, downside=.78, uncertainty=.64, effort=.78, visibility=1.0,
               feasibility=.76, owner="Merz", success=.39, risk_tags=("systemic_crisis",)),
        option("merz_wait_for_coalitions", "避免全国定调，等三州组阁后再调整", "amthor_mv_rebuild",
               effects={"union_de": -.28, "afd_de": .15, "gov_satisfaction": -.25,
                        "merz_approval": -.30, "gov_narrative": -3},
               values={"strategic_direction": -.55, "reform_achievement": -.20,
                       "political_authority": -.35, "unity": .35},
               goals={"recover_governability": -.42}, instrumental={"government_capacity": -.34,
                       "coalition_stability": .28, "electoral_recovery": -.46},
               substantive={"democratic_boundary": .35, "policy_agency": -.62},
               identity=("indecision",), control=("coalition",), strategy="avoid",
               upside=.18, downside=.64, uncertainty=.38, effort=.18, visibility=.42,
               feasibility=.96, owner="Merz", success=.31, risk_tags=("indecision",)),
    ), {"recover_governability": .95}, ("national_decline", "authority_challenge"))

    nodes["amthor_mv_rebuild"] = SimulationNodeV3("amthor_mv_rebuild", "Amthor", (
        option("amthor_dual_track_rebuild", "州内审计和基层巡回重建；联邦职务只提供接口而不替代州组织", "first_week_control",
               effects={"union_de": .04, "afd_de": -.02, "cdu_mv": .30,
                        "gov_satisfaction": .04, "gov_narrative": .4},
               values={"organizational_reconstruction": .92,
                       "democratic_differentiation": .80,
                       "implementation_credibility": .84,
                       "regional_representation": .90},
               goals={"rebuild_without_landtag": .94},
               instrumental={"organizational_recovery": .78, "federal_state_bridge": .74,
                             "local_credibility": .76},
               substantive={"regional_autonomy": .84, "democratic_self_efficacy": .82},
               identity=("party_rebuilding", "regional_representation", "implementation"),
               control=("party_organization", "federal_state_interface"),
               strategy="institutionalize", upside=.78, downside=.38, uncertainty=.54,
               effort=.86, visibility=.72, feasibility=.70, owner="Amthor", success=.59,
               risk_tags=("organizational_rescue", "federal_state_bridge")),
        option("amthor_federalize_rescue", "依靠总理府与全国媒体平台直接接管州党叙事和政策供给", "first_week_control",
               effects={"union_de": .03, "afd_de": .04, "cdu_mv": -.08,
                        "gov_satisfaction": .02, "gov_narrative": .8},
               values={"organizational_reconstruction": .56,
                       "democratic_differentiation": .72,
                       "implementation_credibility": .62,
                       "regional_representation": .18},
               goals={"rebuild_without_landtag": .52},
               instrumental={"organizational_recovery": .40, "federal_state_bridge": .90,
                             "local_credibility": -.32},
               substantive={"regional_autonomy": -.58, "democratic_self_efficacy": .35},
               identity=("federal_state_bridge", "public_debate"),
               control=("federal_state_interface", "argument_and_message"),
               strategy="reframe", upside=.70, downside=.66, uncertainty=.60,
               effort=.74, visibility=.94, feasibility=.82, owner="Amthor", success=.43,
               risk_tags=("personal_credibility",)),
        option("amthor_immediate_permanent_claim", "立即宣布竞选正式州主席并把重建个人化", "first_week_control",
               effects={"union_de": -.04, "afd_de": .07, "cdu_mv": -.16,
                        "gov_satisfaction": -.04, "gov_narrative": .2},
               values={"organizational_reconstruction": .32,
                       "democratic_differentiation": .54,
                       "implementation_credibility": .20,
                       "regional_representation": .45},
               goals={"rebuild_without_landtag": .30},
               instrumental={"organizational_recovery": .22, "federal_state_bridge": .48,
                             "local_credibility": -.45},
               substantive={"regional_autonomy": .20, "democratic_self_efficacy": .24},
               identity=("leadership_claim", "public_debate"),
               control=("argument_and_message", "party_organization"),
               strategy="attack", upside=.68, downside=.78, uncertainty=.68,
               effort=.78, visibility=.98, feasibility=.62, owner="Amthor", success=.34,
               risk_tags=("personal_credibility", "organizational_rescue")),
    ), {"rebuild_without_landtag": .98}, ("organization_collapse", "organizational_rescue"))

    nodes["lsa_opposition"] = SimulationNodeV3("lsa_opposition", "Schulze", (
        option("schulze_project_opposition", "以投资、行政绩效和逐案审查组织建设性反对党", "sitting_close",
               effects={"union_de": -.30, "afd_de": .41, "spd_de": .15,
                        "cdu_lsa": -.02, "cdu_mv": -.20, "gov_narrative": -.6},
               values={"regional_delivery": .90, "economic_progress": .86,
                       "democratic_responsibility": .78, "party_recovery": .82},
               goals={"rebuild_cdu_lsa": .90}, instrumental={"opposition_capacity": .82,
                       "local_credibility": .76}, substantive={"democratic_boundary": .75,
                       "regional_delivery": .88}, identity=("regional_responsibility", "delivery",
                       "accountability"), control=("execution", "economic_project"),
               strategy="institutionalize", upside=.78, downside=.34, uncertainty=.44,
               effort=.72, visibility=.70, feasibility=.80, owner="Schulze", success=.64,
               risk_tags=("concrete_project",)),
        option("schulze_total_blockade", "把每项政府议程都变成反AfD信任表决", "sitting_close",
               effects={"union_de": -.37, "afd_de": .55, "spd_de": .15,
                        "cdu_lsa": -.58, "cdu_mv": -.20, "gov_narrative": -1.3},
               values={"regional_delivery": -.38, "democratic_responsibility": .58,
                       "party_recovery": .30}, goals={"rebuild_cdu_lsa": .32},
               instrumental={"opposition_capacity": .28, "local_credibility": .34},
               substantive={"democratic_boundary": .82, "regional_delivery": -.55},
               identity=("regional_defence", "attack"), control=("faction",), strategy="attack",
               upside=.60, downside=.68, uncertainty=.52, effort=.80, visibility=.88,
               feasibility=.86, owner="Schulze", success=.40, risk_tags=("regional_defence",)),
        option("schulze_quiet_rebuild", "降低曝光，优先重建基层组织", "sitting_close",
               effects={"union_de": -.35, "afd_de": .49, "spd_de": .15,
                        "cdu_lsa": -.32, "cdu_mv": -.20, "gov_narrative": -1.2},
               values={"regional_delivery": .22, "party_recovery": .64,
                       "democratic_responsibility": .25}, goals={"rebuild_cdu_lsa": .55},
               instrumental={"opposition_capacity": .55, "local_credibility": .38},
               substantive={"democratic_boundary": .30, "regional_delivery": .20},
               identity=("faction_rebuild",), control=("faction",), strategy="avoid",
               upside=.40, downside=.38, uncertainty=.30, effort=.42, visibility=.22,
               feasibility=.90, owner="Schulze", success=.49, risk_tags=("no_delivery_path",)),
    ), {"rebuild_cdu_lsa": .96}, ("loss_of_office", "party_recovery"))

    nodes["first_week_control"] = SimulationNodeV3("first_week_control", "Frei", (
        option("frei_counted_calendar", "按票数和委员会成熟度压缩两周议程", "ko_hearing",
               effects={"union_de": .06, "gov_satisfaction": .15, "faction_cohesion": 4,
                        "legislative_capacity": 6, "gov_narrative": .5},
               values={"organization_success": .92, "political_stability": .86,
                       "personal_loyalty": .65}, goals={"deliver_two_weeks": .92},
               instrumental={"passage_security": .90, "calendar_control": .88},
               substantive={"parliamentary_autonomy": .62, "policy_quality": .68},
               identity=("organization", "majority", "implementation"),
               control=("organization", "parliamentary_process"), strategy="institutionalize",
               upside=.72, downside=.28, uncertainty=.26, effort=.76, visibility=.48,
               feasibility=.92, owner="Frei", success=.78, risk_tags=("counted_votes",)),
        option("frei_maximum_sprint", "尽量把所有项目在两周内推向表决", "ko_hearing",
               effects={"union_de": -.08, "gov_satisfaction": -.12, "faction_cohesion": -4,
                        "legislative_capacity": 3, "gov_narrative": 1},
               values={"organization_success": .45, "political_stability": -.28,
                       "personal_loyalty": .74}, goals={"deliver_two_weeks": .58},
               instrumental={"passage_security": -.38, "calendar_control": .54},
               substantive={"parliamentary_autonomy": -.44, "policy_quality": -.28},
               identity=("implementation",), control=("parliamentary_process",), strategy="attack",
               upside=.78, downside=.76, uncertainty=.65, effort=.96, visibility=.72,
               feasibility=.64, owner="Frei", success=.38, risk_tags=("uncounted_votes",)),
        option("frei_faction_independence", "公开强调党团自主并退回数个政府项目", "ko_hearing",
               effects={"union_de": -.04, "gov_satisfaction": -.20, "faction_cohesion": 2,
                        "legislative_capacity": -2, "gov_narrative": -1},
               values={"organization_success": .62, "political_stability": -.32,
                       "personal_loyalty": -.45}, goals={"deliver_two_weeks": .30},
               instrumental={"passage_security": .18, "calendar_control": .42},
               substantive={"parliamentary_autonomy": .88, "policy_quality": .52},
               identity=("organization", "public_split"), control=("organization",),
               strategy="reframe", upside=.52, downside=.62, uncertainty=.50, effort=.62,
               visibility=.82, feasibility=.78, owner="Frei", success=.46,
               risk_tags=("public_split",)),
    ), {"deliver_two_weeks": .94}, ("uncounted_votes", "faction_fragmentation"))

    # The remaining committee/hearing nodes deliberately use narrower choices:
    # the actors can alter design and scheduling, but cannot pretend a hearing is
    # already a final Bundestag vote.
    nodes["ko_hearing"] = policy_node(
        "ko_hearing", "Frei", "intelligence_design", "K.O.-Tropfen 听证后的处理",
        "organization_success", "majority", "passage_security",
        ("bundle_legal_consensus", "保留政府/联邦参议院两案比较并做跨党派法技术整合", .12, .74),
        ("government_text_only", "只推政府文本并快速结束争议", -.05, .49),
        ("defer_ko_bill", "暂缓，优先给预算和安全法腾出容量", -.08, .43),
    )
    nodes["intelligence_design"] = policy_node(
        "intelligence_design", "Dobrindt", "forced_measures", "情报法权限架构",
        "policy_control", "state_capacity", "legal_durability",
        ("dobrindt_guardrailed_power", "保留主动能力、AI与图像比对，同时加窄门槛和独立监督", .08, .69),
        ("dobrindt_maximum_power", "尽可能扩大行政裁量并压缩监督门槛", -.16, .44),
        ("dobrindt_split_bill", "拆分争议权限，先通过信息共享和技术规则", .02, .61),
    )
    nodes["forced_measures"] = policy_node(
        "forced_measures", "Linnemann", "early_pension_committee", "强制医疗措施/照护法",
        "implementation_effect", "clarity", "rights_implementation",
        ("linnemann_narrow_exception", "坚持 ultima ratio，限定院外例外并强化意愿记录", .06, .72),
        ("linnemann_broader_window", "扩大院外适用和法院授权期限以简化执行", -.08, .48),
        ("linnemann_delay_guidance", "先补执行指南，再决定是否推进文本", -.04, .52),
    )
    nodes["early_pension_committee"] = policy_node(
        "early_pension_committee", "Frei", "budget_hearing", "Frühstartrente 委员会路线",
        "organization_success", "political_stability", "passage_security",
        ("frei_staged_early_pension", "接受2020出生队列先行，写入扩围评估和执行期限", .09, .76),
        ("frei_full_6_18_now", "要求立刻覆盖全部6–18岁并扩大财政规模", -.07, .45),
        ("frei_pause_early_pension", "因预算压力暂停委员会推进", -.11, .39),
    )
    nodes["budget_hearing"] = policy_node(
        "budget_hearing", "Merz", "berlin_coalition", "2027预算伴随法听证后的联盟交易",
        "strategic_direction", "reform_achievement", "coalition_stability",
        ("merz_selective_budget_trade", "守住财政方向，用少量定向让步换SPD支持", .08, .68),
        ("merz_maximum_fiscal_line", "拒绝实质让步并要求党团硬过", -.14, .42),
        ("merz_broad_spd_concession", "大幅让步以尽快结束预算争议", -.05, .54),
    )
    nodes["berlin_coalition"] = policy_node(
        "berlin_coalition", "Evers", "vwgo_hearing", "柏林黑红绿组阁文本",
        "administrative_function", "fiscal_feasibility", "government_operability",
        ("evers_admin_contract", "以预算、住房审批和行政绩效指标锁住三党合同", .18, .71),
        ("evers_symbolic_centre", "主要以阻止左翼/AfD掌权来维系联盟", -.09, .46),
        ("evers_loose_compromise", "保留大量未决问题以尽快选出市长", -.14, .40),
    )
    nodes["vwgo_hearing"] = policy_node(
        "vwgo_hearing", "Evers", "lsa_opposition", "VwGO改革的州执行反馈",
        "administrative_function", "fiscal_feasibility", "legal_durability",
        ("evers_city_pilot", "支持加速审理并要求城市试点、人员与数字化配套", .08, .70),
        ("evers_maximum_acceleration", "支持最强期限压缩，不额外要求执行资源", -.05, .48),
        ("evers_defensive_objection", "以州行政负担为由整体反对", -.06, .44),
    )
    nodes["sitting_close"] = policy_node(
        "sitting_close", "Soeder", "fuel_pass_through", "十月连续会期结束后的CSU定位",
        "bavarian_delivery", "union_leadership", "electoral_positioning",
        ("soeder_close_ranks_conditions", "支持政府交付，同时公开列出下一阶段期限和条件", .03, .66),
        ("soeder_public_escalation", "把两周成果描述为不足并公开提高压力", -.08, .49),
        ("soeder_silence", "避免介入联邦秋季议程", -.02, .45),
    )
    nodes["fuel_pass_through"] = policy_node(
        "fuel_pass_through", "Reiche", "quiet_period_strategy", "三周后的燃油降税传导",
        "economic_growth", "market_order", "consumer_credibility",
        ("reiche_publish_and_pressure", "公布地区传导差异并对弱传导企业公开施压", .12, .67),
        ("reiche_price_cap_threat", "立即以价格上限威胁替代传导监测", -.06, .43),
        ("reiche_claim_complete_success", "只强调平均降幅并关闭争议", -.10, .42),
    )
    nodes["quiet_period_strategy"] = policy_node(
        "quiet_period_strategy", "Merz", "november_security", "无常规全会期的政府策略",
        "strategic_direction", "reform_achievement", "coalition_preparation",
        ("merz_private_package", "用两周闭门完成预算、养老金与安全法的交换包", .05, .70),
        ("merz_public_campaign", "连续公开演讲，以改革叙事绕过委员会摩擦", -.03, .52),
        ("merz_personnel_signal", "以新一轮人事信号重夺新闻周期", -.12, .38),
    )
    nodes["november_security"] = policy_node(
        "november_security", "Wadephul", "floor_scheduling", "情报法境外主动措施的外交约束",
        "alliance_reliability", "diplomatic_control", "legal_durability",
        ("wadephul_allied_guardrail", "要求盟友协调、部长级授权和可审计门槛", .04, .72),
        ("wadephul_broad_discretion", "接受广泛秘密行政裁量以提高速度", -.08, .43),
        ("wadephul_remove_active_measures", "从本轮改革中删除所有主动措施", -.03, .54),
    )
    nodes["floor_scheduling"] = policy_node(
        "floor_scheduling", "Frei", "midnovember_direction", "11月上半月的表决排程",
        "organization_success", "political_stability", "passage_security",
        ("frei_schedule_mature_only", "只排票数已锁定项目，争议安全条款继续委员会处理", .07, .77),
        ("frei_schedule_all", "把四个大项目同时推向二三读", -.10, .42),
        ("frei_defer_all_major", "所有大项目推迟到预算后", -.06, .48),
    )
    nodes["midnovember_direction"] = policy_node(
        "midnovember_direction", "Merz", None, "11月中旬的联邦路线选择",
        "strategic_direction", "reform_achievement", "government_authority",
        ("merz_targeted_delivery", "宣布一组有票数、有期限的窄改革并保留后续大改革", .10, .73),
        ("merz_big_bang", "把低民调解释为授权，立即推出更大一揽子改革", -.08, .47),
        ("merz_consensus_pause", "暂停主要改革，转入跨党派稳定叙事", -.04, .53),
    )
    return nodes


def policy_node(node: str, owner: str, next_node: str | None, title: str,
                value_a: str, value_b: str, metric: str, *rows: tuple[str, str, float, float]) -> SimulationNodeV3:
    actions = []
    for index, (key, label, poll_delta, success) in enumerate(rows):
        positive = index == 0
        effects = {
            "union_de": poll_delta if owner not in {"Evers"} else poll_delta * .15,
            "gov_satisfaction": poll_delta * 1.8,
            "legislative_capacity": (.7 if positive else -1.2 if index == 1 else -.7),
            "gov_narrative": (1.2 if positive else -.8),
        }
        if owner == "Evers":
            effects["cdu_berlin"] = poll_delta
        if owner == "Soeder":
            effects["union_de"] = poll_delta
        if owner == "Reiche":
            effects["fuel_pass_through"] = 4 if positive else -2
        actions.append(option(
            key, f"{title}：{label}", next_node, effects=effects,
            values={value_a: .82 if positive else .20, value_b: .74 if positive else .28},
            goals={metric: .82 if positive else .30},
            instrumental={metric: .82 if positive else .34, "implementation": .76 if positive else .38},
            substantive={"rights_and_legitimacy": .70 if positive else .12,
                         "future_option": .65 if positive else .25},
            identity=(value_a, value_b, "implementation"), control=("execution", "organization"),
            strategy="institutionalize" if positive else ("attack" if index == 1 else "avoid"),
            upside=.68 if positive else .52, downside=.30 if positive else .62,
            uncertainty=.34 if positive else .56, effort=.64 if positive else .52,
            visibility=.55 if positive else .70, feasibility=.86 if positive else .68,
            owner=owner, success=success,
            risk_tags=("measurable", "legal_uncertainty") if positive else ("symbolic_only",),
        ))
    return SimulationNodeV3(node, owner, tuple(actions), {metric: .92}, (title,))


def initial_state() -> PoliticalState:
    values = {
        "union_de": 20.0, "afd_de": 29.0, "spd_de": 13.0, "greens_de": 14.0,
        "left_de": 11.0, "merz_approval": 13.0, "gov_satisfaction": 15.0,
        "cdu_lsa": 17.2, "cdu_berlin": 18.8, "cdu_mv": 4.9,
        "fuel_pass_through": 0.0, "gov_narrative": 31.0,
        "faction_cohesion": 72.0, "legislative_capacity": 58.0,
    }
    return PoliticalState(
        variables={key: StateVariable(key, value, uncertainty=.08 if "_de" in key else .12)
                   for key, value in values.items()},
        capital={"government": 48, "union_faction": 68, "cdu_lsa": 34,
                 "cdu_berlin": 57, "csu": 76},
        pressures={"coalition": 68, "faction": 61, "state_elections": 92},
        locks={"fuel_tax_cut_active", "october_two_week_window"},
    )


def build_temporary_offices() -> TemporaryOfficeRegistry:
    return TemporaryOfficeRegistry((TemporaryOfficeAssignment(
        assignment_id="cdu_mv_2026_interim_chair",
        actor="Amthor",
        office="acting_cdu_mv_chair",
        begins_at="2026-09-22",
        ends_when="SUCCESSOR_FORMALLY_ELECTED",
        authority_scope=("state_board_coordination", "state_party_representation",
                         "convene_successor_process"),
    ),))


def build_configuration() -> LayeredConfiguration:
    base = LayeredConfiguration.from_environment_json(
        ROOT / "kfrage_model/environments/2026-07-31/environment.json",
        ROOT / "kfrage_model/personality_cards_2026/rationality_profiles_v3.json",
    )
    expansion = json.loads((ROOT / "kfrage_model/personality_cards_2026/"
                            "rationality_profiles_expansion_2026_09.json").read_text())
    profiles = dict(base.rationality_profiles)
    profiles.update({key: ActorRationalityProfile(**row)
                     for key, row in expansion["actors"].items()})
    offices = dict(base.matrix.actor_offices)
    offices.update({
        "Evers": ("berlin_governing_mayor", "cdu_berlin_chair"),
        "Schulze": ("lsa_opposition_leader", "cdu_lsa_chair"),
        "Reiche": ("federal_economy_minister",),
        "Dobrindt": ("federal_interior_minister", "csu_federal_actor"),
        "Amthor": ("chancellery_state_minister", "bundestag_member",
                   "cdu_federal_members_officer"),
    })
    temporary = build_temporary_offices()
    offices = temporary.apply_to_offices(offices)
    matrix = InstitutionalMatrix(base.matrix.matrix_id + "_october_scenario",
                                 offices, base.matrix.office_permissions, base.matrix.rules)
    return LayeredConfiguration(
        matrix=matrix, logic=replace(base.logic, alternative_legibility=.51,
                                     legitimacy=.48, control_concentration=.63),
        agency=base.agency, rationality_profiles=profiles,
        flags=V3FeatureFlags(True, True, True, False),
    )


def build_polling() -> RealtimePollingTracker:
    specs = tuple(PollSeriesSpec(key, subject, constituency, "vote_intention", scope,
                                retention=.62, publication_grid=.5)
                  for key, subject, constituency, scope in (
        ("union_de", "CDU/CSU", "federal_electorate", "Germany"),
        ("afd_de", "AfD", "federal_electorate", "Germany"),
        ("spd_de", "SPD", "federal_electorate", "Germany"),
        ("greens_de", "Gruene", "federal_electorate", "Germany"),
        ("left_de", "Linke", "federal_electorate", "Germany"),
        ("cdu_lsa", "CDU", "state_electorate", "Sachsen-Anhalt"),
        ("cdu_berlin", "CDU", "state_electorate", "Berlin"),
        ("cdu_mv", "CDU", "state_electorate", "Mecklenburg-Vorpommern"),
        ("merz_approval", "Merz", "federal_electorate", "Germany"),
    ))
    mapping = {f"layered_decision:{node}": date for node, date in NODE_DATES.items()}
    return RealtimePollingTracker("oct-nov-2026-baseline", "three-state-cf-2026-10",
                                  specs, "2026-10-01T00:00:00+02:00", mapping)


def conditional_votes(payload: dict) -> dict:
    state = payload["world_state"]["variables"]
    cohesion = state["faction_cohesion"]["value"] / 100
    runtime = payload["persona_runtime"]["actors"]
    frei_rel = runtime["Frei"]["runtime"]["relationships"].get("Merz", {})
    reliability = float(frei_rel.get("operational_reliability", .75))
    union_whip = max(.72, min(.97, .55 + .25 * cohesion + .20 * reliability))
    model = ParliamentaryVoteModel()
    rule = VoteRule("simple_cast", 630)
    proposals = {
        "Fruehstartrente": (.92, .87, .34, .18, .38),
        "Nachrichtendienstrecht_guardrailed": (union_whip, .74, .38, .18, .16),
        "Haushaltsbegleitgesetz_2027": (union_whip, .84, .18, .08, .10),
        "KO_Tropfen_reform": (.95, .92, .82, .72, .74),
        "Aerztliche_Zwangsmassnahmen": (.87, .84, .66, .61, .58),
        "VwGO_7_reform": (.91, .87, .57, .38, .55),
    }
    out = {}
    for proposal, shares in proposals.items():
        blocs = tuple(BlocVotePrior(key, seats, .96, yes, 1-yes-.02, .02,
                                   discipline=.86, hidden_defection_sigma=.025,
                                   linked_actor="Frei" if key == "Union" else None)
                      for (key, seats), yes in zip(
                          (("Union", 208), ("SPD", 120), ("Gruene", 85),
                           ("Linke", 64), ("AfD", 152)), shares))
        forecast = model.forecast(proposal, "conditional_second_third_reading", rule, blocs,
                                  assumptions=(
                                      "No floor date is asserted unless separately calendared.",
                                      f"Union yes-share adapter={union_whip:.3f} from faction cohesion and Frei-Merz operational reliability.",
                                      "Seat baseline uses the 2025 election allocation; late membership changes are not modelled.",
                                  ))
        simulation = model.simulate(rule, blocs, runs=2000, seed=202610 + len(out))
        out[proposal] = {"forecast": asdict(forecast), "contingency_runs": asdict(simulation)}
    return out


def contingency_ensemble(payload: dict, runs: int = 2000, seed: int = 15112026) -> dict:
    """Measurement/implementation contingencies only; no personality draw."""
    rng = random.Random(seed)
    final = payload["world_state"]["variables"]
    parties = ("union_de", "afd_de", "spd_de", "greens_de", "left_de")
    samples = {key: [] for key in parties}
    order_counts: dict[str, int] = {}
    for _ in range(runs):
        pass_through = rng.triangular(.35, 1.0, .72)
        attention = rng.triangular(.45, 1.15, .72)
        values = {}
        for key in parties:
            base = final[key]["value"]
            implementation = (.28 * (pass_through - .72) if key == "union_de"
                              else -.16 * (pass_through - .72) if key == "afd_de" else 0)
            measurement = rng.gauss(0, .72) * attention
            values[key] = max(0, base + implementation + measurement)
            samples[key].append(values[key])
        order = ">".join(sorted(parties, key=values.get, reverse=True))
        order_counts[order] = order_counts.get(order, 0) + 1
    intervals = {}
    for key, rows in samples.items():
        rows.sort()
        intervals[key] = {"median": round(rows[runs//2], 2),
                          "p10": round(rows[int(runs*.1)], 2),
                          "p90": round(rows[int(runs*.9)], 2)}
    return {"runs": runs, "seed": seed, "end_value_intervals": intervals,
            "rank_order_counts": dict(sorted(order_counts.items(), key=lambda item: -item[1])[:8]),
            "warning": "Conditional model frequencies for implementation and measurement noise; not election probabilities."}


def render_html(payload: dict) -> str:
    report = payload["scenario_report"]
    traces = payload["trace"]
    rows = []
    for turn in traces:
        chosen = turn["chosen_action"]
        ordered = sorted(turn["action_evaluations"].items(),
                         key=lambda item: item[1]["choice_score"], reverse=True)
        for index, (action_key, score) in enumerate(ordered):
            rows.append(
                "<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td>"
                "<td>{:.3f}</td><td>{:.3f}</td><td>{:.3f}</td><td>{:.3f}</td></tr>".format(
                    escape(turn["calendar_date"][:10]) if index == 0 else "",
                    escape(turn["decision_maker"]) if index == 0 else "",
                    escape(turn["scenario_prompt"]) if index == 0 else "",
                    "✓" if action_key == chosen else "",
                    escape(ACTION_LABELS.get(action_key, action_key)),
                    score["instrumental"], score["substantive"],
                    score["persona"]["total"], score["choice_score"])
            )
    final = payload["world_state"]["variables"]
    poll_rows = "".join(
        f"<tr><td>{escape(key)}</td><td>{value['value']:.2f}</td></tr>"
        for key, value in final.items() if key.endswith("_de") or key in {"merz_approval", "cdu_lsa", "cdu_berlin", "cdu_mv"}
    )
    vote_rows = "".join(
        f"<tr><td>{escape(key)}</td><td>{row['forecast']['conclusion']}</td>"
        f"<td>{row['forecast']['expected_yes']:.1f}</td><td>{row['forecast']['required_yes']}</td>"
        f"<td>{row['forecast']['expected_margin']:.1f}</td></tr>"
        for key, row in payload["conditional_vote_forecasts"].items()
    )
    return f"""<!doctype html><html lang='zh-CN'><head><meta charset='utf-8'>
<title>2026年10月三州组阁—联邦秋季模拟</title><style>
body{{font:15px/1.55 system-ui,sans-serif;max-width:1180px;margin:32px auto;color:#182033;padding:0 20px}}
h1,h2{{color:#14213d}} .note{{background:#f3f6fb;padding:14px;border-left:4px solid #5271b8}}
table{{border-collapse:collapse;width:100%;margin:12px 0 28px}}th,td{{border:1px solid #d9dee8;padding:7px;vertical-align:top}}th{{background:#eef2f7}}
svg{{max-width:100%;height:auto;border:1px solid #e2e6ed;margin:10px 0 24px}}
</style></head><body><h1>2026年10月三州组阁—联邦秋季模拟</h1>
<p class='note'>这是一条条件性沙盘路径，不是现实预测概率。LSA AfD–BSW/Siegmund、柏林黑红绿/Evers、MV SPD州长为用户给定的反事实初始条件；人物选择由卡牌与当前状态计算。</p>
<h2>逐节点全部选项与决策</h2><table><thead><tr><th>日期</th><th>人物</th><th>问题</th><th>选中</th><th>选项</th><th>工具性</th><th>实质性</th><th>人格原始分</th><th>总选择值</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
<h2>11月中旬状态</h2><table><tr><th>序列</th><th>潜在模型值</th></tr>{poll_rows}</table>
<h2>人物实时压力</h2>{report['charts']['pss_pressure_svg']}
<h2>实时民调</h2>{report['charts']['polling_svg']}
{render_arcana_embed(report)}
<h2>条件性表决预测</h2><p>仅回答“若按当前文本和队形进入二/三读会怎样”，不声称项目已被排上最终表决。</p>
<table><tr><th>项目</th><th>结论</th><th>预计赞成</th><th>门槛</th><th>余量</th></tr>{vote_rows}</table>
</body></html>"""


def run() -> dict:
    state = initial_state()
    personas = FreeAgentDecisionEngine.from_json(
        ROOT / "kfrage_model/personality_cards_2026/cards_pss.json")
    actors = {node.owner for node in build_nodes().values()}
    rules = {actor: {key: AccessRule(.82, noise=1.1, source="mixed_briefing")
                     for key in state.variables} for actor in actors}
    polling = build_polling()
    nodes = build_nodes()
    orchestrator = LayeredSimulationOrchestrator(
        state, nodes, personas, InformationFilter(rules, seed=20261001, stochastic=False),
        resource_bindings={}, configuration=build_configuration(), event_observers=(polling,),
    )
    payload = orchestrator.run("fuel_launch", max_steps=len(nodes) + 2)
    for turn in payload["trace"]:
        turn["calendar_date"] = NODE_DATES[turn["node"]]
        turn["scenario_prompt"] = NODE_PROMPTS[turn["node"]]
        turn["action_labels"] = {key: ACTION_LABELS.get(key, key)
                                 for key in turn["action_evaluations"]}
    payload["scenario_report"] = ScenarioReportCompiler(
        orchestrator._initial_pss, orchestrator.reporting_policy
    ).compile(payload["trace"], orchestrator.event_observers)
    payload["temporary_offices"] = build_temporary_offices().payload()
    payload["scenario_metadata"] = {
        "time_window": "2026-10-01/2026-11-15",
        "counterfactual_initial_conditions": [
            "Sachsen-Anhalt: AfD-BSW government, Ulrich Siegmund minister-president; Sven Schulze opposition leader",
            "Berlin: CDU-SPD-Gruene government, Stefan Evers governing mayor",
            "Mecklenburg-Vorpommern: SPD-led government",
            "Fuel-tax reduction takes effect on 2026-10-01",
        ],
        "observed_or_scheduled_anchors": [
            "INSA 2026-09-20 federal baseline",
            "2026 state-election results as recorded in source notes",
            "Philipp Amthor is acting CDU-MV chair after the Peters/Hoffmeister/von Allwoerden resignations",
            "Bundestag sitting weeks and named hearings/first readings",
        ],
        "unknown_black_boxes": [
            "coalition-contract details", "fuel-tax pass-through by retailer and region",
            "committee amendments", "late attendance and defections", "media attention allocation",
        ],
    }
    payload["conditional_vote_forecasts"] = conditional_votes(payload)
    payload["contingency_ensemble"] = contingency_ensemble(payload)
    payload["action_labels"] = ACTION_LABELS
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "baseline.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "report.html").write_text(render_html(payload), encoding="utf-8")
    (OUT / "pss_pressure.svg").write_text(payload["scenario_report"]["charts"]["pss_pressure_svg"], encoding="utf-8")
    (OUT / "polling.svg").write_text(payload["scenario_report"]["charts"]["polling_svg"], encoding="utf-8")
    return payload


if __name__ == "__main__":
    result = run()
    print(json.dumps({
        "valid": result["scenario_report"]["valid"],
        "nodes": len(result["trace"]),
        "used_personas": result["scenario_report"]["used_persona_cards"],
        "chosen_actions": [row["chosen_action"] for row in result["trace"]],
        "final_values": {key: row["value"] for key, row in result["world_state"]["variables"].items()},
        "output": str(OUT),
    }, ensure_ascii=False, indent=2))
