# October–November 2026 three-state scenario

Run from the project root:

```bash
python3 -m kfrage_model.scenarios.october_2026_three_state.run_scenario
```

The runner writes:

- `output/baseline.json` — full 17-node trace, every option evaluation, beliefs,
  PSS, institutional diagnostics, conditional votes and contingency ensemble;
- `output/report.html` — readable report with all options and both mandatory
  charts;
- `output/pss_pressure.svg` — pressure line for every used persona card;
- `output/polling.svg` — latent and pollster-like support lines.

The scenario is deterministic at the personality-choice layer.  The 2,000-run
ensemble varies only fuel-price implementation/attention and measurement noise.
Its run shares are not real-world election probabilities.

