# Source notes — October/November 2026 three-state scenario

Cut-off: 2026-09-21.  The simulation never treats a scheduled hearing as an
already completed vote.  All model-generated poll points are labelled
`MODEL_ESTIMATE`.

## Observed facts and scheduled anchors

- **Federal polling baseline.** INSA fieldwork 14–18 September, published
  20 September 2026: CDU/CSU 20%, SPD 13%, Greens 14%, FDP 5%, Left 11%, AfD
  29%, BSW 3%, other 5%.
  <https://www.wahlrecht.de/umfragen/insa.htm>
- **Bundestag seats used by the conditional vote model.** Election allocation:
  Union 208, AfD 152, SPD 120, Greens 85, Left 64 (630 total; the residual seat
  is not assigned a voting prior here).  This is an election baseline, not a
  claim about every later membership change.
  <https://www.bundestag.de/dokumente/textarchiv/2025/kw09-wahlergebnis-1049580>
- **Bundestag calendar.** October sitting weeks are 5–9 and 12–16 October;
  the next sitting weeks before the scenario cut-off are 2–6 and 9–13 November.
  <https://www.bundestag.de/parlament/plenum/sitzungskalender/bt2026-1084980>
- **Frühstartrente.** First reading 25 September, bill 21/7864, referral to the
  Finance Committee.  The proposal is EUR 10 per month; the intended age band
  is 6–18, while the initial subsidised rollout begins with the 2020 birth
  cohort.
  <https://www.bundestag.de/dokumente/textarchiv/2026/kw39-de-fruehstartrente-1211316>
- **Intelligence-law reform.** First reading 24 September, bill 21/7868.  The
  official summary covers BND/BfV powers, AI and biometric image matching,
  information exchange, independent control, and narrowly conditioned active
  measures against hostile foreign systems.
  <https://www.bundestag.de/dokumente/textarchiv/2026/kw39-de-nachrichtendienstrecht-1211260>
- **2027 budget accompanying act.** Public Budget Committee hearing scheduled
  for 12 October, 15:00–17:00, on bill 21/7860.
  <https://www.bundestag.de/ausschuesse/a08_haushalt/anhoerungen/1194566-1194566>
- **K.O.-Tropfen criminal-law reform.** Public hearing scheduled for 5 October,
  14:00–16:00, considering government bill 21/7560 and Bundesrat bill 21/551.
  <https://www.bundestag.de/ausschuesse/recht-verbraucherschutz/sitzungen/1194314-1194314>
- **Compulsory medical measures / care law.** Bill 21/7561 implements the
  Federal Constitutional Court judgment of 26 November 2024, keeps the
  *ultima-ratio* principle and defines narrow exceptions outside a hospital.
  The hearing is scheduled for 7 October.
  <https://www.bundestag.de/presse/hib/kurzmeldungen-1205050>
- **Seventh VwGO amendment.** Bill 21/7824 concerns modernisation and
  acceleration of administrative-court procedure; the public hearing is
  scheduled for 14 October, 14:00–16:00.
  <https://www.bundestag.de/dokumente/textarchiv/2026/kw39-de-verwaltungsgerichtsordnung-1211268>
- **Fuel-tax package.** The federal and state political agreement announced a
  14-cent-per-litre energy-tax reduction on petrol and diesel (about 17 cents
  including VAT), intended from 1 October through the end of 2026.  The model
  treats the start date as a scenario condition but keeps retail pass-through
  uncertain.
  <https://www.bundesregierung.de/breg-de/aktuelles/bund-und-laender-beschliessen-spritpreis-entlastungspaket-2453198>
- **Saxony-Anhalt result.** Preliminary official result: AfD 43.8%, CDU 17.2%,
  BSW represented; official result portal.
  <https://wahlergebnisse.sachsen-anhalt.de/wahlen/lt26/erg_land.html>
- **Berlin result.** Preliminary second-vote result: Left 25.7%, CDU 18.8%, AfD
  16.3%, Greens 14.3%, SPD 12.1%, BSW 4.7%.
  <https://www.berlin.de/wahlen/pressemitteilungen/2026/20260921_vorlaeufiges-ergebnis-festgestellt.pdf>
- **Mecklenburg-Vorpommern result.** Preliminary result reported AfD first,
  SPD second and CDU at 4.9%, outside the Landtag.
  <https://www.tagesschau.de/inland/landtagswahlen/mecklenburg-vorpommern/2026/mecklenburg-vorpommern-landtagswahl-ergebnis-104.html>

## Counterfactual initial conditions supplied by the user

- Saxony-Anhalt forms an AfD–BSW government with Ulrich Siegmund as
  minister-president; Sven Schulze leads the CDU opposition.
- Berlin forms a CDU–SPD–Green government and elects Stefan Evers governing
  mayor, despite the observed election result.
- Mecklenburg-Vorpommern retains an SPD minister-president.
- The fuel-tax reduction begins on 1 October.

These are not claims that the coalitions will occur.  They define the board on
which the agents act.

## Model assumptions

- Poll effects are latent percentage-point responses calibrated to be mostly
  smaller than one pollster publication grid.  Retention is 0.62 and published
  nowcasts are rounded to 0.5 points.
- Committee maturation changes legislative capacity only slightly.  A hearing
  is not scored as a legislative victory.
- Conditional vote forecasts use policy-specific bloc support priors.  Union
  cohesion is linked to the simulated faction-cohesion variable and the live
  Frei–Merz operational-reliability relationship.
- Actor choices use current cards, PSS, information filters, agency horizons,
  instrumental/substantive evaluation and institutional logic.  Personality
  itself is not randomised.

## Unknown black boxes

- Exact coalition contracts and portfolio allocations.
- Retail fuel-price pass-through by firm and region.
- Committee amendments, expert-hearing evidence and coalition side deals.
- Late attendance, individual defections and floor scheduling.
- Allocation and persistence of national versus local media attention.

