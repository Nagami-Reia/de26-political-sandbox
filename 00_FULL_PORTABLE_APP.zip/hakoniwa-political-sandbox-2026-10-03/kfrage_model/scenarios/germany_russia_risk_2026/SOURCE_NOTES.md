# Source notes — snapshot 2026-10-01

## Observed facts

- German government, 4 September 2026: Germany attributes the attempted
  explosive-drone attack at Leipzig/Halle to Russia, describes its response as
  resolute, measured and proportionate, and coordinates with NATO/EU.
  https://www.bundesregierung.de/breg-de/service/fragen-und-anworten/reaktion-angriff-leipzig-2451522
- Federal government drone FAQ: the threat level is high, but there is no
  concrete threat to the public; the National Security Council considered the
  Leipzig incident.
  https://www.bundesregierung.de/breg-de/service/newsletter-und-abos/newsletter-verbraucherschutz/hybride-bedrohung-fragen-antworten-faq-2449150
- Wadephul, 1 September 2026: Russia is conducting destabilisation, sabotage
  and aggression, but a future return to constructive relations remains a
  stated German objective if Moscow changes course.
  https://www.auswaertiges-amt.de/en/newsroom/news/2800600-2800600
- NATO, 10 September 2026: solidarity with Germany after Leipzig and continued
  collective-defence support; Germany has a permanent brigade in Lithuania and
  other eastern-flank commitments.
  https://nato.int/en/news-and-events/articles/news/2026/09/10/nato-secretary-general-in-berlin-germany-and-nato-30-strengthening-europe-delivering-for-the-alliance
- NATO Secretary General, 30 September 2026: no imminent threat to NATO
  territory; the Alliance has not treated Russian nuclear language as evidence
  of an imminent attack.
  https://www.nato.int/en/news-and-events/events/transcripts/2026/09/30/remarks-by-nato-secretary-general-at-euronews-defence--space-summit
- Russia sent NATO an informal note threatening use of its full arsenal if NATO
  tried to isolate Kaliningrad. Public reporting and NATO responses did not
  identify a verified Russian nuclear-force posture change.
  https://apnews.com/article/2bd21dbaf9d67f5e2aada61e9ce8bf06
- Wadephul and Lavrov met on 26 September; the channel produced no substantive
  convergence but demonstrates that a degraded diplomatic channel still exists.
  https://apnews.com/article/2e7fa731f850d3ec92fa8a8641046276
- Bundeswehr 2026 military-strategy material identifies Russia as the largest
  threat to European security and Germany as NATO's logistics hub.
  https://www.bundeswehr.de/de/selbstverstaendnis/geschichte-bundeswehr/reformen-bundeswehr
- AfD programme materials favour resuming NATO–Russia dialogue, ending EU
  sanctions and restoring economic relations with Russia. AfD representatives
  publicly questioned the government's Leipzig account.
  https://www.afd.de/wahlprogramm-aussen-verteidigungspolitik/
  https://www.deutschlandfunk.de/von-notz-nennt-reaktion-ueberfaellig-afd-zweifelt-an-darstellung-der-regierung-100.html

## Model assumptions

- Normalised state values, weekly contingency rates and thresholds are model
  assumptions, not observed probabilities.
- `NUCLEAR_RHETORIC` and `NUCLEAR_POSTURE` are separate variables.
- Route frequencies are conditional stability tests; they are not real-world
  probabilities and must not be presented as polling or intelligence estimates.
- The model never identifies a future attacker or attack date as fact.
