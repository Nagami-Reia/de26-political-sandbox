#!/usr/bin/env python3
"""Forward state-transition sandbox for Germany–Russia escalation risk."""
from __future__ import annotations

import argparse
import json
import math
import random
import secrets
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from html import escape
from pathlib import Path

from kfrage_model.arcana import ArcanaConfig, ArcanaService
from kfrage_model.arcana.hakoniwa import ArcanaDecisionAdapter
from kfrage_model.arcana.report_trace import ArcanaReportTraceCompiler
from kfrage_model.arcana.reporting import ArcanaVisualReportRenderer, SCRIPT as ARCANA_SCRIPT, STYLE as ARCANA_STYLE
from kfrage_model.party_interest import PartyInterestEngine
from kfrage_model.persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine
from kfrage_model.political_state_system import PoliticalEvent


ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = HERE / "output"
STATES = (
    "S0_GREY_ZONE", "S1_HYBRID_CONFRONTATION", "S2_SERIOUS_SECURITY_CRISIS",
    "S3_LIMITED_DIRECT_HOSTILITIES", "S4_NATO_RUSSIA_CONVENTIONAL_CONFLICT",
    "S5_NUCLEAR_CRISIS",
)

SNAPSHOT = {
    "as_of": "2026-10-01",
    "state": "S1_HYBRID_CONFRONTATION",
    "hybrid_intensity": .740,
    "attribution_confidence": .820,
    "kinetic_contact": .000,
    "defensive_posture": .560,
    "attack_preparation": .090,
    "communication_channels": .460,
    "alliance_cohesion": .840,
    "nuclear_rhetoric": .820,
    "nuclear_posture": .120,
    "exit_options": .610,
    "information_uncertainty": .470,
    "direct_hostilities": False,
    "article_4": False,
    "article_5": False,
}


@dataclass(frozen=True)
class DecisionNode:
    key: str
    actor: str
    conflict_actor: str
    prompt: str
    actions: tuple[ActionOption, ...]
    stage: str = "S1"


def action(
    key: str, *, goals: dict[str, float], values: dict[str, float],
    instrumental: dict[str, float], substantive: dict[str, float],
    upside: float, downside: float, uncertainty: float, strategy: str,
    identity: tuple[str, ...], party: dict[str, float],
    party_strategy: dict[str, float], positions: dict[str, float],
    feasibility: float = .880,
) -> ActionOption:
    return ActionOption(
        key, goal_impacts=goals, value_impacts=values, upside=upside,
        downside=downside, uncertainty=uncertainty,
        irreversibility=.180 + .520 * downside, effort=.620, visibility=.780,
        information_confidence=.740, control_domains=("direction", "organization", "process"),
        restores_control=.420 + .260 * instrumental.get("government_control", .5),
        conflict_strategy=strategy, identity_tags=identity,
        event_tags=("hybrid_conflict", "nuclear_rhetoric", "alliance_management"),
        risk_tags=("miscalculation", "relationally_fragile"),
        objective_feasibility=feasibility, instrumental_impacts=instrumental,
        substantive_impacts=substantive, necessity_frame_alignment=.360,
        institutional_deviation=.040, party_interest_impacts=party,
        party_strategy_impacts=party_strategy, issue_positions=positions,
    )


def _initial_decision_nodes() -> tuple[DecisionNode, ...]:
    return (
        DecisionNode("wadephul_note", "Wadephul", "Merz",
            "如何处理俄罗斯关于加里宁格勒的核威胁照会，同时保留可验证沟通渠道？", (
            action("dual_track_clarification", goals={"preserve_alliance_channel": .92},
                values={"alliance_reliability": .90, "diplomatic_control": .94,
                        "de_escalation_credibility": .86, "government_coherence": .78},
                instrumental={"government_control": .78, "channel_preservation": .94,
                              "allied_cohesion": .84},
                substantive={"escalation_control": .90, "truthfulness": .82},
                upside=.72, downside=.30, uncertainty=.46, strategy="negotiate",
                identity=("alliance_reliability", "diplomatic_control", "de_escalation"),
                party={"national_security": .74, "alliance_reliability": .88,
                       "government_capacity": .72},
                party_strategy={"government_stability": .72, "coalition_reliability": .76},
                positions={"nato_collective_defence": .82, "military_escalation": -.15,
                           "russia_sanctions": .62}),
            action("public_counterwarning", goals={"preserve_alliance_channel": .65},
                values={"alliance_reliability": .84, "diplomatic_control": .44,
                        "de_escalation_credibility": .26, "government_coherence": .76},
                instrumental={"government_control": .72, "channel_preservation": .20,
                              "allied_cohesion": .72},
                substantive={"escalation_control": .18, "truthfulness": .68},
                upside=.76, downside=.74, uncertainty=.62, strategy="attack",
                identity=("deterrence", "alliance_reliability"),
                party={"national_security": .88, "alliance_reliability": .78,
                       "government_capacity": .62},
                party_strategy={"government_stability": .42, "narrative_ownership": .86},
                positions={"nato_collective_defence": .94, "military_escalation": .58,
                           "russia_sanctions": .84}),
            action("quiet_channel_first", goals={"preserve_alliance_channel": .82},
                values={"alliance_reliability": .60, "diplomatic_control": .92,
                        "de_escalation_credibility": .94, "government_coherence": .48},
                instrumental={"government_control": .54, "channel_preservation": .98,
                              "allied_cohesion": .48},
                substantive={"escalation_control": .94, "truthfulness": .54},
                upside=.58, downside=.46, uncertainty=.58, strategy="avoid",
                identity=("diplomatic_control", "de_escalation"),
                party={"national_security": .38, "alliance_reliability": .50,
                       "government_capacity": .44},
                party_strategy={"government_stability": .48, "coalition_reliability": .52},
                positions={"nato_collective_defence": .40, "military_escalation": -.52,
                           "russia_sanctions": .20}),
        )),
        DecisionNode("merz_security_council", "Merz", "Wadephul",
            "国家安全委员会如何把高烈度混合威胁转换为政府姿态，而不把核言辞误读成核部署？", (
            action("resilience_and_calibrated_deterrence", goals={"retain_strategic_control": .94},
                values={"strategic_direction": .92, "reform_achievement": .42,
                        "political_authority": .86, "unity": .84},
                instrumental={"government_control": .90, "readiness": .82,
                              "allied_cohesion": .86},
                substantive={"escalation_control": .84, "constitutional_legitimacy": .90},
                upside=.78, downside=.36, uncertainty=.44, strategy="institutionalize",
                identity=("strategic_direction", "agency", "authority"),
                party={"national_security": .90, "government_capacity": .86,
                       "organizational_unity": .78},
                party_strategy={"government_stability": .84, "coalition_reliability": .72},
                positions={"nato_collective_defence": .90, "military_escalation": .10,
                           "defence_spending": .82}),
            action("maximal_visible_deterrence", goals={"retain_strategic_control": .90},
                values={"strategic_direction": .94, "reform_achievement": .30,
                        "political_authority": .96, "unity": .52},
                instrumental={"government_control": .88, "readiness": .94,
                              "allied_cohesion": .68},
                substantive={"escalation_control": .18, "constitutional_legitimacy": .66},
                upside=.84, downside=.78, uncertainty=.60, strategy="attack",
                identity=("authority", "deterrence", "agency"),
                party={"national_security": .98, "government_capacity": .72,
                       "organizational_unity": .46},
                party_strategy={"government_stability": .48, "narrative_ownership": .90},
                positions={"nato_collective_defence": .96, "military_escalation": .68,
                           "defence_spending": .96}),
            action("hold_current_posture", goals={"retain_strategic_control": .56},
                values={"strategic_direction": .38, "reform_achievement": .54,
                        "political_authority": .44, "unity": .76},
                instrumental={"government_control": .46, "readiness": .48,
                              "allied_cohesion": .66},
                substantive={"escalation_control": .78, "constitutional_legitimacy": .74},
                upside=.42, downside=.42, uncertainty=.52, strategy="avoid",
                identity=("restraint", "unity"),
                party={"national_security": .30, "government_capacity": .40,
                       "organizational_unity": .72},
                party_strategy={"government_stability": .54, "coalition_reliability": .62},
                positions={"nato_collective_defence": .50, "military_escalation": -.42,
                           "defence_spending": .30}),
        )),
        DecisionNode("frei_bundestag", "Frei", "Merz",
            "Frei如何组织议会知情、跨党派合法性与Union纪律，以承受下一次触发事件？", (
            action("classified_crossparty_ladder", goals={"preserve_parliamentary_capacity": .94},
                values={"organization_success": .94, "political_stability": .88,
                        "personal_loyalty": .78, "individual_preference": .36},
                instrumental={"government_control": .84, "vote_capacity": .90,
                              "allied_cohesion": .76},
                substantive={"escalation_control": .82, "constitutional_legitimacy": .96},
                upside=.72, downside=.28, uncertainty=.38, strategy="institutionalize",
                identity=("organization", "majority", "institutional_loyalty"),
                party={"government_capacity": .82, "organizational_unity": .80,
                       "national_security": .76},
                party_strategy={"government_stability": .88, "coalition_reliability": .84},
                positions={"nato_collective_defence": .78, "military_escalation": -.04}),
            action("union_only_security_line", goals={"preserve_parliamentary_capacity": .78},
                values={"organization_success": .84, "political_stability": .52,
                        "personal_loyalty": .92, "individual_preference": .42},
                instrumental={"government_control": .80, "vote_capacity": .72,
                              "allied_cohesion": .62},
                substantive={"escalation_control": .42, "constitutional_legitimacy": .46},
                upside=.68, downside=.62, uncertainty=.48, strategy="attack",
                identity=("organization", "personal_loyalty", "majority"),
                party={"government_capacity": .72, "organizational_unity": .88,
                       "national_security": .82},
                party_strategy={"government_stability": .54, "narrative_ownership": .76},
                positions={"nato_collective_defence": .88, "military_escalation": .32}),
            action("minimal_parliamentary_exposure", goals={"preserve_parliamentary_capacity": .50},
                values={"organization_success": .46, "political_stability": .48,
                        "personal_loyalty": .64, "individual_preference": .58},
                instrumental={"government_control": .62, "vote_capacity": .32,
                              "allied_cohesion": .54},
                substantive={"escalation_control": .60, "constitutional_legitimacy": .20},
                upside=.40, downside=.58, uncertainty=.60, strategy="avoid",
                identity=("message_discipline", "secrecy"),
                party={"government_capacity": .32, "organizational_unity": .54,
                       "national_security": .58},
                party_strategy={"government_stability": .28, "coalition_reliability": .30},
                positions={"nato_collective_defence": .58, "military_escalation": -.12}),
        )),
    )


ACTOR_VALUES = {
    "Merz": {"strategic_direction": .94, "political_authority": .88, "unity": .76},
    "Frei": {"organization_success": .96, "political_stability": .90, "personal_loyalty": .80},
    "Wadephul": {"alliance_reliability": .94, "diplomatic_control": .92,
                  "de_escalation_credibility": .88},
}

MODE = {
    # No mode is globally best: each trades readiness, evidence, legitimacy and exit capacity.
    "verify": dict(control=.61, channel=.72, cohesion=.70, escalation=.83, legitimacy=.84,
                   upside=.55, downside=.25, uncertainty=.31, strategy="institutionalize",
                   position=.05, feasibility=.91),
    "consult": dict(control=.73, channel=.78, cohesion=.91, escalation=.79, legitimacy=.93,
                    upside=.68, downside=.33, uncertainty=.42, strategy="negotiate",
                    position=.12, feasibility=.84),
    "defend": dict(control=.84, channel=.48, cohesion=.82, escalation=.52, legitimacy=.78,
                   upside=.77, downside=.51, uncertainty=.48, strategy="institutionalize",
                   position=.42, feasibility=.86),
    "signal": dict(control=.78, channel=.24, cohesion=.67, escalation=.24, legitimacy=.53,
                   upside=.83, downside=.76, uncertainty=.61, strategy="attack",
                   position=.72, feasibility=.78),
    "pause": dict(control=.45, channel=.91, cohesion=.54, escalation=.94, legitimacy=.64,
                  upside=.46, downside=.39, uncertainty=.56, strategy="avoid",
                  position=-.42, feasibility=.89),
}


def generated_action(actor: str, key: str, mode: str) -> ActionOption:
    row = MODE[mode]
    return action(
        key, goals={"preserve_decision_capacity": .50 + .45 * row["control"]},
        values=ACTOR_VALUES[actor],
        instrumental={"government_control": row["control"], "channel_preservation": row["channel"],
                      "allied_cohesion": row["cohesion"], "readiness": .35 + .55 * max(0, row["position"])},
        substantive={"escalation_control": row["escalation"],
                     "constitutional_legitimacy": row["legitimacy"],
                     "negative_evidence_responsiveness": .92 if mode == "verify" else .52},
        upside=row["upside"], downside=row["downside"], uncertainty=row["uncertainty"],
        strategy=row["strategy"], identity=(mode, "crisis_governance"),
        party={"national_security": row["control"], "alliance_reliability": row["cohesion"],
               "government_capacity": row["legitimacy"]},
        party_strategy={"government_stability": row["control"],
                        "coalition_reliability": row["legitimacy"]},
        positions={"nato_collective_defence": row["cohesion"],
                   "military_escalation": row["position"], "defence_spending": max(0, row["position"])},
        feasibility=row["feasibility"],
    )


def decision_nodes() -> tuple[DecisionNode, ...]:
    contingent = (
        DecisionNode("wadephul_negative_evidence", "Wadephul", "Merz",
            "新取证削弱早期归责时，是公开修正、继续核验、盟友磋商还是坚持原说法？",
            tuple(generated_action("Wadephul", key, mode) for key, mode in (
                ("publish_evidence_update", "verify"), ("allied_attribution_review", "consult"),
                ("retain_claim_pending_review", "defend"), ("double_down_publicly", "signal"))), "S1"),
        DecisionNode("frei_article4_process", "Frei", "Merz",
            "若安全危机达到S2，是否寻求Article 4磋商以及如何组织Bundestag知情？",
            tuple(generated_action("Frei", key, mode) for key, mode in (
                ("crossparty_article4_consultation", "consult"), ("evidence_first_briefing", "verify"),
                ("government_only_preparation", "defend"), ("public_majority_pressure", "signal"))), "S2"),
        DecisionNode("merz_defensive_posture", "Merz", "Wadephul",
            "S2阶段如何区分防御部署与攻击准备，并向俄方和盟友传递可验证信号？",
            tuple(generated_action("Merz", key, mode) for key, mode in (
                ("transparent_defensive_reinforcement", "defend"), ("nato_consult_then_reinforce", "consult"),
                ("hold_for_intelligence", "verify"), ("forward_coercive_signal", "signal"))), "S2"),
        DecisionNode("wadephul_first_kinetic_contact", "Wadephul", "Merz",
            "首次正规军直接伤亡后，如何保留事实传递、责任澄清和停火窗口？",
            tuple(generated_action("Wadephul", key, mode) for key, mode in (
                ("military_hotline_fact_exchange", "verify"), ("allied_ceasefire_probe", "consult"),
                ("reciprocal_diplomatic_freeze", "defend"), ("close_channels_and_warn", "signal"))), "S3"),
        DecisionNode("merz_post_contact_choice", "Merz", "Frei",
            "S3有限交火后，是控制升级、有限回应、联盟化还是公开扩大目标？",
            tuple(generated_action("Merz", key, mode) for key, mode in (
                ("bounded_response_with_offramp", "consult"), ("verified_defensive_response", "defend"),
                ("operational_pause_for_attribution", "pause"), ("expand_military_objectives", "signal"))), "S3"),
        DecisionNode("frei_post_contact_mandate", "Frei", "Merz",
            "S3以后议会授权应给政府多大行动空间，同时保留复审和降级机制？",
            tuple(generated_action("Frei", key, mode) for key, mode in (
                ("time_limited_crossparty_mandate", "consult"), ("narrow_verified_mandate", "verify"),
                ("broad_executive_mandate", "defend"), ("emergency_open_ended_mandate", "signal"))), "S3"),
    )
    return _initial_decision_nodes() + contingent


def _normalize_scores(raw: dict[str, float]) -> dict[str, float]:
    low, high = min(raw.values()), max(raw.values())
    if math.isclose(low, high):
        return {key: .500 for key in raw}
    return {key: round(.350 + .500 * (value - low) / (high - low), 3)
            for key, value in raw.items()}


def run_decisions(master_seed: int, arcana_enabled: bool) -> tuple[list[dict], dict, dict]:
    personas = FreeAgentDecisionEngine.from_json(
        ROOT / "kfrage_model/personality_cards_2026/cards_pss.json"
    )
    oracle = ArcanaService(ArcanaConfig(
        enabled=arcana_enabled, master_seed=master_seed, influence_cap=.180,
    ))
    adapter = ArcanaDecisionAdapter()
    initial_shock = PoliticalEvent(
        "kaliningrad_note_2026_09_30", "security_crisis", .660,
        ("national_decline", "authority_challenge", "loss_of_control",
         "alliance_pressure", "media_attack"),
        valence=-1.0, surprise=.580, workload=.050,
    )
    initial_pss = {actor: asdict(personas.runtime[actor].state)
                   for actor in ("Merz", "Frei", "Wadephul")}
    trigger_updates = {actor: personas.apply_event(actor, initial_shock)
                       for actor in initial_pss}
    audits, decisions = [], []
    for node in decision_nodes():
        resources = dict(personas.cards[node.actor].initial_resources)
        result = personas.decide(
            node.actor, node.actions, resources,
            current_goals={next(iter(node.actions[0].goal_impacts)): .960},
            scene_tags=("hybrid_conflict", "nuclear_rhetoric", "fog_of_war"),
            soft_resource_constraints=True,
        )
        raw_scores = {key: row.total for key, row in result.scores.items()}
        state_utility_adjustments = {}
        for option in node.actions:
            adjustment = 0.0
            if node.stage == "S3":
                # Direct bloodshed raises the utility of bounded aims and usable off-ramps;
                # it does not force de-escalation or alter the actor's fixed personality.
                adjustment = .115 * (
                    option.substantive_impacts.get("escalation_control", .5)
                    + option.instrumental_impacts.get("channel_preservation", .5) - 1.0
                )
                raw_scores[option.key] += adjustment
            state_utility_adjustments[option.key] = round(adjustment, 3)
        base_scores = _normalize_scores(raw_scores)
        rational = max(base_scores, key=base_scores.get)
        arcana_row = {"enabled": arcana_enabled, "status": "DISABLED"}
        final = rational
        if arcana_enabled:
            conflict = oracle.run_conflict(
                node.key, node.actor, node.conflict_actor,
                personas.cards[node.actor], personas.runtime[node.actor],
                personas.cards[node.conflict_actor], personas.runtime[node.conflict_actor],
            )
            primary = oracle.repository.get(conflict["primary_reading"]["run_id"])
            modifier = conflict["interaction"]["primary_pss_mediation"]["decision_threshold_modifier"]
            final, adoption = adapter.adapt(
                rational, base_scores, node.actions, primary.advice,
                personas.cards[node.actor], personas.runtime[node.actor],
                node_uncertainty=.620, interaction_modifier=modifier,
                influence_cap=oracle.config.influence_cap,
            )
            arcana_row = {
                "enabled": True, "status": "RUN", "reading": conflict["primary_reading"],
                "adoption": adoption, "conflict_interaction": conflict,
                "node_uncertainty": .620,
            }
        chosen = next(row for row in node.actions if row.key == final)
        outcome = personas.apply_outcome(node.actor, ActionOutcome(
            action=final, success=max(.350, min(.850, chosen.objective_feasibility - chosen.downside * .18)),
            surprise=.180, tags=chosen.identity_tags, target_actor=node.conflict_actor,
            workload=.055, control_restoration=.060 * chosen.restores_control,
            identity_alignment=.030,
        ))
        audit = {
            "node": node.key, "decision_maker": node.actor, **arcana_row,
            "chosen_action": final, "all_actor_pss_after": {
                actor: asdict(personas.runtime[actor].state)
                for actor in (node.actor, node.conflict_actor)
            }, "operational_feedback": {"pss_updates": [outcome]},
        }
        audits.append(audit)
        decisions.append({
            "node": node.key, "actor": node.actor, "conflict_actor": node.conflict_actor,
            "stage": node.stage,
            "prompt": node.prompt, "rational_choice": rational, "chosen_action": final,
            "arcana_changed_choice": final != rational,
            "state_utility_adjustments": state_utility_adjustments,
            "policy_levers": {
                "restraint": round(chosen.substantive_impacts.get("escalation_control", .5), 3),
                "deterrence": round(.5 + .5 * chosen.issue_positions.get("military_escalation", 0), 3),
                "channel": round(chosen.instrumental_impacts.get("channel_preservation", .5), 3),
                "attribution": round(chosen.substantive_impacts.get("negative_evidence_responsiveness",
                                                                     chosen.substantive_impacts.get("truthfulness", .5)), 3),
                "legitimacy": round(chosen.substantive_impacts.get("constitutional_legitimacy", .5), 3),
                "readiness": round(chosen.instrumental_impacts.get("readiness", .5), 3),
            },
            "scores": {key: {"normalized": base_scores[key], **asdict(result.scores[key])}
                       for key in base_scores},
            "pss_after": asdict(personas.runtime[node.actor].state),
            "arcana": arcana_row,
        })
    return decisions, {
        "initial": initial_pss, "trigger_updates": trigger_updates,
        "final": {actor: asdict(personas.runtime[actor].state) for actor in initial_pss},
    }, {"service": oracle.payload(), "audits": audits}


def party_response_menu() -> tuple[ActionOption, ...]:
    return (
        ActionOption("support_calibrated_security", objective_feasibility=.900,
            party_interest_impacts={"national_security": .82, "government_capacity": .72,
                                    "alliance_reliability": .84, "democratic_legitimacy": .62,
                                    "social_protection": .18},
            party_strategy_impacts={"government_stability": .74, "coalition_reliability": .70,
                                    "party_unity": .54, "opposition_differentiation": -.20},
            issue_positions={"nato_collective_defence": .86, "russia_sanctions": .66,
                             "military_escalation": .06, "defence_spending": .72}),
        ActionOption("demand_stronger_response", objective_feasibility=.720,
            party_interest_impacts={"national_security": .96, "government_capacity": .54,
                                    "alliance_reliability": .74, "democratic_legitimacy": .30,
                                    "social_protection": -.16},
            party_strategy_impacts={"government_stability": .26, "coalition_reliability": .22,
                                    "party_unity": .62, "opposition_differentiation": .82},
            issue_positions={"nato_collective_defence": .96, "russia_sanctions": .90,
                             "military_escalation": .64, "defence_spending": .94}),
        ActionOption("challenge_attribution_dialogue_first", objective_feasibility=.820,
            party_interest_impacts={"national_security": .24, "government_capacity": -.44,
                                    "alliance_reliability": -.36, "democratic_legitimacy": .40,
                                    "social_protection": .38},
            party_strategy_impacts={"government_stability": -.58, "coalition_reliability": -.42,
                                    "party_unity": .66, "opposition_differentiation": .94},
            issue_positions={"nato_collective_defence": .10, "russia_sanctions": -.90,
                             "military_escalation": -.82, "defence_spending": -.12}),
    )


def run_party_round() -> dict:
    engine = PartyInterestEngine.from_json(
        ROOT / "kfrage_model/party_profiles_2026/party_interest_profiles.json"
    )
    result = {}
    for party in ("CDU_CSU", "SPD", "GRUENE", "AFD", "LINKE", "BSW"):
        decision = engine.decide(party, party_response_menu())
        result[party] = decision.payload()
    return result


ACTION_LEVERS = {
    "dual_track_clarification": {"restraint": .82, "deterrence": .56, "channel": .78,
                                  "attribution": .88, "legitimacy": .72, "readiness": .44},
    "public_counterwarning": {"restraint": .24, "deterrence": .91, "channel": .25,
                               "attribution": .58, "legitimacy": .52, "readiness": .72},
    "quiet_channel_first": {"restraint": .92, "deterrence": .22, "channel": .94,
                             "attribution": .42, "legitimacy": .38, "readiness": .28},
    "resilience_and_calibrated_deterrence": {"restraint": .76, "deterrence": .75, "channel": .61,
                                               "attribution": .75, "legitimacy": .76, "readiness": .72},
    "maximal_visible_deterrence": {"restraint": .18, "deterrence": .96, "channel": .18,
                                    "attribution": .62, "legitimacy": .55, "readiness": .92},
    "hold_current_posture": {"restraint": .84, "deterrence": .36, "channel": .57,
                              "attribution": .62, "legitimacy": .58, "readiness": .36},
    "classified_crossparty_ladder": {"restraint": .75, "deterrence": .67, "channel": .60,
                                      "attribution": .81, "legitimacy": .93, "readiness": .63},
    "union_only_security_line": {"restraint": .42, "deterrence": .80, "channel": .34,
                                  "attribution": .68, "legitimacy": .46, "readiness": .71},
    "minimal_parliamentary_exposure": {"restraint": .71, "deterrence": .38, "channel": .55,
                                        "attribution": .52, "legitimacy": .25, "readiness": .41},
}


def policy_vector(decisions: list[dict]) -> dict[str, dict[str, float]]:
    result = {}
    for stage in ("S1", "S2", "S3"):
        rows = [row["policy_levers"] for row in decisions if row["stage"] == stage]
        if not rows:
            rows = [row["policy_levers"] for row in decisions]
        result[stage] = {key: round(sum(row[key] for row in rows) / len(rows), 3)
                         for key in rows[0]}
    return result


def _weighted_event(rng: random.Random, rows: list[tuple[str, float]]) -> str:
    draw = rng.random() * sum(weight for _, weight in rows)
    for name, weight in rows:
        draw -= weight
        if draw <= 0:
            return name
    return rows[-1][0]


def simulate_path(seed: int, policies: dict[str, dict[str, float]], weeks: int = 52) -> dict:
    """One contingent history with independent evidence gates and one-level-per-step movement."""
    rng = random.Random(seed)
    level, crisis = 1, .52
    attribution = SNAPSHOT["attribution_confidence"]
    channel_operability = SNAPSHOT["communication_channels"]  # can messages get through?
    defensive_posture = SNAPSHOT["defensive_posture"]
    attack_preparation = SNAPSHOT["attack_preparation"]
    nuclear_posture = SNAPSHOT["nuclear_posture"]
    article_4 = article_5 = False
    calm_steps = 0
    first = {"S2": None, "S3": None, "S4": None, "S5": None}
    trace, checkpoints, institutions = [], {}, {}
    for week in range(1, weeks + 1):
        policy = policies["S1" if level <= 1 else "S2" if level == 2 else "S3"]
        rows = [
            ("no_new_adverse_evidence", .46 + .13 * policy["restraint"]),
            ("negative_evidence", .065 + .055 * policy["attribution"]),
            ("ambiguous_hybrid_incident", .20 + .11 * crisis),
            ("confirmed_state_linked_attack", .060 + .055 * crisis),
            ("lethal_attributed_hybrid_attack", .010 + .020 * crisis),
            ("major_infrastructure_attack", .006 + .015 * crisis),
            ("dangerous_military_contact", .030 + .035 * attack_preparation),
            ("direct_force_casualties", .003 + .012 * attack_preparation * max(.2, crisis)),
            ("missile_on_nato_territory", .0015 + .006 * attack_preparation),
            ("follow_on_armed_strike", .001 + .010 * max(0, level - 2)),
            ("sustained_exchange", .0005 + .008 * max(0, level - 2)),
            ("channel_technical_failure", .030 + .040 * (1 - policy["channel"])),
            ("channel_restoration", .035 + .070 * policy["channel"]),
            ("nuclear_rhetoric", .055),
            ("verified_nuclear_posture_change", .001 + .005 * max(0, level - 3)),
        ]
        event = _weighted_event(rng, rows)
        before = level
        qualifying = None

        # CRISIS_DECAY always operates absent a new qualifying event.
        crisis = max(0, crisis - (.018 + .018 * policy["restraint"]))
        attribution = max(0, attribution - .006)
        calm_steps += 1
        if event == "negative_evidence":
            attribution = max(0, attribution - (.16 + .12 * policy["attribution"]))
            crisis = max(0, crisis - .11)
        elif event == "ambiguous_hybrid_incident":
            crisis = min(1, crisis + .055)
            attribution = min(1, attribution + .015)
            calm_steps = 0
        elif event == "confirmed_state_linked_attack":
            crisis = min(1, crisis + .12)
            attribution = min(1, attribution + .10)
            calm_steps = 0
            if level == 1 and crisis > .69: qualifying = "S1_TO_S2_REPEATED_ATTRIBUTED_ATTACK"
        elif event in {"lethal_attributed_hybrid_attack", "major_infrastructure_attack"}:
            crisis = min(1, crisis + .23)
            attribution = min(1, attribution + .08)
            calm_steps = 0
            if level == 1 and attribution >= .65: qualifying = "S1_TO_S2_SEVERE_ATTRIBUTED_ATTACK"
        elif event == "dangerous_military_contact":
            crisis = min(1, crisis + .11)
            attack_preparation = min(1, attack_preparation + .025)
            calm_steps = 0
        elif event in {"direct_force_casualties", "missile_on_nato_territory"}:
            crisis = min(1, crisis + .28)
            calm_steps = 0
            if level == 2: qualifying = "S2_TO_S3_DIRECT_KINETIC_EVENT"
            elif level == 1: qualifying = "S1_TO_S2_DIRECT_ATTACK_CRISIS"  # cannot skip S2
        elif event in {"follow_on_armed_strike", "sustained_exchange"}:
            crisis = min(1, crisis + .25)
            calm_steps = 0
            if level == 3: qualifying = "S3_TO_S4_NEW_FOLLOW_ON_ATTACK"
        elif event == "channel_technical_failure":
            channel_operability = max(0, channel_operability - .20)
            crisis = min(1, crisis + .05)
        elif event == "channel_restoration":
            channel_operability = min(1, channel_operability + .20)
            # No assumption that either side agrees; only that information can pass.
        elif event == "nuclear_rhetoric":
            crisis = min(1, crisis + .018)
        elif event == "verified_nuclear_posture_change":
            nuclear_posture = min(1, nuclear_posture + .32)
            if level == 4 and nuclear_posture >= .50:
                qualifying = "S4_TO_S5_VERIFIED_NUCLEAR_POSTURE"

        if level == 0 and qualifying is None and event in {
            "confirmed_state_linked_attack", "lethal_attributed_hybrid_attack",
            "major_infrastructure_attack", "dangerous_military_contact",
            "direct_force_casualties", "missile_on_nato_territory",
        }:
            qualifying = "S0_TO_S1_NEW_ADVERSE_SECURITY_EVENT"

        defensive_posture = min(1, max(0, defensive_posture + .012 * policy["readiness"] - .006))
        attack_preparation = min(1, max(0, attack_preparation + .008 * (1-policy["restraint"]) - .004))

        # Institutions are responses to facts, not definitions of S-levels.
        if not article_4 and level >= 2 and rng.random() < .20 + .40 * policy["legitimacy"]:
            article_4 = True
        if not article_5 and level >= 3 and event in {"missile_on_nato_territory", "follow_on_armed_strike",
                                                      "sustained_exchange"} and rng.random() < .25:
            article_5 = True

        if qualifying:
            level = min(5, level + 1)  # strict: never more than one level per timestep
        elif ((level == 1 and calm_steps >= 8 and crisis < .28)
              or (level >= 2 and calm_steps >= 5 and crisis < .36)):
            level = max(0, level - 1)
            calm_steps = 0

        for idx, key in ((2, "S2"), (3, "S3"), (4, "S4"), (5, "S5")):
            if level >= idx and first[key] is None: first[key] = week
        if before != level or event not in {"no_new_adverse_evidence", "ambiguous_hybrid_incident"}:
            trace.append({"week": week, "event": event, "qualifying_event": qualifying,
                          "from": STATES[before], "to": STATES[level], "article_4": article_4,
                          "article_5": article_5, "crisis": round(crisis, 3),
                          "attribution": round(attribution, 3), "channel_operability": round(channel_operability, 3),
                          "defensive_posture": round(defensive_posture, 3),
                          "attack_preparation": round(attack_preparation, 3)})
        if week in (13, 26, 52):
            checkpoints[str(week)] = STATES[level]
            institutions[str(week)] = {"article_4": article_4, "article_5": article_5}
    return {"final": STATES[level], "checkpoints": checkpoints, "institutions": institutions,
            "first_passage": first, "trace": trace}


def run_ensemble(master_seed: int, policy: dict[str, dict[str, float]], runs: int) -> dict:
    rng = random.Random(master_seed ^ 0x5A17D0)
    counts = {"13": Counter(), "26": Counter(), "52": Counter()}
    institutional_counts = {"13": Counter(), "26": Counter(), "52": Counter()}
    passages = defaultdict(list)
    representatives = {}
    for _ in range(runs):
        row = simulate_path(rng.getrandbits(63), policy)
        for week in counts: counts[week][row["checkpoints"][week]] += 1
        for week in institutional_counts:
            for key, value in row["institutions"][week].items():
                if value: institutional_counts[week][key] += 1
        for key, value in row["first_passage"].items():
            if value is not None: passages[key].append(value)
        representatives.setdefault(row["final"], row["trace"])
    return {
        "runs": runs,
        "interpretation": "conditional model-path frequency; not a real-world probability",
        "checkpoints": {week: {state: round(counter[state] / runs, 4) for state in STATES}
                        for week, counter in counts.items()},
        "institutional_responses": {week: {key: round(counter[key] / runs, 4)
                                             for key in ("article_4", "article_5")}
                                    for week, counter in institutional_counts.items()},
        "first_passage": {key: {"count": len(values),
                                     "median_week": (sorted(values)[len(values)//2] if values else None),
                                     "earliest_week": min(values) if values else None}
                          for key, values in passages.items()},
        "representatives": representatives,
    }


def polling_series(decisions: list[dict], parties: dict) -> list[dict]:
    latent = {"Union": 19.0, "AfD": 26.0, "SPD": 14.0, "Greens": 16.0}
    rows = [{"node": "T0 survey anchor", "latent": dict(latent), "nowcast": dict(latent)}]
    afd_line = parties["AFD"]["chosen_action"]
    for index, decision in enumerate(decisions, 1):
        lever = decision["policy_levers"]
        # Narrative-mediated response: competence, restraint and opposition differentiation.
        union = .24 * (lever["legitimacy"] - .5) + .16 * (lever["deterrence"] - .5)
        afd = .16 * (.5 - lever["legitimacy"]) + (.10 if afd_line == "challenge_attribution_dialogue_first" else 0)
        spd = .08 * (lever["restraint"] - .5)
        greens = .07 * (lever["legitimacy"] - .5)
        for key, delta in (("Union", union), ("AfD", afd), ("SPD", spd), ("Greens", greens)):
            latent[key] = round(latent[key] + delta, 3)
        nowcast = {key: round(value * 2) / 2 for key, value in latent.items()}
        rows.append({"node": f"D{index} {decision['actor']}", "latent": dict(latent), "nowcast": nowcast})
    return rows


def pss_series(pss: dict, decisions: list[dict]) -> list[dict]:
    current = {actor: row["pressure"] for actor, row in pss["initial"].items()}
    rows = [{"node": "T0", "values": dict(current)}]
    for actor, update in pss["trigger_updates"].items():
        current[actor] = update["state"]["pressure"]
    rows.append({"node": "Kaliningrad warning", "values": dict(current)})
    for row in decisions:
        current[row["actor"]] = row["pss_after"]["pressure"]
        rows.append({"node": row["node"], "values": dict(current)})
    return rows


def line_svg(rows: list[dict], keys: list[str], value_key: str, title: str,
             y_min: float, y_max: float, percent: bool = False) -> str:
    width, height, left, top, bottom = 920, 360, 68, 40, 62
    colors = ["#8f2d32", "#315e76", "#8a6a20", "#59734a", "#76527a", "#444"]
    inner_w, inner_h = width-left-30, height-top-bottom
    xs = [left + (inner_w * i / max(1, len(rows)-1)) for i in range(len(rows))]
    def yy(v): return top + inner_h * (1 - (v-y_min)/(y_max-y_min))
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
           '<rect width="100%" height="100%" fill="#f6f1e7"/>',
           f'<text x="{left}" y="25" font-family="Georgia" font-size="18">{escape(title)}</text>']
    for i in range(5):
        value = y_min + (y_max-y_min)*i/4
        y = yy(value)
        out += [f'<line x1="{left}" y1="{y:.1f}" x2="{width-30}" y2="{y:.1f}" stroke="#c8bbaa"/>',
                f'<text x="{left-8}" y="{y+4:.1f}" text-anchor="end" font-size="11">{value:.1f}</text>']
    for idx, key in enumerate(keys):
        values = [row[value_key][key] for row in rows]
        points = " ".join(f"{x:.1f},{yy(v):.1f}" for x, v in zip(xs, values))
        out.append(f'<polyline points="{points}" fill="none" stroke="{colors[idx]}" stroke-width="3"/>')
        out.append(f'<text x="{left+idx*120}" y="{height-12}" fill="{colors[idx]}" font-size="12">{escape(key)}</text>')
    for x, row in zip(xs, rows):
        label = str(row["node"])[:18]
        out.append(f'<text x="{x:.1f}" y="{height-bottom+19}" transform="rotate(28 {x:.1f} {height-bottom+19})" font-size="9">{escape(label)}</text>')
    out.append('</svg>')
    return "".join(out)


def _table_checkpoint(ensemble: dict, week: str) -> str:
    cells = "".join(f"<tr><td>{escape(state)}</td><td>{ensemble['checkpoints'][week][state]*100:.2f}%</td></tr>"
                    for state in STATES)
    return f"<table><thead><tr><th>State at week {week}</th><th>path share</th></tr></thead><tbody>{cells}</tbody></table>"


def render_report(payload: dict, arcana_trace: dict) -> str:
    decisions = payload["government_decisions"]
    decision_html = []
    for row in decisions:
        score_rows = "".join(
            f"<tr><td>{escape(key)}</td><td>{vals['normalized']:.3f}</td><td>{vals['total']:.3f}</td>"
            f"<td>{row['state_utility_adjustments'].get(key, 0):+.3f}</td></tr>"
            for key, vals in row["scores"].items())
        decision_html.append(
            f"<article><h3>{escape(row['stage'])} · {escape(row['actor'])}: {escape(row['prompt'])}</h3>"
            f"<p>Rational: <b>{escape(row['rational_choice'])}</b> → final: <b>{escape(row['chosen_action'])}</b>"
            f" · ARCANA changed choice: {row['arcana_changed_choice']}</p>"
            f"<table><tr><th>Action</th><th>normalized</th><th>persona raw</th><th>state utility Δ</th></tr>{score_rows}</table></article>")
    party_rows = "".join(f"<tr><td>{party}</td><td>{escape(row['chosen_action'])}</td></tr>"
                         for party, row in payload["party_collectives"].items())
    rep = payload["ensemble"]["representatives"]
    rep_html = "".join(
        f"<details><summary>{escape(state)}</summary><pre>{escape(json.dumps(trace[:18], ensure_ascii=False, indent=2))}</pre></details>"
        for state, trace in rep.items())
    arcana_fragment = ArcanaVisualReportRenderer().render_fragment(arcana_trace, title="ARCANA — German–Russian risk chain")
    return f'''<!doctype html><html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Germany–Russia risk sandbox</title><style>
body{{margin:0;background:#eee8dc;color:#27221d;font:16px/1.55 system-ui,sans-serif}}main{{max-width:1180px;margin:auto;padding:32px}}h1,h2,h3{{font-family:Georgia,serif;font-weight:500}}header{{padding:80px 0;border-bottom:1px solid #bfb3a3}}.badge{{display:inline-block;padding:5px 9px;border:1px solid #8f2d32;color:#8f2d32}}section{{padding:30px 0;border-bottom:1px solid #bfb3a3}}table{{border-collapse:collapse;width:100%;margin:12px 0}}th,td{{padding:8px;border-bottom:1px solid #cfc4b5;text-align:left}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:18px}}article{{background:#f8f4ec;padding:16px}}img{{max-width:100%;height:auto}}pre{{overflow:auto;background:#26221d;color:#eee6da;padding:12px}}a{{color:#315e76}}.warn{{border-left:4px solid #8f2d32;padding-left:14px}}
{ARCANA_STYLE}</style></head><body><main><header><span class="badge">FORWARD SANDBOX · ARCANA ON</span><h1>德俄会不会直接开战，以及门槛何时可能被跨过</h1>
<p>起点 2026-10-01：S1 INTENSIFIED HYBRID CONFRONTATION。Seed {payload['seed']} · {payload['ensemble']['runs']} 条条件路径。</p></header>
<section><h2>结论先行</h2><p class="warn">本模型不输出“开战概率”或确定日期。它输出的是：在这套明确假设下，模拟路径有多少跨过 S2/S3/S4 门槛，以及最早/典型发生在第几周。</p>
<p><b>Minimum war path:</b> S1 →（独立的严重且可归责事件）→ S2 →（下一 timestep 的正规军直接伤亡或导弹事件）→ S3 →（再一次 follow-on strike / sustained exchange）→ S4。每个 timestep 最多移动一级；同一证据不能重复消费。Article 4/5 是并行制度状态，不定义 S-level。核言论本身永远不能进入 S5。</p></section>
<section><h2>T0 reality / model / black boxes</h2><div class="grid"><article><h3>Observed</h3><p>德国已公开归责莱比锡未遂袭击；NATO称没有迫近攻击迹象；Wadephul–Lavrov渠道仍存在；俄方公开使用核威胁语言。</p></article><article><h3>Model assumptions</h3><pre>{escape(json.dumps(payload['snapshot'], ensure_ascii=False, indent=2))}</pre></article><article><h3>Unknown black boxes</h3><p>Kremlin授权层级、未公开军情、俄军内部控制质量、下一次事件地点与误判链。</p></article></div></section>
<section><h2>德国政府内部处理</h2>{''.join(decision_html)}</section>
<section><h2>党派集合体</h2><p>这些不是虚构人物卡，而是党纲、共同组织利益和当前朝野角色的合成。</p><table><tr><th>Party</th><th>Collective line</th></tr>{party_rows}</table></section>
<section><h2>3 / 6 / 12个月路径分布</h2><p>以下是模型路径占比，不是现实世界事件概率。危机强度在没有新证据时持续衰减，负面证据会降低归责置信度。</p><div class="grid">{_table_checkpoint(payload['ensemble'],'13')}{_table_checkpoint(payload['ensemble'],'26')}{_table_checkpoint(payload['ensemble'],'52')}</div>
<h3>Institutional responses（与S-level分离）</h3><pre>{escape(json.dumps(payload['ensemble']['institutional_responses'], ensure_ascii=False, indent=2))}</pre>
<pre>{escape(json.dumps(payload['ensemble']['first_passage'], ensure_ascii=False, indent=2))}</pre></section>
<section><h2>实时 PSS pressure</h2><img src="pss_pressure.svg" alt="PSS pressure chart"></section>
<section><h2>实时民调 nowcast</h2><p>危机事实不直接改党派支持；变化经由政府动作和党派叙事的简化响应层。不是调查结果。</p><img src="polling.svg" alt="Polling nowcast chart"></section>
<section><h2>Representative conditional paths</h2>{rep_html}</section>
<section><h2>Sources</h2><ul><li><a href="https://www.bundesregierung.de/breg-de/service/fragen-und-anworten/reaktion-angriff-leipzig-2451522">Bundesregierung: Leipzig attribution</a></li><li><a href="https://www.nato.int/en/news-and-events/events/transcripts/2026/09/30/remarks-by-nato-secretary-general-at-euronews-defence--space-summit">NATO: no imminent threat</a></li><li><a href="https://apnews.com/article/2e7fa731f850d3ec92fa8a8641046276">AP: Wadephul–Lavrov channel</a></li><li><a href="https://www.afd.de/wahlprogramm-aussen-verteidigungspolitik/">AfD foreign/defence programme</a></li></ul></section>
</main>{arcana_fragment}<script>{ARCANA_SCRIPT}</script></body></html>'''


def run(seed: int, runs: int, arcana_enabled: bool) -> dict:
    decisions, pss, arcana = run_decisions(seed, arcana_enabled)
    parties = run_party_round()
    policy = policy_vector(decisions)
    ensemble = run_ensemble(seed, policy, runs)
    polls = polling_series(decisions, parties)
    pss_rows = pss_series(pss, decisions)
    payload = {"schema_version": "germany-russia-risk-1.0", "seed": seed,
               "arcana_enabled": arcana_enabled, "snapshot": SNAPSHOT,
               "government_decisions": decisions, "party_collectives": parties,
               "policy_vector": policy, "ensemble": ensemble,
               "polling": polls, "pss_pressure": pss_rows,
               "caveat": "conditional path distribution, not forecast probability"}
    OUT.mkdir(parents=True, exist_ok=True)
    arcana_trace = ArcanaReportTraceCompiler().compile(arcana["audits"]) if arcana_enabled else {
        "schema_version": "arcana-report-trace-1.0", "actors": {}, "nodes": [],
        "dictionary": {"cards": {}, "rules": {}}, "render_contract": {}}
    (OUT / "full_trace.json").write_text(json.dumps({**payload, "arcana_full": arcana}, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "report_trace.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "arcana_report_trace.json").write_text(json.dumps(arcana_trace, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    (OUT / "pss_pressure.svg").write_text(line_svg(pss_rows, ["Merz", "Frei", "Wadephul"], "values", "PSS pressure · 0–1", 0, 1), encoding="utf-8")
    poll_rows = [{"node": row["node"], "values": row["nowcast"]} for row in polls]
    (OUT / "polling.svg").write_text(line_svg(poll_rows, ["Union", "AfD", "SPD", "Greens"], "values", "Party nowcast · percent", 10, 30, True), encoding="utf-8")
    (OUT / "report.html").write_text(render_report(payload, arcana_trace), encoding="utf-8")
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--runs", type=int, default=10000)
    parser.add_argument("--arcana", action="store_true")
    args = parser.parse_args()
    seed = args.seed if args.seed is not None else secrets.randbits(63)
    payload = run(seed, max(100, args.runs), args.arcana)
    print(json.dumps({"seed": seed, "policy_vector": payload["policy_vector"],
                      "checkpoints": payload["ensemble"]["checkpoints"],
                      "report": str(OUT / "report.html")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
