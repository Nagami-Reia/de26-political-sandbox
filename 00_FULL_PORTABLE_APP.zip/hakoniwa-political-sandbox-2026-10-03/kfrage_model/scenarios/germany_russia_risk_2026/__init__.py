"""Forward Germany–Russia escalation-risk sandbox from 2026-10-01."""
