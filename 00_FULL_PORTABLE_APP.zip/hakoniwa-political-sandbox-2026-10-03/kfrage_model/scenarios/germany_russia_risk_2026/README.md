# Germany–Russia escalation risk, 2026-10-01

Forward sandbox from a verified `S1 INTENSIFIED_HYBRID_CONFRONTATION` snapshot.
It does not predict a war date. It reports state-transition frequencies and
first-passage timing under explicit model contingencies.

Core individual PSS/decision actors: Merz, Wadephul and Frei. Other German
parties are collective programme/strategy actors, not invented personalities.
ARCANA is optional and enabled in the saved baseline run.

```bash
python -m kfrage_model.scenarios.germany_russia_risk_2026.run_scenario \
  --arcana --seed 20261001 --runs 10000
```
