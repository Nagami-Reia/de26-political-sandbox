"""Time-bounded and condition-bounded political office assignments.

Temporary offices belong to the objective world, not to a persona card.  An
actor may believe that an assignment will last, but the registry removes it as
soon as the encoded institutional termination condition is satisfied.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from typing import Mapping


@dataclass(frozen=True, slots=True)
class TemporaryOfficeAssignment:
    assignment_id: str
    actor: str
    office: str
    begins_at: str
    status: str = "ACTING"
    ends_when: str = "SUCCESSOR_FORMALLY_ELECTED"
    authority_scope: tuple[str, ...] = ()
    source_status: str = "OBSERVED_FACT"
    ended_at: str | None = None
    successor: str | None = None

    @property
    def active(self) -> bool:
        return self.ended_at is None


class TemporaryOfficeRegistry:
    """Deterministic objective registry for provisional office-holding."""

    def __init__(self, assignments: tuple[TemporaryOfficeAssignment, ...] = ()) -> None:
        self._assignments = {item.assignment_id: item for item in assignments}

    def assign(self, assignment: TemporaryOfficeAssignment) -> None:
        if assignment.assignment_id in self._assignments:
            raise ValueError(f"Duplicate temporary office: {assignment.assignment_id}")
        self._assignments[assignment.assignment_id] = assignment

    def active_offices(self, actor: str) -> tuple[str, ...]:
        return tuple(
            item.office for item in self._assignments.values()
            if item.actor == actor and item.active
        )

    def resolve_successor(
        self,
        assignment_id: str,
        *,
        successor: str,
        elected_at: str,
        procedure: str,
    ) -> TemporaryOfficeAssignment:
        current = self._assignments[assignment_id]
        if not current.active:
            raise ValueError(f"Temporary office already ended: {assignment_id}")
        if procedure != current.ends_when:
            raise ValueError(
                f"Termination procedure {procedure!r} does not satisfy {current.ends_when!r}"
            )
        ended = replace(current, ended_at=elected_at, successor=successor)
        self._assignments[assignment_id] = ended
        return ended

    def apply_to_offices(
        self,
        permanent_offices: Mapping[str, tuple[str, ...]],
    ) -> dict[str, tuple[str, ...]]:
        merged = {actor: tuple(offices) for actor, offices in permanent_offices.items()}
        for item in self._assignments.values():
            if item.active:
                merged[item.actor] = tuple(dict.fromkeys((*merged.get(item.actor, ()), item.office)))
        return merged

    def payload(self) -> dict:
        return {
            "assignments": [asdict(item) | {"active": item.active}
                            for item in self._assignments.values()]
        }

