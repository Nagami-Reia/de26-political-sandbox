"""Mandatory end-of-scenario chart contract.

The simulation trace is the source of truth. This module compiles it into two
chart-ready series that every full scenario must expose: live PSS pressure for
each persona card actually used, and live polling after every node.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from html import escape
from typing import Mapping, Sequence

from .arcana.reporting import ArcanaVisualReportRenderer, SCRIPT as ARCANA_SCRIPT, STYLE as ARCANA_STYLE
from .arcana.report_trace import ArcanaReportTraceCompiler
from .political_state_system import quantize3


@dataclass(frozen=True)
class ScenarioReportingPolicy:
    require_pss_pressure_chart: bool = True
    require_polling_chart: bool = True
    fail_on_missing: bool = True

    @classmethod
    def diagnostics_only(cls) -> "ScenarioReportingPolicy":
        """Explicit opt-out for narrow unit tests, never for scenario reports."""
        return cls(require_polling_chart=False, fail_on_missing=False)


class ScenarioReportCompiler:
    def __init__(
        self,
        initial_pss: Mapping[str, Mapping[str, float]],
        policy: ScenarioReportingPolicy,
    ) -> None:
        self.initial_pss = {actor: dict(state) for actor, state in initial_pss.items()}
        self.policy = policy

    @staticmethod
    def _used_actors(trace: Sequence[Mapping[str, object]]) -> tuple[str, ...]:
        used: set[str] = set()
        for turn in trace:
            owner = turn.get("decision_maker")
            if isinstance(owner, str):
                used.add(owner)
            for actor in turn.get("actors_used", ()):
                if isinstance(actor, str):
                    used.add(actor)
        return tuple(sorted(used))

    def _pressure_series(
        self,
        trace: Sequence[Mapping[str, object]],
        actors: Sequence[str],
    ) -> list[dict]:
        points: list[dict] = []
        for actor in actors:
            baseline = self.initial_pss.get(actor)
            if baseline is not None and "pressure" in baseline:
                points.append({
                    "step": 0,
                    "node": "baseline",
                    "actor": actor,
                    "value": float(baseline["pressure"]),
                    "unit": "index_0_1",
                })
            for step, turn in enumerate(trace, start=1):
                states = turn.get("all_actor_pss_after", {})
                state = states.get(actor) if isinstance(states, Mapping) else None
                if isinstance(state, Mapping) and "pressure" in state:
                    points.append({
                        "step": step,
                        "node": str(turn.get("node", f"step_{step}")),
                        "timestamp": turn.get("calendar_date"),
                        "actor": actor,
                        "value": float(state["pressure"]),
                        "unit": "index_0_1",
                    })
        return points

    @staticmethod
    def _polling_payload(event_observers: Sequence[object]) -> tuple[list[dict], list[dict]]:
        series: list[dict] = []
        events: list[dict] = []
        for observer_index, observer in enumerate(event_observers):
            to_dict = getattr(observer, "to_dict", None)
            if not callable(to_dict):
                continue
            payload = to_dict()
            if "polling_contract" not in payload:
                continue
            for event in payload.get("events", ()):
                events.append({"observer": observer_index, **dict(event)})
            for point in payload.get("support_points", ()):
                series.append({"observer": observer_index, **dict(point)})
        return series, events

    @staticmethod
    def _line_chart_svg(
        points: Sequence[Mapping[str, object]],
        *,
        series_field: str,
        title: str,
        y_max: float,
        y_label: str,
    ) -> str:
        width, height = 900, 380
        left, right, top, bottom = 70, 24, 58, 48
        plot_w = width - left - right
        plot_h = height - top - bottom
        max_step = max((int(row["step"]) for row in points), default=1)
        max_step = max(1, max_step)
        colors = ("#3974d8", "#d26a32", "#2b936f", "#8d61c5", "#be4666", "#8a761c", "#27858e")
        groups: dict[str, list[Mapping[str, object]]] = {}
        for row in points:
            groups.setdefault(str(row.get(series_field, "series")), []).append(row)
        svg = [
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
            f'viewBox="0 0 {width} {height}" role="img" aria-label="{escape(title)}">',
            '<rect width="100%" height="100%" fill="#ffffff"/>',
            f'<text x="{left}" y="28" font-family="system-ui,sans-serif" font-size="18" '
            f'font-weight="600" fill="#172033">{escape(title)}</text>',
        ]
        for tick in range(6):
            value = y_max * tick / 5
            y = top + plot_h - plot_h * tick / 5
            label = f"{value:.3f}" if y_max == 1.0 else f"{value:.0f}"
            svg.extend((
                f'<line x1="{left}" y1="{y:.1f}" x2="{width-right}" y2="{y:.1f}" stroke="#d9dee8"/>',
                f'<text x="{left-10}" y="{y+4:.1f}" text-anchor="end" font-family="system-ui,sans-serif" '
                f'font-size="11" fill="#687083">{label}</text>',
            ))
        for step in range(max_step + 1):
            x = left + plot_w * step / max_step
            svg.extend((
                f'<line x1="{x:.1f}" y1="{top}" x2="{x:.1f}" y2="{top+plot_h}" stroke="#eef1f5"/>',
                f'<text x="{x:.1f}" y="{top+plot_h+22}" text-anchor="middle" font-family="system-ui,sans-serif" '
                f'font-size="11" fill="#687083">{step}</text>',
            ))
        for index, (series, rows) in enumerate(sorted(groups.items())):
            color = colors[index % len(colors)]
            rows = sorted(rows, key=lambda row: int(row["step"]))
            coords = []
            for row in rows:
                x = left + plot_w * int(row["step"]) / max_step
                value = max(0.0, min(y_max, float(row["value"])))
                y = top + plot_h - plot_h * value / y_max
                coords.append((x, y))
            path = " ".join(
                f'{"M" if i == 0 else "L"}{x:.1f},{y:.1f}'
                for i, (x, y) in enumerate(coords)
            )
            svg.append(f'<path d="{path}" fill="none" stroke="{color}" stroke-width="2.4"/>')
            for x, y in coords:
                svg.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="3.6" fill="#fff" stroke="{color}" stroke-width="2"/>')
            legend_x = left + (index % 4) * 195
            legend_y = 45 + (index // 4) * 16
            svg.extend((
                f'<line x1="{legend_x}" y1="{legend_y}" x2="{legend_x+18}" y2="{legend_y}" stroke="{color}" stroke-width="3"/>',
                f'<text x="{legend_x+24}" y="{legend_y+4}" font-family="system-ui,sans-serif" font-size="11" '
                f'fill="#172033">{escape(series)}</text>',
            ))
        svg.extend((
            f'<line x1="{left}" y1="{top+plot_h}" x2="{width-right}" y2="{top+plot_h}" stroke="#687083"/>',
            f'<line x1="{left}" y1="{top}" x2="{left}" y2="{top+plot_h}" stroke="#687083"/>',
            f'<text x="{width/2:.1f}" y="{height-10}" text-anchor="middle" font-family="system-ui,sans-serif" '
            f'font-size="12" fill="#172033">决策/事件节点</text>',
            f'<text x="18" y="{top+plot_h/2:.1f}" text-anchor="middle" transform="rotate(-90 18 {top+plot_h/2:.1f})" '
            f'font-family="system-ui,sans-serif" font-size="12" fill="#172033">{escape(y_label)}</text>',
            '</svg>',
        ))
        return "".join(svg)

    def compile(
        self,
        trace: Sequence[Mapping[str, object]],
        event_observers: Sequence[object],
    ) -> dict:
        actors = self._used_actors(trace)
        pressure_points = self._pressure_series(trace, actors)
        polling_points, polling_events = self._polling_payload(event_observers)
        arcana_audit = []
        for step, turn in enumerate(trace, start=1):
            arcana = turn.get("arcana")
            if isinstance(arcana, Mapping):
                arcana_audit.append({
                    "step": step,
                    "node": turn.get("node"),
                    "decision_maker": turn.get("decision_maker"),
                    **dict(arcana),
                    "chosen_action": turn.get("chosen_action"),
                    "pss_after": turn.get("pss_after"),
                    "all_actor_pss_after": turn.get("all_actor_pss_after"),
                    "operational_feedback": turn.get("operational_feedback"),
                })
        enabled_arcana = [row for row in arcana_audit if row.get("status") == "RUN"]
        arcana_report_trace = ArcanaReportTraceCompiler().compile(enabled_arcana)
        errors: list[str] = []

        expected_steps = set(range(0, len(trace) + 1))
        for actor in actors:
            actor_steps = {row["step"] for row in pressure_points if row["actor"] == actor}
            if self.policy.require_pss_pressure_chart and actor_steps != expected_steps:
                errors.append(
                    f"PSS pressure series for {actor} has steps {sorted(actor_steps)}, "
                    f"expected {sorted(expected_steps)}"
                )
        if self.policy.require_pss_pressure_chart and not actors:
            errors.append("scenario used no persona cards")

        poll_steps = {int(row["step"]) for row in polling_points}
        if self.policy.require_polling_chart and not polling_points:
            errors.append("missing realtime polling series")
        elif self.policy.require_polling_chart and not expected_steps.issubset(poll_steps):
            errors.append(
                f"polling series has steps {sorted(poll_steps)}, expected at least "
                f"{sorted(expected_steps)}"
            )

        report = quantize3({
            "schema_version": "scenario-report-1.0",
            "valid": not errors,
            "errors": errors,
            "used_persona_cards": list(actors),
            "chart_contract": {
                "required_at_end_of_every_scenario": True,
                "x_axis": "decision/event step, starting at baseline step 0",
                "first_quadrant_only": True,
                "pss_pressure": {
                    "y_axis": "0.000..1.000",
                    "one_series_per_used_persona_card": True,
                },
                "polling": {
                    "y_axis": "0..100 percent",
                    "latent_and_nowcast_must_remain_separate": True,
                    "causality_warning": "temporal adjacency is not causal attribution",
                },
            },
            "pss_pressure_series": pressure_points,
            "polling_series": polling_points,
            "polling_events": polling_events,
            "arcana_report_trace": arcana_report_trace,
            "charts": {
                "pss_pressure_svg": self._line_chart_svg(
                    pressure_points,
                    series_field="actor",
                    title="参与人物实时政治压力（PSS）",
                    y_max=1.0,
                    y_label="压力 0.000–1.000",
                ),
                "polling_svg": self._line_chart_svg(
                    polling_points,
                    series_field="series_key",
                    title="实时民调：潜在支持与模型即时估计",
                    y_max=100.0,
                    y_label="支持率 %",
                ),
            },
            "policy": asdict(self.policy),
        })
        if errors and self.policy.fail_on_missing:
            raise RuntimeError("Scenario reporting contract failed: " + "; ".join(errors))
        return report


def render_arcana_embed(report: Mapping[str, object]) -> str:
    """Render compact report JSON only when an HTML document is requested."""
    compact = report.get("arcana_report_trace", {})
    if not isinstance(compact, Mapping) or not compact.get("nodes"):
        return ""
    return (
        f"<style>{ARCANA_STYLE}</style>"
        + ArcanaVisualReportRenderer().render_fragment(compact)
        + f"<script>{ARCANA_SCRIPT}</script>"
    )
