"""Partially observable, multi-horizon, bounded-depth political game engine."""
from __future__ import annotations
from dataclasses import dataclass,field,asdict
from typing import Mapping
from .information_filter import InformationFilter
from .political_state import PoliticalAction,PoliticalState,PressureRule,HORIZONS

@dataclass(frozen=True)
class ActorDecisionModel:
    actor: str
    horizon_weights: Mapping[str,Mapping[str,float]]
    targets: Mapping[str,float]=field(default_factory=dict)
    capital_weights: Mapping[str,float]=field(default_factory=dict)
    pressure_weights: Mapping[str,float]=field(default_factory=dict)
    loss_aversion: float=1.0
    upside_appetite: float=0.0
    irreversibility_aversion: float=0.0
    minimum_feasibility: float=0.0
    hard_minimums: Mapping[str,float]=field(default_factory=dict)
    planning_depth: int=1
    strategic_discount: float=.7
    rule: str="bounded rational expected utility"

@dataclass(frozen=True)
class DecisionNode:
    key: str
    owner: str
    actions: tuple[PoliticalAction,...]
    visible_actors: tuple[str,...]

class StrategicGame:
    def __init__(self,state:PoliticalState,nodes:Mapping[str,DecisionNode],models:Mapping[str,ActorDecisionModel],info:InformationFilter,pressure_rules:tuple[PressureRule,...]=(),event_observers:tuple[object,...]=()):
        self.state=state; self.nodes=dict(nodes); self.models=dict(models); self.info=info; self.pressure_rules=pressure_rules; self.event_observers=event_observers; self.trace=[]

    def evaluate(self,actor:str,action:PoliticalAction,state:PoliticalState):
        m=self.models[actor]; bs=self.info.observe(actor,state,commit=False); rows=[]; total=0.0; rejected=[]
        if action.feasibility<m.minimum_feasibility: rejected.append(f"feasibility<{m.minimum_feasibility}")
        for h in HORIZONS:
            for key,delta in action.effects.get(h,{}).items():
                var=state.variables[key]; belief=bs.beliefs[key]; weight=m.horizon_weights.get(h,{}).get(key,0.0)
                effective=delta*(.5+.5*belief.confidence)
                direct=weight*effective/max(var.scale,1e-9)
                target=m.targets.get(key); target_fit=0.0 if target is None else -abs((belief.estimate+effective)-target)/max(var.scale,1e-9)*abs(weight)*.12
                sigma=action.uncertainty.get(h,{}).get(key,0.0)+(1-belief.confidence)*abs(delta)
                risk=m.loss_aversion*abs(weight)*sigma/max(var.scale,1e-9)*.35
                upside=m.upside_appetite*max(0,direct)*min(1,sigma/max(var.scale,1e-9))
                contribution=direct+target_fit-risk+upside; total+=contribution
                rows.append({"horizon":h,"variable":key,"true_before":var.value,"perceived_before":belief.estimate,"confidence":belief.confidence,"raw_delta":delta,"effective_delta":round(effective,4),"weight":weight,"direct":round(direct,4),"target_fit":round(target_fit,4),"risk_penalty":round(risk,4),"upside_option":round(upside,4),"contribution":round(contribution,4)})
                if h=="immediate" and key in m.hard_minimums and belief.estimate+effective<m.hard_minimums[key]: rejected.append(f"{key}<{m.hard_minimums[key]}")
        capital_rows=[]
        for key,delta in action.capital_delta.items():
            weight=m.capital_weights.get(key,0.0); c=weight*delta/10; total+=c; capital_rows.append({"capital":key,"delta":delta,"weight":weight,"contribution":round(c,4)})
        pressure_rows=[]
        for key,delta in action.pressure_delta.items():
            weight=m.pressure_weights.get(key,0.0); c=weight*delta/10; total+=c; pressure_rows.append({"pressure":key,"delta":delta,"weight":weight,"contribution":round(c,4)})
        irreversible=m.irreversibility_aversion*action.irreversibility; total-=irreversible
        if rejected: total=-1_000_000.0
        return {"actor":actor,"action":action.key,"total_direct":round(total,4),"rejected":rejected,"variable_evaluations":rows,"capital_evaluations":capital_rows,"pressure_evaluations":pressure_rows,"irreversibility_penalty":round(irreversible,4),"rule":m.rule}

    def _score_path(self,actor,path,state):
        score=0.0; discount=self.models[actor].strategic_discount; s=state.clone()
        for i,(_,action) in enumerate(path):
            score+=(discount**(i+1))*self.evaluate(actor,action,s)["total_direct"]
            s.apply(action,self.pressure_rules)
        return score

    def _choose(self,node_key,state,depth,stack=()):
        node=self.nodes[node_key]; owner=node.owner; evaluations={}; paths={}
        for action in node.actions:
            if not state.legal(action): continue
            ev=self.evaluate(owner,action,state); direct=ev["total_direct"]; continuation=0.0; path=[]
            if direct>-999999 and depth>0 and action.next_node and action.next_node not in stack:
                s2=state.clone(); s2.apply(action,self.pressure_rules)
                child=self._choose(action.next_node,s2,depth-1,stack+(node_key,))
                path=child["path"]
                continuation=self._score_path(owner,path,s2)
            ev["continuation_value"]=round(continuation,4); ev["strategic_total"]=round(direct+continuation,4)
            evaluations[action.key]=ev; paths[action.key]=path
        if not evaluations: raise RuntimeError(f"No legal action at {node_key}")
        chosen=max(evaluations,key=lambda k:(evaluations[k]["strategic_total"],k)); action=next(a for a in node.actions if a.key==chosen)
        return {"chosen":action,"evaluations":evaluations,"path":[(node_key,action)]+paths[chosen]}

    def run(self,start_node:str,max_steps:int=20):
        key=start_node
        for _ in range(max_steps):
            node=self.nodes[key]; owner_model=self.models[node.owner]
            # Commit only the view of the actually reached state. Forecast branches
            # use non-committing observations inside evaluate().
            all_views={a:InformationFilter.payload(self.info.observe(a,self.state,commit=True)) for a in node.visible_actors}
            result=self._choose(key,self.state,owner_model.planning_depth)
            all_evals={a:{act.key:self.evaluate(a,act,self.state) for act in node.actions if self.state.legal(act)} for a in node.visible_actors}
            chosen=result["chosen"]; update=self.state.apply(chosen,self.pressure_rules)
            for observer in self.event_observers:
                observer.record(self.state,event_id=f"decision:{key}",actor=node.owner,action=chosen.key,event_kind="actor_decision",resource_changes=update)
            self.trace.append({"node":key,"owner":node.owner,"chosen_action":chosen.key,"owner_strategic_evaluations":result["evaluations"],"forecast_path":[{"node":n,"action":a.key} for n,a in result["path"]],"actor_views":all_views,"all_actor_direct_evaluations":all_evals,"state_update":update})
            if not chosen.next_node: break
            key=chosen.next_node
        return self.payload()

    def payload(self):
        return {"schema_version":"pomdg-2.0","trace":self.trace,"final_state":self.state.payload(),"actor_models":{a:asdict(m) for a,m in self.models.items()},"warning":"Actor beliefs, utilities and branch frequencies are model objects, not observed facts or calibrated probabilities."}
