# 2024 CDU/CSU K-Frage — source notes and evidence boundary

Last calibrated: 2026-09-18. The model cutoff is the public information state immediately before the endogenous 16–17 September decisions. Later retrospectives are used only to describe personality models or to mark black boxes; they do not silently become contemporaneous actor knowledge.

## Evidence labels

- **Observed fact**: an office, public statement, public event, or organization action supported by a contemporaneous or primary source.
- **Model assumption**: a transparent operational mapping from facts to a normalized resource or threshold. It is contestable and belongs in `assumptions.json`.
- **Unknown black box**: private preference, negotiation term, promise, or unobserved network relation. It is never promoted to fact.

## Calibrated timeline

| Date | Evidence status | What is retained | Model use | Source |
|---|---|---|---|---|
| 2024-05-06 | Observed fact | Friedrich Merz was re-elected CDU chair with 89.81%; Carsten Linnemann was elected general secretary with 91.37%. | Strong formal/default and CDU-apparatus resources for Merz; Linnemann is an implementation node, not an independent candidate. | [CDU party conference results](https://www.pt24.cdu.de/wahlen) |
| 2024-08-25 | Observed fact | Söder publicly ruled out a federal black-green coalition under himself; this differentiated him from the black-green state governments led by Wüst and Günther. | Public differentiation and visibility signal only; no inference about private motive. | [Tagesschau retrospective published 17 September, referring to the ARD summer interview](https://www.tagesschau.de/inland/innenpolitik/soeder-merz-108.html) |
| 2024-09-02 | Observed fact | At Gillamoos, Söder said he would not shirk national responsibility, but also said a CSU politician had a chance only if the CDU asked and that he would reach agreement with Merz. | `signal_availability_conditioned_on_CDU_call`; establishes the bridgehead constraint and a stated commitment to bilateral closure. | [Tagesschau, 2 September](https://www.tagesschau.de/inland/innenpolitik/k-frage-soeder-merz-100.html) |
| 2024-09-03 | Observed interpretation, contemporaneous | ARD noted Söder's framing of the selectorate as the two party chairs and that this framing excluded Wüst. | The model records a contest over who belongs in the selectorate; it does not make the framing binding law. | [Tagesschau, 3 September](https://www.tagesschau.de/inland/innenpolitik/kanzerkandidat-union-soeder-merz-100.html) |
| 2024-09-05 | Observed fact | Wüst said the K-question could not be decided by only a few and treated electoral chances as relevant, while not declaring. | Wüst has procedural participation and option value but no automatic federal default. | [RND interview, 5 September](https://www.rnd.de/politik/hendrik-wuest-und-jan-redmann-im-interview-zur-kanzlerfrage-in-der-cdu-OM2VYLLIY5G7PCKOSJOJL555DQ.html) |
| 2024-09-06 | Observed fact | Wüst publicly stressed that CDU/CSU needed unity and no repeat of 2021. | High common-knowledge unity cost before his decision. | [n-tv/dpa, 6 September](https://bilderaws.n-tv.de/politik/Wuest-mahnt-Union-zur-Geschlossenheit-article25210633.html) |
| 2024-09-10 | Observed fact | A contemporaneous report followed all three possible candidates. It described Merz as the natural favorite; Söder signaled availability; Wüst stayed comparatively restrained. | Perceived resource state differs from raw popularity. Public visibility is not equated with institutional viability. | [report München, 10 September](https://www.br.de/fernsehen/das-erste/sendungen/report-muenchen/videos-und-manuskripte/report-cdu-kanzlerkandidat100.html) |
| before 2024-09-16 | Observed fact | Manuel Hagel had publicly described the first-access claim as lying with the party and parliamentary leader and had called Merz the right candidate. | Hagel is a CDU-state signal node that makes a Söder CDU bridgehead less likely. | [dpa/Süddeutsche, 17 September, recalling Hagel's May statement](https://www.sueddeutsche.de/politik/k-frage-in-der-union-zeichen-fuer-geschlossenheit-suedwest-cdu-chef-lobt-wuest-dpa.urn-newsml-dpa-com-20090101-240917-930-234684) |
| 2024-09-16 | **Held out of decision rules; used as comparator** | Wüst said his tasks were in NRW, endorsed Merz, and called on the CSU to support Merz. NRW-CDU was the largest CDU Landesverband. | Target sequence for post-run calibration only: Wüst exits current contest + reallocates NRW signal to Merz. | [ZDF heute, 16 September](https://www.zdfheute.de/politik/deutschland/hendrik-wuest-k-frage-union-100.html) |
| 2024-09-16/17 | **Held out comparator** | CSU-side reaction showed that the Wüst move was not treated as a neutral non-event; Klaus Holetschek said a different procedure had been agreed. | Validates the model's redistribution mechanism: NRW endorsement narrows the Söder path, even though it does not legally decide the nomination. | [BR24 live report](https://www.br.de/nachrichten/deutschland-welt/k-frage-entschieden-merz-und-soeder-treten-vor-die-presse%2CUOc6rxG), [BR24 follow-up](https://www.br.de/nachrichten/bayern/union-und-schwarz-gruen-nach-der-k-frage-die-l-frage%2CUOuGGNL) |
| 2024-09-17 morning | **Held out comparator** | Hagel treated Söder's own prior statement that his place was in Bavaria as closing the path; no strong CDU call for Söder materialized. | Checks the bridgehead mechanism. | [Tagesschau, 17 September](https://www.tagesschau.de/inland/innenpolitik/merz-kanzlerkandidat-union-100.html) |
| 2024-09-17 noon | **Held out comparator** | Merz and Söder appeared jointly; Söder supported Merz and the party bodies were to confirm the proposal. | Target bilateral closure, not a rule. | [Deutschlandfunk, 17 September](https://www.deutschlandfunk.de/soeder-verzichtet-merz-wird-kanzlerkandidat-der-union-dlf-b1ca5ba2-100.html), [BR24 video/report](https://www.br.de/nachrichten/deutschland-welt/k-frage-entschieden-merz-und-soeder-treten-vor-die-presse%2CUOc6rxG) |
| 2024-09-17 | **Held out comparator** | Linnemann and Dobrindt were visibly present as close organizational actors at the joint appearance. | Supports a closure/implementation node after the bilateral choice; it does not prove every detail of the private conversation. | [Tagesspiegel, 17 September](https://www.tagesspiegel.de/politik/merz-machts-union-kurt-ihren-kanzlerkandidaten-12388922.html) |
| 2024-09-17 afternoon | **Held out comparator** | Günther said he would support Merz with all his strength, wanted Merz to become chancellor, and emphasized unity after the unsorted 2021 situation. | Target post-closure synchronization consistent with majority/consensus/operative-responsibility logic. | [NDR, 17 September](https://www.ndr.de/nachrichten/schleswig-holstein/Ministerpraesident-Guenther-will-Merz-nach-allen-Kraeften-unterstuetzen%2Ckanzlerkandidat112.html) |
| 2024-09-28 | Post-closure observed fact | At the NRW party conference, Wüst and the state organization publicly mobilized for Merz. | External check that NRW organizational synchronization persisted after closure. | [CDU NRW, event report](https://www.cdu-nrw.de/46-landesparteitag-der-cdu-nordrhein-westfalen) |

## Office and organization facts

- In the 20th Bundestag, Merz was CDU/CSU parliamentary leader and Thorsten Frei was first parliamentary managing director. This is a formal organizational relation, not a claim that MPs were mechanically controlled. [Bundestag historical handbook, chapter 5.6](https://www.bundestag.de/resource/blob/294002/Kapitel_05_06_Vorstaende_der_Fraktionen_und_Gruppen-pdf.pdf)
- Söder's own public condition—that a CSU candidate needed the CDU to ask—makes the CDU bridgehead a necessary resource in this model. It is not invented from the result.
- NRW-CDU is encoded as a large organizational resource controlled politically, but not as a block of automatic votes. Merz, Linnemann and other federal CDU actors also came from NRW; `NRW_CDU` is therefore a signal/organization node rather than Wüst's personal property.
- The CSU apparatus begins aligned with Söder. Joint closure changes it to `Joint_Merz`, which means acceptance of the joint Union proposal, not absorption into the CDU.

## Project personality evidence

### Wüst

Primary project source: `sources/Hendrik_Wuest_v1.1.txt` (read-only).

The retained rule is exactly the project's formula **Ambition × Kontrolle × Akzeptanz × Timing**. The multiplicative/geometric implementation reflects the source model's claim that a public, binary, irreversible challenge has a high threshold when actors, coalitions and exit routes cannot be sufficiently controlled. The model also retains future option value and the possibility that withdrawal can be an active structuring move.

Supporting interview phrase in `sources/Hendrik_Wuest_采访转写(1).txt`: “Ambition und Akzeptanz miteinander zu verschrauben.” This supports the conjunction but does not identify a numerical coefficient.

### Merz

Primary project sources: `sources/Unvermeidbare, Der - Sara Sievert(1).pdf` and the earlier project model summarized in the referenced conversation.

The model uses **Agency/Gestaltung**, conditional risk acceptance, and institutional default. A later retrospective book reconstruction is used to support the distinction between public calm/default and concern about organizational backing; it is not treated as information known to all actors in September 2024. Its private-process claims remain secondary and partly retrospective.

### Frei

Primary project source: `sources/Vertrauter-von-Friedrich-Merz_-Der-Aufstieg-des-Thorsten-Frei(1).pdf` (RND article captured in the project).

The article describes a first parliamentary managing director who organizes and explains, has a close/trusting relationship with Merz, and combines power awareness with loyalty. The model therefore uses **Gestaltung through Organisation + personal/institutional loyalty**. It does not assume Frei was secretly instructed to make any specific 16 September statement.

### Linnemann

Primary project source: `sources/Carsten_Linnemann_采访转写(2).txt`.

Repeated emphasis on responsibility for the program and getting measures implemented supports a thin **Wirksamkeit/implementation** rule. This is not a complete personality model and does not prove that Linnemann caused the outcome.

### Günther

Primary project source: `sources/Daniel_Guenther_采访转写(2).txt`, plus the contemporaneous 17 September NDR statement above.

The interview material stresses pragmatic cooperation and workable coalitions. The K-Frage node therefore uses **Mehrheiten/consensus/operative responsibility**, with action after a viable closure signal. This rule is supported for synchronization behavior; it is not tested as a candidate-selection rule.

### Söder

No rich personality model is imposed. The source-supported rule includes only:

1. control of the CSU apparatus and high public visibility;
2. public availability;
3. the stated need for a CDU call;
4. bilateral agreement language and the publicly stated goal of avoiding a 2021 repeat.

Anything about resentment, ego, emotional need, or private deal-making remains outside the model.

## Explicit model assumptions

1. Resource values are normalized ordinal encodings, not empirical measurements.
2. A party chair/parliamentary leader default is powerful but not legally automatic.
3. Public statements update perceived resources; they do not reveal all private preferences.
4. The 2021 conflict creates a common coordination cost for every actor, though actors may weight it differently.
5. The largest viable CDU alternative reallocating its organizational signal can reduce a CSU candidate's CDU bridgehead.
6. Organizational synchronization follows a viable joint closure more easily than it creates one from scratch.
7. Thin rules for Rhein and Hagel are role rules, not personality claims.

## Unknown black boxes

- Exact content, timing and any exchange in Merz–Wüst conversations.
- Whether Wüst's 16 September timing was coordinated with Merz in detail.
- Any promise about succession, office, coalition committee membership, or future candidacy.
- Exact content and bargaining terms in the final Merz–Söder meeting.
- Latent, non-public preferences of individual MPs, Landeschefs, delegates and CSU officials.
- Counterfactual media shocks, leaks, polling movements and third-party interventions.

The simulator represents only two black-box families: bounded perception error and a bounded bilateral-negotiation contingency. It never makes personality random.
