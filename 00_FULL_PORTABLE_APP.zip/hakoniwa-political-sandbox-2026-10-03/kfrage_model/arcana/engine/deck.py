from __future__ import annotations

import json
from pathlib import Path

from .models import CardDefinition, HistoricalMeaning


def _meaning(raw: dict) -> HistoricalMeaning:
    return HistoricalMeaning(
        original_french=raw["original_french"],
        normalized_english=raw["normalized_english"],
        chinese_gloss=raw["chinese_gloss"],
        source_id=raw["source_id"],
        source_page=int(raw["source_page"]),
    )


def load_cards(path: str | Path) -> dict[str, CardDefinition]:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if raw.get("schema_version") != "arcana-petit-etteilla-cards-0.1":
        raise ValueError("Expected arcana-petit-etteilla-cards-0.1")
    cards = {}
    for row in raw["cards"]:
        cards[row["card_id"]] = CardDefinition(
            card_id=row["card_id"],
            suit=row.get("suit"),
            rank=row.get("rank"),
            forename_upright=_meaning(row["forename_upright"]),
            forename_reversed=_meaning(row["forename_reversed"]),
            surname_upright=_meaning(row["surname_upright"]) if row.get("surname_upright") else None,
            surname_reversed=_meaning(row["surname_reversed"]) if row.get("surname_reversed") else None,
            etteilla_number=row.get("etteilla_number"),
        )
    if len(cards) != 33:
        raise ValueError(f"Petit Etteilla backend requires 33 cards, got {len(cards)}")
    return cards
