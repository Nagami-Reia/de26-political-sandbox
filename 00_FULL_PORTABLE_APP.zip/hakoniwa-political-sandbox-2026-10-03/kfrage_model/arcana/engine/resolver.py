from __future__ import annotations

import json
from collections import Counter
from itertools import combinations
from pathlib import Path

from .models import CardDefinition, Draw, Orientation, RuleResult


HISTORICAL = Path(__file__).resolve().parents[1] / "historical"


class HistoricalResolver:
    """Only verified historical rules. No advisory psychology lives here."""

    def __init__(self, root: str | Path = HISTORICAL):
        root = Path(root)
        self.meetings = json.loads((root / "meetings.json").read_text(encoding="utf-8"))["meetings"]
        self.multiples = json.loads((root / "multiples.json").read_text(encoding="utf-8"))["rules"]

    def base_meanings(self, draws: tuple[Draw, ...], definitions: dict[str, CardDefinition]) -> tuple[dict, ...]:
        rows = []
        for draw in draws:
            card = definitions[draw.card_id]
            meaning = card.forename_upright if draw.orientation is Orientation.UPRIGHT else card.forename_reversed
            rows.append({
                "position": draw.position,
                "role": draw.role,
                "card_id": draw.card_id,
                "orientation": draw.orientation.value,
                "etteilla_number": card.etteilla_number,
                "forename": {
                    "original_french": meaning.original_french,
                    "normalized_english": meaning.normalized_english,
                    "chinese_gloss": meaning.chinese_gloss,
                    "source_id": meaning.source_id,
                    "source_page": meaning.source_page,
                },
                "surname": None,
            })
        return tuple(rows)

    def resolve_meetings(self, draws: tuple[Draw, ...], definitions: dict[str, CardDefinition]) -> tuple[RuleResult, ...]:
        rules = {tuple(sorted((int(r["a"]), int(r["b"])))): r for r in self.meetings}
        found = []
        # The source treats meeting numbers in the laid sequence. We require
        # adjacency, avoiding an invented all-pairs expansion.
        for left, right in zip(draws, draws[1:]):
            a = definitions[left.card_id].etteilla_number
            b = definitions[right.card_id].etteilla_number
            if a is None or b is None:
                continue
            row = rules.get(tuple(sorted((a, b))))
            if row:
                found.append(RuleResult(
                    "MEETING", row["normalized_english"], row["original_french"],
                    (left.card_id, right.card_id), row["source_id"], int(row["source_page"]),
                ))
        return tuple(found)

    def resolve_multiples(self, draws: tuple[Draw, ...], definitions: dict[str, CardDefinition]) -> tuple[RuleResult, ...]:
        counts = Counter((definitions[d.card_id].rank, d.orientation.value) for d in draws if definitions[d.card_id].rank)
        found = []
        for row in self.multiples:
            key = (row["rank"], row["orientation"])
            if counts[key] == int(row["count"]):
                ids = tuple(d.card_id for d in draws
                            if definitions[d.card_id].rank == row["rank"] and d.orientation.value == row["orientation"])
                found.append(RuleResult(
                    "MULTIPLE", row["normalized_english"], row["original_french"],
                    ids, row["source_id"], int(row["source_page"]),
                ))
        return tuple(found)

    def resolve(self, draws: tuple[Draw, ...], definitions: dict[str, CardDefinition]) -> tuple[RuleResult, ...]:
        return (*self.resolve_meetings(draws, definitions), *self.resolve_multiples(draws, definitions))
