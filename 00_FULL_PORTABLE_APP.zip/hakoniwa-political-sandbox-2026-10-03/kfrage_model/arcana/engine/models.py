from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Mapping


class Orientation(str, Enum):
    UPRIGHT = "UPRIGHT"
    REVERSED = "REVERSED"


class AdviceType(str, Enum):
    TAKE_THE_GAMBLE = "TAKE_THE_GAMBLE"
    DO_NOT_FORCE_IT = "DO_NOT_FORCE_IT"
    WAIT = "WAIT"
    SEEK_COUNSEL = "SEEK_COUNSEL"
    ACT_NOW = "ACT_NOW"
    INDETERMINATE = "INDETERMINATE"


@dataclass(frozen=True)
class HistoricalMeaning:
    original_french: str
    normalized_english: str
    chinese_gloss: str
    source_id: str
    source_page: int


@dataclass(frozen=True)
class CardDefinition:
    card_id: str
    suit: str | None
    rank: str | None
    forename_upright: HistoricalMeaning
    forename_reversed: HistoricalMeaning
    surname_upright: HistoricalMeaning | None
    surname_reversed: HistoricalMeaning | None
    etteilla_number: int | None


@dataclass(frozen=True)
class Draw:
    card_id: str
    orientation: Orientation
    position: int
    role: str = "MAIN"


@dataclass(frozen=True)
class RuleResult:
    rule_type: str
    meaning: str
    original_french: str
    card_ids: tuple[str, ...]
    source_id: str
    source_page: int
    status: str = "VERIFIED_PRIMARY"


@dataclass(frozen=True)
class AdvisorySignal:
    recommendation: AdviceType
    confidence: float
    risk_modifier: float
    urgency_modifier: float
    hesitation_modifier: float
    initiative_modifier: float
    motifs: tuple[str, ...]
    interpretation_status: str = "HAKONIWA_CUSTOM_NOT_HISTORICAL"


@dataclass(frozen=True)
class ArcanaRun:
    run_id: str
    node_id: str
    actor_id: str
    seed: int
    spread_id: str
    draws: tuple[Draw, ...]
    base_meanings: tuple[Mapping[str, object], ...]
    resolved_rules: tuple[RuleResult, ...]
    identity_echoes: tuple[Mapping[str, object], ...]
    advice: AdvisorySignal
    advice_process: Mapping[str, object]
    shuffle_contract: str

    def payload(self) -> dict:
        return asdict(self)
