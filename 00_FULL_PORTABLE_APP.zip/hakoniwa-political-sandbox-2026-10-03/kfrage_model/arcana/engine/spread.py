from __future__ import annotations

import random
from pathlib import Path

from .deck import load_cards
from .models import Draw, Orientation


HISTORICAL = Path(__file__).resolve().parents[1] / "historical"


class PetitEtteillaDeck:
    """Reproducible 33-card deck with the verified coup-de-douze layout."""

    def __init__(self, cards_path: str | Path | None = None):
        self.definitions = load_cards(cards_path or HISTORICAL / "cards.json")

    def coup_de_douze(self, seed: int) -> tuple[Draw, ...]:
        rng = random.Random(int(seed))
        oriented = [
            (card_id, Orientation.UPRIGHT if rng.getrandbits(1) else Orientation.REVERSED)
            for card_id in self.definitions
        ]
        rng.shuffle(oriented)
        main = [Draw(card, orientation, index + 1, "MAIN")
                for index, (card, orientation) in enumerate(oriented[:12])]
        thirteenth = Draw(oriented[12][0], oriented[12][1], 13, "TURN_CARD")
        bottom = Draw(oriented[-1][0], oriented[-1][1], 14, "BOTTOM_CARD")
        return tuple((*main, thirteenth, bottom))
