from __future__ import annotations

from typing import Mapping, Sequence

from kfrage_model.persona_v2 import ActionOption, PersonaCard, PersonaRuntime
from ..engine.models import AdviceType, AdvisorySignal
from .receptivity import calculate_receptivity


class ArcanaDecisionAdapter:
    """Threshold/gamble-window adapter; never adds a flat action bonus."""

    def adapt(
        self,
        rational_choice: str,
        scores: Mapping[str, float],
        actions: Sequence[ActionOption],
        signal: AdvisorySignal,
        card: PersonaCard,
        runtime: PersonaRuntime,
        node_uncertainty: float,
        interaction_modifier: float = 0.000,
        influence_cap: float = 0.180,
    ) -> tuple[str, dict]:
        scored_actions = tuple(action for action in actions if action.key in scores)
        if not scored_actions:
            raise ValueError("ARCANA requires at least one previously scored action")
        order = {action.key: index for index, action in enumerate(scored_actions)}
        receptivity = calculate_receptivity(card, runtime, node_uncertainty)
        effective = receptivity["effective_receptivity"] * signal.confidence
        riskiness = {
            action.key: round((action.downside + action.uncertainty + action.irreversibility) / 3.000, 3)
            for action in scored_actions
        }
        gamble_value = {
            action.key: round(action.upside * (0.500 + 0.500 * action.objective_feasibility), 3)
            for action in scored_actions
        }
        viable_risky = [a for a in scored_actions if a.objective_feasibility >= 0.350 and riskiness[a.key] >= 0.450]
        risky_key = max(viable_risky, key=lambda a: (gamble_value[a.key], -order[a.key])).key if viable_risky else None
        safe_key = min(scored_actions, key=lambda a: (riskiness[a.key], -scores[a.key], order[a.key])).key
        counsel = [a for a in scored_actions if a.conflict_strategy in {"negotiate", "institutionalize", "reframe"}]
        counsel_key = max(counsel, key=lambda a: (scores[a.key], -order[a.key])).key if counsel else None
        initiative_key = max(scored_actions, key=lambda a: (a.upside - 0.350 * a.downside, -order[a.key])).key
        candidates = {key for key in (risky_key, safe_key, counsel_key, initiative_key) if key}
        gaps = {key: round(max(scores.values()) - scores[key], 3) for key in candidates}
        base_threshold = 0.025 + 0.090 * card.dna.risk_appetite
        advisory_delta = max(
            -influence_cap,
            min(influence_cap, effective * 0.120 + interaction_modifier),
        )
        threshold = max(0.000, base_threshold + advisory_delta)
        chosen = rational_choice
        status = "DECLINE_ADVICE"
        reason = "advice did not open a viable near-tie branch"

        if signal.recommendation is AdviceType.INDETERMINATE:
            status, reason = "NO_EFFECT", "reading was indeterminate"
        elif signal.recommendation is AdviceType.TAKE_THE_GAMBLE and risky_key and gaps[risky_key] <= threshold:
            chosen, status, reason = risky_key, "ACCEPT_ADVICE", "risky viable branch entered gamble window"
        elif signal.recommendation is AdviceType.DO_NOT_FORCE_IT and gaps.get(safe_key, 1.0) <= threshold:
            chosen, status, reason = safe_key, "ACCEPT_ADVICE", "safer branch remained within commitment threshold"
        elif signal.recommendation is AdviceType.WAIT and gaps.get(safe_key, 1.0) <= threshold:
            chosen, status, reason = safe_key, "ACCEPT_ADVICE", "hesitation signal changed a near-tie"
        elif signal.recommendation is AdviceType.SEEK_COUNSEL and counsel_key and gaps[counsel_key] <= threshold:
            chosen, status, reason = counsel_key, "ACCEPT_ADVICE", "counsel-compatible branch remained in range"
        elif signal.recommendation is AdviceType.ACT_NOW and gaps.get(initiative_key, 1.0) <= threshold:
            chosen, status, reason = initiative_key, "ACCEPT_ADVICE", "initiative branch remained in range"

        if status == "ACCEPT_ADVICE" and chosen == rational_choice:
            status = "CONFIRM_RATIONAL_CHOICE"
            reason = "reading supported the already-selected rational branch"

        return chosen, {
            "rational_choice_before_arcana": rational_choice,
            "selected_action_after_arcana": chosen,
            "adoption_status": status,
            "reason": reason,
            "base_scores": {key: round(value, 3) for key, value in scores.items()},
            "riskiness": riskiness,
            "gamble_value": gamble_value,
            "candidate_gaps": gaps,
            "base_gamble_threshold": round(base_threshold, 3),
            "effective_threshold": round(threshold, 3),
            "advisory_threshold_delta": round(advisory_delta, 3),
            "influence_cap": round(influence_cap, 3),
            "interaction_modifier": round(interaction_modifier, 3),
            "receptivity": receptivity,
        }
