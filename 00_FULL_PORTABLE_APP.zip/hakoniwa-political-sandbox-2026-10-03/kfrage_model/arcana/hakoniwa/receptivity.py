from __future__ import annotations

from dataclasses import asdict

from kfrage_model.persona_v2 import PersonaCard, PersonaRuntime


def calculate_receptivity(card: PersonaCard, runtime: PersonaRuntime, node_uncertainty: float) -> dict:
    """Operational receptivity, never a claim that the politician believes in divination."""
    dna = card.dna
    state = runtime.state
    intuition_receptivity = 0.350 + 0.250 * dna.adaptability + 0.200 * dna.risk_appetite
    uncertainty_tolerance = 0.400 + 0.350 * dna.risk_appetite + 0.150 * state.confidence
    regret_aversion = 0.350 + 0.350 * (1.000 - dna.risk_appetite) + 0.200 * state.pressure
    commitment_threshold = 0.550 + 0.200 * (1.000 - dna.risk_appetite) + 0.150 * (1.000 - state.control)
    receptivity = min(1.000, max(0.000,
        intuition_receptivity * 0.350
        + uncertainty_tolerance * 0.250
        + (1.000 - regret_aversion) * 0.200
        + (1.000 - commitment_threshold) * 0.200
    ))
    effective = receptivity * min(1.000, max(0.000, node_uncertainty))
    return {
        "intuition_receptivity": round(intuition_receptivity, 3),
        "uncertainty_tolerance": round(uncertainty_tolerance, 3),
        "regret_aversion": round(regret_aversion, 3),
        "commitment_threshold": round(commitment_threshold, 3),
        "node_uncertainty": round(node_uncertainty, 3),
        "actor_receptivity": round(receptivity, 3),
        "effective_receptivity": round(effective, 3),
        "pss_snapshot": asdict(state),
        "interpretation": "behavioural receptivity proxy; not belief in cartomancy",
    }
