from __future__ import annotations

from dataclasses import asdict

from kfrage_model.persona_v2 import PersonaCard, PersonaRuntime
from ..engine.models import ArcanaRun


class ArcanaInteractionEngine:
    """Two independent readings mediated by each actor's PSS and risk logic."""

    @staticmethod
    def _stance(run: ArcanaRun) -> float:
        a = run.advice
        return max(-1.0, min(1.0,
            a.risk_modifier * 3.0 + a.initiative_modifier * 2.0
            + a.urgency_modifier * 1.5 - a.hesitation_modifier * 2.0
        ))

    def resolve(
        self,
        primary_run: ArcanaRun,
        counter_run: ArcanaRun,
        primary_card: PersonaCard,
        primary_runtime: PersonaRuntime,
        counter_card: PersonaCard,
        counter_runtime: PersonaRuntime,
    ) -> dict:
        left = self._stance(primary_run)
        right = self._stance(counter_run)
        opposed = left * right < 0
        collision = abs(left - right) * 0.500 if opposed else 0.000
        convergence = 1.000 - min(1.000, abs(left - right) * 0.500)

        def pss_response(card: PersonaCard, runtime: PersonaRuntime, stance: float) -> dict:
            state = runtime.state
            activation = collision * (
                0.400 * state.pressure + 0.350 * (1.000 - state.control) + 0.250 * state.confidence
            )
            risk_direction = (card.dna.risk_appetite - 0.500) * 2.000
            decision_modifier = activation * risk_direction * 0.040
            return {
                "stance": round(stance, 3),
                "pss_activation": round(activation, 3),
                "decision_threshold_modifier": round(decision_modifier, 3),
                "pressure_exposure_if_conflict_occurs": round(activation * 0.080, 3),
                "pss_snapshot": asdict(state),
                "note": "diagnostic until an actual interaction outcome applies a PSS event",
            }

        left_response = pss_response(primary_card, primary_runtime, left)
        right_response = pss_response(counter_card, counter_runtime, right)
        if collision >= 0.450:
            interaction = "ESCALATION_CONTEST"
        elif opposed:
            interaction = "ASYMMETRIC_PRESSURE"
        elif convergence >= 0.800 and left < -0.100:
            interaction = "MUTUAL_HESITATION"
        elif convergence >= 0.800:
            interaction = "CONVERGENT_INITIATIVE"
        else:
            interaction = "INDETERMINATE_INTERACTION"
        return {
            "interaction_type": interaction,
            "primary_actor": primary_run.actor_id,
            "counterparty_actor": counter_run.actor_id,
            "independent_seeds": [primary_run.seed, counter_run.seed],
            "stance_collision": round(collision, 3),
            "stance_convergence": round(convergence, 3),
            "primary_pss_mediation": left_response,
            "counterparty_pss_mediation": right_response,
            "causal_boundary": "readings alter postures/thresholds; only realised actions and outcomes mutate PSS",
        }
