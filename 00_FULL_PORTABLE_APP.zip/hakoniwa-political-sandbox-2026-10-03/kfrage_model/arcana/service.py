from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path

from .engine.models import ArcanaRun, Orientation
from .engine.resolver import HistoricalResolver
from .engine.spread import PetitEtteillaDeck
from .hakoniwa.interaction import ArcanaInteractionEngine
from .interpretation.advice import AdvisoryInterpreter
from .logging.runs import ArcanaRunRepository


ROOT = Path(__file__).resolve().parent


@dataclass(frozen=True)
class ArcanaConfig:
    enabled: bool = False
    master_seed: int = 0
    backend: str = "PETIT_ETTEILLA_1773"
    spread_id: str = "COUP_DE_DOUZE_12_PLUS_2"
    influence_cap: float = 0.180


class ArcanaService:
    """Stateless readings plus a replay log; world and actors retain the memory."""

    def __init__(self, config: ArcanaConfig = ArcanaConfig()):
        self.config = config
        if config.backend != "PETIT_ETTEILLA_1773":
            raise ValueError(f"Unsupported ARCANA backend: {config.backend}")
        self.deck = PetitEtteillaDeck()
        self.resolver = HistoricalResolver()
        self.interpreter = AdvisoryInterpreter()
        self.interactions = ArcanaInteractionEngine()
        self.repository = ArcanaRunRepository()
        self._occurrences: dict[tuple[str, str], int] = {}
        identity_raw = json.loads((ROOT / "hakoniwa" / "identity_cards.json").read_text(encoding="utf-8"))
        self.identity_cards = identity_raw["assignments"]

    def _seed(self, node_id: str, actor_id: str, occurrence: int) -> int:
        material = f"{self.config.master_seed}|{node_id}|{actor_id}|{occurrence}".encode("utf-8")
        return int.from_bytes(hashlib.sha256(material).digest()[:8], "big")

    def _identity_echoes(self, draws, actor_id: str) -> tuple[dict, ...]:
        reverse = {}
        for person, row in self.identity_cards.items():
            reverse.setdefault(row["card_id"], []).append((person, row))
        echoes = []
        for draw in draws:
            for person, identity in reverse.get(draw.card_id, ()):
                expected = identity["orientation"]
                same = draw.orientation.value == expected
                self_echo = person == actor_id
                echoes.append({
                    "person_id": person,
                    "card_id": draw.card_id,
                    "draw_orientation": draw.orientation.value,
                    "identity_orientation": expected,
                    "echo_type": (
                        "SELF_ECHO" if self_echo and same else
                        "INVERTED_SELF_ECHO" if self_echo else
                        "INTERPERSONAL_ECHO" if same else
                        "INVERTED_IDENTITY_ECHO"
                    ),
                    "assignment_status": "PROVISIONAL_NOT_LOCKED",
                })
        return tuple(echoes)

    def run_reading(self, node_id: str, actor_id: str, *, seed: int | None = None) -> ArcanaRun:
        key = (node_id, actor_id)
        occurrence = self._occurrences.get(key, 0)
        self._occurrences[key] = occurrence + 1
        actual_seed = self._seed(node_id, actor_id, occurrence) if seed is None else int(seed)
        draws = self.deck.coup_de_douze(actual_seed)
        meanings = self.resolver.base_meanings(draws, self.deck.definitions)
        rules = self.resolver.resolve(draws, self.deck.definitions)
        advice, process = self.interpreter.interpret(meanings, rules)
        run_hash = hashlib.sha256(f"{node_id}|{actor_id}|{actual_seed}".encode()).hexdigest()[:16]
        run = ArcanaRun(
            run_id=f"arcana-{run_hash}",
            node_id=node_id,
            actor_id=actor_id,
            seed=actual_seed,
            spread_id=self.config.spread_id,
            draws=draws,
            base_meanings=meanings,
            resolved_rules=rules,
            identity_echoes=self._identity_echoes(draws, actor_id),
            advice=advice,
            advice_process=process,
            shuffle_contract="random.Random(seed): independent orientation bits, then deck shuffle",
        )
        self.repository.add(run)
        return run

    def replay(self, run_id: str) -> ArcanaRun:
        original = self.repository.get(run_id)
        # Replay does not advance occurrence counters and is byte-for-byte comparable.
        draws = self.deck.coup_de_douze(original.seed)
        meanings = self.resolver.base_meanings(draws, self.deck.definitions)
        rules = self.resolver.resolve(draws, self.deck.definitions)
        advice, process = self.interpreter.interpret(meanings, rules)
        replayed = ArcanaRun(
            run_id=original.run_id, node_id=original.node_id, actor_id=original.actor_id,
            seed=original.seed, spread_id=original.spread_id, draws=draws,
            base_meanings=meanings, resolved_rules=rules,
            identity_echoes=self._identity_echoes(draws, original.actor_id),
            advice=advice, advice_process=process, shuffle_contract=original.shuffle_contract,
        )
        if replayed.payload() != original.payload():
            raise RuntimeError(f"ARCANA replay mismatch: {run_id}")
        return replayed

    def run_conflict(self, node_id: str, primary_actor: str, counterparty_actor: str,
                     primary_card, primary_runtime, counter_card, counter_runtime) -> dict:
        primary = self.run_reading(node_id, primary_actor)
        counter = self.run_reading(node_id, counterparty_actor)
        interaction = self.interactions.resolve(
            primary, counter, primary_card, primary_runtime, counter_card, counter_runtime
        )
        return {
            "primary_reading": primary.payload(),
            "counterparty_reading": counter.payload(),
            "interaction": interaction,
        }

    def payload(self) -> dict:
        return {"config": asdict(self.config), "runs": self.repository.payload()}
