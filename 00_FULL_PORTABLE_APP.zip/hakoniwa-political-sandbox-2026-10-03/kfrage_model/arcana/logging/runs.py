from __future__ import annotations

from ..engine.models import ArcanaRun


class ArcanaRunRepository:
    def __init__(self):
        self.runs: dict[str, ArcanaRun] = {}

    def add(self, run: ArcanaRun) -> None:
        if run.run_id in self.runs and self.runs[run.run_id] != run:
            raise ValueError(f"Arcana run id collision: {run.run_id}")
        self.runs[run.run_id] = run

    def get(self, run_id: str) -> ArcanaRun:
        return self.runs[run_id]

    def payload(self) -> dict:
        return {key: run.payload() for key, run in self.runs.items()}
