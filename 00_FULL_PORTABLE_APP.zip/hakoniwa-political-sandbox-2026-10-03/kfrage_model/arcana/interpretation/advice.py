"""Hakoniwa advisory interpretation, explicitly separate from historical rules."""
from __future__ import annotations

from collections import Counter

from ..engine.models import AdviceType, AdvisorySignal, RuleResult


# These mappings are modelling choices, not Etteilla's psychological theory.
MEANING_MOTIFS = {
    "victory": ("OPPORTUNITY", "INITIATIVE"),
    "enterprise / undertaking": ("INITIATIVE", "RISK_OPENING"),
    "hope": ("OPPORTUNITY",),
    "friendship": ("COOPERATION", "COUNSEL"),
    "letter": ("MESSAGE",),
    "note / billet": ("MESSAGE",),
    "envoy / messenger": ("MESSAGE", "INITIATIVE"),
    "thought": ("REFLECTION",),
    "delay": ("WAIT", "HESITATION"),
    "weariness / boredom": ("WAIT",),
    "treachery": ("CAUTION",),
    "spy": ("CAUTION", "INFORMATION_RISK"),
    "tears": ("CAUTION",),
    "losses": ("CAUTION", "DO_NOT_FORCE"),
    "illness": ("CAUTION", "WAIT"),
    "Saturn / mortality": ("DO_NOT_FORCE",),
    "difficulty / embarrassment": ("CAUTION", "HESITATION"),
    "gossip / chatter": ("MESSAGE", "INFORMATION_RISK"),
    "birth": ("NEW_PATH", "INITIATIVE"),
    "gift": ("OPPORTUNITY",),
    "large sum of money": ("OPPORTUNITY",),
}

RULE_MOTIFS = {
    "consultation": ("COUNSEL", "COOPERATION"),
    "small council": ("COUNSEL",),
    "politics": ("POLITICS", "COUNSEL"),
    "peace": ("COOPERATION", "DO_NOT_FORCE"),
    "time": ("WAIT",),
    "disunity": ("CONFLICT", "CAUTION"),
    "disputes": ("CONFLICT",),
    "faith / trust": ("COOPERATION",),
    "cessation of all sorrows": ("OPPORTUNITY",),
    "small success": ("OPPORTUNITY",),
    "great success": ("OPPORTUNITY", "INITIATIVE"),
    "waiting": ("WAIT", "HESITATION"),
    "imprudence": ("CAUTION", "DO_NOT_FORCE"),
    "error": ("CAUTION", "DO_NOT_FORCE"),
    "project": ("INITIATIVE", "NEW_PATH"),
}


class AdvisoryInterpreter:
    def interpret(self, base_meanings: tuple[dict, ...], rules: tuple[RuleResult, ...]) -> tuple[AdvisorySignal, dict]:
        motif_rows: list[dict] = []
        tally: Counter[str] = Counter()
        for row in base_meanings:
            key = str(row["forename"]["normalized_english"])
            motifs = MEANING_MOTIFS.get(key, ())
            if motifs:
                weight = 0.700 if row["role"] == "MAIN" else 0.450
                for motif in motifs:
                    tally[motif] += weight
                motif_rows.append({"origin": "FORENAME", "card_id": row["card_id"], "meaning": key,
                                   "motifs": motifs, "weight": weight})
        for rule in rules:
            motifs = RULE_MOTIFS.get(rule.meaning, ())
            if motifs:
                weight = 1.250 if rule.rule_type == "MEETING" else 1.000
                for motif in motifs:
                    tally[motif] += weight
                motif_rows.append({"origin": rule.rule_type, "card_ids": rule.card_ids,
                                   "meaning": rule.meaning, "motifs": motifs, "weight": weight})

        positive = tally["OPPORTUNITY"] + 0.700 * tally["INITIATIVE"] + 0.400 * tally["NEW_PATH"]
        caution = tally["CAUTION"] + 0.800 * tally["DO_NOT_FORCE"] + 0.400 * tally["INFORMATION_RISK"]
        wait = tally["WAIT"] + 0.500 * tally["HESITATION"]
        counsel = tally["COUNSEL"] + 0.500 * tally["COOPERATION"] + 0.350 * tally["POLITICS"]
        ranked = sorted({"positive": positive, "caution": caution, "wait": wait, "counsel": counsel}.items(),
                        key=lambda item: item[1], reverse=True)
        top_name, top = ranked[0]
        margin = top - ranked[1][1]
        if top < 1.200 or margin < 0.350:
            recommendation = AdviceType.INDETERMINATE
        elif top_name == "counsel":
            recommendation = AdviceType.SEEK_COUNSEL
        elif top_name == "wait":
            recommendation = AdviceType.WAIT
        elif top_name == "caution":
            recommendation = AdviceType.DO_NOT_FORCE_IT
        elif tally["INITIATIVE"] >= tally["OPPORTUNITY"]:
            recommendation = AdviceType.ACT_NOW
        else:
            recommendation = AdviceType.TAKE_THE_GAMBLE
        confidence = 0.000 if recommendation is AdviceType.INDETERMINATE else min(0.750, 0.250 + 0.100 * margin + 0.030 * len(motif_rows))
        scale = confidence
        signal = AdvisorySignal(
            recommendation=recommendation,
            confidence=round(confidence, 3),
            risk_modifier=round(scale * (positive - caution) / max(1.000, positive + caution) * 0.160, 3),
            urgency_modifier=round(scale * (tally["INITIATIVE"] - wait) / max(1.000, tally["INITIATIVE"] + wait) * 0.140, 3),
            hesitation_modifier=round(scale * (wait + caution) / max(1.000, positive + caution + wait) * 0.140, 3),
            initiative_modifier=round(scale * tally["INITIATIVE"] / max(1.000, sum(tally.values())) * 0.160, 3),
            motifs=tuple(key for key, _ in tally.most_common()),
        )
        process = {
            "boundary": "Historical meanings -> explicit Hakoniwa motif map -> advisory signal",
            "motif_rows": motif_rows,
            "motif_tally": {key: round(value, 3) for key, value in tally.items()},
            "advice_axes": {"positive": round(positive, 3), "caution": round(caution, 3),
                            "wait": round(wait, 3), "counsel": round(counsel, 3)},
            "ranking": [(key, round(value, 3)) for key, value in ranked],
            "indeterminate_rule": "top < 1.200 or margin < 0.350",
        }
        return signal, process
