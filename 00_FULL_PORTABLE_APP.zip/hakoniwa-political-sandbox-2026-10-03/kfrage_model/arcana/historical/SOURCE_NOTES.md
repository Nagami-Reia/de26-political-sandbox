# Petit Etteilla source notes

## Primary rule source

Jean-Baptiste Alliette (Etteilla), *Etteilla, ou la seule manière de tirer les
cartes* (Amsterdam/Paris: Lesclapart, 1773), scan:

<https://www.labirintoermetico.com/02Tarocchi/Etteilla_ou_la_seule_maniere_de_tirer_les_cartes.pdf>

The scan was inspected visually because text extraction is unreliable.

| Scan pages | Imported evidence |
|---|---|
| 30–37 | 33-card composition, numbered cards, Forename upright/reversed table |
| 46–47 | fifteen meetings, including 12+19 `Politiques` and 15+16 `Paix` |
| 53, 55, 57 | same-rank multiple-card tables; three upright kings `Consultation` |
| 58–62 | first operation: mixed orientation and `coup de douze` layout |
| 64–70, 82–88 | relational reading instructions and worked examples |

Conservative implementation choice: meeting meanings are resolved only for
adjacent cards in the laid sequence. The source's worked method is sequential;
an all-pairs expansion would create meanings the program has not sourced.

## Bibliographic corroboration

- Hachette/BnF record for Etteilla's 1770 *Etteilla, ou manière de se récréer
  avec un jeu de cartes*, <https://www.hachettebnf.fr/livre/etteilla-ou-maniere-de-se-recreer-avec-un-jeu-de-cartes-9782329749778/>.
  This confirms the earlier title/edition; the machine-readable rules use the
  visually inspected 1773 scan above.
- Bibliothèque nationale de France catalogue: *Le petit Etteilla ou l'Art de
  tirer les cartes* (Lille, 1826), <https://catalogue.bnf.fr/ark:/12148/cb33532186k>.
  Catalogue metadata only; no rules were imported from unseen pages.
- Caitlín Matthews and Rebecca Birrell, *The Original Petit Etteilla*, publisher
  record: <https://www.simonandschuster.com/books/The-Original-Petit-Etteilla/Caitlin-Matthews/9798888503010>.
  Bibliographic confirmation only; unverified modern reconstructions were not
  used to fill gaps.

## Translation discipline

The database retains original French, normalized English and a cautious Chinese
gloss. A historical word is not automatically a psychological variable. For
example, `Espérance` is stored as hope; it does not directly become optimism,
risk appetite or confidence. Such mappings exist only in the separate Hakoniwa
interpretation layer.

Unresolved families remain explicit: Surname, proximity, sequence, pairing,
mute cards and timing. Null is preferable to invented completeness.
