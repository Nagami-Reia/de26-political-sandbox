"""Deterministic compact ARCANA report renderer with lazy node-detail mounting."""
from __future__ import annotations

import html
import json
from collections import Counter, defaultdict
from typing import Mapping, Sequence

from .report_trace import ArcanaReportTraceCompiler


SUITS = {"SPADES": "♠", "HEARTS": "♥", "DIAMONDS": "♦", "CLUBS": "♣"}


def _e(value: object) -> str:
    return html.escape(str(value), quote=True)


def _status_symbol(status: str) -> str:
    return {"FLIP": "★", "CONFIRM": "○", "NO_EFFECT": "·"}.get(status, "·")


class ArcanaVisualReportRenderer:
    """Consumes arcana-report-trace-1.0; full audits are compatibility input only."""

    def __init__(self, compiler: ArcanaReportTraceCompiler | None = None) -> None:
        self.compiler = compiler or ArcanaReportTraceCompiler()

    def _coerce(self, value: Mapping[str, object] | Sequence[Mapping[str, object]]) -> dict:
        if isinstance(value, Mapping):
            if value.get("schema_version") != "arcana-report-trace-1.0":
                raise ValueError("Expected arcana-report-trace-1.0")
            return dict(value)
        return self.compiler.compile(value)

    @staticmethod
    def _identity(actor: str, row: Mapping[str, object]) -> str:
        code = row.get("identity")
        if not code:
            return f'<span class="arc-id-card is-unassigned">{_e(actor[:1].upper())}</span>'
        raw, orientation = str(code)[:-1], str(code)[-1]
        suit = {"S": "♠", "H": "♥", "D": "♦", "C": "♣"}.get(raw[-1:], "◇")
        rank = raw[:-1] if raw[-1:] in "SHDC" else raw
        cls = " is-red" if raw.endswith(("H", "D")) else ""
        cls += " is-reversed" if orientation == "R" else ""
        return f'<span class="arc-id-card{cls}"><b>{_e(rank)}</b><i>{suit}</i></span>'

    @staticmethod
    def _mini_cards(codes: Sequence[str], dictionary: Mapping[str, object]) -> str:
        labels = []
        for code in codes[:6]:
            card_id, orientation = code[:-1], code[-1]
            card = dictionary.get(card_id, {})
            labels.append(
                f'{card.get("r") or "E"}{SUITS.get(card.get("s"), "◇")}'
                f'{"↧" if orientation == "R" else ""}'
            )
        return " ".join(labels) + (f" … +{len(codes)-6}" if len(codes) > 6 else "")

    def render_fragment(
        self,
        report_or_audits: Mapping[str, object] | Sequence[Mapping[str, object]],
        *,
        title: str = "ARCANA Chronicle",
    ) -> str:
        report = self._coerce(report_or_audits)
        nodes = list(report.get("nodes", ()))
        actors = report.get("actors", {})
        cards = report.get("dictionary", {}).get("cards", {})
        counts = Counter(str(node.get("status")) for node in nodes)
        lanes: dict[str, list[tuple[int, Mapping[str, object], Mapping[str, object]]]] = defaultdict(list)
        for index, node in enumerate(nodes):
            lanes[str(node["actor"])].append((index, node, node["reading"]))
            if node.get("conflict"):
                conflict = node["conflict"]
                lanes[str(conflict["actor"])].append((index, node, conflict["reading"]))

        actor_tokens = "".join(
            '<div class="arc-actor">'
            f'{self._identity(actor, row)}<span><b>{_e(actor)}</b><small>{_e(row.get("identity_status"))}</small></span>'
            '</div>'
            for actor, row in sorted(actors.items())
        )
        lane_html = []
        for actor, items in sorted(lanes.items()):
            cells = []
            for index, node, reading in items:
                clash = reading is not node["reading"]
                symbol = "◆" if clash else _status_symbol(str(node["status"]))
                cells.append(
                    f'<button type="button" class="arc-chronicle-cell" data-arc-node="{index}">'
                    f'<small>{_e(node["id"])}</small><span>{_e(self._mini_cards(reading["cards"], cards))}</span>'
                    f'<b>{symbol}</b></button>'
                )
            lane_html.append(
                '<div class="arc-lane"><div class="arc-lane-id">'
                f'{self._identity(actor, actors.get(actor, {}))}<b>{_e(actor)}</b></div>'
                f'<div class="arc-lane-cells">{"".join(cells)}</div></div>'
            )

        summaries = []
        for index, node in enumerate(nodes):
            advice = node["reading"]["advice"][0]
            summaries.append(
                f'<button type="button" class="arc-node-summary" data-arc-node="{index}" '
                f'aria-expanded="false"><span>NODE {index+1:03d}</span><b>{_e(node["id"])}</b>'
                f'<small>{_e(node["actor"])} · {_e(advice)} · {_e(node.get("final", "—"))}</small>'
                f'<strong>{_status_symbol(str(node["status"]))}</strong></button>'
            )

        safe_json = json.dumps(report, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
        return (
            '<section id="arcana-visual-report" class="arc-report">'
            '<header class="arc-cover"><p>ILLUSTRATED SIMULATION RECORD</p>'
            f'<h1>{_e(title)}</h1><span>Reason chose. The cards advised. Events changed the world.</span>'
            f'<div class="arc-actors">{actor_tokens}</div><div class="arc-stats">'
            f'<span><b>{len(nodes)}</b> nodes</span><span><b>{counts["FLIP"]}</b> changed</span>'
            f'<span><b>{counts["CONFIRM"]}</b> confirmed</span><span><b>{counts["NO_EFFECT"]}</b> no effect</span>'
            '</div></header><section class="arc-section"><h2>Chronicle</h2>'
            '<p>○ confirm　· no effect　★ changed choice　◆ interpersonal clash</p>'
            f'<div class="arc-lanes">{"".join(lane_html)}</div></section>'
            '<section class="arc-section"><h2>Nodes</h2>'
            f'<div class="arc-node-list">{"".join(summaries)}</div>'
            '<div id="arcana-detail-host" class="arc-detail-host" aria-live="polite"></div></section>'
            f'<script type="application/json" id="arcana-report-data">{safe_json}</script></section>'
        )

    def render_document(
        self,
        report_or_audits: Mapping[str, object] | Sequence[Mapping[str, object]],
        *,
        title: str = "ARCANA Chronicle",
    ) -> str:
        fragment = self.render_fragment(report_or_audits, title=title)
        return (
            '<!doctype html><html lang="zh"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            f'<title>{_e(title)}</title><style>{STYLE}</style></head><body>{fragment}'
            f'<script>{SCRIPT}</script></body></html>'
        )


STYLE = r"""
#arcana-visual-report{color-scheme:light dark;--ap:light-dark(#f1ebde,#171512);--ai:light-dark(#262019,#eee7dc);--am:light-dark(#71685c,#aaa095);--al:light-dark(#c8bbaa,#514a42);--as:light-dark(#fffaf0,#211e1a);--ac:light-dark(#fffdf8,#f4eee4);--ar:#982c32;--ag:light-dark(#75561b,#d4b36b);--ab:light-dark(#315e76,#79a9c0);box-sizing:border-box;background:var(--ap);color:var(--ai);font-family:ui-serif,Georgia,serif;max-width:1500px;margin:auto;padding:32px}#arcana-visual-report *{box-sizing:border-box}.arc-cover{min-height:330px;display:flex;flex-direction:column;justify-content:center;border-bottom:1px solid var(--al)}.arc-cover>p,.arc-cover>span,.arc-section>p{color:var(--am);letter-spacing:.06em}.arc-cover h1{font-size:clamp(34px,6vw,72px);font-weight:400;margin:.12em 0}.arc-actors,.arc-stats{display:flex;gap:20px;flex-wrap:wrap;margin-top:24px}.arc-actor{display:flex;align-items:center;gap:9px}.arc-actor small{display:block;color:var(--am);font-size:11px}.arc-id-card{position:relative;display:grid;place-items:center;width:42px;height:62px;background:var(--ac);color:#17130f;border:1px solid var(--ag);border-radius:4px;box-shadow:0 2px 5px #0002}.arc-id-card b{position:absolute;top:4px;left:5px}.arc-id-card i{font-size:25px;font-style:normal}.arc-id-card.is-red{color:var(--ar)}.arc-id-card.is-reversed{transform:rotate(180deg)}.arc-id-card.is-unassigned{color:var(--am);font-size:22px}.arc-stats span{border-left:2px solid var(--ag);padding-left:9px}.arc-stats b{font-size:22px}.arc-section{padding:30px 0;border-bottom:1px solid var(--al)}.arc-section h2{font-weight:400}.arc-lanes{display:grid;gap:14px}.arc-lane{display:grid;grid-template-columns:130px 1fr;gap:12px;align-items:center}.arc-lane-id{display:flex;align-items:center;gap:8px}.arc-lane-cells{display:flex;gap:8px;overflow-x:auto;padding:5px}.arc-chronicle-cell,.arc-node-summary{appearance:none;color:inherit;background:transparent;border:0;font:inherit;text-align:left}.arc-chronicle-cell{min-width:190px;border-bottom:1px solid var(--al);padding:7px}.arc-chronicle-cell small,.arc-chronicle-cell span{display:block;color:var(--am);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.arc-chronicle-cell b{color:var(--ag)}.arc-node-list{display:grid}.arc-node-summary{display:grid;grid-template-columns:90px minmax(180px,1fr) minmax(180px,auto) 28px;gap:12px;align-items:center;padding:12px 8px;border-bottom:1px solid var(--al)}.arc-node-summary span,.arc-node-summary small{color:var(--am)}.arc-node-summary[aria-expanded="true"]{background:color-mix(in srgb,var(--ab) 10%,transparent)}.arc-detail-host:empty{display:none}.arc-detail{margin-top:18px;background:var(--as);border:1px solid var(--al);padding:18px}.arc-detail-head{display:flex;align-items:center;justify-content:space-between;gap:12px}.arc-close{appearance:none;border:1px solid var(--al);background:transparent;color:inherit;padding:7px 10px;font:inherit}.arc-reading-layout{display:grid;gap:14px;margin-top:16px}.arc-duel{display:grid;grid-template-columns:minmax(0,1fr) 170px minmax(0,1fr);gap:12px}.arc-clash-core{display:grid;place-content:center;text-align:center;border-inline:1px solid var(--al);padding:12px}.arc-clash-core strong{color:var(--ar);font-size:22px}.arc-cards{display:flex;gap:6px;overflow-x:auto;padding:10px 0 14px}.arc-playing-card{appearance:none;position:relative;width:56px;height:84px;flex:0 0 auto;border:1px solid var(--al);border-radius:4px;background:var(--ac);color:#17130f;font:inherit;box-shadow:0 2px 5px #0002}.arc-playing-card.is-red{color:var(--ar)}.arc-playing-card.is-reversed{transform:rotate(180deg)}.arc-playing-card b{position:absolute;top:4px;left:5px}.arc-playing-card i{font-size:30px;font-style:normal}.arc-rules,.arc-motifs{display:flex;flex-wrap:wrap;gap:7px;margin:8px 0}.arc-rules span{border-bottom:1px solid var(--al);padding:5px;color:var(--ag)}.arc-motifs span{background:color-mix(in srgb,var(--ab) 10%,transparent);padding:5px 7px;font:12px ui-sans-serif,system-ui,sans-serif}.arc-reading-result,.arc-path,.arc-outcome{display:flex;align-items:center;gap:12px;flex-wrap:wrap;padding:10px 0;border-top:1px solid var(--al)}.arc-reading-result strong{font-size:20px;font-weight:400}.arc-path b{font-weight:500}.arc-path span,.arc-outcome span,.arc-inspector{color:var(--am);font:12px ui-sans-serif,system-ui,sans-serif}.arc-inspector{min-height:34px;padding-top:9px;border-top:1px dashed var(--al)}
@media(max-width:820px){#arcana-visual-report{padding:18px}.arc-lane{grid-template-columns:1fr}.arc-node-summary{grid-template-columns:70px 1fr 28px}.arc-node-summary small{display:none}.arc-duel{grid-template-columns:1fr}.arc-clash-core{border:1px solid var(--al)}}
"""


SCRIPT = r"""
(() => {
 const root=document.getElementById('arcana-visual-report');if(!root||root.dataset.ready)return;root.dataset.ready='1';
 const report=JSON.parse(root.querySelector('#arcana-report-data').textContent),host=root.querySelector('#arcana-detail-host'),suit={SPADES:'♠',HEARTS:'♥',DIAMONDS:'♦',CLUBS:'♣'};let active=null;
 const el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
 function identity(actor){const row=report.actors[actor]||{},box=el('span','arc-id-card');if(!row.identity){box.classList.add('is-unassigned');box.textContent=actor.slice(0,1);return box;}const id=row.identity.slice(0,-1),rev=row.identity.endsWith('R'),def=report.dictionary.cards[id]||{};if(['HEARTS','DIAMONDS'].includes(def.s))box.classList.add('is-red');if(rev)box.classList.add('is-reversed');box.append(el('b','',def.r||'E'),el('i','',suit[def.s]||'◇'));return box;}
 function card(code,inspector){const id=code.slice(0,-1),rev=code.endsWith('R'),def=report.dictionary.cards[id]||{},b=el('button','arc-playing-card');b.type='button';if(['HEARTS','DIAMONDS'].includes(def.s))b.classList.add('is-red');if(rev)b.classList.add('is-reversed');b.append(el('b','',def.r||'E'),el('i','',suit[def.s]||'◇'));b.addEventListener('click',()=>{const m=rev?def.rvs:def.u;inspector.textContent=`${id} ${rev?'REVERSED':'UPRIGHT'} — ${m?.original_french||'unresolved'} / ${m?.normalized_english||'unresolved'} · ${m?.source_id||'no source'}, p.${m?.source_page||'?'}`;});return b;}
 function readingBox(reading,label){const box=el('section','arc-reading-box'),inspector=el('div','arc-inspector','Select a card to inspect its historical meaning.'),cards=el('div','arc-cards');box.append(el('h3','',label));reading.cards.forEach(c=>cards.append(card(c,inspector)));box.append(cards);const rules=el('div','arc-rules');reading.rules.forEach(ref=>{const d=report.dictionary.rules[ref.id]||{};rules.append(el('span','',`${ref.cards.join(' · ')} — ${d.meaning||ref.id} · p.${d.page||'?'}`));});box.append(rules);const motifs=el('div','arc-motifs');Object.entries(reading.motifs).sort((a,b)=>b[1]-a[1]).forEach(([k,v])=>motifs.append(el('span','',`${k} ${Number(v).toFixed(3)}`)));box.append(motifs);const result=el('div','arc-reading-result');result.append(el('span','','ADVICE'),el('strong','',reading.advice[0]),el('b','',Number(reading.advice[1]).toFixed(3)));box.append(result,inspector);return box;}
 function deterministicSummary(n){if(n.status==='FLIP')return `ARCANA favored ${n.reading.advice[0]}; ${n.final} lay inside the effective decision window.`;if(n.status==='CONFIRM')return `ARCANA confirmed the rational lead held by ${n.rational[0]}.`;return `ARCANA produced no decision-changing signal; ${n.rational[0]} retained the lead.`;}
 function mount(index){root.querySelectorAll('[data-arc-node]').forEach(b=>b.setAttribute('aria-expanded','false'));if(active===index){host.replaceChildren();active=null;return;}active=index;root.querySelectorAll(`[data-arc-node="${index}"]`).forEach(b=>b.setAttribute('aria-expanded','true'));const n=report.nodes[index],detail=el('article','arc-detail'),head=el('div','arc-detail-head'),who=el('div','arc-actor');who.append(identity(n.actor),el('b','',n.actor));const close=el('button','arc-close','Close detail');close.type='button';close.addEventListener('click',()=>mount(index));head.append(who,close);detail.append(head);const layout=el('div','arc-reading-layout');if(n.conflict){const duel=el('div','arc-duel'),core=el('div','arc-clash-core');core.append(el('span','','ADVISORY COLLISION'),el('strong','',n.conflict.type.replaceAll('_',' ')),el('b','',Number(n.conflict.collision).toFixed(3)),el('small','',`${n.conflict.stances[0]} ↔ ${n.conflict.stances[1]}`));duel.append(readingBox(n.reading,n.actor),core,readingBox(n.conflict.reading,n.conflict.actor));layout.append(duel);}else layout.append(readingBox(n.reading,n.actor));const path=el('div','arc-path');path.append(el('span','','RATIONAL'),el('b','',`${n.rational[0]} ${Number(n.rational[1]).toFixed(3)}`),el('span','','→ ARCANA'),el('b','',n.status==='FLIP'?'CHANGED':n.status==='CONFIRM'?'CONFIRMED':'NO EFFECT'),el('span','','→ FINAL'),el('b','',n.final),el('small','',`gap ${Number(n.gap).toFixed(3)} · window ±${Number(n.window).toFixed(3)}`));layout.append(path,el('p','arc-template-summary',deterministicSummary(n)));const outcome=el('div','arc-outcome');outcome.append(el('b','','ACTUAL INTERACTION'),el('span','',n.chosen_action||n.final));for(const actor of Object.keys(n.pss||{})){const impact=n.outcome_pss?.[actor]?.delta;outcome.append(el('span','',impact?`${actor}: pressure ${Number(impact.pressure||0).toFixed(3)} · control ${Number(impact.control||0).toFixed(3)}`:`${actor}: no outcome attached`));}n.relationships.forEach(r=>outcome.append(el('span','',`${r.a}↔${r.b}: trust ${r.trust.toFixed(3)} · reliability ${r.reliability.toFixed(3)}`)));layout.append(outcome);detail.append(layout);host.replaceChildren(detail);host.scrollIntoView({behavior:'smooth',block:'nearest'});}
 root.querySelectorAll('[data-arc-node]').forEach(button=>button.addEventListener('click',()=>mount(Number(button.dataset.arcNode))));
})();
"""
