"""Deterministic full ARCANA audit -> compact display-trace compiler."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Mapping, Sequence


ROOT = Path(__file__).resolve().parent
PSS_KEYS = ("energy", "pressure", "confidence", "control", "identity_integrity")


def _q(value: object) -> float:
    return round(float(value), 3)


def _slug(value: object) -> str:
    return re.sub(r"[^A-Z0-9]+", "_", str(value).upper()).strip("_")


def _card_code(draw: Mapping[str, object]) -> str:
    raw_orientation = draw.get("orientation")
    orientation_value = getattr(raw_orientation, "value", raw_orientation)
    orientation = "U" if str(orientation_value) == "UPRIGHT" else "R"
    return f'{draw.get("card_id", "CB")}{orientation}'


def _display_advice(value: object) -> str:
    raw = str(getattr(value, "value", value))
    return raw.replace("AdviceType.", "").replace("_", " ")


class ArcanaReportTraceCompiler:
    """Creates a compact, presentation-only trace without invoking an LLM."""

    def __init__(self, historical_root: str | Path | None = None) -> None:
        root = Path(historical_root or ROOT / "historical")
        self.cards = json.loads((root / "cards.json").read_text(encoding="utf-8"))["cards"]
        identity_payload = json.loads(
            (ROOT / "hakoniwa" / "identity_cards.json").read_text(encoding="utf-8")
        )
        self.identities = identity_payload["assignments"]

    def _card_dictionary(self) -> dict:
        rows = {}
        for raw in self.cards:
            rows[raw["card_id"]] = {
                "r": raw.get("rank"),
                "s": raw.get("suit"),
                "n": raw.get("etteilla_number"),
                "u": raw["forename_upright"],
                "rvs": raw["forename_reversed"],
            }
        return rows

    @staticmethod
    def _pss_entry(actor: str, state: Mapping[str, object], previous: dict[str, dict]) -> dict:
        current = {key: _q(state.get(key, 0.0)) for key in PSS_KEYS}
        if actor not in previous:
            previous[actor] = current
            return {"snapshot": current}
        delta = {
            key: _q(current[key] - previous[actor][key])
            for key in PSS_KEYS
            if abs(current[key] - previous[actor][key]) >= 0.0005
        }
        previous[actor] = current
        return {"delta": delta}

    def _reading(
        self,
        reading: Mapping[str, object],
        rule_dictionary: dict,
    ) -> dict:
        rule_refs = []
        for row in reading.get("resolved_rules", ()):
            rule_id = f'{_slug(row.get("rule_type", "RULE"))}_{_slug(row.get("meaning", "UNKNOWN"))}'
            if rule_id not in rule_dictionary:
                rule_dictionary[rule_id] = {
                    "type": row.get("rule_type"),
                    "meaning": row.get("meaning"),
                    "original": row.get("original_french"),
                    "source": row.get("source_id"),
                    "page": row.get("source_page"),
                }
            rule_refs.append({"id": rule_id, "cards": list(row.get("card_ids", ()))})
        advice = reading.get("advice", {})
        process = reading.get("advice_process", {})
        return {
            "seed": reading.get("seed"),
            "cards": [_card_code(row) for row in reading.get("draws", ())],
            "rules": rule_refs,
            "motifs": {key: _q(value) for key, value in process.get("motif_tally", {}).items()},
            "advice": [_display_advice(advice.get("recommendation", "INDETERMINATE")),
                       _q(advice.get("confidence", 0.0))],
        }

    @staticmethod
    def _status(adoption: Mapping[str, object]) -> str:
        raw = adoption.get("adoption_status", "NO_EFFECT")
        return {
            "ACCEPT_ADVICE": "FLIP",
            "CONFIRM_RATIONAL_CHOICE": "CONFIRM",
            "NO_EFFECT": "NO_EFFECT",
            "DECLINE_ADVICE": "NO_EFFECT",
        }.get(str(raw), "NO_EFFECT")

    def compile(self, audits: Sequence[Mapping[str, object]]) -> dict:
        rules: dict[str, dict] = {}
        previous_pss: dict[str, dict] = {}
        actors: dict[str, dict] = {}
        nodes = []
        for index, audit in enumerate(audits):
            if audit.get("status", "RUN") != "RUN":
                continue
            reading = audit.get("reading", {})
            actor = str(audit.get("decision_maker", reading.get("actor_id", "Actor")))
            identity = self.identities.get(actor)
            actors.setdefault(actor, {
                "identity": (
                    f'{identity["card_id"]}{"U" if identity.get("orientation") == "UPRIGHT" else "R"}'
                    if identity else None
                ),
                "identity_status": "PROVISIONAL" if identity else "UNASSIGNED",
            })
            adoption = audit.get("adoption", {}) or {}
            scores = adoption.get("base_scores", {}) or {}
            rational_action = adoption.get("rational_choice_before_arcana", "—")
            final_action = adoption.get("selected_action_after_arcana", rational_action)
            other_gaps = [
                _q(value) for key, value in (adoption.get("candidate_gaps", {}) or {}).items()
                if key != rational_action
            ]
            pss_before = adoption.get("receptivity", {}).get("pss_snapshot", {})
            node = {
                "id": str(audit.get("node", f"node_{index + 1}")),
                "actor": actor,
                "reading": self._reading(reading, rules),
                "rational": [rational_action, _q(scores.get(rational_action, 0.0))],
                "final": final_action,
                "status": self._status(adoption),
                "gap": min(other_gaps, default=0.0),
                "window": _q(adoption.get("effective_threshold", 0.0)),
                "pss": {actor: self._pss_entry(actor, pss_before, previous_pss)},
                "chosen_action": audit.get("chosen_action", final_action),
            }
            conflict = audit.get("conflict_interaction")
            if isinstance(conflict, Mapping):
                counter = conflict.get("counterparty_reading", {})
                counter_actor = str(counter.get("actor_id", "Counterparty"))
                counter_identity = self.identities.get(counter_actor)
                actors.setdefault(counter_actor, {
                    "identity": (
                        f'{counter_identity["card_id"]}{"U" if counter_identity.get("orientation") == "UPRIGHT" else "R"}'
                        if counter_identity else None
                    ),
                    "identity_status": "PROVISIONAL" if counter_identity else "UNASSIGNED",
                })
                interaction = conflict.get("interaction", {})
                counter_pss = interaction.get("counterparty_pss_mediation", {}).get("pss_snapshot", {})
                node["pss"][counter_actor] = self._pss_entry(counter_actor, counter_pss, previous_pss)
                node["conflict"] = {
                    "actor": counter_actor,
                    "reading": self._reading(counter, rules),
                    "type": interaction.get("interaction_type", "INDETERMINATE_INTERACTION"),
                    "collision": _q(interaction.get("stance_collision", 0.0)),
                    "stances": [
                        _q(interaction.get("primary_pss_mediation", {}).get("stance", 0.0)),
                        _q(interaction.get("counterparty_pss_mediation", {}).get("stance", 0.0)),
                    ],
                }
            after = audit.get("all_actor_pss_after", {}) or {}
            node["outcome_pss"] = {}
            for actor_id, values in after.items():
                if actor_id not in node["pss"]:
                    continue
                baseline = previous_pss.get(actor_id, {})
                delta = {
                    key: _q(float(values.get(key, 0.0)) - float(baseline.get(key, 0.0)))
                    for key in ("pressure", "control")
                    if abs(float(values.get(key, 0.0)) - float(baseline.get(key, 0.0))) >= 0.0005
                }
                node["outcome_pss"][actor_id] = {"delta": delta}
            relationship_rows = []
            feedback = audit.get("operational_feedback", {}) or {}
            for update in feedback.get("pss_updates", ()) if isinstance(feedback, Mapping) else ():
                for counterpart, relation in (update.get("relationship_updates", {}) or {}).items():
                    relationship_rows.append({
                        "a": update.get("actor"), "b": counterpart,
                        "trust": _q(relation.get("trust", 0.0)),
                        "reliability": _q(relation.get("operational_reliability", 0.0)),
                    })
            node["relationships"] = relationship_rows
            nodes.append(node)

        return {
            "schema_version": "arcana-report-trace-1.0",
            "actors": actors,
            "nodes": nodes,
            "dictionary": {
                "cards": self._card_dictionary(),
                "rules": rules,
            },
            "render_contract": {
                "deterministic": True,
                "llm_required": False,
                "detail_mount_policy": "AT_MOST_ONE",
                "pss_storage": "FIRST_SNAPSHOT_THEN_DELTA",
            },
        }
