import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from kfrage_model import cli


ROOT = Path(__file__).parents[1]


class CliTests(unittest.TestCase):
    def run_cli(self, args):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = cli.main(args)
        return code, output.getvalue()

    def test_validate_reports_single_sixteen_actor_deck(self):
        code, output = self.run_cli(["validate", "--json"])
        payload = json.loads(output)
        self.assertEqual(code, 0)
        self.assertTrue(payload["valid"])
        self.assertEqual(payload["actor_count"], 17)

    def test_protocol_is_machine_readable(self):
        code, output = self.run_cli(["protocol"])
        payload = json.loads(output)
        self.assertEqual(code, 0)
        self.assertEqual(payload["protocol_version"], "political-sandbox-cli-1.0")
        self.assertGreaterEqual(len(payload["request_example"]["actions"]), 2)
        self.assertEqual(payload["arcana_contract"]["default"], "disabled")

    def test_example_decision_request_runs(self):
        request = ROOT / "examples" / "decision_request.json"
        code, output = self.run_cli(["decide", "Merz", "--request", str(request)])
        payload = json.loads(output)
        self.assertEqual(code, 0)
        self.assertIn(payload["decision"]["chosen_action"], payload["decision"]["scores"])
        self.assertEqual(payload["actor"], "Merz")

    def test_arcana_is_opt_in_seeded_and_fully_reported(self):
        request = ROOT / "examples" / "decision_request.json"
        code, output = self.run_cli([
            "--arcana", "--arcana-seed", "42",
            "decide", "Merz", "--request", str(request),
        ])
        payload = json.loads(output)
        self.assertEqual(code, 0)
        self.assertTrue(payload["arcana"]["enabled"])
        self.assertEqual(payload["arcana"]["status"], "RUN")
        self.assertEqual(len(payload["arcana"]["reading"]["draws"]), 14)
        self.assertIn("advice_process", payload["arcana"]["reading"])
        self.assertIn("selected_action_after_arcana", payload)


if __name__ == "__main__":
    unittest.main()
