import unittest
from kfrage_model.roguelike_engine import Action, ActorProfile, Node, RoguelikeEngine, Variable

class RoguelikeEngineTests(unittest.TestCase):
    def test_every_changed_variable_is_evaluated_for_every_visible_actor(self):
        engine=RoguelikeEngine(
            {"poll":Variable("poll",20,1),"power":Variable("power",50,10)},
            {a:ActorProfile(a,{"poll":1,"power":1}) for a in ("A","B")})
        node=Node("n","A",(Action("x",{"poll":1,"power":2}),Action("y",{"poll":0,"power":-1})),("A","B"))
        event=engine.play(node)
        for actor in ("A","B"):
            for action in ("x","y"):
                self.assertEqual({r["variable"] for r in event["all_actor_action_evaluations"][actor][action]["variable_evaluations"]},{"poll","power"})

    def test_only_decision_makers_ranking_selects_action(self):
        engine=RoguelikeEngine(
            {"power":Variable("power",50,10)},
            {"A":ActorProfile("A",{"power":1}),"B":ActorProfile("B",{"power":-1})})
        node=Node("n","A",(Action("gain",{"power":5}),Action("lose",{"power":-5})),("A","B"))
        self.assertEqual(engine.play(node)["chosen_action"],"gain")

if __name__=="__main__": unittest.main()
