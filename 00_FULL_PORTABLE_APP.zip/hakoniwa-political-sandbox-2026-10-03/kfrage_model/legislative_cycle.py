"""Orchestration for debate -> forecast -> vote -> feedback cycles."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, replace
from typing import Mapping

from .parliamentary_vote import (
    BlocVotePrior, ParliamentaryVoteModel, VoteFeedback, VoteForecast,
    VoteResult, VoteRule, VoteSimulation,
)
from .political_activity import (
    ActivityContext, ActivityOutcome, PoliticalActivityModel,
    RoutineActivityProgram,
)
from .political_state import PoliticalState, PressureRule


@dataclass(frozen=True)
class DebateSignal:
    key: str
    bloc_yes_shift: Mapping[str, float] = field(default_factory=dict)
    bloc_attendance_shift: Mapping[str, float] = field(default_factory=dict)
    state_effects: Mapping[str, float] = field(default_factory=dict)
    source_status: str = "MODEL_ASSUMPTION"


class LegislativeCycle:
    def __init__(
        self,
        state: PoliticalState,
        vote_model: ParliamentaryVoteModel,
        activity_model: PoliticalActivityModel,
        pressure_rules: tuple[PressureRule, ...] = (),
        event_observers: tuple[object, ...] = (),
    ) -> None:
        self.state = state
        self.vote_model = vote_model
        self.activity_model = activity_model
        self.pressure_rules = pressure_rules
        self.event_observers = event_observers
        self.trace: list[dict] = []

    @staticmethod
    def apply_debate_signals(
        blocs: tuple[BlocVotePrior, ...], signals: tuple[DebateSignal, ...]
    ) -> tuple[BlocVotePrior, ...]:
        yes_shift: dict[str, float] = {}; attendance_shift: dict[str, float] = {}
        for signal in signals:
            for key, value in signal.bloc_yes_shift.items(): yes_shift[key] = yes_shift.get(key, 0.0) + value
            for key, value in signal.bloc_attendance_shift.items(): attendance_shift[key] = attendance_shift.get(key, 0.0) + value
        updated = []
        for bloc in blocs:
            shift = yes_shift.get(bloc.key, 0.0)
            yes = max(0.0, min(1.0, bloc.yes_share + shift))
            # Debate conversion is taken proportionally from no/abstention.
            remainder_before = bloc.no_share + bloc.abstain_share
            remainder_after = 1.0 - yes
            no = remainder_after * bloc.no_share / remainder_before if remainder_before else 0.0
            abstain = 1.0 - yes - no
            attendance = max(0.0, min(1.0, bloc.attendance + attendance_shift.get(bloc.key, 0.0)))
            updated.append(replace(bloc, attendance=attendance, yes_share=yes, no_share=no, abstain_share=abstain))
        return tuple(updated)

    def run(
        self,
        *,
        proposal: str,
        stage: str,
        rule: VoteRule,
        blocs: tuple[BlocVotePrior, ...],
        debate_signals: tuple[DebateSignal, ...],
        activity_programs: tuple[RoutineActivityProgram, ...],
        activity_contexts: Mapping[str, ActivityContext],
        feedback_by_outcome: Mapping[str, VoteFeedback],
        days: int,
        seed: int,
        stochastic: bool,
        vote_runs: int = 5000,
        settled_counts: tuple[int, int, int, int] | None = None,
    ) -> dict:
        events = self.activity_model.generate(activity_programs, days, seed, stochastic)
        outcomes: list[ActivityOutcome] = []
        accounts = {program.actor: program.capital_account for program in activity_programs}
        aliases = {program.actor: program.channel_aliases for program in activity_programs}
        for index, event in enumerate(events):
            context = activity_contexts[event.issue]
            outcome = self.activity_model.resolve(event, context, accounts[event.actor], aliases[event.actor], seed + index + 1, stochastic)
            update = self.activity_model.apply(self.state, outcome, self.pressure_rules)
            for observer in self.event_observers:
                observer.record(self.state,event_id=f"activity:{event.event_id}",actor=event.actor,action=event.activity_type,event_kind="routine_political_activity",resource_changes=update)
            outcomes.append(outcome)

        # Debate signals change both the parliamentary belief state and, when
        # configured, the surrounding political environment.
        updated_blocs = self.apply_debate_signals(blocs, debate_signals)
        for signal in debate_signals:
            if signal.state_effects:
                from .political_state import PoliticalAction
                known = {key: value for key, value in signal.state_effects.items() if key in self.state.variables}
                update = self.state.apply(PoliticalAction(
                    f"debate:{signal.key}", {"immediate": known, "medium": {}, "long": {}}, tags=("debate_signal",)
                ), self.pressure_rules)
                for observer in self.event_observers:
                    observer.record(self.state,event_id=f"debate:{signal.key}",actor="Parliament",action=signal.key,event_kind="parliamentary_debate",resource_changes=update)

        assumptions = tuple(
            [f"{b.key}:{b.source_status}" for b in updated_blocs]
            + [f"debate:{s.key}:{s.source_status}" for s in debate_signals]
        )
        forecast = self.vote_model.forecast(proposal, stage, rule, updated_blocs, assumptions)
        for observer in self.event_observers:
            observer.record(self.state,event_id=f"forecast:{proposal}:{stage}",actor="ParliamentaryVoteModel",action=forecast.conclusion,event_kind="vote_forecast")
        simulation: VoteSimulation | None = None
        if stochastic:
            simulation = self.vote_model.simulate(rule, updated_blocs, vote_runs, seed)
        if settled_counts is None:
            if stochastic:
                yes, no, abstain, absent = self.vote_model._sample_once(rule, updated_blocs, __import__("random").Random(seed + 10_000))
            else:
                yes = round(forecast.expected_yes); no = round(forecast.expected_no)
                abstain = round(forecast.expected_abstain); absent = rule.total_members - yes - no - abstain
        else:
            yes, no, abstain, absent = settled_counts
        result = self.vote_model.settle(proposal, stage, rule, yes, no, abstain, absent)
        feedback = self.vote_model.apply_feedback(self.state, result, feedback_by_outcome, self.pressure_rules)
        for observer in self.event_observers:
            observer.record(self.state,event_id=f"vote:{proposal}:{stage}",actor="Bundestag",action=result.outcome_class,event_kind="vote_result_and_feedback",resource_changes=feedback)
        payload = {
            "schema_version": "legislative-cycle-1.0",
            "proposal": proposal,
            "stage": stage,
            "randomness_scope": "attendance, hidden defections, routine-event timing and media reach only; personality parameters stay fixed",
            "activities": [asdict(item) for item in outcomes],
            "debate_signals": [asdict(item) for item in debate_signals],
            "vote_forecast": asdict(forecast),
            "vote_simulation": asdict(simulation) if simulation else None,
            "vote_result": asdict(result),
            "feedback": feedback,
            "final_state": self.state.payload(),
            "polling": [observer.to_dict() for observer in self.event_observers if hasattr(observer, "to_dict")],
        }
        self.trace.append(payload)
        return payload
