"""Minimal example: replace one actor while leaving the environment unchanged."""

from kfrage_model.personality_api import DecisionContext, PersonalityPolicy, PolicyDecision


class AlwaysWaitWuest(PersonalityPolicy):
    policy_id = "example_always_wait_wuest"
    actor = "Wuest"

    def decide(self, context: DecisionContext) -> PolicyDecision:
        if context.stage != "candidacy_choice":
            raise ValueError(context.stage)
        return PolicyDecision(
            action="remain_ambiguous",
            utilities={"challenge": 0.0, "remain_ambiguous": 1.0},
            rule="Example policy only: always preserve ambiguity.",
        )
