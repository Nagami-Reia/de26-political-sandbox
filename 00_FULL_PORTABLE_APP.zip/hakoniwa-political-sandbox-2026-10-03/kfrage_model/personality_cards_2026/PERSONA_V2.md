# 人格卡 v2：自由决策角色层

## 唯一正式人物卡文件

当前16人已合并为一份canonical deck：

```python
engine = FreeAgentDecisionEngine.from_json(
    "personality_cards_2026/cards_pss.json"
)
```

2026-09研究波次已合并进主文件；其来源与推理边界仍见`SOURCE_INDEX_EXPANSION_2026_09.md`和`REPORT_EXPANSION_2026_09.md`。

## 为什么重写

v1 卡把若干历史上观察到的行为压缩成了固定权重，容易产生两个问题：

1. 人物像在执行作者预先写好的策略；
2. 同一人物在不同压力、资源和关系状态下仍然倾向重复同一种动作。

v2 不再保存“遇到某事就做某事”的规则。它只保存稳定偏好、风险处理方式、控制对象、压力敏感性和记忆残留。环境每轮自由提供行动菜单，人物对所有合法行动重新评分。

## 五层卡片

### A. Character DNA

- `archetype`：惯用的政治问题解决方式；
- `core_drive`：持续投入政治工作的内在燃料；
- `value_hierarchy`：价值冲突时的排序。

### B. Decision parameters

- `ambition`：为改变局面承受风险的意愿；
- `risk_appetite` 与 `risk_modifiers`：区分可逆/不可逆、公开/私下、结构已准备/尚未准备的风险；
- `control_preferences`：想控制方向、过程、组织、执行、联盟还是公共议程；
- `adaptability`：新信息和失败出现后的改线能力；
- `conflict_strategies`：攻击、谈判、回避、制度化、重构叙事的相对偏好；
- `stress_resistance`、`recovery_rate`、`sensitivity_map`。

### C. Resources

卡内资源只是一个带日期的启动快照。真正运行时必须由环境传入人物当轮**可感知**的资源；人格不能给自己增加职位、票数或关系。

### D. Political State System（PSS）

每位人物实时维护：

- `energy`
- `pressure`
- `confidence`
- `control`
- `identity_integrity`

五项状态与全部量化卡片参数统一使用 `0.000–1.000`，对外 trace 保留三位小数。它们会改变努力成本、公开暴露成本、有效风险偏好和恢复控制的价值。因此同一个行动菜单可以在不同轮次得到不同结果。

事件必须先由 PSS 转换为人物特定 `StateImpact`，不能直接扣状态。自然时间只恢复 Energy、降低 Pressure；Confidence、Control、Identity Integrity 分别需要成功、资源/程序恢复和身份一致行动。

### E. Memory

- `event_memory`：事件标签、正负效价、强度、衰减和未愈合程度；
- `relationship_memory`：对方的信任、执行可靠性、依赖和杠杆；
- `learned_response_tags`：人物从一次经历中形成的应对方式。

记忆不直接指定动作。只有当新场景/行动标签与旧记忆产生共振时，才进入本轮评分。

## 环境必须提供的 ActionOption

每个候选行动由环境定义：

- 对当前目标和人物价值的预期影响；
- 所需资源与资源消耗；
- 上行、下行、不确定性、不可逆性、努力和公共暴露；
- 能恢复哪类控制；
- 冲突方式、身份标签、风险标签；
- 目标人物及关系依赖；
- 是否制度上合法。

卡片无权创造动作，也无权修改行动后果。

## 决策公式

```text
Action Score =
    Goal Alignment
  + Resource Feasibility
  + Risk Calculation
  + Current State Modifier
  + Memory Modifier
  + Identity Consistency
```

六个部分都会单独写入 trace。若职位、票数、联盟或其他硬资源不达标，行动被硬拒绝，而不是用人格分数弥补。

这里的“最高分”是有边界的自由选择：角色可以在环境允许的菜单内自主选择，但不能凭空生成权力或绕过制度。

## 每轮运行

```text
世界事件
  ↓
资源、压力、关系、记忆更新
  ↓
每个角色通过自己的信息过滤器看到局部世界
  ↓
角色独立给全部合法行动评分
  ↓
执行最高分行动
  ↓
投票/谈判/舆论等世界机制结算结果
  ↓
结果回写状态、记忆、关系、资源与下一轮事件压力
```

人格在 deterministic baseline 中不随机。随机项只能来自未观测信息、传播、投票偏差、执行结果等外部 contingency。

## 文件

- `cards_pss.json`：十位人物的正式 PSS 人格卡；
- `POLITICAL_STATE_SYSTEM.md`：PSS 数值、事件、共振和恢复规范；
- `../persona_v2.py`：加载、评分、事件冲击、结果记忆和恢复机制；
- `../test_persona_v2.py`：卡片加载、资源硬约束、状态变化、压力敏感性和关系记忆测试。

v1 文件继续保留，用于复现旧结果。新情景应优先调用 v2；不得把 v1 历史路径当成 v2 的动作规则。
