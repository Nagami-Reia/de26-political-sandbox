# Philipp Amthor — card and temporary-office source notes

As of: 2026-09-22

## Observed facts

- Daniel Peters resigned as CDU Mecklenburg-Vorpommern chair after the party's
  4.9% Landtag result; general secretary Katy Hoffmeister and deputy chair Ann
  Christin von Allwörden also resigned. NDR reports that deputy chair Philipp
  Amthor assumed the chair on an acting basis until a state party congress,
  expected in early 2027. No verified successor candidate is encoded.
- CDU-MV no longer has a Landtag parliamentary group. Its state-level policy,
  staffing and media infrastructure therefore cannot be modelled as if Amthor
  inherited a functioning faction.
- Amthor remains State Minister in the Federal Chancellery for federal-state
  cooperation, a Bundestag member, chair of the CDU Mecklenburg-Vorpommern
  Bundestag group and CDU federal members officer.
- The CDU-MV statute makes the state party congress the highest party organ and
  assigns it the election of the state executive board.
- In the NDR interview of 2026-08-26 Amthor stressed implementation over
  announcement. In the project interview transcript he repeatedly describes
  politics through pre-coordination, institutional process, party organization,
  democratic differentiation and political self-efficacy.

## Model assumptions

- The acting chair can coordinate and represent the state organization and
  organize a successor process, but cannot recreate Landtag faction powers.
- The Chancellery post supplies information and federal-state access, not an
  automatic substitute for local organization or electoral acceptance.
- Baseline decision logic treats immediate self-coronation as less consistent
  with a credible organizational rebuild than an open, criteria-based process.
  This is a falsifiable model assumption, not an observed private intention.

## Unknown black boxes

- Internal delegate alignments and district-chair preferences.
- Whether Amthor wants the permanent chairmanship.
- The exact state-party-congress date and the eventual candidate field.
- Distribution of former faction staff and retained organizational capacity.

## Sources

- NDR, “Nach Wahl-Debakel: CDU-Chef Peters tritt zurück - Amthor übernimmt”:
  https://www.ndr.de/nachrichten/mecklenburg-vorpommern/landtagswahl/nach-wahl-debakel-cdu-chef-peters-tritt-zurueck-amthor-uebernimmt,mvwahl-446.html
- NDR election liveblog:
  https://www.ndr.de/nachrichten/mecklenburg-vorpommern/landtagswahl/liveblog-wahl-mv-ruecktritte-bei-der-cdu-gespraechsangebote-fuer-sondierungen,mvwahl-liveticker-100.html
- Federal Government biography:
  https://www.bundesregierung.de/breg-de/bundesregierung/bundeskanzleramt/philipp-amthor-2448320
- Federal Government, cabinet changes and federal-state remit:
  https://www.bundesregierung.de/breg-de/suche/merz-veraenderungen-im-kabinett--2448244
- NDR interview, “Weniger ankündigen, mehr handwerklich umsetzen”:
  https://www.ndr.de/nachrichten/info/sendungen/interviews/cdu-politiker-amthor-weniger-ankuendigen-mehr-handwerklich-umsetzen,audio-3440584.html
- CDU Mecklenburg-Vorpommern statute: https://cdu-mv.de/satzung/
- Project transcript (read-only source): `sources/Philipp_Amthor_采访转写(1).txt`

