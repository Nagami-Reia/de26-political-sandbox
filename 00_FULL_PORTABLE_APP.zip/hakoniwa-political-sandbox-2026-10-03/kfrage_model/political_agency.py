"""Dynamic political action horizon, deliberately separate from PSS control."""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from typing import Mapping

from .institutional_logic import q3


@dataclass(frozen=True)
class AgencyHorizon:
    perceived_alternatives: float = 1.000
    confidence_in_deviation: float = 1.000
    collective_change_expectation: float = 1.000
    access_to_organizational_carrier: float = 1.000
    epistemic_status: str = "MODEL_ASSUMPTION"

    def __post_init__(self) -> None:
        for key, value in asdict(self).items():
            if key == "epistemic_status":
                continue
            if not 0.0 <= float(value) <= 1.0:
                raise ValueError(f"{key} must be in 0.000..1.000")

    def update(
        self,
        *,
        successful_deviation: float = 0.0,
        alternative_endorsements: float = 0.0,
        necessity_pressure: float = 0.0,
        organizational_support: float = 0.0,
        previous_failed_attempts: float = 0.0,
    ) -> "AgencyHorizon":
        success = float(successful_deviation)
        endorsements = float(alternative_endorsements)
        necessity = float(necessity_pressure)
        support = float(organizational_support)
        failures = float(previous_failed_attempts)
        return replace(
            self,
            perceived_alternatives=q3(
                self.perceived_alternatives + 0.200 * endorsements + 0.100 * success - 0.150 * necessity
            ),
            confidence_in_deviation=q3(
                self.confidence_in_deviation + 0.250 * success + 0.100 * support - 0.200 * failures
            ),
            collective_change_expectation=q3(
                self.collective_change_expectation + 0.200 * endorsements + 0.150 * support - 0.150 * failures
            ),
            access_to_organizational_carrier=q3(
                self.access_to_organizational_carrier + 0.250 * support - 0.100 * necessity
            ),
        )

    def evolve(self, agency_delta: float = 0.0, carrier_delta: float = 0.0) -> "AgencyHorizon":
        """Apply already-assessed system feedback without reinterpreting it."""
        delta = float(agency_delta)
        return replace(
            self,
            perceived_alternatives=q3(self.perceived_alternatives + delta),
            confidence_in_deviation=q3(self.confidence_in_deviation + 0.750 * delta),
            collective_change_expectation=q3(self.collective_change_expectation + delta),
            access_to_organizational_carrier=q3(
                self.access_to_organizational_carrier + float(carrier_delta)
            ),
        )

    def payload(self) -> dict:
        return {key: round(value, 3) if isinstance(value, float) else value for key, value in asdict(self).items()}


class AgencyRegistry:
    def __init__(self, values: Mapping[str, AgencyHorizon] | None = None):
        self.values = dict(values or {})

    def get(self, actor: str) -> AgencyHorizon:
        return self.values.get(actor, AgencyHorizon())

    def set(self, actor: str, horizon: AgencyHorizon) -> None:
        self.values[actor] = horizon

    def payload(self) -> dict:
        return {actor: horizon.payload() for actor, horizon in self.values.items()}
