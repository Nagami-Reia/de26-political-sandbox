# Generated Decision Space

`decision_space.py` replaces large hand-authored branch trees with a bounded,
auditable political action grammar.

Its upstream input may come from `historical_dynamics.py`, which explains why an
event occurred before this module asks what the actor perceives or chooses.

## Five layers

1. **Perception** — `InformationFilter` beliefs, source trust, event ambiguity,
   memory resonance and relationship trust produce a distribution over frames.
   Perception is not an action and cannot be chosen opportunistically.
2. **Goals** — value hierarchy, PSS pressure/confidence, event cues and live goals
   determine which objectives are currently salient.
3. **Strategies** — reusable families such as direct control, private negotiation,
   institutional consultation, public signalling, bounded countermoves and delay
   for verification become available only when the event supplies a consequence
   model and at least one active goal.
4. **Execution styles** — behind-the-scenes coordination, formal procedure,
   public pressure, measured statements and verification pauses combine with the
   strategy. Character conflict and control preferences affect style fit.
5. **Outcomes** — success, partial success and failure are settled only after the
   actor chooses. A seed may alter the outcome, never personality or the choice.

## Scenario authoring

The scenario no longer needs to write every action. It declares one event and one
factual effect model per strategy it wants to make physically possible:

```python
event = DecisionEvent(
    key="coalition_vote_warning",
    domain="legislative",
    tags=("votes", "coalition", "uncertain"),
    severity=.800,
    ambiguity=.600,
    signal_variables={"rebel_pressure": 1.0},
    effect_models={
        "private_negotiation": StrategyEffectModel(
            effects={
                "immediate": {"coalition_stability": 5},
                "medium": {},
                "long": {},
            },
            base_feasibility=.750,
        ),
    },
)
```

Then place it on a generated node:

```python
node = SimulationNodeV3("n1", "Merz", (), decision_event=event)
engine = LayeredSimulationOrchestrator(
    state, {"n1": node}, personas, information, bindings, configuration,
    decision_generator=DecisionSpaceGenerator(),
    outcome_resolver=OutcomeResolver(seed=7, stochastic=True),
)
```

Static `WorldAction` nodes remain valid for archived scenarios.

## Trace contract

Every generated turn preserves:

- the full perception distribution and accessible signals;
- active goals and their value/event/PSS components;
- every generated strategy/style path and generation score;
- rejected generation paths and reasons;
- institutional and perceptual filtering;
- Persona v2's six-component evaluation;
- the chosen action;
- all three conditional outcome weights;
- the resolved outcome and resulting world transition.

Conditional weights are model branches, not real-world probabilities.
