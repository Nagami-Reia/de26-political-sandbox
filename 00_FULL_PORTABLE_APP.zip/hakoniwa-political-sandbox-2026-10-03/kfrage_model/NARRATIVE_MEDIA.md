# Narrative and Media Route

`narrative_media.py` models competition over what a fact means. It is deliberately
separate from substantive policy choice and from the historical event generator.

```text
Fact or settled outcome
  -> actor-specific media move choice
  -> competing NarrativeFrames x MediaChannels
  -> heterogeneous audience interpretation
  -> frame shares + agenda ownership
  -> public legitimacy/support signals
  -> political state / polling / next-turn FoW
```

## Core objects

### NarrativeFact

Stores the issue, evidence tags, salience, ambiguity, evidence strength and
competing-news load. Creating a fact does not itself change support.

### NarrativeFrame

Contains:

- eligible sponsors;
- claim and contradiction tags;
- target audiences;
- baseline credibility;
- emotional force and simplicity;
- identity cues;
- legitimacy and support interpretations;
- optional blame target and relationship posture.

### MediaChannel

Separates broadcast, social, regional, party-owned or other channels through
reach, speed, channel trust, volatility, audience affinity, visibility and cost.

### AudienceSegment

Audiences differ in attention, emotional susceptibility, identity cues, source
trust, size and interpretation inertia. There is no single undifferentiated
“public”.

## Separate actor choice

`NarrativeMoveGenerator` builds a media-only menu of frame/channel combinations,
plus an explicit `hold_message` option. Persona v2 chooses from this menu without
replacing the actor's substantive decision for the turn.

Media reach is resolved only after the deterministic choice. Changing a reach
seed may change diffusion but cannot change which media action the character
selected.

## Competition rule

For each audience, persuasion power combines:

```text
fact salience
× audience attention
× channel reach and audience affinity
× source trust
× effective frame credibility
× evidence alignment
× emotional/identity fit
× novelty remaining after saturation
× available attention after competing news
```

Existing interpretations contribute inertia. Counterframes therefore compete
for share rather than independently adding unconstrained poll points.

Repeated use of the same frame/channel/audience combination increases saturation
and lowers marginal attention. Emotional force is useful only when it fits the
audience; contradiction by strong evidence reduces effective credibility.

## Outputs

Every round reports:

- narrative shares and winner for each audience;
- effective attention and credibility for every frame/audience pair;
- frame saturation and evidence alignment;
- agenda ownership by actor;
- target-specific public-legitimacy changes;
- target-specific support changes;
- media-capital expenditure.

`NarrativeRoundOutcome.apply_to_political_state()` performs the explicit mapping
to state variables. Its legitimacy, support and media-capital conversion scales
are explicit arguments because Persona resources use `0..1` while political
capital accounts use `0..100`. A polling tracker can then observe the updated latent support;
the narrative engine does not pretend that an instant real survey occurred.

## Important boundary

The institutional legitimacy diagnostic in `system_feedback.py` is not the same
as public legitimacy. Institutional reproduction may succeed while the government
loses the narrative round, or vice versa. Both channels remain visible.
