import unittest

from kfrage_model.calibration.pollster_projection import project, round_grid


class PollsterProjectionTests(unittest.TestCase):
    def test_half_point_grid_uses_half_up_rounding(self):
        self.assertEqual(round_grid(19.9, 0.5), 20.0)

    def test_one_point_grid_can_hide_small_latent_change(self):
        result = project(20.0, 0.4, 1.0, 1.0)
        self.assertEqual(result["continuous_central"], 20.4)
        self.assertEqual(result["published_central"], 20.0)

    def test_timing_retention_is_explicit(self):
        result = project(21.0, 0.4, 0.75, 1.0)
        self.assertEqual(result["retained_delta"], 0.3)
        self.assertEqual(result["published_central"], 21.0)


if __name__ == "__main__":
    unittest.main()
