import unittest
from pathlib import Path

from kfrage_model.decision_space import (
    DecisionEvent,
    DecisionSpaceGenerator,
    OutcomeResolver,
    StrategyEffectModel,
)
from kfrage_model.information_filter import AccessRule, InformationFilter
from kfrage_model.persona_v2 import FreeAgentDecisionEngine
from kfrage_model.political_state import PoliticalState, StateVariable
from kfrage_model.scenario_reporting import ScenarioReportingPolicy
from kfrage_model.simulation_orchestrator import (
    LayeredConfiguration,
    LayeredSimulationOrchestrator,
    SimulationNodeV3,
)


ROOT = Path(__file__).parent
CARDS = ROOT / "personality_cards_2026" / "cards_pss.json"
ENV = ROOT / "environments" / "2026-07-31" / "environment.json"


def effects(**immediate):
    return {"immediate": immediate, "medium": {}, "long": {}}


def legislative_event():
    return DecisionEvent(
        key="pension_rebel_warning",
        domain="legislative",
        tags=("votes", "coalition", "authority", "implementation", "uncertain"),
        severity=.820,
        ambiguity=.620,
        source_actor="Frei",
        target_actor="Frei",
        signal_variables={"rebel_pressure": 1.0},
        allowed_strategy_keys=(
            "direct_control",
            "private_negotiation",
            "institutional_consultation",
            "public_signal",
            "delay_verify",
        ),
        effect_models={
            "direct_control": StrategyEffectModel(
                effects(policy_delivery=8, coalition_stability=-5),
                base_feasibility=.520,
                irreversibility=.650,
            ),
            "private_negotiation": StrategyEffectModel(
                effects(policy_delivery=3, coalition_stability=6),
                base_feasibility=.760,
                irreversibility=.180,
            ),
            "institutional_consultation": StrategyEffectModel(
                effects(policy_delivery=4, coalition_stability=4),
                base_feasibility=.720,
                irreversibility=.220,
            ),
            "public_signal": StrategyEffectModel(
                effects(policy_delivery=2, coalition_stability=-2),
                base_feasibility=.580,
                irreversibility=.420,
            ),
            "delay_verify": StrategyEffectModel(
                effects(policy_delivery=-1, coalition_stability=2),
                base_feasibility=.880,
                irreversibility=.080,
            ),
        },
    )


def state(rebel_pressure=70):
    return PoliticalState(
        {
            "rebel_pressure": StateVariable("rebel_pressure", rebel_pressure, uncertainty=.20),
            "policy_delivery": StateVariable("policy_delivery", 50),
            "coalition_stability": StateVariable("coalition_stability", 55),
        },
        {},
        {},
    )


def info(rebel_access=.90):
    return InformationFilter({
        "Merz": {
            "rebel_pressure": AccessRule(rebel_access, source="whip_count"),
            "policy_delivery": AccessRule(.85),
            "coalition_stability": AccessRule(.75),
        },
        "Frei": {
            "rebel_pressure": AccessRule(.98, source="whip_count"),
            "policy_delivery": AccessRule(.80),
            "coalition_stability": AccessRule(.80),
        },
    })


class DecisionSpaceTests(unittest.TestCase):
    def test_generator_grows_multilayer_menu_from_event(self):
        personas = FreeAgentDecisionEngine.from_json(CARDS)
        beliefs = info().observe("Merz", state(), commit=False)
        generated = DecisionSpaceGenerator().generate(
            "Merz",
            legislative_event(),
            beliefs,
            personas.cards["Merz"],
            personas.runtime["Merz"],
            personas.cards["Merz"].initial_resources,
        )
        self.assertGreaterEqual(len(generated.perceptions), 3)
        self.assertGreaterEqual(len(generated.goals), 4)
        self.assertGreaterEqual(len(generated.actions), 5)
        self.assertGreaterEqual(len({row.path.strategy for row in generated.actions}), 5)
        for action in generated.actions:
            self.assertEqual(len(action.outcome_branches), 3)
            self.assertAlmostEqual(
                sum(row.conditional_weight for row in action.outcome_branches),
                1.0,
                places=2,
            )

    def test_fog_of_war_changes_perception_before_action_scoring(self):
        personas = FreeAgentDecisionEngine.from_json(CARDS)
        generator = DecisionSpaceGenerator()
        high_beliefs = info().observe("Merz", state(90), commit=False)
        low_beliefs = info().observe("Merz", state(15), commit=False)
        high = generator.generate(
            "Merz", legislative_event(), high_beliefs,
            personas.cards["Merz"], personas.runtime["Merz"],
            personas.cards["Merz"].initial_resources,
        )
        low = generator.generate(
            "Merz", legislative_event(), low_beliefs,
            personas.cards["Merz"], personas.runtime["Merz"],
            personas.cards["Merz"].initial_resources,
        )
        high_authority = next(row for row in high.perceptions if row.key == "authority_test")
        low_authority = next(row for row in low.perceptions if row.key == "authority_test")
        self.assertGreater(high_authority.perceived_signal, low_authority.perceived_signal)
        self.assertGreater(high_authority.weight, low_authority.weight)

    def test_same_event_produces_actor_specific_style_scores(self):
        personas = FreeAgentDecisionEngine.from_json(CARDS)
        generator = DecisionSpaceGenerator(max_actions=12)
        world = state()
        views = info()
        spaces = {}
        for actor in ("Merz", "Frei"):
            spaces[actor] = generator.generate(
                actor,
                legislative_event(),
                views.observe(actor, world, commit=False),
                personas.cards[actor],
                personas.runtime[actor],
                personas.cards[actor].initial_resources,
            )
        merz = {row.world_action.choice.key: row.generation_score for row in spaces["Merz"].actions}
        frei = {row.world_action.choice.key: row.generation_score for row in spaces["Frei"].actions}
        common = set(merz) & set(frei)
        self.assertTrue(common)
        self.assertTrue(any(merz[key] != frei[key] for key in common))

    def test_same_event_can_produce_different_actor_consistent_choices(self):
        choices = {}
        for actor in ("Merz", "Frei"):
            result = LayeredSimulationOrchestrator(
                state(),
                {"n": SimulationNodeV3("n", actor, (), decision_event=legislative_event())},
                FreeAgentDecisionEngine.from_json(CARDS),
                info(),
                {},
                LayeredConfiguration.from_environment_json(ENV),
                decision_generator=DecisionSpaceGenerator(),
                outcome_resolver=OutcomeResolver(seed=7, stochastic=False),
                reporting_policy=ScenarioReportingPolicy.diagnostics_only(),
            ).run("n")
            choices[actor] = result["trace"][0]["chosen_action"]
        self.assertIn("direct_control__formal_process", choices["Merz"])
        self.assertIn("institutional_consultation__behind_scenes", choices["Frei"])

    def test_orchestrator_generates_then_resolves_outcome(self):
        config = LayeredConfiguration.from_environment_json(ENV)
        result = LayeredSimulationOrchestrator(
            state(),
            {"n": SimulationNodeV3("n", "Merz", (), decision_event=legislative_event())},
            FreeAgentDecisionEngine.from_json(CARDS),
            info(),
            {},
            config,
            decision_generator=DecisionSpaceGenerator(),
            outcome_resolver=OutcomeResolver(seed=7, stochastic=True),
            reporting_policy=ScenarioReportingPolicy.diagnostics_only(),
        ).run("n")
        turn = result["trace"][0]
        self.assertIsNotNone(turn["decision_space_generation"])
        self.assertEqual(turn["decision_source"], "generated_persona_v2_choice")
        self.assertGreaterEqual(len(turn["objective_action_menu"]), 5)
        self.assertEqual(
            turn["operational_feedback"]["settlement_status"],
            "GENERATED_OUTCOME_RESOLVED",
        )
        self.assertIn(
            turn["operational_feedback"]["outcome_branch"]["branch"],
            {"success", "partial_success", "failure"},
        )
        self.assertEqual(len(turn["operational_feedback"]["pss_updates"]), 1)
        self.assertEqual(
            turn["operational_feedback"]["pss_updates"][0]["action"],
            turn["chosen_action"],
        )

    def test_outcome_seed_cannot_randomize_actor_choice(self):
        choices = []
        outcomes = []
        for seed in (1, 2, 3, 4):
            result = LayeredSimulationOrchestrator(
                state(),
                {"n": SimulationNodeV3("n", "Merz", (), decision_event=legislative_event())},
                FreeAgentDecisionEngine.from_json(CARDS),
                info(),
                {},
                LayeredConfiguration.from_environment_json(ENV),
                decision_generator=DecisionSpaceGenerator(),
                outcome_resolver=OutcomeResolver(seed=seed, stochastic=True),
                reporting_policy=ScenarioReportingPolicy.diagnostics_only(),
            ).run("n")
            turn = result["trace"][0]
            choices.append(turn["chosen_action"])
            outcomes.append(turn["operational_feedback"]["outcome_branch"]["branch"])
        self.assertEqual(len(set(choices)), 1)
        self.assertGreaterEqual(len(set(outcomes)), 2)

    def test_generated_event_without_generator_fails_loudly(self):
        with self.assertRaisesRegex(RuntimeError, "no DecisionSpaceGenerator"):
            LayeredSimulationOrchestrator(
                state(),
                {"n": SimulationNodeV3("n", "Merz", (), decision_event=legislative_event())},
                FreeAgentDecisionEngine.from_json(CARDS),
                info(),
                {},
                LayeredConfiguration.from_environment_json(ENV),
            ).run("n")


if __name__ == "__main__":
    unittest.main()
