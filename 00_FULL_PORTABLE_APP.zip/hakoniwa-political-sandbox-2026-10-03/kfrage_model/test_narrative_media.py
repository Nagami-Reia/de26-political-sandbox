import unittest
from pathlib import Path

from kfrage_model.narrative_media import (
    AudienceSegment,
    MediaChannel,
    NarrativeArena,
    NarrativeFact,
    NarrativeFrame,
    NarrativeMove,
    NarrativeMoveGenerator,
)
from kfrage_model.persona_v2 import FreeAgentDecisionEngine
from kfrage_model.political_state import PoliticalState, StateVariable


ROOT = Path(__file__).parent
CARDS = ROOT / "personality_cards_2026" / "cards_pss.json"


def fact(tags=("economic_downturn", "external_energy_shock")):
    return NarrativeFact(
        "economic_release",
        "economy",
        tuple(tags),
        salience=.850,
        ambiguity=.450,
        evidence_strength=.800,
        news_competition=.150,
    )


def frames():
    return (
        NarrativeFrame(
            "external_shock",
            "economy",
            ("Merz",),
            ("external_energy_shock", "economic_downturn"),
            ("domestic_policy_failure",),
            ("centrist_public", "union_base"),
            credibility=.720,
            emotional_force=.420,
            simplicity=.720,
            identity_tags=("responsibility", "stability"),
            goal_impacts={"preserve_authority": .650},
            value_impacts={"political_authority": .550, "unity": .300},
            legitimacy_impacts={"government": .550, "Merz": .350},
            support_impacts={"Union": .300},
        ),
        NarrativeFrame(
            "government_failure",
            "economy",
            ("Soeder",),
            ("domestic_policy_failure", "economic_downturn"),
            ("strong_external_evidence",),
            ("centrist_public", "union_base"),
            credibility=.660,
            emotional_force=.780,
            simplicity=.850,
            identity_tags=("accountability", "change"),
            goal_impacts={"preserve_authority": .550},
            value_impacts={"political_authority": .500},
            legitimacy_impacts={"government": -.700, "Merz": -.500},
            support_impacts={"Union": -.250, "Soeder": .300},
            blame_target="Merz",
            conflict_strategy="attack",
            relationship_posture="boundary",
        ),
    )


def channels():
    return (
        MediaChannel(
            "broadcast",
            reach=.800,
            speed=.650,
            trust=.750,
            volatility=.150,
            audience_affinity={"centrist_public": .900, "union_base": .650},
            resource_cost=.180,
            visibility=.850,
        ),
        MediaChannel(
            "social",
            reach=.720,
            speed=.950,
            trust=.480,
            volatility=.500,
            audience_affinity={"centrist_public": .550, "union_base": .900},
            resource_cost=.120,
            visibility=.950,
        ),
    )


def audiences(merz_trust=.75, soeder_trust=.55):
    return (
        AudienceSegment(
            "centrist_public", .650, .720, .450,
            ("responsibility", "stability"),
            {"Merz": merz_trust, "Soeder": soeder_trust},
            .600,
        ),
        AudienceSegment(
            "union_base", .350, .850, .700,
            ("accountability", "change"),
            {"Merz": .650, "Soeder": .780},
            .500,
        ),
    )


def moves():
    return (
        NarrativeMove("Merz", "external_shock", "broadcast", .800, .180, .650),
        NarrativeMove("Soeder", "government_failure", "social", .850, .120, .950),
    )


class NarrativeMediaTests(unittest.TestCase):
    def test_fact_does_not_directly_change_legitimacy(self):
        state = PoliticalState(
            {
                "government_legitimacy": StateVariable("government_legitimacy", 55),
                "union_support": StateVariable("union_support", 30),
            },
            {"merz_media_capital": 10, "soeder_media_capital": 10},
            {},
        )
        before = {key: row.value for key, row in state.variables.items()}
        outcome = NarrativeArena(frames(), channels(), audiences()).resolve_round(fact(), moves())
        self.assertEqual(before, {key: row.value for key, row in state.variables.items()})
        outcome.apply_to_political_state(
            state,
            legitimacy_variables={"government": "government_legitimacy"},
            support_variables={"Union": "union_support"},
            capital_accounts={
                "Merz": "merz_media_capital",
                "Soeder": "soeder_media_capital",
            },
        )
        self.assertNotEqual(before, {key: row.value for key, row in state.variables.items()})
        self.assertAlmostEqual(state.capital["merz_media_capital"], 8.2)
        self.assertAlmostEqual(state.capital["soeder_media_capital"], 8.8)

    def test_source_trust_and_audience_identity_shape_competing_frames(self):
        outcome = NarrativeArena(frames(), channels(), audiences(.90, .25)).resolve_round(
            fact(), moves()
        )
        centrist = next(row for row in outcome.audience_results if row.audience == "centrist_public")
        self.assertGreater(
            centrist.frame_shares["external_shock"],
            centrist.frame_shares["government_failure"],
        )
        union = next(row for row in outcome.audience_results if row.audience == "union_base")
        self.assertGreater(union.frame_shares["government_failure"], 0.0)

    def test_evidence_contradiction_reduces_effective_credibility(self):
        outcome = NarrativeArena(frames(), channels(), audiences()).resolve_round(
            fact(("economic_downturn", "strong_external_evidence")), moves()
        )
        centrist = {
            row.frame: row for row in outcome.frame_audience_results
            if row.audience == "centrist_public"
        }
        self.assertGreater(
            centrist["external_shock"].effective_credibility,
            centrist["government_failure"].effective_credibility,
        )

    def test_repetition_saturates_attention(self):
        arena = NarrativeArena(frames(), channels(), audiences())
        first = arena.resolve_round(fact(), (moves()[0],))
        second = arena.resolve_round(fact(), (moves()[0],))
        first_row = next(row for row in first.frame_audience_results if row.audience == "centrist_public")
        second_row = next(row for row in second.frame_audience_results if row.audience == "centrist_public")
        self.assertGreater(first_row.effective_attention, second_row.effective_attention)
        self.assertEqual(first_row.saturation, 0.0)
        self.assertGreater(second_row.saturation, 0.0)

    def test_agenda_ownership_is_separate_from_frame_winner(self):
        outcome = NarrativeArena(frames(), channels(), audiences()).resolve_round(fact(), moves())
        self.assertAlmostEqual(sum(outcome.agenda_ownership.values()), 1.0, places=3)
        self.assertEqual(set(outcome.agenda_ownership), {"Merz", "Soeder"})
        self.assertTrue(all(row.winning_frame for row in outcome.audience_results))

    def test_no_media_move_means_no_narrative_reaction(self):
        outcome = NarrativeArena(frames(), channels(), audiences()).resolve_round(fact(), ())
        self.assertEqual(outcome.legitimacy_deltas, {})
        self.assertEqual(outcome.support_deltas, {})
        self.assertEqual(outcome.agenda_ownership, {})
        self.assertTrue(all(row.winning_frame == "__unframed__" for row in outcome.audience_results))

    def test_personality_selects_media_move_before_reach_contingency(self):
        personas_a = FreeAgentDecisionEngine.from_json(CARDS)
        personas_b = FreeAgentDecisionEngine.from_json(CARDS)
        generator = NarrativeMoveGenerator(frames(), channels())
        choice_a = generator.choose(
            "Merz", fact(), personas_a, personas_a.cards["Merz"].initial_resources
        )
        choice_b = generator.choose(
            "Merz", fact(), personas_b, personas_b.cards["Merz"].initial_resources
        )
        self.assertEqual(choice_a.chosen_move, choice_b.chosen_move)
        # Reach seeds are only consumed after this deterministic choice.
        low_seed = NarrativeArena(frames(), channels(), audiences(), seed=1, stochastic=True)
        high_seed = NarrativeArena(frames(), channels(), audiences(), seed=9, stochastic=True)
        first = low_seed.resolve_round(fact(), (choice_a.chosen_move,))
        second = high_seed.resolve_round(fact(), (choice_a.chosen_move,))
        self.assertEqual(first.moves, second.moves)


if __name__ == "__main__":
    unittest.main()
