import json
import tempfile
import unittest
from pathlib import Path

from kfrage_model.decision_telemetry import DecisionTelemetry, SupportPoint, from_observed_update_stream


ROOT = Path(__file__).resolve().parent
UPDATES = ROOT / "environments" / "2026-07-31" / "observed_updates_through_2026-09-18.json"


class DecisionTelemetryTests(unittest.TestCase):
    def test_observed_stream_builds_and_validates(self):
        log = from_observed_update_stream(UPDATES)
        payload = log.to_dict()
        self.assertEqual(len(payload["events"]), 12)
        self.assertGreater(len(payload["support_points"]), 10)
        self.assertTrue(all(p["evidence_status"] == "OBSERVED" for p in payload["support_points"]))

    def test_observed_point_requires_source(self):
        point = SupportPoint(
            step=0, timestamp="2026-09-18T10:00:00+02:00", event_id="anchor",
            subject="Merz", constituency="public", measure="job_satisfaction",
            scope="DE", value=13, unit="percent", evidence_status="OBSERVED",
        )
        with self.assertRaises(ValueError):
            point.validate()

    def test_model_delta_is_separate_index_series(self):
        log = DecisionTelemetry("run", "env")
        step = log.record_event(
            event_id="D1", timestamp="2026-09-18T10:00:00+02:00",
            actor="Wuest", action="wait",
        )
        first = log.record_model_delta(
            step=step, timestamp="2026-09-18T10:00:00+02:00", event_id="D1",
            subject="Wuest", constituency="party_elite", measure="party_elite_support",
            scope="CDU_federal", baseline=50, delta=3,
        )
        self.assertEqual(first.value, 53)
        self.assertEqual(first.unit, "index_0_100")
        self.assertEqual(first.evidence_status, "MODEL_ESTIMATE")
        self.assertEqual([point.step for point in log.points], [0, 1])

    def test_complete_decision_records_four_audiences(self):
        log = DecisionTelemetry("run", "env")
        impacts = {
            "party_elite": {"scope": "CDU_federal", "baseline": 50, "delta": 1},
            "member_organization": {"scope": "CDU_federal", "baseline": 50, "delta": 0},
            "public": {"scope": "DE", "baseline": 50, "delta": -1},
            "poll_momentum": {"scope": "DE", "baseline": 50, "delta": -0.5},
        }
        log.record_decision_with_impacts(
            event_id="D1", timestamp="2026-09-18T10:00:00+02:00",
            actor="Merz", action="hold", impacts=impacts,
        )
        self.assertEqual(len(log.points), 8)

    def test_json_roundtrip(self):
        log = from_observed_update_stream(UPDATES)
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "telemetry.json"
            log.write_json(output)
            loaded = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(loaded["schema_version"], "1.0")


if __name__ == "__main__":
    unittest.main()
