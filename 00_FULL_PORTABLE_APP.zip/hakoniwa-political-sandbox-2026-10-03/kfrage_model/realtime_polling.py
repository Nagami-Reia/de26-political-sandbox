"""A model-nowcast snapshot after every decision and exogenous event.

This is not an instant survey.  The latent state and the pollster-like nowcast
are stored as separate series so a small political effect may be real inside
the model but invisible after retention and publication rounding.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from typing import Mapping

from .decision_telemetry import DecisionTelemetry, SupportPoint
from .political_state import PoliticalState


def round_grid(value: float, grid: float) -> float:
    units = Decimal(str(value)) / Decimal(str(grid))
    return float(units.quantize(Decimal("1"), rounding=ROUND_HALF_UP) * Decimal(str(grid)))


@dataclass(frozen=True)
class PollSeriesSpec:
    state_variable: str
    subject: str
    constituency: str
    measure: str
    scope: str
    retention: float = 1.0
    publication_grid: float = .5
    include_latent_series: bool = True

    def __post_init__(self) -> None:
        if not 0 <= self.retention <= 1:
            raise ValueError("retention must be within 0..1")
        if self.publication_grid <= 0:
            raise ValueError("publication_grid must be positive")


class RealtimePollingTracker:
    def __init__(
        self,
        run_id: str,
        environment_id: str,
        specs: tuple[PollSeriesSpec, ...],
        start_timestamp: str,
        timestamp_by_event_id: Mapping[str, str] | None = None,
    ) -> None:
        self.telemetry = DecisionTelemetry(run_id, environment_id)
        self.specs = specs
        self.start = datetime.fromisoformat(start_timestamp)
        self.timestamp_by_event_id = dict(timestamp_by_event_id or {})
        self._latent_previous: dict[str, float] = {}
        self._nowcast_continuous: dict[str, float] = {}
        self._nowcast_previous: dict[str, float] = {}

    def _timestamp(self, step: int) -> str:
        return (self.start + timedelta(minutes=step)).isoformat()

    def record_baseline(self, state: PoliticalState) -> None:
        for spec in self.specs:
            value = state.variables[spec.state_variable].value
            self._latent_previous[spec.state_variable] = value
            self._nowcast_continuous[spec.state_variable] = value
            published = round_grid(value, spec.publication_grid)
            self._nowcast_previous[spec.state_variable] = published
            if spec.include_latent_series:
                self.telemetry.record_support(SupportPoint(
                    step=0, timestamp=self._timestamp(0), event_id="baseline",
                    subject=spec.subject, constituency=spec.constituency,
                    measure=f"{spec.measure}_latent", scope=spec.scope,
                    value=value, unit="percent", evidence_status="MODEL_ESTIMATE",
                    note="latent model support before event sequence",
                ))
            self.telemetry.record_support(SupportPoint(
                step=0, timestamp=self._timestamp(0), event_id="baseline",
                subject=spec.subject, constituency=spec.constituency,
                measure=f"{spec.measure}_nowcast", scope=spec.scope,
                value=published, unit="percent", evidence_status="MODEL_ESTIMATE",
                note="pollster-like baseline after publication rounding",
            ))

    def record(
        self,
        state: PoliticalState,
        *,
        event_id: str,
        actor: str,
        action: str,
        event_kind: str,
        resource_changes: Mapping[str, object] | None = None,
    ) -> int:
        timestamp = self.timestamp_by_event_id.get(
            event_id,
            self._timestamp(self.telemetry.next_step),
        )
        # Validate scenario-supplied calendar timestamps before recording them.
        datetime.fromisoformat(timestamp)
        step = self.telemetry.record_event(
            event_id=event_id,
            timestamp=timestamp,
            actor=actor,
            action=action,
            information_update={"event_kind": event_kind},
            resource_changes=resource_changes,
        )
        for spec in self.specs:
            current = state.variables[spec.state_variable].value
            previous_latent = self._latent_previous.get(spec.state_variable, current)
            previous_continuous = self._nowcast_continuous.get(spec.state_variable, previous_latent)
            retained_delta = (current - previous_latent) * spec.retention
            continuous_nowcast = previous_continuous + retained_delta
            nowcast = round_grid(continuous_nowcast, spec.publication_grid)
            self._latent_previous[spec.state_variable] = current
            self._nowcast_continuous[spec.state_variable] = continuous_nowcast
            self._nowcast_previous[spec.state_variable] = nowcast
            if spec.include_latent_series:
                self.telemetry.record_support(SupportPoint(
                    step=step, timestamp=timestamp, event_id=event_id,
                    subject=spec.subject, constituency=spec.constituency,
                    measure=f"{spec.measure}_latent", scope=spec.scope,
                    value=current, unit="percent", evidence_status="MODEL_ESTIMATE",
                    note="latent state immediately after this event",
                ))
            self.telemetry.record_support(SupportPoint(
                step=step, timestamp=timestamp, event_id=event_id,
                subject=spec.subject, constituency=spec.constituency,
                measure=f"{spec.measure}_nowcast", scope=spec.scope,
                value=nowcast, unit="percent", evidence_status="MODEL_ESTIMATE",
                note=f"retention={spec.retention}; publication_grid={spec.publication_grid}",
            ))
        return step

    def to_dict(self) -> dict[str, object]:
        payload = self.telemetry.to_dict()
        payload["polling_contract"] = {
            "frequency": "one snapshot after every recorded decision or event",
            "latent_series": "continuous model state, not a survey",
            "nowcast_series": "retained and rounded pollster-like model output, not an observed release",
            "actual_poll_rule": "append separately as OBSERVED with a source_id when a real poll is published",
        }
        return payload
