"""Actor intentions before objective institutional checking."""

from .intents import Intent, IntentCompiler

__all__ = ["Intent", "IntentCompiler"]
