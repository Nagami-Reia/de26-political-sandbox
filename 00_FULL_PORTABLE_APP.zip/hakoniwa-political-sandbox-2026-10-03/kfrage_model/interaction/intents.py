"""Intent objects preserve mistaken, impossible and unlawful actor choices."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class Intent:
    intent_id: str
    actor: str
    intent_type: str
    target: str | None = None
    payload: Mapping[str, Any] = field(default_factory=dict)


class IntentCompiler:
    """Normalize wording only; never silently legalize an actor's intention."""

    ALIASES = {
        "dismiss_bundeskanzler": "dismiss_chancellor",
        "remove_chancellor": "dismiss_chancellor",
        "constructive_vote_no_confidence": "replace_chancellor",
        "name_federal_minister": "appoint_minister",
        "remove_federal_minister": "dismiss_minister",
        "vertrauensfrage": "request_confidence",
    }

    def compile(
        self,
        *,
        intent_id: str,
        actor: str,
        verb: str,
        target: str | None = None,
        payload: Mapping[str, Any] | None = None,
    ) -> Intent:
        normalized = self.ALIASES.get(verb.strip().lower(), verb.strip().lower())
        return Intent(intent_id, actor, normalized, target, dict(payload or {}))
