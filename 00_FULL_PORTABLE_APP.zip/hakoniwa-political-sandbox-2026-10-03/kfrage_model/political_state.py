"""Reality, time, political capital, pressure tracks and irreversible route locks."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from copy import deepcopy
from typing import Mapping

HORIZONS=("immediate","medium","long")

@dataclass(frozen=True)
class StateVariable:
    key: str
    value: float
    scale: float=10.0
    uncertainty: float=0.0
    evidence: str="MODEL_STATE"

@dataclass(frozen=True)
class PoliticalAction:
    key: str
    effects: Mapping[str,Mapping[str,float]]
    uncertainty: Mapping[str,Mapping[str,float]]=field(default_factory=dict)
    capital_delta: Mapping[str,float]=field(default_factory=dict)
    pressure_delta: Mapping[str,float]=field(default_factory=dict)
    locks_add: tuple[str,...]=()
    locks_remove: tuple[str,...]=()
    closes_actions: tuple[str,...]=()
    opens_actions: tuple[str,...]=()
    irreversibility: float=0.0
    feasibility: float=1.0
    next_node: str|None=None
    tags: tuple[str,...]=()

@dataclass(frozen=True)
class PressureRule:
    track: str
    threshold: float
    event: str
    effects: Mapping[str,float]=field(default_factory=dict)
    locks_add: tuple[str,...]=()

@dataclass
class PoliticalState:
    variables: dict[str,StateVariable]
    capital: dict[str,float]
    pressures: dict[str,float]
    locks: set[str]=field(default_factory=set)
    closed_actions: set[str]=field(default_factory=set)
    pending_effects: list[dict]=field(default_factory=list)
    triggered_events: set[str]=field(default_factory=set)
    history: list[dict]=field(default_factory=list)

    def clone(self): return deepcopy(self)

    def legal(self,action:PoliticalAction):
        return action.key not in self.closed_actions and not any(tag.startswith("requires_lock:") and tag.split(":",1)[1] not in self.locks for tag in action.tags)

    def apply(self,action:PoliticalAction,pressure_rules:tuple[PressureRule,...]=()):
        before={k:v.value for k,v in self.variables.items()}
        for key,delta in action.effects.get("immediate",{}).items():
            v=self.variables[key]; self.variables[key]=StateVariable(key,max(0,min(100,v.value+delta)),v.scale,v.uncertainty,v.evidence)
        for horizon in ("medium","long"):
            if action.effects.get(horizon): self.pending_effects.append({"horizon":horizon,"source_action":action.key,"effects":dict(action.effects[horizon])})
        for key,delta in action.capital_delta.items(): self.capital[key]=max(0,min(100,self.capital.get(key,50)+delta))
        for key,delta in action.pressure_delta.items(): self.pressures[key]=max(0,min(100,self.pressures.get(key,0)+delta))
        self.locks.update(action.locks_add); self.locks.difference_update(action.locks_remove)
        self.closed_actions.update(action.closes_actions); self.closed_actions.difference_update(action.opens_actions)
        fired=[]
        for rule in pressure_rules:
            if self.pressures.get(rule.track,0)>=rule.threshold and rule.event not in self.triggered_events:
                self.triggered_events.add(rule.event); self.locks.update(rule.locks_add); fired.append(rule.event)
                for key,delta in rule.effects.items():
                    v=self.variables[key]; self.variables[key]=StateVariable(key,max(0,min(100,v.value+delta)),v.scale,v.uncertainty,v.evidence)
        event={"action":action.key,"before":before,"after":{k:v.value for k,v in self.variables.items()},"capital":dict(self.capital),"pressures":dict(self.pressures),"locks":sorted(self.locks),"triggered_events":fired}
        self.history.append(event); return event

    def payload(self):
        return {"variables":{k:asdict(v) for k,v in self.variables.items()},"capital":self.capital,"pressures":self.pressures,"locks":sorted(self.locks),"closed_actions":sorted(self.closed_actions),"pending_effects":self.pending_effects,"triggered_events":sorted(self.triggered_events),"history":self.history}
