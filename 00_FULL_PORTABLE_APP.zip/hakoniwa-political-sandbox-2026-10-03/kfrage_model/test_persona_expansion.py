import unittest
from pathlib import Path

from kfrage_model.persona_v2 import ActionOption, FreeAgentDecisionEngine, WorldEvent


ROOT = Path(__file__).parent / "personality_cards_2026"
BASE = ROOT / "cards_pss.json"


EXPECTED = {
    "Merz": "strategic_reform_direction",
    "Frei": "counted_majority_operation",
    "Wuest": "acceptance_verified_coalition",
    "Soeder": "bavarian_apparatus_signal",
    "Linnemann": "measurable_implementation_mechanism",
    "Guenther": "broad_majority_consensus",
    "Rhein": "mandate_backed_state_delivery",
    "Dobrindt": "staged_enforcement_package",
    "Wadephul": "alliance_legal_intersection",
    "Evers": "budgeted_administrative_rescue",
    "Schulze": "regional_delivery_program",
    "Kretschmer": "territorial_variable_majority",
    "Warken": "stakeholder_passage_package",
    "Baer": "hightech_flagship_coalition",
    "Hoppermann": "party_trust_and_process_audit",
    "Reiche": "executive_industrial_reset",
}


def option(key, values, identity, control, strategy, risk):
    return ActionOption(
        key=key,
        value_impacts=values,
        upside=0.620,
        downside=0.180,
        uncertainty=0.120,
        irreversibility=0.180,
        effort=0.420,
        visibility=0.550,
        information_confidence=0.880,
        control_domains=(control,),
        restores_control=0.620,
        conflict_strategy=strategy,
        identity_tags=identity,
        risk_tags=(risk,),
    )


MENU = (
    option("strategic_reform_direction", {"strategic_direction": 0.900, "reform_achievement": 0.820}, ("strategic_direction", "reform", "agency"), "direction", "reframe", "systemic_crisis"),
    option("counted_majority_operation", {"organization_success": 0.900, "political_stability": 0.800}, ("organization", "majority", "institutional_loyalty"), "parliamentary_process", "institutionalize", "counted_votes"),
    option("acceptance_verified_coalition", {"governability": 0.880, "broad_acceptance": 0.840}, ("coalition", "connection", "acceptance", "process_control"), "process", "negotiate", "acceptance_verified"),
    option("bavarian_apparatus_signal", {"csu_relevance": 0.900, "bavarian_control": 0.840}, ("relevance", "visibility", "bavaria", "apparatus"), "apparatus", "attack", "public_signal"),
    option("measurable_implementation_mechanism", {"implementation_effect": 0.900, "economic_reform": 0.820}, ("implementation", "measurable_effect", "reform", "clarity"), "policy_mechanism", "institutionalize", "measurable"),
    option("broad_majority_consensus", {"working_majority": 0.880, "democratic_norms": 0.840}, ("consensus", "governability", "pluralism"), "consensus_space", "negotiate", "broad_majority"),
    option("mandate_backed_state_delivery", {"governable_majority": 0.880, "state_delivery": 0.840}, ("governability", "mandate", "delivery"), "state_delivery", "institutionalize", "strong_mandate"),
    option("staged_enforcement_package", {"policy_control": 0.880, "csu_leverage": 0.760}, ("enforcement", "strategic_bargaining"), "execution", "attack", "measurable_enforcement"),
    option("alliance_legal_intersection", {"allied_cohesion": 0.860, "legal_legitimacy": 0.820}, ("diplomacy", "alliance", "legal_legitimacy"), "alliance", "negotiate", "allied_consensus"),
    option("budgeted_administrative_rescue", {"administrative_function": 0.880, "assigned_duty": 0.800}, ("administration", "duty", "rescue_role"), "budget", "institutionalize", "assigned_responsibility"),
    option("regional_delivery_program", {"regional_delivery": 0.880, "economic_progress": 0.820}, ("regional_responsibility", "delivery", "economic_project"), "economic_project", "attack", "concrete_project"),
    option("territorial_variable_majority", {"state_governability": 0.860, "territorial_representation": 0.840}, ("territorial_representation", "citizen_contact", "brokerage"), "citizen_feedback", "negotiate", "variable_majority"),
    option("stakeholder_passage_package", {"government_function": 0.880, "implementable_reform": 0.840}, ("reform_delivery", "coordination", "institutional_loyalty"), "legislative_process", "institutionalize", "coalition_backed_reform"),
    option("hightech_flagship_coalition", {"innovation_capacity": 0.900, "implementation_speed": 0.800}, ("innovation", "technology", "coalition_building"), "innovation_agenda", "reframe", "technology_upside"),
    option("party_trust_and_process_audit", {"organizational_trust": 0.900, "state_capability": 0.780}, ("organizational_trust", "party_base", "state_modernization"), "administrative_process", "institutionalize", "organizational_mandate"),
    option("executive_industrial_reset", {"economic_growth": 0.900, "energy_security": 0.840}, ("growth", "industry", "executive_direction"), "strategic_direction", "attack", "industrial_emergency"),
    ActionOption(
        key="unfunded_symbolic_spectacle",
        value_impacts={key: -0.300 for key in (
            "strategic_direction", "organization_success", "governability",
            "csu_relevance", "implementation_effect", "working_majority",
            "governable_majority",
            "policy_control", "legal_legitimacy", "fiscal_feasibility",
            "regional_delivery", "state_governability", "implementable_reform",
            "innovation_capacity", "fiscal_accountability", "economic_growth",
        )},
        upside=0.300,
        downside=0.750,
        uncertainty=0.700,
        irreversibility=0.650,
        effort=0.700,
        visibility=0.950,
        information_confidence=0.300,
        conflict_strategy="attack",
        identity_tags=("personal_show",),
        risk_tags=("symbolic_only", "unfunded_promise"),
    ),
)


class CurrentDeckCharacterTests(unittest.TestCase):
    def engine(self):
        return FreeAgentDecisionEngine.from_json(BASE)

    def test_all_current_cards_have_complete_runnable_structure(self):
        engine = self.engine()
        for actor in EXPECTED:
            card = engine.cards[actor]
            self.assertGreaterEqual(len(card.dna.value_hierarchy), 4, actor)
            self.assertGreaterEqual(len(card.dna.control_preferences), 4, actor)
            self.assertEqual(set(card.dna.conflict_strategies), {"attack", "negotiate", "avoid", "institutionalize", "reframe"}, actor)
            self.assertGreaterEqual(len(card.dna.risk_context_appetite), 4, actor)
            self.assertEqual(set(card.initial_resources), {"formal_power", "organization_base", "parliamentary_base", "network_capital", "public_capital", "future_option"}, actor)
            self.assertGreaterEqual(len(card.source_ids), 6, actor)

    def test_shared_menu_produces_actor_specific_non_ooc_choices(self):
        engine = self.engine()
        for actor, expected in EXPECTED.items():
            decision = engine.decide(actor, MENU, {})
            self.assertEqual(decision.chosen_action, expected, actor)
            self.assertFalse(decision.scores[expected].hard_rejections, actor)
            self.assertGreater(
                decision.scores[expected].total,
                decision.scores["unfunded_symbolic_spectacle"].total,
                actor,
            )

    def test_high_pressure_modulates_but_does_not_erase_identity(self):
        engine = self.engine()
        for actor, expected in EXPECTED.items():
            most_sensitive_tag = max(
                engine.cards[actor].pss_profile.sensitivity_map,
                key=engine.cards[actor].pss_profile.sensitivity_map.get,
            )
            engine.apply_event(
                actor,
                WorldEvent(
                    event_id=f"stress_probe_{actor}",
                    event_type="stress_probe",
                    severity=0.900,
                    tags=(most_sensitive_tag,),
                    valence=-1.000,
                    surprise=0.700,
                    workload=0.080,
                ),
            )
            decision = engine.decide(actor, MENU, {})
            self.assertEqual(decision.chosen_action, expected, actor)


if __name__ == "__main__":
    unittest.main()
