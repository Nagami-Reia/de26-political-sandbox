# 决策遥测接口

`decision_telemetry.py` 是环境层的一部分，不属于人格插件。人格模型只选择行动；环境执行资源再分配后，把四类模型指标变化写入遥测：

- `party_elite_support`：主席团、州首长、党团领导等精英支持指数；
- `member_organization_support`：党员、地方组织、党机器响应指数；
- `public_acceptance`：模型中的公众接受指数；
- `electoral_momentum`：模型中的选举动量指数。

这些都使用 `index_0_100`，不是现实百分比。真实民调、选举结果和正式表决使用 `percent + OBSERVED + source_id`。图表永远把二者分开。

## 在未来模拟的一个决策后记录

```python
from kfrage_model.decision_telemetry import DecisionTelemetry

telemetry = DecisionTelemetry("forecast_run_001", environment["environment_id"])
step = telemetry.record_decision_with_impacts(
    event_id="D001",
    timestamp="2026-09-19T10:00:00+02:00",
    actor="Hendrik_Wuest",
    action="call_for_policy_correction",
    information_update={"visible": ["state-premier statement", "latest polls"]},
    resource_changes={"public_platform": "+0.03", "union_acceptability": "-0.01"},
    impacts={
        "party_elite": {"scope": "CDU_federal", "baseline": 52, "delta": 2.5},
        "member_organization": {"scope": "CDU_federal", "baseline": 55, "delta": 1},
        "public": {"scope": "DE", "baseline": 48, "delta": 0.5},
        "poll_momentum": {"scope": "DE", "baseline": 49, "delta": 0},
    },
)
telemetry.write_json(output_path)
```

第一笔模型序列必须给 `baseline`；后续只给 `delta`。所有值被限制在 0—100。观测点必须带来源，不能被模型 delta 覆盖。

## 生成当前图表

```bash
python3 kfrage_model/decision_telemetry.py \
  --updates kfrage_model/environments/2026-07-31/observed_updates_through_2026-09-18.json \
  --output kfrage_model/environments/2026-07-31/current_telemetry.json

python3 kfrage_model/render_telemetry.py \
  --input kfrage_model/environments/2026-07-31/current_telemetry.json \
  --output kfrage_model/environments/2026-07-31/current_telemetry_chart.html
```

图中横轴是事件/决策步，纵轴固定 0—100；因此是第一象限直角坐标系。范围选择器用于防止把全国、州、党团混成同一含义。
