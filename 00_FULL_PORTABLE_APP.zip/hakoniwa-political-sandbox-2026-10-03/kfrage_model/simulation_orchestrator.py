"""Canonical political-simulation 3.0 pipeline.

The default mode is shadow-only: v3 diagnostics are recorded while the exact v2
persona choice and world transition remain authoritative.  Feature flags enable
each causal channel separately so a changed result is attributable and testable.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Callable, Mapping, Sequence

from .action_perception import ActionPerceptionFilter
from .action_repertoire import ActionRepertoireFilter
from .arcana import ArcanaService
from .arcana.hakoniwa import ArcanaDecisionAdapter
from .checks.base import Resolution
from .checks.context import CheckContext
from .checks.engine import CheckEngine, InstitutionalResolver
from .decision_space import (
    DecisionEvent,
    DecisionSpaceGenerator,
    GeneratedDecisionSpace,
    OutcomeResolver,
)
from .free_agent_game import WorldAction
from .information_filter import InformationFilter
from .institutional_logic import InstitutionalLogic
from .institutional_matrix import InstitutionalMatrix, InstitutionalRule
from .persona_v2 import ActionOutcome, FreeAgentDecisionEngine
from .party_interest import PartyInterestEngine
from .political_agency import AgencyHorizon, AgencyRegistry
from .political_state import PoliticalAction, PoliticalState, PressureRule
from .rationality_evaluation import ActorRationalityProfile, RationalityEvaluator
from .scenario_reporting import ScenarioReportCompiler, ScenarioReportingPolicy
from .system_feedback import SystemFeedbackAssessor


@dataclass(frozen=True)
class V3FeatureFlags:
    institutional_logic_affects_choice: bool = False
    agency_horizon_affects_choice: bool = False
    system_feedback_mutates_world: bool = False
    strategic_response_uses_perceived_menu: bool = False
    party_interest_affects_choice: bool = False

    @property
    def shadow_mode(self) -> bool:
        return not (
            self.institutional_logic_affects_choice
            or self.agency_horizon_affects_choice
            or self.system_feedback_mutates_world
            or self.strategic_response_uses_perceived_menu
            or self.party_interest_affects_choice
        )

    @property
    def choice_active(self) -> bool:
        return (
            self.institutional_logic_affects_choice
            or self.agency_horizon_affects_choice
            or self.party_interest_affects_choice
        )


@dataclass(frozen=True)
class SimulationNodeV3:
    key: str
    owner: str
    actions: tuple[WorldAction, ...]
    current_goals: Mapping[str, float] = field(default_factory=dict)
    scene_tags: tuple[str, ...] = ()
    strategic_scores: Mapping[str, float] = field(default_factory=dict)
    decision_event: DecisionEvent | None = None
    conflict_actor: str | None = None


@dataclass(frozen=True)
class LayeredConfiguration:
    matrix: InstitutionalMatrix
    logic: InstitutionalLogic
    agency: AgencyRegistry
    rationality_profiles: Mapping[str, ActorRationalityProfile]
    flags: V3FeatureFlags = V3FeatureFlags()

    @classmethod
    def from_environment_json(
        cls,
        path: str | Path,
        rationality_path: str | Path | None = None,
    ) -> "LayeredConfiguration":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        if raw.get("schema_version") != "political-simulation-3.0":
            raise ValueError("Expected political-simulation-3.0 environment")
        matrix_raw = raw["institutional_matrix"]
        matrix = InstitutionalMatrix(
            matrix_id=matrix_raw["matrix_id"],
            actor_offices={key: tuple(value) for key, value in matrix_raw.get("actor_offices", {}).items()},
            office_permissions={key: tuple(value) for key, value in matrix_raw.get("office_permissions", {}).items()},
            rules=tuple(
                InstitutionalRule(
                    key=item["key"],
                    kind=item["kind"],
                    strength=float(item["strength"]),
                    enforcement=float(item["enforcement"]),
                    action_permissions=tuple(item.get("action_permissions", ())),
                    source_status=item.get("source_status", "MODEL_ASSUMPTION"),
                )
                for item in matrix_raw.get("rules", ())
            ),
        )
        agency = AgencyRegistry({
            actor: AgencyHorizon(**values)
            for actor, values in raw.get("agency_horizons", {}).items()
        })
        profile_payload = (
            json.loads(Path(rationality_path).read_text(encoding="utf-8"))
            if rationality_path is not None
            else {"actors": {}}
        )
        if profile_payload.get("schema_version") not in {None, "actor-rationality-profiles-3.0"}:
            raise ValueError("Expected actor-rationality-profiles-3.0")
        profiles = {
            actor: ActorRationalityProfile(**values)
            for actor, values in profile_payload.get("actors", {}).items()
        }
        return cls(
            matrix=matrix,
            logic=InstitutionalLogic.from_mapping(raw["institutional_logic"]),
            agency=agency,
            rationality_profiles=profiles,
            flags=V3FeatureFlags(**raw.get("feature_flags", {})),
        )


class LayeredSimulationOrchestrator:
    """Single entry point for new scenarios and v3 trace generation."""

    def __init__(
        self,
        state: PoliticalState,
        nodes: Mapping[str, SimulationNodeV3],
        personas: FreeAgentDecisionEngine,
        information: InformationFilter,
        resource_bindings: Mapping[str, Mapping[str, str]],
        configuration: LayeredConfiguration,
        pressure_rules: Sequence[PressureRule] = (),
        event_observers: Sequence[object] = (),
        decision_generator: DecisionSpaceGenerator | None = None,
        outcome_resolver: OutcomeResolver | None = None,
        reporting_policy: ScenarioReportingPolicy = ScenarioReportingPolicy(),
        objective_check_engine: CheckEngine | None = None,
        check_context_provider: Callable[[PoliticalState], CheckContext] | None = None,
        party_interests: PartyInterestEngine | None = None,
        actor_party_map: Mapping[str, str] | None = None,
        party_overlay_weights: Mapping[str, float] | None = None,
        arcana: ArcanaService | None = None,
    ) -> None:
        self.state = state
        self.nodes = dict(nodes)
        self.personas = personas
        self.information = information
        self.resource_bindings = {actor: dict(values) for actor, values in resource_bindings.items()}
        self.matrix = configuration.matrix
        self.logic = configuration.logic
        self.agency = configuration.agency
        self.rationality_profiles = dict(configuration.rationality_profiles)
        self.flags = configuration.flags
        self.pressure_rules = tuple(pressure_rules)
        self.event_observers = tuple(event_observers)
        self.repertoire_filter = ActionRepertoireFilter(self.matrix)
        self.perception_filter = ActionPerceptionFilter()
        self.rationality = RationalityEvaluator()
        self.system_assessor = SystemFeedbackAssessor()
        self.decision_generator = decision_generator
        self.outcome_resolver = outcome_resolver
        self.reporting_policy = reporting_policy
        self.objective_check_engine = objective_check_engine
        self.check_context_provider = check_context_provider
        self.institutional_resolver = InstitutionalResolver()
        self.party_interests = party_interests
        self.actor_party_map = dict(actor_party_map or {})
        self.party_overlay_weights = dict(party_overlay_weights or {})
        self.arcana = arcana
        self.arcana_adapter = ArcanaDecisionAdapter()
        self._initial_pss = {
            actor: asdict(runtime.state)
            for actor, runtime in self.personas.runtime.items()
        }
        self.trace: list[dict] = []

    def _materialize_actions(
        self,
        node: SimulationNodeV3,
        beliefs,
        resources: Mapping[str, float],
    ) -> tuple[tuple[WorldAction, ...], GeneratedDecisionSpace | None]:
        """Return static actions or grow a menu from the current actor state."""
        if node.decision_event is None:
            return node.actions, None
        if self.decision_generator is None:
            raise RuntimeError(
                f"Node {node.key} declares decision_event but no DecisionSpaceGenerator was supplied"
            )
        generated = self.decision_generator.generate(
            node.owner,
            node.decision_event,
            beliefs,
            self.personas.cards[node.owner],
            self.personas.runtime[node.owner],
            resources,
            node.current_goals,
        )
        return generated.world_actions, generated

    def _perceived_resources(
        self,
        actor: str,
        belief_state,
        state: PoliticalState | None = None,
    ) -> dict[str, float]:
        source_state = state or self.state
        resources = dict(self.personas.cards[actor].initial_resources)
        for resource, binding in self.resource_bindings.get(actor, {}).items():
            kind, key = binding.split(":", 1)
            if kind == "variable":
                resources[resource] = max(0.0, min(1.0, belief_state.beliefs[key].estimate / 100.0))
            elif kind == "capital":
                resources[resource] = max(0.0, min(1.0, source_state.capital.get(key, 0.0) / 100.0))
            else:
                raise ValueError(f"Unknown resource binding kind: {kind}")
        return resources

    def _active_v3_choice(
        self,
        node: SimulationNodeV3,
        actions,
        resources,
        perceived,
    ) -> tuple[str, dict, dict, dict, dict]:
        serious = [
            action for action in actions
            if perceived[action.key].perceived_status == "CONSIDERED"
        ]
        if not serious:
            serious = [
                action for action in actions
                if perceived[action.key].role_status == "AVAILABLE"
            ]
        if not serious:
            raise RuntimeError(f"No role-available action at {node.key}")
        persona_scores = {
            action.key: self.personas.score(
                node.owner,
                action,
                resources,
                node.current_goals,
                node.scene_tags,
                soft_resource_constraints=True,
            )
            for action in serious
        }
        profile = self.rationality_profiles.get(node.owner, ActorRationalityProfile())
        rationality = {
            action.key: self.rationality.evaluate(
                action,
                persona_scores[action.key],
                profile,
                perceived_feasibility=perceived[action.key].perceived_feasibility,
                strategic_score=node.strategic_scores.get(action.key, 0.500),
            )
            for action in serious
        }
        party_rows = self._party_evaluations(node.owner, serious)
        base_scores = {key: row.choice_score for key, row in rationality.items()}
        if self.flags.party_interest_affects_choice and party_rows:
            combined = self.party_interests.overlay(
                base_scores,
                party_rows,
                self.party_overlay_weights.get(node.owner, 0.250),
            )
        else:
            combined = base_scores
        order = {action.key: index for index, action in enumerate(actions)}
        chosen = max(combined, key=lambda key: (combined[key], -order[key]))
        return chosen, persona_scores, rationality, party_rows, combined

    def _party_evaluations(self, actor: str, actions) -> dict:
        if self.party_interests is None or actor not in self.actor_party_map:
            return {}
        party_id = self.actor_party_map[actor]
        return {
            action.key: self.party_interests.evaluate(party_id, action)
            for action in actions
        }

    def _forecast_response_path(
        self,
        opening: WorldAction,
        state: PoliticalState,
        max_depth: int = 2,
    ) -> list[dict]:
        """Forecast future actors through their own perceived menus, without commits.

        The path is diagnostic in phases 1-2.  A later calibrated response-payoff
        adapter may convert it into the current actor's strategic continuation
        value; no payoff is invented here.
        """
        if not self.flags.strategic_response_uses_perceived_menu or not opening.world.next_node:
            return []
        rng_state = self.information.rng.getstate()
        forecast_state = state.clone()
        opening_executable = True
        if opening.intent is not None:
            if self.objective_check_engine is None or self.check_context_provider is None:
                raise RuntimeError(
                    f"Action {opening.world.key} carries an institutional intent but the "
                    "objective check environment is not configured"
                )
            opening_bundle = self.objective_check_engine.check(
                self.check_context_provider(forecast_state), opening.intent
            )
            opening_executable = opening_bundle.resolution is Resolution.EXECUTABLE
        if opening_executable:
            forecast_state.apply(opening.world, self.pressure_rules)
        key = opening.world.next_node
        path: list[dict] = []
        try:
            for _ in range(max_depth):
                node = self.nodes[key]
                beliefs = self.information.observe(node.owner, forecast_state, commit=False)
                resources = self._perceived_resources(node.owner, beliefs, forecast_state)
                node_actions, _ = self._materialize_actions(node, beliefs, resources)
                mean_confidence = (
                    sum(item.confidence for item in beliefs.beliefs.values()) / len(beliefs.beliefs)
                    if beliefs.beliefs else 0.500
                )
                legal_pairs = [item for item in node_actions if forecast_state.legal(item.world)]
                options = tuple(
                    replace(
                        item.choice,
                        legal=item.choice.legal and forecast_state.legal(item.world),
                        information_confidence=min(item.choice.information_confidence, mean_confidence),
                    )
                    for item in legal_pairs
                )
                repertoire = self.repertoire_filter.apply(node.owner, options, resources)
                perceived = self.perception_filter.apply(
                    options,
                    repertoire,
                    self.logic,
                    self.agency.get(node.owner),
                    resources,
                    mean_confidence,
                )
                serious = [item for item in options if perceived[item.key].perceived_status == "CONSIDERED"]
                if not serious:
                    serious = [item for item in options if perceived[item.key].role_status == "AVAILABLE"]
                if not serious:
                    path.append({"node": key, "owner": node.owner, "status": "NO_PERCEIVED_ACTION"})
                    break
                profile = self.rationality_profiles.get(node.owner, ActorRationalityProfile())
                persona_scores = {
                    item.key: self.personas.score(
                        node.owner,
                        item,
                        resources,
                        node.current_goals,
                        node.scene_tags,
                        soft_resource_constraints=True,
                    )
                    for item in serious
                }
                evaluations = {
                    item.key: self.rationality.evaluate(
                        item,
                        persona_scores[item.key],
                        profile,
                        perceived_feasibility=perceived[item.key].perceived_feasibility,
                        strategic_score=node.strategic_scores.get(item.key, 0.500),
                    )
                    for item in serious
                }
                order = {item.key: index for index, item in enumerate(options)}
                chosen = max(evaluations, key=lambda item: (evaluations[item].choice_score, -order[item]))
                selected = next(item for item in legal_pairs if item.world.key == chosen)
                forecast_precheck = None
                if selected.intent is not None:
                    if self.objective_check_engine is None or self.check_context_provider is None:
                        raise RuntimeError(
                            f"Action {chosen} carries an institutional intent but the objective "
                            "check environment is not configured"
                        )
                    forecast_precheck = self.objective_check_engine.check(
                        self.check_context_provider(forecast_state), selected.intent
                    )
                path.append({
                    "node": key,
                    "owner": node.owner,
                    "chosen_response": chosen,
                    "perceived_action_menu": {name: row.payload() for name, row in perceived.items()},
                    "choice_scores": {name: row.choice_score for name, row in evaluations.items()},
                    "objective_precheck": (
                        forecast_precheck.payload() if forecast_precheck is not None else None
                    ),
                })
                if forecast_precheck is None or forecast_precheck.resolution is Resolution.EXECUTABLE:
                    forecast_state.apply(selected.world, self.pressure_rules)
                if not selected.world.next_node:
                    break
                key = selected.world.next_node
        finally:
            self.information.rng.setstate(rng_state)
        return path

    def run(self, start_node: str, max_steps: int = 20) -> dict:
        for observer in self.event_observers:
            telemetry = getattr(observer, "telemetry", None)
            points = getattr(telemetry, "points", None)
            record_baseline = getattr(observer, "record_baseline", None)
            if callable(record_baseline) and points is not None and not points:
                record_baseline(self.state)
        node_key = start_node
        for _ in range(max_steps):
            node = self.nodes[node_key]
            beliefs = self.information.observe(node.owner, self.state, commit=True)
            resources = self._perceived_resources(node.owner, beliefs)
            node_actions, generated_space = self._materialize_actions(node, beliefs, resources)
            mean_confidence = (
                sum(item.confidence for item in beliefs.beliefs.values()) / len(beliefs.beliefs)
                if beliefs.beliefs else 0.500
            )
            all_choices = tuple(
                replace(
                    item.choice,
                    legal=item.choice.legal and self.state.legal(item.world),
                )
                for item in node_actions
            )
            objective_menu = [
                {
                    "action": item.choice.key,
                    "world_legal": self.state.legal(item.world),
                    "choice_legal": item.choice.legal,
                }
                for item in node_actions
            ]
            repertoire = self.repertoire_filter.apply(node.owner, all_choices, resources)
            actor_agency = self.agency.get(node.owner)
            perceived = self.perception_filter.apply(
                all_choices,
                repertoire,
                self.logic,
                actor_agency,
                resources,
                mean_confidence,
            )
            choice_logic = (
                self.logic
                if self.flags.institutional_logic_affects_choice
                else InstitutionalLogic.neutral("choice_neutral_logic")
            )
            choice_agency = (
                actor_agency
                if self.flags.agency_horizon_affects_choice
                else AgencyHorizon()
            )
            choice_perceived = self.perception_filter.apply(
                all_choices,
                repertoire,
                choice_logic,
                choice_agency,
                resources,
                mean_confidence,
            )
            forecast_responses = {
                item.world.key: self._forecast_response_path(item, self.state)
                for item in node_actions
            }

            legal_pairs = [item for item in node_actions if self.state.legal(item.world)]
            v2_options = [
                replace(
                    item.choice,
                    legal=item.choice.legal and self.state.legal(item.world),
                    information_confidence=min(item.choice.information_confidence, mean_confidence),
                )
                for item in legal_pairs
            ]
            if not self.flags.choice_active:
                decision = self.personas.decide(
                    node.owner,
                    v2_options,
                    resources,
                    current_goals=node.current_goals,
                    scene_tags=node.scene_tags,
                )
                chosen_key = decision.chosen_action
                persona_scores = decision.scores
                profile = self.rationality_profiles.get(node.owner, ActorRationalityProfile())
                rationality_rows = {
                    action.key: self.rationality.evaluate(
                        action,
                        persona_scores[action.key],
                        profile,
                        perceived_feasibility=perceived[action.key].perceived_feasibility,
                        strategic_score=node.strategic_scores.get(action.key, 0.500),
                    )
                    for action in v2_options
                }
                party_rows = self._party_evaluations(node.owner, v2_options)
                combined_choice_scores = {
                    key: row.choice_score for key, row in rationality_rows.items()
                }
                decision_source = (
                    "generated_persona_v2_choice"
                    if generated_space is not None
                    else "persona_v2_compatibility"
                )
            else:
                (
                    chosen_key,
                    persona_scores,
                    rationality_rows,
                    party_rows,
                    combined_choice_scores,
                ) = self._active_v3_choice(
                    node, v2_options, resources, choice_perceived
                )
                decision_source = (
                    "layered_v3_party_overlay"
                    if self.flags.party_interest_affects_choice and party_rows
                    else "layered_v3_choice"
                )

            arcana_trace = {
                "enabled": bool(self.arcana is not None and self.arcana.config.enabled),
                "status": "DISABLED",
            }
            if self.arcana is not None and self.arcana.config.enabled:
                node_uncertainty = (
                    node.decision_event.ambiguity
                    if node.decision_event is not None
                    else max(
                        1.000 - mean_confidence,
                        sum(action.uncertainty for action in v2_options) / len(v2_options),
                    )
                )
                interaction_modifier = 0.000
                if node.conflict_actor is not None:
                    if node.conflict_actor not in self.personas.cards:
                        raise ValueError(
                            f"ARCANA conflict actor has no persona/PSS card: {node.conflict_actor}"
                        )
                    conflict_bundle = self.arcana.run_conflict(
                        node.key,
                        node.owner,
                        node.conflict_actor,
                        self.personas.cards[node.owner],
                        self.personas.runtime[node.owner],
                        self.personas.cards[node.conflict_actor],
                        self.personas.runtime[node.conflict_actor],
                    )
                    primary_run = self.arcana.repository.get(
                        conflict_bundle["primary_reading"]["run_id"]
                    )
                    interaction_modifier = conflict_bundle["interaction"][
                        "primary_pss_mediation"
                    ]["decision_threshold_modifier"]
                    reading_payload = conflict_bundle["primary_reading"]
                else:
                    primary_run = self.arcana.run_reading(node.key, node.owner)
                    reading_payload = primary_run.payload()
                    conflict_bundle = None
                chosen_key, adoption = self.arcana_adapter.adapt(
                    chosen_key,
                    combined_choice_scores,
                    v2_options,
                    primary_run.advice,
                    self.personas.cards[node.owner],
                    self.personas.runtime[node.owner],
                    node_uncertainty,
                    interaction_modifier,
                    self.arcana.config.influence_cap,
                )
                arcana_trace = {
                    "enabled": True,
                    "status": "RUN",
                    "reading": reading_payload,
                    "adoption": adoption,
                    "conflict_interaction": conflict_bundle,
                    "node_uncertainty": round(node_uncertainty, 3),
                }
                decision_source = f"{decision_source}_arcana"

            selected = next(item for item in legal_pairs if item.world.key == chosen_key)
            action_eval = rationality_rows[chosen_key]
            resolved_outcome = None
            settled_world_action = selected.world
            operational_success = selected.world.feasibility
            precheck_bundle = None
            institutional_resolution = None
            if selected.intent is not None:
                if self.objective_check_engine is None or self.check_context_provider is None:
                    raise RuntimeError(
                        f"Action {chosen_key} carries an institutional intent but the objective "
                        "check environment is not configured"
                    )
                precheck_bundle = self.objective_check_engine.check(
                    self.check_context_provider(self.state), selected.intent
                )
                institutional_resolution = self.institutional_resolver.resolve(precheck_bundle)
                if institutional_resolution.resolution is not Resolution.EXECUTABLE:
                    settled_world_action = PoliticalAction(
                        key=f"{selected.world.key}:{institutional_resolution.resolution.value}",
                        effects={"immediate": {}, "medium": {}, "long": {}},
                        feasibility=0.0,
                        next_node=selected.world.next_node,
                        tags=(
                            *selected.world.tags,
                            f"institutional_resolution:{institutional_resolution.resolution.value}",
                        ),
                    )
                    operational_success = 0.0
            if (
                institutional_resolution is None
                or institutional_resolution.resolution is Resolution.EXECUTABLE
            ) and generated_space is not None and self.outcome_resolver is not None:
                generated_action = generated_space.by_key()[chosen_key]
                resolved_outcome = self.outcome_resolver.resolve(generated_action)
                settled_world_action = resolved_outcome.world_action
                operational_success = resolved_outcome.success_level
            system_feedback = self.system_assessor.assess(
                selected.choice,
                action_eval,
                self.logic,
                operational_success=operational_success,
            )
            logic_before = self.logic.payload()
            agency_before = actor_agency.payload()
            state_update = self.state.apply(settled_world_action, self.pressure_rules)
            pss_updates: list[dict] = []
            if resolved_outcome is not None:
                pss_updates.append(self.personas.apply_outcome(
                    node.owner,
                    ActionOutcome(
                        action=chosen_key,
                        success=resolved_outcome.success_level,
                        surprise=abs(resolved_outcome.success_level - .500),
                        tags=(
                            "generated_outcome",
                            resolved_outcome.branch,
                            node.decision_event.domain,
                        ),
                        target_actor=node.decision_event.target_actor,
                        workload=.030 + .070 * selected.choice.effort,
                        control_restoration=(
                            selected.choice.restores_control
                            * resolved_outcome.success_level
                            * .120
                        ),
                        identity_alignment=(resolved_outcome.success_level - .500) * .120,
                    ),
                ))
            for affected_actor, events in selected.actor_events.items():
                for event in events:
                    pss_updates.append(self.personas.apply_event(affected_actor, event))
            for affected_actor, outcome in selected.actor_outcomes.items():
                pss_updates.append(self.personas.apply_outcome(affected_actor, outcome))
            if self.flags.system_feedback_mutates_world:
                self.logic = self.logic.evolve(
                    legitimacy_delta=system_feedback.legitimacy_delta,
                    control_concentration_delta=system_feedback.control_concentration_delta,
                    logic_reinforcement=system_feedback.logic_reinforcement,
                    alternative_legibility_delta=system_feedback.alternative_legibility_delta,
                )
                self.agency.set(
                    node.owner,
                    actor_agency.evolve(agency_delta=system_feedback.agency_delta),
                )
            for observer in self.event_observers:
                observer.record(
                    self.state,
                    event_id=f"layered_decision:{node.key}",
                    actor=node.owner,
                    action=chosen_key,
                    event_kind="layered_actor_decision",
                    resource_changes=state_update,
                )
            polling_after = []
            for observer in self.event_observers:
                telemetry = getattr(observer, "telemetry", None)
                points = getattr(telemetry, "points", None)
                if points:
                    latest_step = max(point.step for point in points)
                    polling_after.extend(
                        asdict(point) for point in points if point.step == latest_step
                    )
            self.trace.append({
                "node": node.key,
                "decision_maker": node.owner,
                "decision_source": decision_source,
                "decision_space_generation": (
                    generated_space.payload() if generated_space is not None else None
                ),
                "objective_action_menu": objective_menu,
                "role_filtered_menu": {key: row.payload() for key, row in repertoire.items()},
                "perceived_action_menu": {key: row.payload() for key, row in perceived.items()},
                "choice_action_menu": {
                    key: row.payload() for key, row in choice_perceived.items()
                },
                "actor_belief_state": InformationFilter.payload(beliefs),
                "institutional_logic_state": logic_before,
                "agency_horizon_before": agency_before,
                "action_evaluations": {
                    key: {
                        "instrumental": rationality_rows[key].instrumental_score,
                        "substantive": rationality_rows[key].substantive_score,
                        "persona": asdict(persona_scores[key]),
                        "strategic_continuation": rationality_rows[key].strategic_score,
                        "choice_score": rationality_rows[key].choice_score,
                        "party_interest": (
                            party_rows[key].payload() if key in party_rows else None
                        ),
                        "combined_choice_score": combined_choice_scores[key],
                        "rationality_conflict": rationality_rows[key].rationality_conflict,
                    }
                    for key in rationality_rows
                },
                "party_interest_layer": {
                    "party_id": self.actor_party_map.get(node.owner),
                    "affects_choice": bool(
                        self.flags.party_interest_affects_choice and party_rows
                    ),
                    "overlay_weight": round(
                        self.party_overlay_weights.get(node.owner, 0.250), 3
                    ) if party_rows else 0.000,
                    "evaluations": {
                        key: row.payload() for key, row in party_rows.items()
                    },
                },
                "arcana": arcana_trace,
                "forecast_responses": forecast_responses,
                "chosen_action": chosen_key,
                "objective_precheck": (
                    precheck_bundle.payload() if precheck_bundle is not None else None
                ),
                "institutional_resolution": (
                    institutional_resolution.payload()
                    if institutional_resolution is not None else {
                        "resolution": "not_invoked",
                        "effects": [],
                        "required_procedures": [],
                        "reasons": [],
                    }
                ),
                "actors_used": sorted({
                    node.owner,
                    *((node.conflict_actor,) if node.conflict_actor in self.personas.cards else ()),
                    *selected.actor_events.keys(),
                    *selected.actor_outcomes.keys(),
                    *(
                        (selected.choice.target_actor,)
                        if selected.choice.target_actor in self.personas.cards
                        else ()
                    ),
                    *(
                        response["owner"]
                        for paths in forecast_responses.values()
                        for response in paths
                        if response.get("owner") in self.personas.cards
                    ),
                }),
                "operational_feedback": {
                    "settlement_status": (
                        "GENERATED_OUTCOME_RESOLVED"
                        if resolved_outcome is not None
                        else "WORLD_TRANSITION_ONLY"
                    ),
                    "operational_success_input": round(operational_success, 3),
                    "outcome_branch": (
                        resolved_outcome.payload() if resolved_outcome is not None else None
                    ),
                    "state_update": state_update,
                    "pss_updates": pss_updates,
                },
                "system_feedback": system_feedback.payload(),
                "system_feedback_applied": self.flags.system_feedback_mutates_world,
                "agency_horizon_after": self.agency.get(node.owner).payload(),
                "institutional_logic_after": self.logic.payload(),
                "polling_after": polling_after,
                "pss_after": asdict(self.personas.runtime[node.owner].state),
                "all_actor_pss_after": {
                    actor: asdict(runtime.state)
                    for actor, runtime in self.personas.runtime.items()
                },
            })
            if settled_world_action.next_node is None:
                break
            node_key = settled_world_action.next_node
        return self.payload()

    def payload(self) -> dict:
        scenario_report = ScenarioReportCompiler(
            self._initial_pss,
            self.reporting_policy,
        ).compile(self.trace, self.event_observers)
        return {
            "schema_version": "political-simulation-3.0",
            "feature_flags": asdict(self.flags),
            "trace": self.trace,
            "world_state": self.state.payload(),
            "institutional_matrix": self.matrix.payload(),
            "institutional_logic": self.logic.payload(),
            "agency_horizons": self.agency.payload(),
            "persona_runtime": self.personas.payload(),
            "scenario_report": scenario_report,
            "arcana": self.arcana.payload() if self.arcana is not None else {
                "config": {"enabled": False}, "runs": {}
            },
            "warning": (
                "Utilities and system classifications are model diagnostics, not observed facts. "
                "Shadow mode cannot alter the authoritative v2 choice."
            ),
        }
