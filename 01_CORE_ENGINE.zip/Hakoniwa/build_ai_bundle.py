"""Build the deterministic GitHub release shelf for Hakoniwa.

Every pre-existing archive is replaced. Category bundles overlap where useful;
the full bundle is the canonical hand-off artifact.
"""
from __future__ import annotations

import hashlib
import json
import re
import zipfile
from pathlib import Path
from typing import Callable


ROOT = Path(__file__).resolve().parent
SHELF = ROOT / "github_shelf"
RELEASE_ROOT = "Hakoniwa"
RELEASE_VERSION = "v.3.1.0-a"
RELEASE_DATE = "2026-10-26"
FIXED_TIME = (2026, 10, 26, 0, 0, 0)
ROOT_FILES = {
    "README.md",
    "AI_START_HERE.md", "PORTABLE_QUICKSTART_CN.md", "run_cli.py",
    "hakoniwa.sh", "hakoniwa.bat", "build_ai_bundle.py", "verify_ai_bundle.py",
}
EXCLUDED_PARTS = {
    "__pycache__", ".pytest_cache", ".mypy_cache", ".DS_Store", "output",
    "outputs", "tmp", "dist", "github_shelf",
}
EXCLUDED_SUFFIXES = {".pyc", ".pyo"}
GENERATED_NAMES = {
    "full_trace.json", "report_trace.json", "baseline.json", "report.html",
    "polling.svg", "pressure.svg", "current_telemetry_chart.html",
}
SENSITIVE_FILENAMES = {".env", "credentials", "credentials.json", "secrets.json", "id_rsa", "id_ed25519"}
SECRET_PATTERNS = {
    "OpenAI/API secret": re.compile(rb"sk-(?:proj-)?[A-Za-z0-9_-]{20,}"),
    "AWS access key": re.compile(rb"(?:AKIA|ASIA)[0-9A-Z]{16}"),
    "GitHub token": re.compile(rb"(?:ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})"),
    "Google API key": re.compile(rb"AIza[A-Za-z0-9_-]{30,}"),
    "Slack token": re.compile(rb"xox[baprs]-[A-Za-z0-9-]{20,}"),
    "private key": re.compile(rb"BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY"),
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def is_source(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    return (
        path.is_file()
        and not any(part in EXCLUDED_PARTS for part in relative.parts)
        and path.suffix not in EXCLUDED_SUFFIXES
        and path.name not in GENERATED_NAMES
    )


def project_files() -> list[Path]:
    files = [ROOT / name for name in ROOT_FILES if (ROOT / name).is_file()]
    files.extend(path for path in (ROOT / "hakoniwa").rglob("*") if is_source(path))
    return sorted(set(files), key=lambda path: path.relative_to(ROOT).as_posix())


def preflight_secret_scan(files: list[Path]) -> None:
    """Fail closed without printing the suspected secret itself."""
    findings: list[str] = []
    for path in files:
        lowered = path.name.lower()
        if lowered in SENSITIVE_FILENAMES or lowered.startswith(".env.") or path.suffix.lower() in {".pem", ".key"}:
            findings.append(f"sensitive filename: {rel(path)}")
            continue
        content = path.read_bytes()
        for label, pattern in SECRET_PATTERNS.items():
            if pattern.search(content):
                findings.append(f"{label}: {rel(path)}")
    if findings:
        raise RuntimeError("Release blocked by secret preflight:\n" + "\n".join(sorted(findings)))


def rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def core(path: Path) -> bool:
    name = rel(path)
    if name in ROOT_FILES:
        return True
    if not name.startswith("hakoniwa/"):
        return False
    excluded = ("data/", "docs/", "tests/", "scenarios/", "plugins/", "labs/", "examples/", "legacy/", "checks/", "procedures/")
    return not name.removeprefix("hakoniwa/").startswith(excluded)


def data(path: Path) -> bool:
    return rel(path).startswith("hakoniwa/data/")


def institutions(path: Path) -> bool:
    name = rel(path)
    prefixes = ("hakoniwa/checks/", "hakoniwa/procedures/", "hakoniwa/interaction/")
    modules = {
        "hakoniwa/institutional_logic.py", "hakoniwa/institutional_matrix.py",
        "hakoniwa/legislative_cycle.py",
        "hakoniwa/temporary_offices.py", "hakoniwa/action_repertoire.py",
    }
    return name.startswith(prefixes) or name in modules


def scenarios(path: Path) -> bool:
    return rel(path).startswith("hakoniwa/scenarios/")


def plugins(path: Path) -> bool:
    return rel(path).startswith("hakoniwa/plugins/arcana/") or rel(path)=="hakoniwa/plugins/__init__.py"


def polling_plugin(path: Path) -> bool:
    return rel(path).startswith("hakoniwa/plugins/polling/") or rel(path)=="hakoniwa/plugins/__init__.py"


def majority_plugin(path: Path) -> bool:
    return rel(path).startswith("hakoniwa/plugins/majorities/") or rel(path)=="hakoniwa/plugins/__init__.py"


def developer(path: Path) -> bool:
    return rel(path).startswith(("hakoniwa/tests/", "hakoniwa/labs/", "hakoniwa/examples/", "hakoniwa/legacy/"))


def documentation(path: Path) -> bool:
    name = rel(path)
    return (
        name in {"README.md", "AI_START_HERE.md", "PORTABLE_QUICKSTART_CN.md", "hakoniwa/README.md"}
        or name.startswith("hakoniwa/docs/")
        or (path.suffix.lower() == ".md" and name.startswith(("hakoniwa/data/", "hakoniwa/scenarios/", "hakoniwa/checks/")))
    )


BundleSelector = Callable[[Path], bool]
BUNDLES: tuple[tuple[str, str, BundleSelector], ...] = (
    ("00_FULL_PORTABLE_APP.zip", "Complete runnable Hakoniwa source distribution", lambda _path: True),
    ("01_CORE_ENGINE.zip", "Core decision, world, media, polling and CLI engine", core),
    ("02_PERSONAS_AND_DATA.zip", "Persona cards, party interests, environments and calibration", data),
    ("03_INSTITUTIONS_AND_LAW.zip", "Constitutional, procedural and institutional checks", institutions),
    ("04_SCENARIO_PACKS.zip", "Runnable scenario source packs without generated reports", scenarios),
    ("05_PLUGIN_ARCANA.zip", "Optional ARCANA plug-in", plugins),
    ("06_DEVELOPER_TESTS.zip", "Tests, labs, examples and legacy calibration adapters", developer),
    ("07_DOCUMENTATION.zip", "Architecture, model and source documentation", documentation),
    ("08_PLUGIN_POLLING.zip", "Voter response, polling, electorate evidence and publication models", polling_plugin),
    ("09_PLUGIN_MAJORITIES.zip", "Organizational majorities, discipline and member-level voting", majority_plugin),
)


def write_entry(archive: zipfile.ZipFile, name: str, data_bytes: bytes, executable: bool = False) -> None:
    info = zipfile.ZipInfo(f"{RELEASE_ROOT}/{name}", FIXED_TIME)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = (0o755 if executable else 0o644) << 16
    archive.writestr(info, data_bytes)


def build_zip(filename: str, description: str, selected: list[Path]) -> dict:
    target = SHELF / filename
    manifest_files = []
    for path in selected:
        content = path.read_bytes()
        manifest_files.append({"path": rel(path), "bytes": len(content), "sha256": sha256(content)})
    manifest = {
        "project": "Hakoniwa", "version": RELEASE_VERSION, "release_date": RELEASE_DATE,
        "description": description, "python": ">=3.11; standard library only",
        "entrypoint": "AI_START_HERE.md", "cli": "python3 -m hakoniwa",
        "canonical_personas": "hakoniwa/data/personas/registry.json",
        "persona_components": "hakoniwa/data/personas/actors/",
        "compatibility_personas": "hakoniwa/data/personas/cards_pss.json",
        "standalone": filename=="00_FULL_PORTABLE_APP.zip",
        "partial_bundle_note": "Topical archives are overlays for the full package, not independently runnable applications.",
        "files": manifest_files,
    }
    with zipfile.ZipFile(target, "w") as archive:
        write_entry(archive, "BUNDLE_MANIFEST.json", json.dumps(manifest, ensure_ascii=False, indent=2).encode())
        for path in selected:
            write_entry(archive, rel(path), path.read_bytes(), path.name == "hakoniwa.sh")
    payload = target.read_bytes()
    return {"file": filename, "bytes": len(payload), "sha256": sha256(payload), "source_files": len(selected)}


def github_readme() -> str:
    # Preserve the user's existing prose. Only the version and a now-obsolete
    # package-number range change when rebuilding the upload shelf.
    existing = ROOT / "README.md"
    if not existing.exists():
        existing = SHELF / "README.md"
    if existing.exists():
        body = existing.read_text(encoding="utf-8")
        if re.search(r"(?m)^# v\.\d+\.\d+\.\d+[^\n]*$", body):
            body = re.sub(r"(?m)^# v\.\d+\.\d+\.\d+[^\n]*$", f"# {RELEASE_VERSION}", body, count=1)
        elif re.search(r"(?m)^Version: .*$", body):
            body = re.sub(r"(?m)^Version: .*$", f"Version: {RELEASE_VERSION}", body)
        else:
            first, separator, rest = body.partition('\n')
            body = first + f"\n\nVersion: {RELEASE_VERSION}\n" + separator + rest
        return body.replace("`01`–`07`", "`01`–`09`")
    return """# Hakoniwa

Hakoniwa is an auditable political decision sandbox. It separates world facts,
institutions, incomplete information, actor-specific personality/PSS, strategic
interaction, party interests, media narratives, outcomes, and feedback.

## Download

- `00_FULL_PORTABLE_APP.zip` — recommended complete package.
- `01`–`09` — smaller topical packages for inspection or selective use.
- `SHA256SUMS.txt` — integrity hashes for every downloadable ZIP.
- `UPLOAD_PLAN.md` — exact replacement list for this release.

Unzip the full package, open `AI_START_HERE.md`, then run:

```bash
python3 -m hakoniwa validate --pretty
python3 -m hakoniwa actors
python3 -m hakoniwa scenarios
```

ARCANA is optional and disabled unless explicitly enabled. Scenario reports and
caches are generated locally and are not shipped in the source archives.
""".replace("# Hakoniwa\n",f"# Hakoniwa\n\nVersion: {RELEASE_VERSION}\n",1)


def first_readme() -> str:
    return """# 从这里开始

下载 `00_FULL_PORTABLE_APP.zip` 即可获得完整的 Hakoniwa。

解压后先读 `AI_START_HERE.md`。最小检查命令：

```bash
python3 -m hakoniwa validate --pretty
python3 -m hakoniwa actors
python3 -m hakoniwa scenarios
```

十个 ZIP 本次都已重新生成；不能只上传新增文件，因为原有核心代码、
人物卡、制度规则、场景、测试和文档也都有修改。旧的 `kfrage_model`
包名已由 `hakoniwa` 替代，K-Frage 2024 仅作为 legacy calibration 保留。
"""


def category_map() -> str:
    lines = ["# Hakoniwa release shelf", "", "| File | Contents |", "|---|---|"]
    for filename, description, _selector in BUNDLES:
        lines.append(f"| `{filename}` | {description} |")
    lines.extend(["", "All ZIPs are deterministic and contain `Hakoniwa/BUNDLE_MANIFEST.json`.",
                  "Generated reports, scenario outputs, caches and bytecode are excluded."])
    return "\n".join(lines) + "\n"


def upload_plan(rows: list[dict]) -> str:
    old = [name for name, _description, _selector in BUNDLES[:8]] + ["CATEGORY_MAP.md", "README.md", "README_FIRST.md", "SHA256SUMS.txt", "UPLOAD_PLAN.md"]
    lines = [f"# GitHub upload plan — {RELEASE_DATE} · {RELEASE_VERSION}", "",
             "Target: `Nagami-Reia/de26-political-sandbox` (`main`).", "",
             "## Replace every existing file", ""]
    lines.extend(f"- REPLACE `{name}`" for name in old)
    lines.extend(["", "## Add", "", "- ADD `08_PLUGIN_POLLING.zip`", "- ADD `09_PLUGIN_MAJORITIES.zip`",
                  "- ADD `RELEASE_MANIFEST.json`", "- ADD `VERIFICATION.json`", "",
                  "Do not retain an older ZIP under the same release shelf: GitHub does not merge ZIP contents.",
                  "The new full package contains `hakoniwa/`; the former internal `kfrage_model/` package is obsolete.",
                  "", "## Archive checksums", ""])
    lines.extend(f"- `{row['file']}` — `{row['sha256']}`" for row in rows)
    return "\n".join(lines) + "\n"


def build() -> list[dict]:
    SHELF.mkdir(parents=True, exist_ok=True)
    all_files = project_files()
    preflight_secret_scan(all_files)
    rows = []
    for filename, description, selector in BUNDLES:
        rows.append(build_zip(filename, description, [path for path in all_files if selector(path)]))
    (SHELF / "README.md").write_text(github_readme(), encoding="utf-8")
    (SHELF / "README_FIRST.md").write_text(first_readme(), encoding="utf-8")
    (SHELF / "CATEGORY_MAP.md").write_text(category_map(), encoding="utf-8")
    (SHELF / "UPLOAD_PLAN.md").write_text(upload_plan(rows), encoding="utf-8")
    (SHELF / "SHA256SUMS.txt").write_text(
        "".join(f"{row['sha256']}  {row['file']}\n" for row in rows), encoding="utf-8")
    (SHELF / "RELEASE_MANIFEST.json").write_text(json.dumps({
        'project':'Hakoniwa','version':RELEASE_VERSION,'release_date':RELEASE_DATE,
        'repository':'https://github.com/Nagami-Reia/de26-political-sandbox',
        'remote_readme_checked':False,'readme_basis':'User-provided README text; only version line added',
        'archives':rows,'excluded':'Generated reports, caches, bytecode, synced sources and downloaded input archives',
        'category_archives_are_partial':True,
    },ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return rows


if __name__ == "__main__":
    print(json.dumps({"shelf": str(SHELF), "archives": build()}, ensure_ascii=False, indent=2))
