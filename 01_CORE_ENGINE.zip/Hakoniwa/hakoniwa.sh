#!/bin/sh
set -eu
exec python3 -m hakoniwa "$@"
