"""Zero-install launcher for the self-contained Hakoniwa bundle."""
from hakoniwa.cli import main


raise SystemExit(main())
