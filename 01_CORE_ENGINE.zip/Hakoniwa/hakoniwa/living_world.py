"""Time/agenda scheduling around the existing v3 orchestrator and persona engine."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, replace
from copy import copy
from datetime import timedelta
from html import escape
import json
from pathlib import Path
from typing import Mapping, Callable
import math

from .persona_v2 import ActionOption, ActionOutcome, WorldEvent
from .political_state import PoliticalAction
from .political_state_system import quantize3
from .scenario_reporting import ScenarioReportCompiler, render_arcana_embed
from .simulation_orchestrator import LayeredSimulationOrchestrator
from .world_clock import WorldClock, WorkCalendar, ScheduledEvent, COMPLETION, DEADLINE, DISPATCH
from .world_clock import CLAIM_RESOLUTION, EFFECT
from .delayed_effects import DelayedEffectExecutor
from .opportunity_windows import OpportunityRegistry
from .political_timing import TimingBeliefs, TimingReport
from .world_environment import SchedulingRules


@dataclass
class Task:
    key: str
    owner: str
    release: int
    deadline: int
    duration: int
    importance: float = .5
    value_impacts: dict[str, float] = field(default_factory=dict)
    tags: tuple[str, ...] = ()
    node: str | None = None
    effects: dict[str, float] = field(default_factory=dict)
    dependencies: tuple[str, ...] = ()
    requires_windows: tuple[tuple[int, int], ...] = ()
    followups: dict[str, tuple[str, ...]] = field(default_factory=dict)
    activation: str = "scheduled"
    operation: str | None = None
    operation_data: dict = field(default_factory=dict)
    status: str = "UNRELEASED"
    started: int | None = None
    finished: int | None = None
    overdue: bool = False
    deadline_policy: str = "SOFT"
    late_decay_per_hour: float = 0.0
    dependency_outcomes: dict[str,str] = field(default_factory=dict)
    lifecycle: str = "LEGACY_COMPLETION"
    action_timing: dict[str,dict] = field(default_factory=dict)
    window: str|None = None
    phase: str = "PREPARING"
    work_status: str = "NOT_STARTED"
    action_outcome: str = "PENDING"
    institutional_outcome: str = "NOT_EVALUATED"
    world_outcome: str = "NOT_SETTLED"
    committed_at: int|None = None
    committed_action: str|None = None
    execution_duration: int = 0
    execution_started: int|None = None
    execution_attention: bool = True
    reservation_started: int|None = None
    reserved_duration: int = 0
    reservation_day: str|None = None
    revision: int = 0
    policy_project: str | None = None

    def __post_init__(self) -> None:
        if any(type(value) is not int for value in (self.release, self.deadline, self.duration)):
            raise ValueError("Task times and durations must be integer minutes")
        if not 0 <= self.importance <= 1 or self.duration <= 0:
            raise ValueError("Task importance must be 0..1 and duration positive")
        if self.deadline < self.release:
            raise ValueError("Task deadline precedes release")
        if self.activation not in {"scheduled", "conditional"}:
            raise ValueError("Task activation must be scheduled or conditional")
        if self.deadline_policy not in {"SOFT","HARD","DECAY"}:raise ValueError("Unknown deadline policy")
        if not math.isfinite(self.late_decay_per_hour) or self.late_decay_per_hour<0 or (self.deadline_policy=="DECAY" and self.late_decay_per_hour<=0):raise ValueError("DECAY requires an explicit positive hourly decay")
        if self.lifecycle not in {"LEGACY_COMPLETION","STAGED"}:raise ValueError("Unknown task lifecycle")
        if set(self.dependency_outcomes)-set(self.dependencies):raise ValueError("Dependency outcome refers to a non-dependency")
        if any(v not in {"action_success","work_complete","institution_executable","world_change"} for v in self.dependency_outcomes.values()):raise ValueError("Unknown dependency outcome requirement")
        for timing in self.action_timing.values():
            if set(timing)-{"execution_minutes","estimated_execution_minutes","attention_required"} or type(timing.get("execution_minutes")) is not int or timing["execution_minutes"]<0 or type(timing.get("attention_required",True)) is not bool:
                raise ValueError("Explicit nonnegative execution minutes and attention flag required")
            if "estimated_execution_minutes" in timing and (type(timing["estimated_execution_minutes"]) is not int or timing["estimated_execution_minutes"]<0):raise ValueError("Invalid perceived execution time")


@dataclass
class Capacity:
    daily_minutes: int = 360
    slots: int = 1
    calendar: WorkCalendar = field(default_factory=WorkCalendar)
    busy: set[str] = field(default_factory=set)
    spent_by_day: dict[str, int] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if type(self.daily_minutes) is not int or type(self.slots) is not int or self.daily_minutes <= 0 or self.slots <= 0:
            raise ValueError("Capacity must be positive")


class LivingPoliticalWorld:
    """The clock owns timing; existing orchestrator owns political decisions/outcomes.

    A task reserves deliberation or execution time. Political choice occurs at
    completion, using information available at that timestamp. It is not settled
    in advance. Personal tasks are non-preemptive in this first implementation.
    """

    def __init__(self, game: LayeredSimulationOrchestrator, clock: WorldClock,
                 capacities: Mapping[str, Capacity], tasks: list[Task],
                 reactive_rules: tuple[dict, ...] = (), scheduling: SchedulingRules | None = None):
        self.game, self.clock = game, clock
        self.capacities = dict(capacities)
        if len({t.key for t in tasks}) != len(tasks):
            raise ValueError("Duplicate task keys")
        self.tasks = {task.key: task for task in tasks}
        self._initial_task_durations={task.key:task.duration for task in tasks}
        self.reactive_rules = reactive_rules
        self.fired_rules: set[str] = set()
        self.configuration: dict = {}
        self.environment: dict = {}
        self.scheduling = scheduling or SchedulingRules()
        self.event_handlers: dict[str, Callable] = {}
        self.operation_handlers: dict[str, Callable] = {}
        self.listeners: list[Callable] = []
        self.services: dict[str, object] = {}
        self.trace: list[dict] = []
        self._dispatch_pending: set[tuple[str, int]] = set()
        self.used_personas = sorted(set(self.capacities) & set(game.personas.cards))
        self.initial_pss = {a: asdict(game.personas.runtime[a].state) for a in self.used_personas}
        self.variable_provenance = {}
        self.external_environment = None
        self._audited_history = 0
        self.game.state.now_minute=clock.minute
        self._organization_tasks = {}
        if game.organizations is not None:
            def schedule_response(due, request_id):
                self.clock.schedule(due, "organizational_response", {"request_id": request_id}, phase=EFFECT)
            game.organization_schedule_hook = schedule_response
        self.delayed_effects=DelayedEffectExecutor(self)
        self.opportunities=OpportunityRegistry()
        self._commit_plans={}
        self._paused_tasks={}
        self.policy_projects={}
        self.policy_action_providers={}
        self._claim_events=set()
        self._window_status_cache={}
        self._refreshing_temporal=False
        self.timing_beliefs=TimingBeliefs()
        self.waiting_policies={}
        self._waiting_until={};self._wait_spent={};self._waiting_since={}
        self.game.temporal_choice_adapter=self._temporal_choices
        if game.check_context_provider is not None:
            original_provider = game.check_context_provider
            base_hours = original_provider(game.state).now_hours
            def timed_context(state):
                context = copy(original_provider(state))
                context.now_hours = base_hours + self.clock.minute // 60
                return context
            game.check_context_provider = timed_context
        for owner, capacity in self.capacities.items():
            if owner in game.personas.cards and capacity.slots != 1:
                raise ValueError("A person can occupy only one attention slot")
        for task in tasks:
            self._validate_task(task)
        self._validate_dependencies()
        for task in tasks:
            if task.activation == "scheduled":
                clock.schedule(task.release, "release", {"task": task.key})
                clock.schedule(task.deadline, "deadline", {"task": task.key}, phase=DEADLINE)
        for rule in reactive_rules:
            if rule.get("direction", "above") not in {"above", "below"}:
                raise ValueError("Rule direction must be above or below")
            if rule["variable"] not in game.state.variables:
                raise ValueError("Rule references unknown variable")
            if any(key not in self.tasks for key in rule["release_tasks"]):
                raise ValueError("Rule references unknown task")
        for observer in game.event_observers:
            if hasattr(observer, "telemetry") and not observer.telemetry.points:
                observer.record_baseline(game.state)
        self._check_reactive_rules()

    def _validate_task(self, task: Task) -> None:
        if task.owner not in self.capacities:
            raise ValueError(f"No capacity for {task.owner}")
        cap = self.capacities[task.owner]
        if task.duration > cap.daily_minutes:
            raise ValueError(f"{task.key} exceeds daily capacity; split it into stages")
        cap.calendar.next_slot(self.clock, max(self.clock.minute, task.release), task.duration)
        if task.node is not None:
            if task.node not in self.game.nodes or self.game.nodes[task.node].owner != task.owner:
                raise ValueError(f"Task/node owner mismatch at {task.key}")
            if task.owner not in self.game.personas.cards:
                raise ValueError("Political nodes require an existing persona")
        elif task.owner in self.game.personas.cards:
            raise ValueError("Personal tasks require a v3 decision node")
        if task.node is not None and task.effects:
            raise ValueError("Personal effects belong to existing WorldActions")
        if task.lifecycle=="STAGED" and not task.node:raise ValueError("Staged commitments require a persona decision node")
        if task.lifecycle=="STAGED":
            node=self.game.nodes[task.node]
            if node.actions and set(task.action_timing)!={a.world.key for a in node.actions}:
                raise ValueError("Every staged action requires explicit execution timing")
            for timing in task.action_timing.values():
                if timing.get("attention_required",True):
                    if timing["execution_minutes"]>cap.daily_minutes:raise ValueError("Execution attention must fit a day; split into stages")
                    if timing["execution_minutes"]:cap.calendar.next_slot(self.clock,max(task.release,self.clock.minute),timing["execution_minutes"])
        if task.deadline_policy=="DECAY" and task.node and any(a.intent for a in self.game.nodes[task.node].actions):
            raise ValueError("Do not scale legal acts using a numerical lateness penalty")
        if task.operation and (task.node or task.effects):
            raise ValueError("A service operation must own its settlement, without duplicate node/effects")
        if task.operation == "parliamentary_vote" and not task.requires_windows:
            raise ValueError("A parliamentary vote needs an explicit procedure window")
        missing = set(task.effects) - set(self.game.state.variables)
        if missing:
            raise ValueError(f"Unknown operational variables: {sorted(missing)}")
        # Organisational jobs are operational only, never a shortcut around legal intent checks.
        poll_vars = {spec.state_variable for observer in self.game.event_observers
                     for spec in getattr(observer, "specs", ())}
        if poll_vars & set(task.effects):
            raise ValueError("Organisational work cannot directly change party support; use media feedback")
        for start, end in task.requires_windows:
            if start >= end:
                raise ValueError("Invalid procedure window")

    def _validate_dependencies(self) -> None:
        visited, active = set(), set()
        def visit(key):
            if key in active:
                raise ValueError("Cyclic task dependencies")
            if key in visited:
                return
            active.add(key)
            for dependency in self.tasks[key].dependencies:
                if dependency not in self.tasks:
                    raise ValueError(f"Unknown dependency {dependency}")
                visit(dependency)
            active.remove(key)
            visited.add(key)
        for key in self.tasks:
            visit(key)
            for targets in self.tasks[key].followups.values():
                if any(target not in self.tasks for target in targets):
                    raise ValueError("Unknown followup task")

    def add_event(self, at: int, key: str, affected: tuple[str, ...],
                  severity: float = .4, tags: tuple[str, ...] = (),
                  effects: dict[str, float] | None = None, *, visibility: str = "PUBLIC") -> None:
        if visibility not in {"PUBLIC", "PRIVATE", "HIDDEN"}:
            raise ValueError("Invalid event visibility")
        if visibility == "HIDDEN" and affected:
            raise ValueError("Hidden event cannot notify personas; schedule later knowledge delivery")
        if any(a not in self.used_personas for a in affected):
            raise ValueError("Event recipients must be participating personas")
        poll_vars = {spec.state_variable for observer in self.game.event_observers
                     for spec in getattr(observer, "specs", ())}
        if poll_vars & set(effects or {}):
            raise ValueError("Facts cannot directly change party support")
        if set(effects or {}) - set(self.game.state.variables):
            raise ValueError("Unknown event variables")
        self.clock.schedule(at, "external_event", {"key": key, "affected": affected,
                            "severity": severity, "tags": tags, "effects": effects or {}, "visibility": visibility})

    def submit_task(self, task: Task) -> None:
        """Add an actor/organisation's new agenda item while a world is running."""
        if task.key in self.tasks or task.release < self.clock.minute:
            raise ValueError("New tasks need a unique key and a release time in the present/future")
        if task.policy_project and task.policy_project not in self.policy_projects:
            raise ValueError('Runtime task needs a registered policy project')
        self._validate_task(task)
        self.tasks[task.key] = task
        self._initial_task_durations[task.key]=task.duration
        try:
            self._validate_dependencies()
        except Exception:
            del self.tasks[task.key]
            self._initial_task_durations.pop(task.key,None)
            raise
        if task.activation == "scheduled":
            self.clock.schedule(task.release, "release", {"task": task.key})
            self.clock.schedule(task.deadline, "deadline", {"task": task.key}, phase=DEADLINE)

    def register_event_handler(self, kind: str, handler: Callable) -> None:
        if kind in {"dispatch", "release", "complete", "deadline", "external_event","delayed_effect_boundary","opportunity_claims","opportunity_boundary","external_execution_start"} or kind in self.event_handlers:
            raise ValueError(f"Reserved or duplicate clock handler: {kind}")
        self.event_handlers[kind] = handler

    def register_operation(self, kind: str, handler: Callable) -> None:
        if kind in self.operation_handlers:
            raise ValueError(f"Duplicate operation: {kind}")
        self.operation_handlers[kind] = handler

    def _elapse(self, minutes: int) -> None:
        self.game.state.now_minute=self.clock.minute+minutes
        self.delayed_effects.elapse(self.clock.minute,self.clock.minute+minutes)
        for actor in self.used_personas:
            self.game.personas.elapse_minutes(actor, minutes)

    def _record(self, kind: str, *, task: Task | None = None, details: dict | None = None,
                decision: dict | None = None) -> None:
        self._refresh_temporal()
        index = len(self.trace) + 1
        event_id = f"living:{index}:{kind}"
        timestamp = self.clock.at().isoformat()
        # Electorate response must settle before measurement AND provenance audit.
        if decision is None:  # political nodes were already processed by the game
            for observer in self.game.event_observers:
                if hasattr(observer, "timestamp_by_event_id"):
                    observer.timestamp_by_event_id[event_id] = timestamp
                observer.record(self.game.state,event_id=event_id,actor=task.owner if task else "world",
                                action=kind,event_kind=kind,resource_changes=details or {})
        provenance_updates = []
        for update in self.game.state.history[self._audited_history:]:
            for key, value in update["after"].items():
                if value != update["before"].get(key):
                    prior = self.variable_provenance.get(key, {"status": "SIMULATION_ASSUMPTION", "sources": []})
                    self.variable_provenance[key] = {"status": "SCENARIO_GENERATED",
                        "initial_status": prior.get("initial_status", prior["status"]),
                        "sources": prior.get("sources", []), "last_action": update["action"]}
                    self.game.state.variables[key] = replace(self.game.state.variables[key], evidence="SCENARIO_GENERATED")
                    provenance_updates.append({"variable": key, "before_status": prior["status"],
                                               "after_status": "SCENARIO_GENERATED", "action": update["action"]})
        self._audited_history = len(self.game.state.history)
        details = {**(details or {}), "provenance_updates": provenance_updates}
        row = {"node": event_id, "calendar_date": timestamp, "elapsed_minutes": self.clock.minute,
               "kind": kind, "task": task.key if task else None,
               "actors_used": self.used_personas, "details": details or {},
               "decision": decision,
               "all_actor_pss_after": {a: asdict(self.game.personas.runtime[a].state)
                                       for a in self.used_personas}}
        if decision:
            for key in ("arcana", "chosen_action", "decision_maker", "operational_feedback"):
                row[key] = decision[key]
        elif kind=="task_committed":
            row["arcana"]=(details or {}).get("arcana_at_commitment",{})
            row["chosen_action"]=task.committed_action
            row["decision_maker"]=task.owner
        self.trace.append(row)
        self._check_reactive_rules()
        for listener in self.listeners:
            listener(self, row)

    def _check_reactive_rules(self) -> None:
        for rule in self.reactive_rules:
            if rule["key"] in self.fired_rules:
                continue
            value = self.game.state.variables[rule["variable"]].value
            met = value >= rule["threshold"] if rule.get("direction", "above") == "above" else value <= rule["threshold"]
            if met:
                self.fired_rules.add(rule["key"])
                for target in rule["release_tasks"]:
                    task = self.tasks[target]
                    if task.status == "UNRELEASED":
                        self.clock.schedule(max(self.clock.minute+1, task.release), "release", {"task": target})

    def _stage_duration(self,task):
        return task.execution_duration if task.phase=="EXECUTION_READY" else task.duration

    def _temporal_choices(self,node,actions):
        task=self.tasks.get(node.key.removeprefix("living_task:")) if node.key.startswith("living_task:") else None
        if task is None or task.lifecycle!="STAGED":return actions,{}
        actor_beliefs=self.game.information.states[node.owner]
        estimate=self.timing_beliefs.estimate(node.owner,task.window,self.clock.minute,actor_beliefs.source_trust) if task.window else None
        rows={};adapted=[]
        for action in actions:
            timing=task.action_timing.get(action.world.key)
            if timing is None:raise ValueError("Action has no explicit timing contract")
            duration=timing.get("estimated_execution_minutes",timing["execution_minutes"])
            survival=1.0
            if estimate is not None and estimate["remaining_minutes"] is not None:
                believed_feasible=estimate["available_probability"] if duration<=estimate["remaining_minutes"] else 0.0
                survival=1-estimate["confidence"]*(1-believed_feasible)
            if task.deadline_policy=="HARD" and self.clock.minute+duration>task.deadline:survival=0.0
            # Apply time through expected goal attainment once, not repeated
            # good/bad rewards in risk, identity, feasibility and outcome layers.
            option=replace(action.choice,goal_impacts={k:v*survival if v>0 else v for k,v in action.choice.goal_impacts.items()})
            adapted.append(replace(action,choice=option))
            rows[action.world.key]={"estimated_execution_minutes":duration,"expected_goal_survival":survival,
                "timing_belief":estimate,"objective_window_read":False,"actual_outcome_not_modified":True}
        return tuple(adapted),rows

    def install_opportunities(self,windows):
        if self.opportunities.windows:raise ValueError("Opportunity registry already configured")
        self.opportunities=OpportunityRegistry(tuple(windows))
        for task in self.tasks.values():
            if task.window and task.window not in self.opportunities.windows:raise ValueError("Unknown task opportunity")
            if task.window and self.opportunities.windows[task.window].decay_per_hour:
                if task.operation or (task.node and any(a.intent for a in self.game.nodes[task.node].actions)):
                    raise ValueError("A decaying numerical window cannot silently scale institutional acts")
        for window in windows:
            for at in {window.opens_at,*((window.closes_at+1,) if window.closes_at is not None else ())}:
                if at>=self.clock.minute:self.clock.schedule(at,"opportunity_boundary",{"window":window.key})

    def configure_waiting(self,policies):
        for actor,row in policies.items():
            if actor not in self.used_personas:raise ValueError("Waiting policy needs a participating persona")
            if set(row)-{"window","review_minutes","max_wait_minutes"} or not row.get("window"):
                raise ValueError("Waiting policy needs an explicit belief topic, review interval and finite budget")
            if any(type(row.get(k)) is not int or row[k]<=0 for k in ("review_minutes","max_wait_minutes")):
                raise ValueError("Positive integer waiting intervals required")
        self.waiting_policies={a:dict(row) for a,row in policies.items()}

    def deliver_timing_report(self,actor,report):
        if actor not in self.used_personas:raise ValueError("Unknown timing report recipient")
        self.timing_beliefs.deliver(actor,report,self.clock.minute)
        self._end_wait(actor)
        self._record("timing_report_delivered",details={"actor":actor,"report":asdict(report)})
        self._dispatch_at(actor,self.clock.minute)

    def notify_information(self,actor,message_id):
        if actor in self._waiting_until:
            self._end_wait(actor)
            self._dispatch_at(actor,self.clock.minute)

    def _end_wait(self,actor):
        if actor in self._waiting_since:
            self._wait_spent[actor]=self._wait_spent.get(actor,0)+max(0,self.clock.minute-self._waiting_since.pop(actor))
        self._waiting_until.pop(actor,None)

    def _planner_resources(self,actor):
        rng=self.game.information.rng.getstate()
        try:return self.game._perceived_resources(actor,self.game.information.observe(actor,self.game.state,commit=False))
        finally:self.game.information.rng.setstate(rng)

    def _choose_wait(self,owner,task):
        policy=self.waiting_policies.get(owner)
        if not policy or task.phase=="EXECUTION_READY":return False
        review=policy["review_minutes"]
        if self._wait_spent.get(owner,0)+review>policy["max_wait_minutes"]:return False
        beliefs=self.game.information.states[owner]
        estimate=self.timing_beliefs.estimate(owner,policy["window"],self.clock.minute,beliefs.source_trust)
        if estimate is None:return False
        remaining=estimate["remaining_minutes"]
        # A disclosed heuristic on the actor's estimate, never an objective hazard.
        loss=estimate["available_probability"]*min(1,review/max(1,remaining)) if remaining is not None else 0.0
        known_slack=task.deadline-self.clock.minute-self._stage_duration(task)
        if task.deadline_policy=="HARD" and known_slack<review:loss=1.0
        gain=estimate["information_gain"]*estimate["confidence"]
        act=ActionOption("start_now",goal_impacts={"agenda":task.importance},value_impacts=task.value_impacts,
            effort=min(1,self._stage_duration(task)/self.capacities[owner].daily_minutes),upside=task.importance,downside=.1,event_tags=task.tags)
        wait=ActionOption("wait_for_information",goal_impacts={"agenda":task.importance*(1-loss),"information_quality":gain},
            upside=gain,downside=loss,uncertainty=1-estimate["confidence"],effort=0,
            event_tags=("deliberation","future_option"))
        decision=self.game.personas.decide(owner,(act,wait),self._planner_resources(owner),
            current_goals={"agenda":1.0,"information_quality":1.0},soft_resource_constraints=True)
        if decision.chosen_action!="wait_for_information":return False
        self._waiting_since[owner]=self.clock.minute
        self._waiting_until[owner]=self.clock.minute+review
        self._dispatch_at(owner,self.clock.minute+review)
        self._record("actor_waiting",task=task,details={"review_at":self.clock.minute+review,"attention_reserved":False,
            "timing_belief":estimate,"estimated_option_loss_heuristic":loss,
            "evaluations":{k:asdict(v) for k,v in decision.scores.items()}})
        return True

    def _dependency_state(self,task,key):
        if task.policy_project:
            project=self.policy_projects[task.policy_project]
            if project.status in {'WITHDRAWN','CLOSED'}:return 'FAILED'
            if project.status!='ACTIVE':return 'PENDING'
        parent=self.tasks[key];requirement=task.dependency_outcomes.get(key,"action_success")
        if parent.policy_project and requirement!='work_complete':
            state=self.policy_projects[parent.policy_project].status
            if state in {'WITHDRAWN','CLOSED'}:return 'FAILED'
            if state not in {'ACTIVE','WORK_COMPLETED'}:return 'PENDING'
        if requirement=="work_complete" and parent.work_status=="COMPLETED":return "SATISFIED"
        if requirement=="action_success" and parent.action_outcome=="SUCCEEDED":return "SATISFIED"
        if requirement=="institution_executable" and parent.institutional_outcome=="EXECUTABLE":return "SATISFIED"
        if requirement=="world_change" and parent.world_outcome=="CHANGED":return "SATISFIED"
        if parent.status in {"MISSED","BLOCKED","FAILED","EXPIRED","CANCELLED"} or parent.action_outcome in {"FAILED","BLOCKED","CANCELLED"}:return "FAILED"
        if parent.status in {"COMPLETED","COMPLETED_LATE"} and parent.action_outcome not in {"PENDING_PROCEDURE","PENDING_RESPONSE"}:return "FAILED"
        return "PENDING"

    def _release_attention(self,task,abort=False):
        cap=self.capacities[task.owner]
        if task.key not in cap.busy:return
        cap.busy.remove(task.key)
        if abort and task.reservation_started is not None:
            unused=max(0,task.reserved_duration-(self.clock.minute-task.reservation_started))
            cap.spent_by_day[task.reservation_day]-=unused
            if task.owner in self.used_personas:
                state=self.game.personas.runtime[task.owner].state
                state.energy=min(1,state.energy+self.scheduling.energy_cost_per_daily_budget*unused/cap.daily_minutes)

    def _fail_task(self,task,status,reason,diagnostic=None):
        self._release_attention(task,abort=True)
        task.status=status;task.finished=self.clock.minute
        task.work_status="INTERRUPTED" if task.work_status not in {"COMPLETED","PREPARED"} else task.work_status
        task.action_outcome="CANCELLED" if status=="CANCELLED" else "FAILED"
        task.world_outcome="NOT_SETTLED"
        plan=self._commit_plans.pop(task.key,None)
        self._paused_tasks.pop(task.key,None)
        pss=None
        if task.owner in self.used_personas and status!="CANCELLED" and reason!="HARD_DEADLINE":
            expected=(plan or {}).get("temporal_assessment",{}).get(task.committed_action,{}).get("expected_goal_survival",.5)
            pss=self.game.personas.apply_outcome(task.owner,ActionOutcome(
                action=task.committed_action or task.key,success=0,expected_success=expected,evidence_quality=1,
                outcome_scope=task.importance,workload=0,tags=("opportunity_not_executed","loss_of_control")))
        self._record("task_not_executed",task=task,details={"reason":reason,"commitment":task.committed_action,
            "objective_diagnostic":diagnostic,"pss_update":pss,
            "cost_policy":"spent preparation/attention retained; only unspent reservation released"})
        for owner in self.capacities:self._dispatch_at(owner,self.clock.minute)

    def cancel_task(self,key,reason):
        if not reason:raise ValueError("Cancellation requires an auditable reason")
        task=self.tasks[key]
        if task.status in {"COMPLETED","COMPLETED_LATE","EXPIRED","CANCELLED","FAILED","MISSED","BLOCKED"}:return False
        self._fail_task(task,"CANCELLED",reason)
        self._paused_tasks.pop(key,None)
        return True

    def suspend_task(self,key,reason):
        """Hold reversible operational work, retaining spent attention/commitment."""
        task=self.tasks[key]
        if not reason:raise ValueError('Suspension requires a reason')
        if task.status in {'COMPLETED','COMPLETED_LATE','EXPIRED','CANCELLED','FAILED','MISSED','BLOCKED','PAUSED'}:return False
        if task.operation or (task.node and any(a.intent for a in self.game.nodes[task.node].actions)):
            return False  # A poll cannot mechanically suspend an institutional act.
        previous={'status':task.status,'phase':task.phase,'duration':task.duration,'execution_duration':task.execution_duration}
        if task.status=='RUNNING':
            elapsed=self.clock.minute-task.reservation_started
            remaining=task.reserved_duration-elapsed
            if remaining<=0:return False
            if task.phase=='EXECUTING':task.execution_duration=remaining
            else:task.duration=remaining
        elif task.status=='EXECUTING_EXTERNAL' and task.phase=='EXECUTING':
            remaining=task.execution_duration-(self.clock.minute-task.execution_started)
            if remaining<=0:return False
            task.execution_duration=remaining
        self._release_attention(task,abort=True)
        task.revision+=1
        self._paused_tasks[key]=previous
        task.status='PAUSED'
        self._record('task_suspended',task=task,details={'reason':reason,'previous':previous,
            'spent_cost_retained':True,'commitment_retained':task.committed_action})
        return True

    def resume_task(self,key,reason):
        task=self.tasks[key]
        if task.status!='PAUSED':return False
        previous=self._paused_tasks.pop(key)
        if previous['phase']=='EXECUTING':task.phase='EXECUTION_READY'
        if self.clock.minute<task.release:
            task.status='UNRELEASED'
        else:
            task.status='READY'
            if task.committed_at is not None:
                if task.window and task.key not in self.opportunities.windows[task.window].claims:
                    if self.opportunities.windows[task.window].resolved_claims.get(task.key)=='CONTESTED':
                        task.status='WAITING_ALLOCATION'
                    else:self._request_claim(task)
                else:self._queue_execution(task)
            else:self._dispatch_at(task.owner,self.clock.minute+1)
        self._record('task_resumed',task=task,details={'reason':reason,'new_political_choice':False})
        return True

    def restart_task_preparation(self,key,reason):
        task=self.tasks[key]
        if task.status!='PAUSED':return False
        previous=self._paused_tasks.pop(key)
        self._commit_plans.pop(key,None)
        task.duration=self._initial_task_durations[key];task.execution_duration=0
        task.committed_action=None;task.committed_at=None;task.execution_started=None
        task.phase='PREPARING';task.work_status='NOT_STARTED';task.revision+=1
        task.status='READY' if self.clock.minute>=task.release else 'UNRELEASED'
        self._record('task_repreparation_required',task=task,details={'reason':reason,'spent_cost_retained':True})
        self._dispatch_at(task.owner,self.clock.minute+1)
        return True

    def _execution_gate(self,task,starting_execution=False):
        reason=None;diagnostic=None
        if task.deadline_policy=="HARD" and self.clock.minute>task.deadline:reason="HARD_DEADLINE"
        if task.requires_windows and (starting_execution or task.phase=="EXECUTING" or task.lifecycle=="LEGACY_COMPLETION"):
            # Execution must finish inside a statutory/procedural interval.
            remaining=task.execution_duration if starting_execution else 0
            if not any(start<=self.clock.minute and self.clock.minute+remaining<=end for start,end in task.requires_windows):reason="PROCEDURE_WINDOW_CLOSED"
        if task.window:
            status=self.opportunities.windows[task.window].check(self.game.state,self.clock.minute,task.key)
            if status!="OPEN":
                reason="OPPORTUNITY_"+status
                diagnostic=self.opportunities.windows[task.window].diagnostic(self.game.state,self.clock.minute,task.key)
        plan=self._commit_plans.get(task.key)
        if plan:
            selected=next(a for a in plan["legal_pairs"] if a.world.key==task.committed_action)
            if not self.game.state.legal(selected.world):reason="COMMITTED_ACTION_NO_LONGER_EXECUTABLE"
        if reason:self._fail_task(task,"EXPIRED",reason,diagnostic);return False
        return True

    def _refresh_temporal(self):
        if self._refreshing_temporal:return
        self._refreshing_temporal=True
        try:
            self.game.state.now_minute=self.clock.minute
            self.delayed_effects.refresh()
            for key,window in self.opportunities.windows.items():
                status=window.check(self.game.state,self.clock.minute)
                if self._window_status_cache.get(key)!=status:
                    self.opportunities.history.append({"window":key,"transition_from":self._window_status_cache.get(key),
                        "transition_to":status,"diagnostic":window.diagnostic(self.game.state,self.clock.minute)})
                    self._window_status_cache[key]=status
            for task in list(self.tasks.values()):
                if task.window and task.window not in self.opportunities.windows:raise ValueError("Unknown opportunity: "+task.window)
                if task.committed_at is not None and task.status in {"RUNNING","EXECUTING_EXTERNAL","READY","WAITING_ALLOCATION"} and task.window:
                    # Secret political closure cannot release attention early.
                    if self.opportunities.windows[task.window].running_policy=="INTERRUPT":self._execution_gate(task)
        finally:self._refreshing_temporal=False

    def _request_claim(self,task):
        if task.policy_project and self.policy_projects[task.policy_project].status!='ACTIVE':
            if self.suspend_task(task.key,'PROJECT_AWAITING_POLITICAL_REVIEW'):return
        task.status="WAITING_ALLOCATION"
        self.opportunities.request(task.window,task.key,task.owner,self.clock.minute)
        key=(task.window,self.clock.minute)
        if key not in self._claim_events:
            self._claim_events.add(key)
            phase=max(CLAIM_RESOLUTION,self.clock._active_phase or 0)
            self.clock.schedule(self.clock.minute,"opportunity_claims",{"window":task.window},phase=phase)

    def _resume_claims(self,results):
        for key,status in results.items():
            task=self.tasks[key]
            if task.status!="WAITING_ALLOCATION":continue
            if status=="ACCEPTED":
                if task.lifecycle=="STAGED":self._queue_execution(task)
                else:self._execute_task(task)
            elif status!="CONTESTED":self._fail_task(task,"EXPIRED","CLAIM_"+status)

    def resolve_opportunity(self,key,winners,*,authority):
        window=self.opportunities.windows[key]
        if not authority or authority!=window.allocation_authority:raise ValueError("Contested allocation must be resolved by its configured decision authority")
        if any(c not in self.tasks or self.tasks[c].status!="WAITING_ALLOCATION" for c in winners):raise ValueError("Cannot award an expired or withdrawn claim")
        self.opportunities.resolve_contest(key,winners,self.game.state,self.clock.minute)
        self._record("opportunity_owner_resolution",details={"window":key,"winners":list(winners),"authority":authority})
        self._resume_claims(dict(window.resolved_claims))

    def extend_opportunity(self,key,new_closes_at,*,authority,reason):
        window=self.opportunities.windows[key]
        if not authority or authority!=window.allocation_authority or not reason:raise ValueError("Extension needs its objective decision authority and reason")
        if window.closes_at is None or type(new_closes_at) is not int or new_closes_at<=max(window.closes_at,self.clock.minute):raise ValueError("Extension must move an existing deadline into the future")
        before=window.closes_at;window.closes_at=new_closes_at
        self.clock.schedule(new_closes_at+1,"opportunity_boundary",{"window":key})
        self._record("opportunity_extended",details={"window":key,"before":before,"after":new_closes_at,"authority":authority,"reason":reason,
            "note":"World agreement only; actor beliefs and independent legal/procedure deadlines unchanged"})

    def release_opportunity_claim(self,key,claim,*,authority,reason):
        window=self.opportunities.windows[key]
        if not authority or authority!=window.allocation_authority or not reason:raise ValueError("Release needs authority and reason")
        if claim not in window.claims:raise ValueError("Unknown accepted claim")
        del window.claims[claim];window.resolved_claims[claim]="RELEASED"
        self._record("opportunity_claim_released",details={"window":key,"claim":claim,"authority":authority,"reason":reason})

    def _queue_execution(self,task):
        if task.policy_project and self.policy_projects[task.policy_project].status!='ACTIVE':
            if self.suspend_task(task.key,'PROJECT_AWAITING_POLITICAL_REVIEW'):return
        if not self._execution_gate(task):return
        if not task.execution_duration:
            self._execute_task(task)
        elif task.execution_attention:
            task.phase="EXECUTION_READY";task.status="READY"
            self._dispatch_at(task.owner,self.clock.minute)
        else:
            task.phase="WAITING_EXTERNAL";task.status="EXECUTING_EXTERNAL";task.revision+=1
            start=self.clock.minute
            if task.requires_windows:
                slots=[max(start,a) for a,b in task.requires_windows if max(start,a)+task.execution_duration<=b]
                if not slots:self._fail_task(task,"EXPIRED","NO_EXTERNAL_PROCEDURE_WINDOW");return
                start=min(slots)
            if start==self.clock.minute:self._start_external_execution(task)
            else:self.clock.schedule(start,"external_execution_start",{"task":task.key,"revision":task.revision},phase=COMPLETION)

    def _start_external_execution(self,task):
        if not self._execution_gate(task,starting_execution=True):return
        task.phase="EXECUTING";task.execution_started=self.clock.minute
        self.clock.schedule(self.clock.minute+task.execution_duration,"complete",{"task":task.key,"revision":task.revision},phase=COMPLETION)
        self._record("external_execution_started",task=task,details={"attention_reserved":False})

    def _execute_task(self,task):
        if not self._execution_gate(task):return
        multiplier=math.exp(-task.late_decay_per_hour*max(0,self.clock.minute-task.deadline)/60) if task.deadline_policy=="DECAY" else 1.0
        if task.window:multiplier*=self.opportunities.windows[task.window].payoff(self.clock.minute)
        before={k:v.value for k,v in self.game.state.variables.items()}
        decision=None;operation_result=None
        if task.node:
            instance_key=f"living_task:{task.key}"
            self.game.nodes[instance_key]=replace(self.game.nodes[task.node],key=instance_key)
            decision=self.game.run(instance_key,max_steps=1,timestamp=self.clock.at().isoformat(),compile_report=False,
                prepared=self._commit_plans.get(task.key),effect_multiplier=multiplier)
            resolution=decision["institutional_resolution"]["resolution"]
            task.institutional_outcome=resolution.upper()
            task.action_outcome="SUCCEEDED" if resolution in {"not_invoked","executable"} else "BLOCKED" if resolution=="blocked" else "PENDING_PROCEDURE"
            request = decision["operational_feedback"].get("organization_request")
            if request is not None:
                task.action_outcome = "PENDING_RESPONSE"
                self._organization_tasks[request["request_id"]] = task.key
        elif task.operation:
            if multiplier!=1:raise ValueError("Do not silently scale service-defined institutional outcomes")
            if task.operation not in self.operation_handlers:raise ValueError("Unregistered operation")
            operation_result=self.operation_handlers[task.operation](self,task)
            task.action_outcome=(operation_result or {}).get("action_outcome","SUCCEEDED")
            task.institutional_outcome=(operation_result or {}).get("institutional_outcome","NOT_EVALUATED")
        else:
            if task.effects:self.game.state.apply(PoliticalAction("implementation:"+task.key,{"immediate":{k:v*multiplier for k,v in task.effects.items()}}))
            task.action_outcome="SUCCEEDED";task.institutional_outcome="NOT_APPLICABLE"
        task.status="COMPLETED_LATE" if task.overdue else "COMPLETED"
        task.work_status="COMPLETED";task.finished=self.clock.minute
        self._commit_plans.pop(task.key,None)
        task.world_outcome="CHANGED" if any(v.value!=before[k] for k,v in self.game.state.variables.items()) else "UNCHANGED"
        self._record("task_completed",task=task,decision=decision,details={"late":task.overdue,"payoff_multiplier":multiplier,
            "implementation_effects":task.effects,"operation_result":operation_result,
            "action_outcome":task.action_outcome,"institutional_outcome":task.institutional_outcome,"world_outcome":task.world_outcome})
        if decision is not None and task.action_outcome=="SUCCEEDED":
            for key in task.followups.get(decision["chosen_action"],()):
                self.clock.schedule(max(self.clock.minute+1,self.tasks[key].release),"release",{"task":key})
        for owner in self.capacities:self._dispatch_at(owner,self.clock.minute)

    def _dispatch_at(self, owner: str, minute: int) -> None:
        key = (owner, minute)
        if key not in self._dispatch_pending:
            self._dispatch_pending.add(key)
            self.clock.schedule(minute, "dispatch", {"owner": owner}, phase=DISPATCH)

    def _next_slot(self, task: Task) -> int|None:
        cap = self.capacities[task.owner]
        earliest = self.clock.minute
        for _ in range(370):
            duration=self._stage_duration(task)
            slot = cap.calendar.next_slot(self.clock, earliest, duration)
            day = self.clock.at(slot).date().isoformat()
            if cap.spent_by_day.get(day, 0) + duration > cap.daily_minutes:
                next_day = self.clock.at(slot).replace(hour=0, minute=0) + timedelta(days=1)
                earliest = self.clock.offset(next_day.isoformat())
                continue
            if task.requires_windows and (task.lifecycle=="LEGACY_COMPLETION" or task.phase=="EXECUTION_READY"):
                slots = [max(slot, start) for start, end in task.requires_windows
                         if max(slot, start)+duration <= end]
                if not slots:
                    return None
                if min(slots) != slot:
                    earliest = min(slots)
                    continue
            return slot
        return None

    def _priority(self, task: Task) -> dict:
        remaining = task.deadline-self.clock.minute
        duration=self._stage_duration(task)
        slack = remaining-duration
        urgency = 1.0 if slack <= 0 else duration / (duration+slack)
        if task.owner in self.used_personas:
            option = ActionOption(
                task.key, goal_impacts={"agenda": task.importance}, value_impacts=task.value_impacts,
                effort=min(1, duration/self.capacities[task.owner].daily_minutes),
                upside=task.importance, downside=.1, event_tags=task.tags,
            )
            score = self.game.personas.score(task.owner, option,
                self._planner_resources(task.owner),
                {"agenda": 1.0}, task.tags, soft_resource_constraints=True)
            persona_value = score.total / 100.0  # existing persona score units; no per-menu rescaling
            diagnosis = asdict(score)
        else:
            persona_value, diagnosis = task.importance, {"rule": "organizational importance"}
        return {"task": task.key, "persona": diagnosis, "slack_minutes": slack,
                "urgency": round(urgency, 3),
                "priority": round(self.scheduling.persona_weight*persona_value
                    + self.scheduling.urgency_weight*urgency
                    + self.scheduling.importance_weight*task.importance, 6)}

    def _dispatch(self, owner: str) -> None:
        if self._waiting_until.get(owner,-1)>self.clock.minute:return
        self._end_wait(owner)
        cap = self.capacities[owner]
        while len(cap.busy) < cap.slots:
            candidates, wakes = [], []
            for task in self.tasks.values():
                if task.owner != owner or task.status != "READY":
                    continue
                if task.policy_project:
                    project=self.policy_projects[task.policy_project]
                    if project.status!='ACTIVE':
                        if project.status in {'WITHDRAWN','CLOSED'}:
                            task.status='BLOCKED';task.action_outcome='BLOCKED'
                        continue
                requirements=[self._dependency_state(task,key) for key in task.dependencies]
                if "FAILED" in requirements:
                    task.status = "BLOCKED"
                    self._record("dependency_blocked", task=task,
                                 details={"dependencies": list(task.dependencies)})
                    continue
                if any(value!="SATISFIED" for value in requirements):
                    continue
                slot = self._next_slot(task)
                if slot == self.clock.minute:
                    candidates.append(task)
                elif slot is not None and (slot <= task.deadline or (task.committed_at is not None and task.deadline_policy!="HARD")):
                    wakes.append(slot)
            if not candidates:
                if wakes:
                    self._dispatch_at(owner, min(wakes))
                return
            evaluations = [self._priority(t) for t in candidates]
            winner = max(evaluations, key=lambda row: (row["priority"],
                         -self.tasks[row["task"]].deadline, row["task"]))
            task = self.tasks[winner["task"]]
            if self._choose_wait(owner,task):return
            if task.phase=="EXECUTION_READY" and not self._execution_gate(task,starting_execution=True):continue
            task.status="RUNNING"
            if task.started is None:task.started=self.clock.minute
            task.work_status="EXECUTING" if task.phase=="EXECUTION_READY" else "PREPARING"
            duration=self._stage_duration(task)
            if task.phase=="EXECUTION_READY":task.phase="EXECUTING";task.execution_started=self.clock.minute
            task.reservation_started=self.clock.minute;task.reserved_duration=duration
            cap.busy.add(task.key)
            day = self.clock.at().date().isoformat()
            task.reservation_day=day
            cap.spent_by_day[day] = cap.spent_by_day.get(day, 0)+duration
            if owner in self.used_personas:
                # Charge attention once; completion outcomes carry no duplicate duration debit.
                state = self.game.personas.runtime[owner].state
                state.energy = max(0, state.energy-self.scheduling.energy_cost_per_daily_budget*duration/cap.daily_minutes)
            task.revision+=1
            self.clock.schedule(self.clock.minute+duration, "complete", {"task": task.key,"revision":task.revision}, phase=COMPLETION)
            self._record("task_started", task=task, details={"agenda_evaluations": evaluations,
                         "reserved_minutes": duration, "non_preemptive": True})

    def _handle(self, event: ScheduledEvent) -> None:
        self.game.state.now_minute=self.clock.minute
        self._refresh_temporal()
        if event.kind == "organizational_response":
            for row in self.game.settle_organizational_responses():
                response = row["organization_response"]
                task_key = self._organization_tasks.get(response["request_id"])
                if task_key is not None:
                    task = self.tasks[task_key]
                    task.action_outcome = {"ACCEPTED": "SUCCEEDED", "PARTIAL": "PARTIAL",
                        "REJECTED": "FAILED"}.get(response["status"], "PENDING_RESPONSE")
                    update = row["operational_feedback"]["state_update"]
                    task.world_outcome = "CHANGED" if update["before"] != update["after"] else task.world_outcome
                    if task.action_outcome == "SUCCEEDED":
                        for key in task.followups.get(task.committed_action or row["submitted_action"], ()):
                            self.clock.schedule(max(self.clock.minute+1,self.tasks[key].release), "release", {"task":key})
                self._record("organizational_response", details=row)
            for owner in self.capacities:self._dispatch_at(owner,self.clock.minute)
            return
        if event.kind=="delayed_effect_boundary":
            self._record("delayed_effect_boundary",details=event.data)
            for owner in self.capacities:self._dispatch_at(owner,self.clock.minute)
            return
        if event.kind=="opportunity_boundary":
            self._record("opportunity_boundary",details=event.data)
            for owner in self.capacities:self._dispatch_at(owner,self.clock.minute)
            return
        if event.kind=="external_execution_start":
            task=self.tasks[event.data["task"]]
            if task.status=="EXECUTING_EXTERNAL" and task.revision==event.data["revision"]:self._start_external_execution(task)
            return
        if event.kind=="opportunity_claims":
            key=event.data["window"];self._claim_events.discard((key,self.clock.minute))
            results=self.opportunities.settle_batch(key,self.clock.minute,self.game.state)
            self._record("opportunity_claims_resolved",details={"window":key,"results":results})
            self._resume_claims(results)
            return
        if event.kind in self.event_handlers:
            details = self.event_handlers[event.kind](self, event)
            self._record(event.kind, details=details or {})
            return
        if event.kind == "dispatch":
            self._dispatch_pending.discard((event.data["owner"], self.clock.minute))
            self._dispatch(event.data["owner"])
            return
        if event.kind == "external_event":
            data = event.data
            updates = [self.game.personas.apply_event(a, WorldEvent(data["key"], "scheduled_information",
                       data["severity"], tuple(data["tags"]))) for a in data["affected"]]
            for actor in data["affected"]:self.notify_information(actor,data["key"])
            if data["effects"]:
                self.game.state.apply(PoliticalAction(data["key"], {"immediate": data["effects"]}))
            self._record("world_fact_occurred" if data["visibility"] == "HIDDEN" else "information_delivered",
                         details={**data, "pss_updates": updates})
            return
        task = self.tasks[event.data["task"]]
        if event.kind == "release":
            if task.status != "UNRELEASED":
                return
            task.status = "READY"
            if task.activation == "conditional":
                self.clock.schedule(max(self.clock.minute, task.deadline), "deadline",
                                    {"task": task.key}, phase=DEADLINE)
            self._record("task_released", task=task)
            self._dispatch_at(task.owner, self.clock.minute)
        elif event.kind == "deadline":
            if task.status in {"COMPLETED", "COMPLETED_LATE", "BLOCKED","EXPIRED","CANCELLED","FAILED"} or task.overdue:
                return
            task.overdue = True
            if task.deadline_policy=="HARD":
                self._fail_task(task,"EXPIRED","HARD_DEADLINE")
            elif task.status not in {"RUNNING","EXECUTING_EXTERNAL"} and task.committed_at is None:
                task.status = "MISSED"
                task.action_outcome="FAILED"
            update = None
            if task.owner in self.used_personas:
                update = self.game.personas.apply_event(task.owner, WorldEvent(
                    f"deadline:{task.key}", "missed_deadline",
                    self.scheduling.deadline_severity_base+self.scheduling.deadline_severity_importance*task.importance,
                    ("loss_of_control", "policy_failure"), surprise=.1))
            self._record("deadline_missed", task=task, details={"pss_update": update})
            for owner in self.capacities:
                self._dispatch_at(owner, self.clock.minute)
        elif event.kind == "complete":
            if task.status not in {"RUNNING","EXECUTING_EXTERNAL"} or event.data.get("revision",task.revision)!=task.revision:
                return
            self._release_attention(task)
            if task.lifecycle=="STAGED" and task.phase=="PREPARING":
                instance_key=f"living_task:{task.key}"
                self.game.nodes[instance_key]=replace(self.game.nodes[task.node],key=instance_key)
                plan=self.game.prepare_decision(instance_key)
                timing=task.action_timing.get(plan["chosen_key"])
                if timing is None:raise ValueError("Selected generated action needs explicit timing")
                self._commit_plans[task.key]=plan
                task.committed_action=plan["chosen_key"];task.committed_at=self.clock.minute
                task.execution_duration=timing["execution_minutes"];task.execution_attention=timing.get("attention_required",True)
                task.phase="COMMITTED";task.work_status="PREPARED";task.status="COMMITTING"
                self._record("task_committed",task=task,details={"chosen_action":task.committed_action,
                    "execution_minutes":task.execution_duration,"beliefs_at_commitment":self.game.information.payload(plan["beliefs"]),
                    "temporal_assessment":plan["temporal_assessment"],
                    "action_evaluations":{k:{"persona":asdict(v),"combined_choice_score":plan["combined_choice_scores"].get(k)} for k,v in plan["persona_scores"].items()},
                    "arcana_at_commitment":plan["arcana_trace"]})
                if task.action_outcome!="FAILED":
                    if task.window:self._request_claim(task)
                    else:self._queue_execution(task)
            elif task.window and task.key not in self.opportunities.windows[task.window].claims:
                task.work_status="COMPLETED";self._request_claim(task)
            else:self._execute_task(task)
            for owner in self.capacities:self._dispatch_at(owner,self.clock.minute)

    def run_until(self, timestamp: str) -> dict:
        if any(task.operation and task.operation not in self.operation_handlers for task in self.tasks.values()):
            raise ValueError("A task references an unconfigured world service")
        self._refresh_temporal()
        self.clock.advance(self.clock.offset(timestamp), self._handle, self._elapse)
        self._record("observation_horizon")
        policy = replace(self.game.reporting_policy, allow_no_personas=True)
        report = ScenarioReportCompiler(self.initial_pss, policy).compile(
            self.trace, self.game.event_observers)
        return quantize3({"schema_version": "living-political-world-1.0", "clock": self.clock.payload(),
                "tasks": {key: asdict(task) for key, task in self.tasks.items()},
                "configuration": self.configuration,
                "variable_provenance": self.variable_provenance,
                "environment": self.environment,
                "scheduling_rules": asdict(self.scheduling),
                "subsystems": {key: service.payload() for key, service in self.services.items()},
                "capacities": {key: {"daily_minutes": cap.daily_minutes, "slots": cap.slots,
                    "calendar": asdict(cap.calendar),
                    "busy": sorted(cap.busy), "spent_by_day": cap.spent_by_day}
                    for key, cap in self.capacities.items()},
                "trace": self.trace, "political_decisions": self.game.trace,
                "world_state": self.game.state.payload(), "persona_runtime": self.game.personas.payload(),
                "temporal_system": {"delayed_effects":self.delayed_effects.payload(),"opportunities":self.opportunities.payload(),
                    "timing_beliefs":self.timing_beliefs.payload(),"waiting_policies":self.waiting_policies,
                    "waiting_state":{"until":dict(self._waiting_until),"since":dict(self._waiting_since),"settled_wait_minutes":dict(self._wait_spent)},
                    "legacy_personal_tasks":[t.key for t in self.tasks.values() if t.node and t.lifecycle=="LEGACY_COMPLETION"],
                    "unscheduled_legacy_effects":[r for r in self.game.state.pending_effects if r.get("status","UNSCHEDULED")=="UNSCHEDULED"]},
                "fired_rules": sorted(self.fired_rules), "scenario_report": report})

    @staticmethod
    def save(payload: dict, output: Path) -> None:
        output.mkdir(parents=True, exist_ok=True)
        (output/"full_trace.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        used=payload['scenario_report']['used_persona_cards']
        (output/'cards_used.json').write_text(json.dumps({'actors':{
            a:payload['persona_runtime']['actors'][a]['card'] for a in used}},ensure_ascii=False,indent=2))
        charts = payload["scenario_report"]["charts"]
        environment = payload.get("environment", {})
        environment_text = (f'<p>公共环境：{escape(environment.get("environment_id", "Python API"))}；'
            f'历史快照截止：{escape(environment.get("historical_cutoff", "未指定"))}。'
            '时间与容量系数为模型假设；本报告中的测试输入不代表现实预测。</p>')
        subsystem_details = "".join(f'<details><summary>{escape(name)} · 子系统运行记录</summary>'
            f'<pre>{escape(json.dumps(data, ensure_ascii=False, indent=2))}</pre></details>'
            for name, data in payload.get("subsystems", {}).items())
        for key, filename in (("pss_pressure_svg", "pss_pressure.svg"), ("polling_svg", "polling.svg")):
            (output/filename).write_text(charts[key], encoding="utf-8")
        for actor in payload['scenario_report']['used_persona_cards']:
            points=[p for p in payload['scenario_report']['pss_pressure_series'] if p['actor']==actor]
            (output/f'pss_{actor}.svg').write_text(ScenarioReportCompiler._line_chart_svg(points,
                series_field='actor',title=actor+' PSS',y_max=1.,y_label='Pressure 0–1'))
        feedback=payload.get('subsystems',{}).get('poll_feedback')
        policy_section=''
        if feedback:
            reviews=[r for r in feedback['history'] if 'action' in r]
            review_rows=''.join('<tr>'+''.join('<td>'+escape(str(v))+'</td>' for v in
                (r['at'],feedback['projects'][r['project']]['owner'],r['project'],r['action'],r['status']))+'</tr>' for r in reviews)
            released=[{'step':r['elapsed_minutes'],'actor':r['details']['release']['subject']+' / '+r['details']['release']['channel']+' / '+r['details']['release']['region'],
                'value':r['details']['release']['value_percent']} for r in payload['trace'] if r['kind']=='poll_release' and 'release' in r['details']]
            released_svg=ScenarioReportCompiler._line_chart_svg(released,series_field='actor',
                title='已发布并送达的民调消息（模型假设或来源标注）',y_max=100.,y_label='Published %',x_label='距模拟起点的分钟')
            (output/'published_poll.svg').write_text(released_svg)
            policy_section=('<h2>民调送达与政策复审</h2><p>消息不等于潜在支持；人物权重与公共反应系数为明确标注的模型假设。'
                '复审使用原Persona引擎，并占用注意力。工作完成不等于法案生效。</p>'+released_svg+
                '<table><tr><th>时间</th><th>人物</th><th>项目</th><th>决策</th><th>当时状态</th></tr>'+review_rows+'</table>')
            if not released:policy_section+='<p>尚无已发布消息；不能用潜在支持替代人物已知的民调。</p>'
        rows = "".join(f'<tr><td>{escape(row["calendar_date"])}</td><td>{escape(row["kind"])}</td>'
                       f'<td>{escape(row["task"] or "—")}</td><td>{escape((row["decision"] or {}).get("chosen_action", "—"))}</td></tr>'
                       for row in payload["trace"])
        decisions = "".join(f'<details><summary>{escape(row["decision_maker"])} · {escape(row["chosen_action"])}</summary>'
                            f'<pre>{escape(json.dumps(row, ensure_ascii=False, indent=2))}</pre></details>'
                            for row in payload["political_decisions"])
        document = ('<!doctype html><html lang="zh"><meta charset="utf-8"><title>Living Political World</title>'
                    '<style>body{max-width:1100px;margin:40px auto;padding:0 20px;font:15px/1.6 system-ui;background:#f7f4ef;color:#272522}'
                    'td,th{padding:7px;border-bottom:1px solid #ccc;text-align:left}table{width:100%;border-collapse:collapse}svg{max-width:100%;height:auto}pre{white-space:pre-wrap;overflow-wrap:anywhere}</style>'
                    '<h1>Living Political World · 持续政治世界</h1><p>时间、容量、截止期限与程序队列的机制验证。所有情景数值均为合成假设。</p>'
                    f'<p>运行到：{escape(payload["clock"]["timestamp"])}</p>'
                    + environment_text +
                    policy_section+'<h2>人物压力</h2>'+charts["pss_pressure_svg"]+'<h2>民调观察</h2>'+charts["polling_svg"]+
                    '<h2>时间线</h2><table><tr><th>时间</th><th>事件</th><th>任务</th><th>政治选择</th></tr>'+rows+'</table>'
                    '<h2>逐节点人物评价与决定</h2>'+decisions+
                    '<h2>公共环境反馈链</h2>'+subsystem_details+
                    render_arcana_embed(payload["scenario_report"])+ '</html>')
        (output/"report.html").write_text(document, encoding="utf-8")
