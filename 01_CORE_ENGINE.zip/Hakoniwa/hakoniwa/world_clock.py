"""Deterministic simulated time; no wall-clock waiting or political judgement."""
from __future__ import annotations

import heapq
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Callable
from zoneinfo import ZoneInfo


DELIVERY, COMPLETION, DEADLINE, DISPATCH = 10, 20, 30, 40
CLAIM_RESOLUTION, EFFECT = 22, 25


def aware_datetime(value: str) -> datetime:
    result = datetime.fromisoformat(value)
    if result.tzinfo is None or result.utcoffset() is None:
        raise ValueError("Clock timestamps require an explicit UTC offset")
    if result.second or result.microsecond:
        raise ValueError("WorldClock uses whole-minute timestamps")
    return result.astimezone(timezone.utc)


@dataclass(order=True, frozen=True)
class ScheduledEvent:
    minute: int
    phase: int
    sequence: int
    event_id: str = field(compare=False)
    kind: str = field(compare=False)
    data: dict[str, Any] = field(compare=False, default_factory=dict)


class WorldClock:
    def __init__(self, start: str, timezone_name: str = "Europe/Berlin"):
        self.origin = aware_datetime(start)
        self.zone = ZoneInfo(timezone_name)
        self.minute = 0
        self._sequence = 0
        self._queue: list[ScheduledEvent] = []
        self._ids: set[str] = set()
        self._cancelled: set[str] = set()
        self._active_phase: int | None = None

    def at(self, minute: int | None = None) -> datetime:
        return (self.origin + timedelta(minutes=self.minute if minute is None else minute)).astimezone(self.zone)

    def offset(self, timestamp: str) -> int:
        return int((aware_datetime(timestamp) - self.origin).total_seconds() // 60)

    def schedule(self, minute: int, kind: str, data: dict | None = None,
                 *, phase: int = DELIVERY, event_id: str | None = None) -> str:
        if not isinstance(minute, int) or minute < self.minute:
            raise ValueError("Cannot schedule in the past or at a fractional minute")
        if minute == self.minute and self._active_phase is not None and phase < self._active_phase:
            raise ValueError("Cannot insert an earlier phase into the current minute; use the next minute")
        identity = event_id or f"clock:{self._sequence}"
        if identity in self._ids:
            raise ValueError(f"Duplicate event id: {identity}")
        self._ids.add(identity)
        heapq.heappush(self._queue, ScheduledEvent(minute, phase, self._sequence,
                                                 identity, kind, dict(data or {})))
        self._sequence += 1
        return identity

    def cancel(self, event_id: str) -> None:
        if event_id not in self._ids:
            raise KeyError(event_id)
        self._cancelled.add(event_id)

    def advance(self, until: int, handler: Callable[[ScheduledEvent], None],
                elapse: Callable[[int], None] | None = None, max_events: int = 100000) -> int:
        if not isinstance(until, int) or until < self.minute:
            raise ValueError("Time must advance monotonically in whole minutes")
        processed = 0
        while self._queue and self._queue[0].minute <= until:
            if processed >= max_events:
                raise RuntimeError("Event budget exceeded; inspect a possible same-minute scheduling loop")
            event = heapq.heappop(self._queue)
            if event.event_id in self._cancelled:
                continue
            if elapse is not None and event.minute > self.minute:
                elapse(event.minute - self.minute)
            self.minute = event.minute
            self._active_phase = event.phase
            try:
                handler(event)
            finally:
                self._active_phase = None
            processed += 1
        if elapse is not None and until > self.minute:
            elapse(until - self.minute)
        self.minute = until
        return processed

    def payload(self) -> dict:
        return {"timestamp": self.at().isoformat(), "elapsed_minutes": self.minute,
                "timezone": str(self.zone), "pending_events": [
                    {"id": row.event_id, "at": self.at(row.minute).isoformat(),
                     "phase": row.phase, "kind": row.kind, "data": row.data}
                    for row in sorted(self._queue) if row.event_id not in self._cancelled
                ]}


@dataclass(frozen=True)
class WorkCalendar:
    """Configured working windows, not a claim about any real parliamentary calendar."""
    weekdays: tuple[int, ...] = (0, 1, 2, 3, 4)
    open_hour: int = 8
    close_hour: int = 18
    closed_dates: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.weekdays or any(day not in range(7) for day in self.weekdays):
            raise ValueError("Calendar needs valid weekdays 0..6")
        if not 0 <= self.open_hour < self.close_hour <= 24:
            raise ValueError("Invalid daily working window")

    def next_slot(self, clock: WorldClock, earliest: int, duration: int) -> int:
        if duration <= 0 or duration > (self.close_hour-self.open_hour)*60:
            raise ValueError("Task duration must fit one work window; split longer work into stages")
        candidate = clock.at(earliest)
        for _ in range(370):
            day = candidate.replace(hour=0, minute=0, second=0, microsecond=0)
            opening = day + timedelta(hours=self.open_hour)
            closing = day + timedelta(hours=self.close_hour)
            start = max(candidate, opening)
            if (day.weekday() in self.weekdays and day.date().isoformat() not in self.closed_dates
                    and start.astimezone(timezone.utc) + timedelta(minutes=duration) <= closing.astimezone(timezone.utc)):
                return int((start.astimezone(timezone.utc)-clock.origin).total_seconds()//60)
            candidate = day + timedelta(days=1)
        raise ValueError("No work window in the next year")
