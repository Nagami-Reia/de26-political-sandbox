"""Legacy import adapter. Canonical implementation: plugins.polling.tracker."""
from .plugins.polling.tracker import PollSeriesSpec, RealtimePollingTracker, round_grid
__all__=["PollSeriesSpec","RealtimePollingTracker","round_grid"]
