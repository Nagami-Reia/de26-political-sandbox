"""Delivered timing reports, separate from the objective opportunity registry."""
from dataclasses import dataclass, asdict
import math


@dataclass(frozen=True)
class TimingReport:
    window: str
    source: str
    message_id: str
    observed_at: int
    information_gain: float
    confidence: float
    available_probability: float
    remaining_minutes: int|None=None

    def __post_init__(self):
        if not self.source or not self.message_id or type(self.observed_at) is not int:raise ValueError("Timing reports require a source, message ID and timestamp")
        for v in (self.information_gain,self.confidence,self.available_probability):
            if not math.isfinite(v) or not 0<=v<=1:raise ValueError("Invalid timing belief probability")
        if self.remaining_minutes is not None and (type(self.remaining_minutes) is not int or self.remaining_minutes<0):raise ValueError("Invalid reported remaining time")


class TimingBeliefs:
    def __init__(self):self.reports={};self.history=[]

    def deliver(self,actor,report,minute):
        if report.observed_at>minute:raise ValueError("Cannot receive a report from the future")
        key=(actor,report.window,report.source)
        prior=self.reports.get(key)
        if prior and report.observed_at<prior.observed_at:raise ValueError("Stale report must not replace a newer report from the same channel")
        self.reports[key]=report
        self.history.append({"actor":actor,"received_at":minute,**asdict(report)})

    def estimate(self,actor,window,minute,source_trust):
        rows=[r for (a,w,_),r in self.reports.items() if a==actor and w==window]
        weighted=[(r,r.confidence*source_trust.get(r.source,.75)) for r in rows]
        total=sum(w for _,w in weighted)
        if total<=0:return None
        avg=lambda attr:sum(getattr(r,attr)*w for r,w in weighted)/total
        timed=[(r,w) for r,w in weighted if r.remaining_minutes is not None]
        time_weight=sum(w for _,w in timed)
        remaining=sum(max(0,r.remaining_minutes-(minute-r.observed_at))*w for r,w in timed)/time_weight if time_weight else None
        return {"information_gain":avg("information_gain"),"available_probability":avg("available_probability"),
            "remaining_minutes":remaining,"confidence":min(1,total/len(rows)),
            "sources":[r.message_id for r in rows],"status":"ACTOR_BELIEF_NOT_OBJECTIVE_WINDOW"}

    def payload(self):return {"delivered_reports":list(self.history)}
