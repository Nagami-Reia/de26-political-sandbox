"""Objective, condition-derived opportunities. Actor beliefs live elsewhere."""
from dataclasses import dataclass, field, asdict
import math
from .temporal_conditions import conditions_hold, Condition


@dataclass
class OpportunityWindow:
    key: str
    opens_when: tuple[dict,...]=()
    closes_when: tuple[dict,...]=()
    required_resources: dict[str,float]=field(default_factory=dict)
    opens_at: int=0
    closes_at: int|None=None
    capacity: int|None=None
    allocation_authority: str|None=None
    preserve_expiry_after_commit: bool=False
    decay_per_hour: float=0.0
    running_policy: str="FINISH_WITHOUT_PAYOFF"
    claims: dict[str,str]=field(default_factory=dict)
    resolved_claims: dict[str,str]=field(default_factory=dict)

    def __post_init__(self):
        if type(self.opens_at) is not int or (self.closes_at is not None and (type(self.closes_at) is not int or self.closes_at<self.opens_at)):
            raise ValueError("Invalid objective opportunity times")
        if self.capacity is not None and (type(self.capacity) is not int or self.capacity<1):raise ValueError("Invalid opportunity capacity")
        if not math.isfinite(self.decay_per_hour) or self.decay_per_hour<0:raise ValueError("Invalid window decay")
        if self.running_policy not in {"FINISH_WITHOUT_PAYOFF","INTERRUPT"}:raise ValueError("Unknown running-window policy")
        for c in (*self.opens_when,*self.closes_when):Condition(**c)
        if any(not math.isfinite(v) for v in self.required_resources.values()):raise ValueError("Invalid resource threshold")

    def check(self,state,minute,claim=None):
        if minute<self.opens_at:return "NOT_YET_OPEN"
        if self.closes_at is not None and minute>self.closes_at:
            if not (self.preserve_expiry_after_commit and claim in self.claims):return "EXPIRED"
        opening=conditions_hold(self.opens_when,state)
        if opening is not True:return "UNKNOWN" if opening is None else "NOT_READY"
        if self.closes_when:
            closure=conditions_hold(self.closes_when,state)
            if closure is True:return "CLOSED_CONDITION"
            if closure is None:return "UNKNOWN"
        for variable,minimum in self.required_resources.items():
            if variable not in state.variables:return "UNKNOWN"
            if state.variables[variable].value<minimum:return "RESOURCE_INSUFFICIENT"
        if self.capacity is not None and len(self.claims)>=self.capacity and claim not in self.claims:return "CAPACITY_COMMITTED"
        return "OPEN"

    def payoff(self,minute):return math.exp(-self.decay_per_hour*max(0,minute-self.opens_at)/60)

    def diagnostic(self,state,minute,claim=None):
        return {"status":self.check(state,minute,claim),"minute":minute,"opens_at":self.opens_at,"closes_at":self.closes_at,
            "opening_conditions":[{**c,"satisfied":Condition(**c).evaluate(state)} for c in self.opens_when],
            "closing_conditions":[{**c,"satisfied":Condition(**c).evaluate(state)} for c in self.closes_when],
            "resources":{k:{"required":v,"actual":state.variables[k].value if k in state.variables else None} for k,v in self.required_resources.items()},
            "capacity":self.capacity,"accepted_claims":sorted(self.claims),"claim":claim,
            "evidence_scope":"OBJECTIVE_AUDIT_NOT_AUTOMATICALLY_DELIVERED_TO_ACTOR"}


class OpportunityRegistry:
    def __init__(self,windows=()):
        self.windows={w.key:w for w in windows}
        if len(self.windows)!=len(windows):raise ValueError("Duplicate opportunity window")
        self.pending={};self.history=[]

    def request(self,key,claim,actor,minute):
        self.pending.setdefault((key,minute),{})[claim]=actor

    def settle_batch(self,key,minute,state):
        window=self.windows[key];batch=self.pending.pop((key,minute),{})
        status=window.check(state,minute)
        results={}
        if status!="OPEN":results={claim:status for claim in batch}
        elif window.capacity is not None and len(batch)>window.capacity-len(window.claims):
            # Same-minute contenders do not win by insertion order or actor name.
            results={claim:"CONTESTED" for claim in batch}
        else:
            window.claims.update(batch);results={claim:"ACCEPTED" for claim in batch}
        window.resolved_claims.update(results)
        self.history.append({"window":key,"minute":minute,"claims":dict(batch),"results":results})
        return results

    def resolve_contest(self,key,winners,state,minute):
        window=self.windows[key]
        if len(set(winners))!=len(winners):raise ValueError("Duplicate winner")
        if window.capacity is not None and len(winners)>window.capacity-len(window.claims):raise ValueError("Too many claims")
        if window.check(state,minute)!="OPEN":raise ValueError("Window no longer executable")
        contested={c for c,s in window.resolved_claims.items() if s=="CONTESTED"}
        if not set(winners).issubset(contested):raise ValueError("Winner must be a contested claim")
        for claim in contested:
            status="ACCEPTED" if claim in winners else "REJECTED"
            window.resolved_claims[claim]=status
            if status=="ACCEPTED":window.claims[claim]="resolved_by_external_actor"
        self.history.append({"window":key,"minute":minute,"resolution":"explicit_owner_resolution","winners":list(winners)})

    def payload(self):return {"windows":{k:asdict(v) for k,v in self.windows.items()},"history":list(self.history),
        "pending_claim_batches":[{"window":key,"minute":minute,"claims":dict(batch)} for (key,minute),batch in self.pending.items()]}
