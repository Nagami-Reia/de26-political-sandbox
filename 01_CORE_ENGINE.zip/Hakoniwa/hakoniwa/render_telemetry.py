"""Compatibility adapter for the polling plugin's deterministic chart renderer."""
from .plugins.polling.reporting import TEMPLATE, render_payload, main
if __name__ == "__main__":main()
