"""Canonical political-simulation 3.0 pipeline.

The default mode is shadow-only: v3 diagnostics are recorded while the exact v2
persona choice and world transition remain authoritative.  Feature flags enable
each causal channel separately so a changed result is attributable and testable.
"""
from __future__ import annotations
from .persona_repository import load_rationality_payload

import json
import math
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Callable, Mapping, Sequence

from .action_perception import ActionPerceptionFilter
from .action_repertoire import ActionRepertoireFilter
from .plugins.arcana import ArcanaService
from .plugins.arcana.hakoniwa import ArcanaDecisionAdapter
from .checks.base import Resolution
from .checks.context import CheckContext
from .checks.engine import CheckEngine, InstitutionalResolver
from .decision_space import (
    DecisionEvent,
    DecisionSpaceGenerator,
    GeneratedDecisionSpace,
    OutcomeResolver,
)
from .free_agent_game import WorldAction
from .information_filter import InformationFilter
from .institutional_logic import InstitutionalLogic
from .institutional_matrix import InstitutionalMatrix, InstitutionalRule
from .persona_v2 import ActionOutcome, FreeAgentDecisionEngine
from .party_interest import PartyInterestEngine
from .organizational_response import OrganizationalResponseEngine
from .political_agency import AgencyHorizon, AgencyRegistry
from .political_state import PoliticalAction, PoliticalState, PressureRule
from .rationality_evaluation import ActorRationalityProfile, RationalityEvaluator
from .scenario_reporting import ScenarioReportCompiler, ScenarioReportingPolicy
from .system_feedback import SystemFeedbackAssessor, SystemFeedbackContext, SystemFeedbackLedger


@dataclass(frozen=True)
class V3FeatureFlags:
    institutional_logic_affects_choice: bool = False
    agency_horizon_affects_choice: bool = False
    system_feedback_mutates_world: bool = False
    strategic_response_uses_perceived_menu: bool = False
    party_interest_affects_choice: bool = False

    @property
    def shadow_mode(self) -> bool:
        return not (
            self.institutional_logic_affects_choice
            or self.agency_horizon_affects_choice
            or self.system_feedback_mutates_world
            or self.strategic_response_uses_perceived_menu
            or self.party_interest_affects_choice
        )

    @property
    def choice_active(self) -> bool:
        return (
            self.institutional_logic_affects_choice
            or self.agency_horizon_affects_choice
            or self.party_interest_affects_choice
        )


@dataclass(frozen=True)
class SimulationNodeV3:
    key: str
    owner: str
    actions: tuple[WorldAction, ...]
    current_goals: Mapping[str, float] = field(default_factory=dict)
    scene_tags: tuple[str, ...] = ()
    strategic_scores: Mapping[str, float] = field(default_factory=dict)
    decision_event: DecisionEvent | None = None
    conflict_actor: str | None = None
    system_feedback_context: SystemFeedbackContext | None = None

    def __post_init__(self):
        value = self.system_feedback_context
        if isinstance(value, Mapping):
            value = SystemFeedbackContext(**value)
            object.__setattr__(self, "system_feedback_context", value)
        if value is not None and not isinstance(value, SystemFeedbackContext):
            raise ValueError("system_feedback_context must be an explicit event context")


@dataclass(frozen=True)
class LayeredConfiguration:
    matrix: InstitutionalMatrix
    logic: InstitutionalLogic
    agency: AgencyRegistry
    rationality_profiles: Mapping[str, ActorRationalityProfile]
    flags: V3FeatureFlags = V3FeatureFlags()

    @classmethod
    def from_environment_json(
        cls,
        path: str | Path,
        rationality_path: str | Path | None = None,
    ) -> "LayeredConfiguration":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        if raw.get("schema_version") != "political-simulation-3.0":
            raise ValueError("Expected political-simulation-3.0 environment")
        matrix_raw = raw["institutional_matrix"]
        matrix = InstitutionalMatrix(
            matrix_id=matrix_raw["matrix_id"],
            actor_offices={key: tuple(value) for key, value in matrix_raw.get("actor_offices", {}).items()},
            office_permissions={key: tuple(value) for key, value in matrix_raw.get("office_permissions", {}).items()},
            rules=tuple(
                InstitutionalRule(
                    key=item["key"],
                    kind=item["kind"],
                    strength=float(item["strength"]),
                    enforcement=float(item["enforcement"]),
                    action_permissions=tuple(item.get("action_permissions", ())),
                    source_status=item.get("source_status", "MODEL_ASSUMPTION"),
                )
                for item in matrix_raw.get("rules", ())
            ),
        )
        agency = AgencyRegistry({
            actor: AgencyHorizon(**values)
            for actor, values in raw.get("agency_horizons", {}).items()
        })
        profile_payload = (
            load_rationality_payload(rationality_path)
            if rationality_path is not None
            else {"actors": {}}
        )
        if profile_payload.get("schema_version") not in {None, "actor-rationality-profiles-3.0"}:
            raise ValueError("Expected actor-rationality-profiles-3.0")
        profiles = {
            actor: ActorRationalityProfile(**values)
            for actor, values in profile_payload.get("actors", {}).items()
        }
        return cls(
            matrix=matrix,
            logic=InstitutionalLogic.from_mapping(raw["institutional_logic"]),
            agency=agency,
            rationality_profiles=profiles,
            flags=V3FeatureFlags(**raw.get("feature_flags", {})),
        )


class LayeredSimulationOrchestrator:
    """Single entry point for new scenarios and v3 trace generation."""

    def __init__(
        self,
        state: PoliticalState,
        nodes: Mapping[str, SimulationNodeV3],
        personas: FreeAgentDecisionEngine,
        information: InformationFilter,
        resource_bindings: Mapping[str, Mapping[str, str]],
        configuration: LayeredConfiguration,
        pressure_rules: Sequence[PressureRule] = (),
        event_observers: Sequence[object] = (),
        decision_generator: DecisionSpaceGenerator | None = None,
        outcome_resolver: OutcomeResolver | None = None,
        reporting_policy: ScenarioReportingPolicy = ScenarioReportingPolicy(),
        objective_check_engine: CheckEngine | None = None,
        check_context_provider: Callable[[PoliticalState], CheckContext] | None = None,
        party_interests: PartyInterestEngine | None = None,
        actor_party_map: Mapping[str, str] | None = None,
        party_overlay_weights: Mapping[str, float] | None = None,
        arcana: ArcanaService | None = None,
        organizations: OrganizationalResponseEngine | None = None,
        system_feedback_ledger: SystemFeedbackLedger | None = None,
    ) -> None:
        self.state = state
        self.nodes = dict(nodes)
        self.personas = personas
        self.information = information
        self.resource_bindings = {actor: dict(values) for actor, values in resource_bindings.items()}
        self.matrix = configuration.matrix
        self.logic = configuration.logic
        self.agency = configuration.agency
        self.rationality_profiles = dict(configuration.rationality_profiles)
        self.flags = configuration.flags
        self.pressure_rules = tuple(pressure_rules)
        self.event_observers = tuple(event_observers)
        self.repertoire_filter = ActionRepertoireFilter(self.matrix)
        self.perception_filter = ActionPerceptionFilter()
        self.rationality = RationalityEvaluator()
        self.system_assessor = SystemFeedbackAssessor()
        self.system_feedback_ledger = system_feedback_ledger if system_feedback_ledger is not None else SystemFeedbackLedger()
        self.decision_generator = decision_generator
        self.outcome_resolver = outcome_resolver
        self.reporting_policy = reporting_policy
        self.objective_check_engine = objective_check_engine
        self.check_context_provider = check_context_provider
        self.institutional_resolver = InstitutionalResolver()
        self.party_interests = party_interests
        self.actor_party_map = dict(actor_party_map or {})
        self.party_overlay_weights = dict(party_overlay_weights or {})
        self.arcana = arcana
        self.organizations = organizations
        self._organization_bindings: dict[str, dict] = {}
        self.organization_schedule_hook = None
        self.action_context_adapters = []
        self.arcana_adapter = ArcanaDecisionAdapter()
        self._initial_pss = {
            actor: asdict(runtime.state)
            for actor, runtime in self.personas.runtime.items()
        }
        self.trace: list[dict] = []

    def _commit_system_feedback(self, feedback, context, actor, *, enabled):
        logic, agency, record = self.system_feedback_ledger.apply(
            feedback, context, self.logic, self.agency.get(actor), actor=actor,
            enabled=enabled, now_minute=self.state.now_minute)
        if record["applied"]:
            self.logic = logic
            self.agency.set(actor, agency)
        return record

    def settle_organizational_responses(self) -> list[dict]:
        """Settle due recipient responses on the objective simulation clock."""
        if self.organizations is None:
            return []
        if self.state.now_minute is None:
            raise ValueError("Organizational responses require a bound world clock")
        rows = []
        for response in self.organizations.advance_to(self.state.now_minute):
            binding = self._organization_bindings[response.request_id]
            choice, evaluation = binding["choice"], binding["evaluation"]
            effects = {key: value * response.realization_fraction
                       for key, value in binding["effects"].items()}
            update = self.state.apply(PoliticalAction(
                f"organization_response:{response.request_id}", {"immediate": effects}))
            final = response.status in {"ACCEPTED", "PARTIAL", "REJECTED"}
            success = 1.0 if response.status == "ACCEPTED" else response.realization_fraction
            pss = []
            feedback = None
            feedback_application = None
            if final:
                pss.append(self.personas.apply_outcome(response.proposer, ActionOutcome(
                    choice.key, success, workload=0.0,
                    expected_success=evaluation.political_success_expectation,
                    evidence_quality=1.0, outcome_scope=.650,
                    tags=("organizational_response", response.status),
                    control_restoration=choice.restores_control * response.realization_fraction * .080,
                )))
                feedback = self.system_assessor.assess(choice, evaluation, self.logic, success)
                feedback_application = self._commit_system_feedback(feedback,
                    binding.get("system_feedback_context"), response.proposer,
                    enabled=self.flags.system_feedback_mutates_world)
            for observer in self.event_observers:
                observer.record(self.state, event_id=f"organization_response:{response.request_id}",
                    actor=response.proposer, action=choice.key, event_kind="organizational_response",
                    resource_changes=update)
            row = {"node": f"organization_response:{response.request_id}",
                   "submitted_action": choice.key,
                   "event_kind": "organizational_response", "actors_used": [response.proposer],
                   "elapsed_minutes": self.state.now_minute, "organization_response": response.payload(),
                   "operational_feedback": {"state_update": update, "pss_updates": pss},
                   "system_feedback": feedback.payload() if feedback else None,
                   "system_feedback_application": feedback_application,
                   "system_feedback_applied": bool(feedback_application and feedback_application["applied"]),
                   "all_actor_pss_after": {key: asdict(runtime.state) for key, runtime in self.personas.runtime.items()}}
            self.trace.append(row); rows.append(row)
        return rows

    def _materialize_actions(
        self,
        node: SimulationNodeV3,
        beliefs,
        resources: Mapping[str, float],
    ) -> tuple[tuple[WorldAction, ...], GeneratedDecisionSpace | None]:
        """Return static actions or grow a menu from the current actor state."""
        if node.decision_event is None:
            actions=node.actions
            for adapter in self.action_context_adapters:
                actions=tuple(adapter(node,beliefs,resources,actions))
            return actions, None
        if self.decision_generator is None:
            raise RuntimeError(
                f"Node {node.key} declares decision_event but no DecisionSpaceGenerator was supplied"
            )
        generated = self.decision_generator.generate(
            node.owner,
            node.decision_event,
            beliefs,
            self.personas.cards[node.owner],
            self.personas.runtime[node.owner],
            resources,
            node.current_goals,
        )
        return generated.world_actions, generated

    def _perceived_resources(
        self,
        actor: str,
        belief_state,
        state: PoliticalState | None = None,
    ) -> dict[str, float]:
        source_state = state or self.state
        resources = dict(self.personas.cards[actor].initial_resources)
        for resource, binding in self.resource_bindings.get(actor, {}).items():
            kind, key = binding.split(":", 1)
            if kind == "variable":
                belief = belief_state.beliefs.get(key)
                if belief is not None:
                    resources[resource] = max(0.0, min(1.0, belief.estimate / 100.0))
                # No report: retain the card's explicit prior, never read hidden truth.
            elif kind == "capital":
                if self.information.delivery_only:
                    belief = belief_state.beliefs.get(f"capital:{key}")
                    if belief is not None:
                        resources[resource] = max(0.0, min(1.0, belief.estimate / 100.0))
                else:
                    resources[resource] = max(0.0, min(1.0, source_state.capital.get(key, 0.0) / 100.0))
            else:
                raise ValueError(f"Unknown resource binding kind: {kind}")
        return resources

    def _active_v3_choice(
        self,
        node: SimulationNodeV3,
        actions,
        resources,
        perceived,
    ) -> tuple[str, dict, dict, dict, dict]:
        serious = [
            perceived[action.key].for_scoring(action) for action in actions
            if perceived[action.key].perceived_status == "CONSIDERED"
        ]
        if not serious:
            serious = [
                perceived[action.key].for_scoring(action) for action in actions
                if perceived[action.key].role_status == "AVAILABLE"
                and perceived[action.key].execution_feasibility > 0.0
            ]
        if not serious:
            raise RuntimeError(f"No role-available action at {node.key}")
        persona_scores = {
            action.key: self.personas.score(
                node.owner,
                action,
                resources,
                node.current_goals,
                node.scene_tags,
                soft_resource_constraints=True,
            )
            for action in serious
        }
        profile = self.rationality_profiles.get(node.owner, ActorRationalityProfile())
        rationality = {
            action.key: self.rationality.evaluate(
                action,
                persona_scores[action.key],
                profile,
                perceived_feasibility=perceived[action.key].perceived_feasibility,
                action_assessment=perceived[action.key],
                strategic_score=node.strategic_scores.get(action.key, 0.500),
            )
            for action in serious
        }
        party_rows = self._party_evaluations(node.owner, serious)
        base_scores = {key: row.choice_score for key, row in rationality.items()}
        if self.flags.party_interest_affects_choice and party_rows:
            combined = self.party_interests.overlay(
                base_scores,
                party_rows,
                self.party_overlay_weights.get(node.owner, 0.250),
            )
        else:
            combined = base_scores
        order = {action.key: index for index, action in enumerate(actions)}
        chosen = max(combined, key=lambda key: (combined[key], -order[key]))
        return chosen, persona_scores, rationality, party_rows, combined

    def _party_evaluations(self, actor: str, actions) -> dict:
        if self.party_interests is None or actor not in self.actor_party_map:
            return {}
        party_id = self.actor_party_map[actor]
        return {
            action.key: self.party_interests.evaluate(party_id, action)
            for action in actions
        }

    def _forecast_response_path(
        self,
        opening: WorldAction,
        state: PoliticalState,
        max_depth: int = 2,
    ) -> list[dict]:
        """Forecast future actors through their own perceived menus, without commits.

        The path is diagnostic in phases 1-2.  A later calibrated response-payoff
        adapter may convert it into the current actor's strategic continuation
        value; no payoff is invented here.
        """
        if not self.flags.strategic_response_uses_perceived_menu or not opening.world.next_node:
            return []
        if opening.choice.execution_estimate <= 0:
            return []
        rng_state = self.information.rng.getstate()
        forecast_state = state.clone()
        opening_executable = True
        if opening.intent is not None:
            if self.objective_check_engine is None or self.check_context_provider is None:
                raise RuntimeError(
                    f"Action {opening.world.key} carries an institutional intent but the "
                    "objective check environment is not configured"
                )
            opening_bundle = self.objective_check_engine.check(
                self.check_context_provider(forecast_state), opening.intent
            )
            opening_executable = opening_bundle.resolution is Resolution.EXECUTABLE
        if opening_executable:
            forecast_state.apply(replace(opening.world, effect_status="DETERMINISTIC_ASSUMPTION"), self.pressure_rules)
        else:
            return []
        key = opening.world.next_node
        path: list[dict] = []
        try:
            for _ in range(max_depth):
                node = self.nodes[key]
                beliefs = self.information.observe(node.owner, forecast_state, commit=False)
                resources = self._perceived_resources(node.owner, beliefs, forecast_state)
                node_actions, _ = self._materialize_actions(node, beliefs, resources)
                mean_confidence = (
                    sum(item.confidence for item in beliefs.beliefs.values()) / len(beliefs.beliefs)
                    if beliefs.beliefs else 0.500
                )
                legal_pairs = [item for item in node_actions if forecast_state.legal(item.world)]
                options = tuple(
                    replace(
                        item.choice,
                        legal=item.choice.legal and forecast_state.legal(item.world),
                        information_confidence=min(item.choice.information_confidence, mean_confidence),
                    )
                    for item in legal_pairs
                )
                repertoire = self.repertoire_filter.apply(node.owner, options, resources)
                perceived = self.perception_filter.apply(
                    options,
                    repertoire,
                    self.logic,
                    self.agency.get(node.owner),
                    resources,
                    mean_confidence,
                )
                serious = [perceived[item.key].for_scoring(item) for item in options
                           if perceived[item.key].perceived_status == "CONSIDERED"]
                if not serious:
                    serious = [perceived[item.key].for_scoring(item) for item in options
                               if perceived[item.key].role_status == "AVAILABLE"
                               and perceived[item.key].execution_feasibility > 0.0]
                if not serious:
                    path.append({"node": key, "owner": node.owner, "status": "NO_PERCEIVED_ACTION"})
                    break
                profile = self.rationality_profiles.get(node.owner, ActorRationalityProfile())
                persona_scores = {
                    item.key: self.personas.score(
                        node.owner,
                        item,
                        resources,
                        node.current_goals,
                        node.scene_tags,
                        soft_resource_constraints=True,
                    )
                    for item in serious
                }
                evaluations = {
                    item.key: self.rationality.evaluate(
                        item,
                        persona_scores[item.key],
                        profile,
                        perceived_feasibility=perceived[item.key].perceived_feasibility,
                        action_assessment=perceived[item.key],
                        strategic_score=node.strategic_scores.get(item.key, 0.500),
                    )
                    for item in serious
                }
                order = {item.key: index for index, item in enumerate(options)}
                chosen = max(evaluations, key=lambda item: (evaluations[item].choice_score, -order[item]))
                selected = next(item for item in legal_pairs if item.world.key == chosen)
                forecast_precheck = None
                if selected.intent is not None:
                    if self.objective_check_engine is None or self.check_context_provider is None:
                        raise RuntimeError(
                            f"Action {chosen} carries an institutional intent but the objective "
                            "check environment is not configured"
                        )
                    forecast_precheck = self.objective_check_engine.check(
                        self.check_context_provider(forecast_state), selected.intent
                    )
                path.append({
                    "forecast_contract": "CONDITIONAL_ON_DECLARED_EFFECTS_NOT_RESOLVED_OUTCOMES",
                    "node": key,
                    "owner": node.owner,
                    "chosen_response": chosen,
                    "perceived_action_menu": {name: row.payload() for name, row in perceived.items()},
                    "choice_scores": {name: row.choice_score for name, row in evaluations.items()},
                    "objective_precheck": (
                        forecast_precheck.payload() if forecast_precheck is not None else None
                    ),
                })
                if forecast_precheck is None or forecast_precheck.resolution is Resolution.EXECUTABLE:
                    forecast_state.apply(replace(selected.world, effect_status="DETERMINISTIC_ASSUMPTION"), self.pressure_rules)
                else:
                    break
                if not selected.world.next_node:
                    break
                key = selected.world.next_node
        finally:
            self.information.rng.setstate(rng_state)
        return path

    def prepare_decision(self, node_key: str) -> dict:
        """Choose once without settling outcomes; retain a frozen commitment context."""
        from copy import deepcopy
        if self.organizations is not None and self.organization_schedule_hook is None:
            self.settle_organizational_responses()
        node = self.nodes[node_key]
        beliefs = self.information.observe(node.owner, self.state, commit=True)
        resources = self._perceived_resources(node.owner, beliefs)
        node_actions, generated_space = self._materialize_actions(node, beliefs, resources)
        temporal_assessment={}
        if getattr(self,"temporal_choice_adapter",None):
            node_actions,temporal_assessment=self.temporal_choice_adapter(node,node_actions)
        mean_confidence = (
            sum(item.confidence for item in beliefs.beliefs.values()) / len(beliefs.beliefs)
            if beliefs.beliefs else 0.500
        )
        all_choices = tuple(
            replace(
                item.choice,
                legal=item.choice.legal and self.state.legal(item.world),
            )
            for item in node_actions
        )
        objective_menu = [
            {
                "action": item.choice.key,
                "world_legal": self.state.legal(item.world),
                "choice_legal": item.choice.legal,
            }
            for item in node_actions
        ]
        repertoire = self.repertoire_filter.apply(node.owner, all_choices, resources)
        actor_agency = self.agency.get(node.owner)
        perceived = self.perception_filter.apply(
            all_choices,
            repertoire,
            self.logic,
            actor_agency,
            resources,
            mean_confidence,
        )
        choice_logic = (
            self.logic
            if self.flags.institutional_logic_affects_choice
            else InstitutionalLogic.neutral("choice_neutral_logic")
        )
        choice_agency = (
            actor_agency
            if self.flags.agency_horizon_affects_choice
            else AgencyHorizon()
        )
        choice_perceived = self.perception_filter.apply(
            all_choices,
            repertoire,
            choice_logic,
            choice_agency,
            resources,
            mean_confidence,
        )
        forecast_responses = {
            item.world.key: self._forecast_response_path(item, self.state)
            for item in node_actions
        }

        legal_pairs = [item for item in node_actions if self.state.legal(item.world)]
        v2_options = [
            replace(
                item.choice,
                legal=item.choice.legal and self.state.legal(item.world),
                information_confidence=min(item.choice.information_confidence, mean_confidence),
            )
            for item in legal_pairs
        ]
        if not self.flags.choice_active:
            decision = self.personas.decide(
                node.owner,
                v2_options,
                resources,
                current_goals=node.current_goals,
                scene_tags=node.scene_tags,
            )
            chosen_key = decision.chosen_action
            persona_scores = decision.scores
            profile = self.rationality_profiles.get(node.owner, ActorRationalityProfile())
            rationality_rows = {
                action.key: self.rationality.evaluate(
                    action,
                    persona_scores[action.key],
                    profile,
                    perceived_feasibility=perceived[action.key].perceived_feasibility,
                    action_assessment=perceived[action.key],
                    strategic_score=node.strategic_scores.get(action.key, 0.500),
                )
                for action in v2_options
            }
            party_rows = self._party_evaluations(node.owner, v2_options)
            combined_choice_scores = {
                key: row.choice_score for key, row in rationality_rows.items()
            }
            decision_source = (
                "generated_persona_v2_choice"
                if generated_space is not None
                else "persona_v2_compatibility"
            )
        else:
            (
                chosen_key,
                persona_scores,
                rationality_rows,
                party_rows,
                combined_choice_scores,
            ) = self._active_v3_choice(
                node, v2_options, resources, choice_perceived
            )
            decision_source = (
                "layered_v3_party_overlay"
                if self.flags.party_interest_affects_choice and party_rows
                else "layered_v3_choice"
            )

        arcana_trace = {
            "enabled": bool(self.arcana is not None and self.arcana.config.enabled),
            "status": "DISABLED",
        }
        if self.arcana is not None and self.arcana.config.enabled:
            node_uncertainty = (
                node.decision_event.ambiguity
                if node.decision_event is not None
                else max(
                    1.000 - mean_confidence,
                    sum(action.uncertainty for action in v2_options) / len(v2_options),
                )
            )
            interaction_modifier = 0.000
            if node.conflict_actor is not None:
                if node.conflict_actor not in self.personas.cards:
                    raise ValueError(
                        f"ARCANA conflict actor has no persona/PSS card: {node.conflict_actor}"
                    )
                conflict_bundle = self.arcana.run_conflict(
                    node.key,
                    node.owner,
                    node.conflict_actor,
                    self.personas.cards[node.owner],
                    self.personas.runtime[node.owner],
                    self.personas.cards[node.conflict_actor],
                    self.personas.runtime[node.conflict_actor],
                )
                primary_run = self.arcana.repository.get(
                    conflict_bundle["primary_reading"]["run_id"]
                )
                interaction_modifier = conflict_bundle["interaction"][
                    "primary_pss_mediation"
                ]["decision_threshold_modifier"]
                reading_payload = conflict_bundle["primary_reading"]
            else:
                primary_run = self.arcana.run_reading(node.key, node.owner)
                reading_payload = primary_run.payload()
                conflict_bundle = None
            chosen_key, adoption = self.arcana_adapter.adapt(
                chosen_key,
                combined_choice_scores,
                v2_options,
                primary_run.advice,
                self.personas.cards[node.owner],
                self.personas.runtime[node.owner],
                node_uncertainty,
                interaction_modifier,
                self.arcana.config.influence_cap,
            )
            arcana_trace = {
                "enabled": True,
                "status": "RUN",
                "reading": reading_payload,
                "adoption": adoption,
                "conflict_interaction": conflict_bundle,
                "node_uncertainty": round(node_uncertainty, 3),
            }
            decision_source = f"{decision_source}_arcana"

        return deepcopy({"node": node, "beliefs": beliefs, "resources": resources, "generated_space": generated_space, "objective_menu": objective_menu, "repertoire": repertoire, "actor_agency": actor_agency, "perceived": perceived, "choice_perceived": choice_perceived, "forecast_responses": forecast_responses, "legal_pairs": legal_pairs, "v2_options": v2_options, "chosen_key": chosen_key, "persona_scores": persona_scores, "rationality_rows": rationality_rows, "party_rows": party_rows, "combined_choice_scores": combined_choice_scores, "decision_source": decision_source, "arcana_trace": arcana_trace,"temporal_assessment":temporal_assessment})

    def run(self, start_node: str, max_steps: int = 20, *,
            timestamp: str | None = None, compile_report: bool = True,
            prepared: dict | None = None, effect_multiplier: float = 1.0) -> dict:
        if prepared is not None and max_steps != 1:
            raise ValueError("Committed execution is exactly one frozen decision")
        if not 0 <= effect_multiplier <= 1:
            raise ValueError("Effect multiplier must be within 0..1")
        for observer in self.event_observers:
            telemetry = getattr(observer, "telemetry", None)
            points = getattr(telemetry, "points", None)
            record_baseline = getattr(observer, "record_baseline", None)
            if callable(record_baseline) and points is not None and not points:
                record_baseline(self.state)
        node_key = start_node
        for _ in range(max_steps):
            node = self.nodes[node_key]
            context = prepared if prepared is not None else self.prepare_decision(node_key)
            node, beliefs, resources, generated_space, objective_menu, repertoire, actor_agency, perceived, choice_perceived, forecast_responses, legal_pairs, v2_options, chosen_key, persona_scores, rationality_rows, party_rows, combined_choice_scores, decision_source, arcana_trace = (context[k] for k in ["node","beliefs","resources","generated_space","objective_menu","repertoire","actor_agency","perceived","choice_perceived","forecast_responses","legal_pairs","v2_options","chosen_key","persona_scores","rationality_rows","party_rows","combined_choice_scores","decision_source","arcana_trace"])

            selected = next(item for item in legal_pairs if item.world.key == chosen_key)
            if selected.choice.execution_estimate <= 0:
                raise ValueError(f"Action {chosen_key} has no execution capacity; an intention cannot settle world effects")
            if generated_space is not None and self.outcome_resolver is None:
                raise ValueError("Generated actions require an outcome resolver before settlement")
            if selected.intent is None and generated_space is None:
                # Validate before queuing requests or applying attached rewards.
                selected.world.settlement_basis()
            organization_submission = None
            if selected.organization_effects and selected.organization_request is None:
                raise ValueError("Conditional organization effects require a recipient request")
            if selected.organization_request is not None:
                request = selected.organization_request
                if self.organizations is None or self.state.now_minute is None:
                    raise ValueError("Organizational requests require a response engine and world clock")
                if request.proposer != node.owner or request.delay_minutes <= 0:
                    raise ValueError("Request needs its actual proposer and a positive deliberation delay")
                if selected.intent is not None or generated_space is not None:
                    raise ValueError("Separate organizational requests from institutional acts/generated outcomes")
                if selected.actor_outcomes:
                    raise ValueError("Do not pre-award actor success while an organizational response is pending")
                if request.request_id in self._organization_bindings:
                    raise ValueError("Use a new request id for a new attempt")
                poll_variables = {spec.state_variable for observer in self.event_observers
                                  for spec in getattr(observer, "specs", ())}
                if poll_variables & set(selected.organization_effects):
                    raise ValueError("An organizational response cannot directly reward polling support")
                if set(selected.organization_effects) - set(self.state.variables) or any(
                        not math.isfinite(v) for v in selected.organization_effects.values()):
                    raise ValueError("Invalid conditional operational effects")
                organization_submission = self.organizations.submit(request, self.state.now_minute)
                self._organization_bindings[request.request_id] = {
                    "choice": next(a for a in v2_options if a.key == chosen_key),
                    "evaluation": rationality_rows[chosen_key],
                    "system_feedback_context": node.system_feedback_context,
                    "effects": {k: v * effect_multiplier for k, v in selected.organization_effects.items()},
                }
                if self.organization_schedule_hook is not None:
                    self.organization_schedule_hook(organization_submission["due_at"], request.request_id)
            if prepared is not None:
                arcana_trace=dict(arcana_trace)
                if arcana_trace.get("status")=="RUN":arcana_trace["status"]="REUSED_COMMITMENT"
                decision_source+="_committed_execution"
            action_eval = rationality_rows[chosen_key]
            resolved_outcome = None
            settled_world_action = selected.world
            operational_success = selected.world.feasibility
            precheck_bundle = None
            institutional_resolution = None
            if selected.intent is not None:
                if self.objective_check_engine is None or self.check_context_provider is None:
                    raise RuntimeError(
                        f"Action {chosen_key} carries an institutional intent but the objective "
                        "check environment is not configured"
                    )
                precheck_bundle = self.objective_check_engine.check(
                    self.check_context_provider(self.state), selected.intent
                )
                institutional_resolution = self.institutional_resolver.resolve(precheck_bundle)
                if institutional_resolution.resolution is not Resolution.EXECUTABLE:
                    settled_world_action = PoliticalAction(
                        key=f"{selected.world.key}:{institutional_resolution.resolution.value}",
                        effects={"immediate": {}, "medium": {}, "long": {}},
                        feasibility=0.0,
                        effect_status="REALIZED",
                        next_node=None,
                        tags=(
                            *selected.world.tags,
                            f"institutional_resolution:{institutional_resolution.resolution.value}",
                        ),
                    )
                    operational_success = 0.0
            if (
                institutional_resolution is None
                or institutional_resolution.resolution is Resolution.EXECUTABLE
            ) and generated_space is not None and self.outcome_resolver is not None:
                generated_action = generated_space.by_key()[chosen_key]
                resolved_outcome = self.outcome_resolver.resolve(generated_action)
                settled_world_action = resolved_outcome.world_action
                operational_success = resolved_outcome.success_level
            if effect_multiplier != 1.0:
                if selected.intent is not None:
                    raise ValueError("Do not scale constitutional/institutional acts as a decaying numerical payoff")
                settled_world_action = replace(settled_world_action,effects={
                    horizon:{key:value*effect_multiplier for key,value in effects.items()}
                    for horizon,effects in settled_world_action.effects.items()})
            system_feedback = self.system_assessor.assess(
                selected.choice,
                action_eval,
                self.logic,
                operational_success=operational_success,
            )
            logic_before = self.logic.payload()
            agency_before = self.agency.get(node.owner).payload()
            execution_authorized = institutional_resolution is None or institutional_resolution.resolution is Resolution.EXECUTABLE
            state_update = (self.state.apply(settled_world_action, self.pressure_rules)
                            if execution_authorized else {"action": chosen_key, "status": "NOT_EXECUTED",
                                "institutional_resolution": institutional_resolution.resolution.value})
            pss_updates: list[dict] = []
            if organization_submission is not None:
                # Paying for coordination is observable; gaining confidence or
                # control from an endorsement that has not arrived is not.
                pss_updates.append(self.personas.advance_time(node.owner, 0,
                    workload=.025 + .055 * selected.choice.effort))
            if resolved_outcome is not None:
                pss_updates.append(self.personas.apply_outcome(
                    node.owner,
                    ActionOutcome(
                        action=chosen_key,
                        success=resolved_outcome.success_level,
                        surprise=abs(resolved_outcome.success_level - .500),
                        tags=(
                            "generated_outcome",
                            resolved_outcome.branch,
                            node.decision_event.domain,
                            f"strategy:{generated_action.path.strategy}",
                            f"style:{generated_action.path.execution_style}",
                            *selected.choice.identity_tags,
                        ),
                        target_actor=node.decision_event.target_actor,
                        workload=.030 + .070 * selected.choice.effort,
                        control_restoration=(
                            selected.choice.restores_control
                            * resolved_outcome.success_level
                            * .120
                        ),
                        identity_alignment=(resolved_outcome.success_level - .500) * .120,
                        expected_success=resolved_outcome.expected_success,
                        evidence_quality=selected.choice.information_confidence,
                        outcome_scope=.600 + .400 * selected.choice.effort,
                        outcome_id=f"decision:{node.key}:{len(self.trace)}:{node.owner}",
                        relationship_effect=("repair" if selected.choice.relationship_posture == "repair" else "none"),
                    ),
                ))
            for affected_actor, events in (selected.actor_events.items() if execution_authorized else ()):
                for event in events:
                    pss_updates.append(self.personas.apply_event(affected_actor, event))
            for affected_actor, outcome in (selected.actor_outcomes.items() if execution_authorized else ()):
                pss_updates.append(self.personas.apply_outcome(affected_actor, outcome))
            feedback_application = self._commit_system_feedback(system_feedback,
                node.system_feedback_context, node.owner,
                enabled=self.flags.system_feedback_mutates_world and organization_submission is None and execution_authorized)
            for observer in self.event_observers:
                if timestamp is not None and hasattr(observer, "timestamp_by_event_id"):
                    observer.timestamp_by_event_id[f"layered_decision:{node.key}"] = timestamp
                observer.record(
                    self.state,
                    event_id=f"layered_decision:{node.key}",
                    actor=node.owner,
                    action=chosen_key,
                    event_kind="layered_actor_decision",
                    resource_changes=state_update,
                )
            polling_after = []
            for observer in self.event_observers:
                telemetry = getattr(observer, "telemetry", None)
                points = getattr(telemetry, "points", None)
                if points:
                    latest_step = max(point.step for point in points)
                    polling_after.extend(
                        asdict(point) for point in points if point.step == latest_step
                    )
            self.trace.append({
                "node": node.key,
                **({"calendar_date": timestamp} if timestamp is not None else {}),
                "decision_maker": node.owner,
                "decision_source": decision_source,
                "decision_space_generation": (
                    generated_space.payload() if generated_space is not None else None
                ),
                "objective_action_menu": objective_menu,
                "role_filtered_menu": {key: row.payload() for key, row in repertoire.items()},
                "perceived_action_menu": {key: row.payload() for key, row in perceived.items()},
                "choice_action_menu": {
                    key: row.payload() for key, row in choice_perceived.items()
                },
                "actor_belief_state": InformationFilter.payload(beliefs),
                "institutional_logic_state": logic_before,
                "agency_horizon_before": agency_before,
                "action_evaluations": {
                    key: {
                        "instrumental": rationality_rows[key].instrumental_score,
                        "expected_instrumental": rationality_rows[key].expected_instrumental_score,
                        "action_channels": {
                            "mode": rationality_rows[key].channel_mode,
                            "execution_feasibility": rationality_rows[key].execution_feasibility,
                            "political_success_expectation": rationality_rows[key].political_success_expectation,
                            "information_confidence": rationality_rows[key].information_confidence,
                            "failure_instrumental_score": rationality_rows[key].failure_instrumental_score,
                        },
                        "substantive": rationality_rows[key].substantive_score,
                        "persona": asdict(persona_scores[key]),
                        "strategic_continuation": rationality_rows[key].strategic_score,
                        "choice_score": rationality_rows[key].choice_score,
                        "party_interest": (
                            party_rows[key].payload() if key in party_rows else None
                        ),
                        "combined_choice_score": combined_choice_scores[key],
                        "rationality_conflict": rationality_rows[key].rationality_conflict,
                    }
                    for key in rationality_rows
                },
                "party_interest_layer": {
                    "party_id": self.actor_party_map.get(node.owner),
                    "affects_choice": bool(
                        self.flags.party_interest_affects_choice and party_rows
                    ),
                    "overlay_weight": round(
                        self.party_overlay_weights.get(node.owner, 0.250), 3
                    ) if party_rows else 0.000,
                    "evaluations": {
                        key: row.payload() for key, row in party_rows.items()
                    },
                },
                "arcana": arcana_trace,
                "forecast_responses": forecast_responses,
                "chosen_action": chosen_key,
                "temporal_assessment": context.get("temporal_assessment",{}),
                "objective_precheck": (
                    precheck_bundle.payload() if precheck_bundle is not None else None
                ),
                "institutional_resolution": (
                    institutional_resolution.payload()
                    if institutional_resolution is not None else {
                        "resolution": "not_invoked",
                        "effects": [],
                        "required_procedures": [],
                        "reasons": [],
                    }
                ),
                "actors_used": sorted({
                    node.owner,
                    *((node.conflict_actor,) if node.conflict_actor in self.personas.cards else ()),
                    *selected.actor_events.keys(),
                    *selected.actor_outcomes.keys(),
                    *(
                        (selected.choice.target_actor,)
                        if selected.choice.target_actor in self.personas.cards
                        else ()
                    ),
                    *(
                        response["owner"]
                        for paths in forecast_responses.values()
                        for response in paths
                        if response.get("owner") in self.personas.cards
                    ),
                }),
                "operational_feedback": {
                    "action_execution": ("NOT_EXECUTED" if not execution_authorized else
                                         "SUBMITTED" if organization_submission is not None else "LEGACY_OR_GENERATED_SETTLEMENT"),
                    "organization_request": organization_submission,
                    "temporal_payoff_multiplier": effect_multiplier,
                    "settlement_status": (
                        "NOT_EXECUTED_INSTITUTIONAL_PRECHECK" if not execution_authorized else "GENERATED_OUTCOME_RESOLVED"
                        if resolved_outcome is not None
                        else "PENDING_ORGANIZATIONAL_RESPONSE" if organization_submission is not None
                        else "WORLD_TRANSITION_ONLY"
                    ),
                    "operational_success_input": round(operational_success, 3),
                    "outcome_branch": (
                        resolved_outcome.payload() if resolved_outcome is not None else None
                    ),
                    "state_update": state_update,
                    "pss_updates": pss_updates,
                },
                "system_feedback": system_feedback.payload() if organization_submission is None and execution_authorized else None,
                "system_feedback_applied": feedback_application["applied"],
                "system_feedback_application": feedback_application,
                "agency_horizon_after": self.agency.get(node.owner).payload(),
                "institutional_logic_after": self.logic.payload(),
                "polling_after": polling_after,
                "pss_after": asdict(self.personas.runtime[node.owner].state),
                "all_actor_pss_after": {
                    actor: asdict(runtime.state)
                    for actor, runtime in self.personas.runtime.items()
                },
            })
            if settled_world_action.next_node is None:
                break
            node_key = settled_world_action.next_node
        return self.payload() if compile_report else self.trace[-1]

    def payload(self) -> dict:
        scenario_report = ScenarioReportCompiler(
            self._initial_pss,
            self.reporting_policy,
        ).compile(self.trace, self.event_observers)
        return {
            "schema_version": "political-simulation-3.0",
            "system_feedback_ledger": self.system_feedback_ledger.payload(),
            "feature_flags": asdict(self.flags),
            "trace": self.trace,
            "world_state": self.state.payload(),
            "organizations": self.organizations.payload() if self.organizations is not None else None,
            "institutional_matrix": self.matrix.payload(),
            "institutional_logic": self.logic.payload(),
            "agency_horizons": self.agency.payload(),
            "persona_runtime": self.personas.payload(),
            "scenario_report": scenario_report,
            "arcana": self.arcana.payload() if self.arcana is not None else {
                "config": {"enabled": False}, "runs": {}
            },
            "warning": (
                "Utilities and system classifications are model diagnostics, not observed facts. "
                "Shadow mode cannot alter the authoritative v2 choice."
            ),
        }
