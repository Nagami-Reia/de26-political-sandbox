"""Load a living-world schedule using the project's existing v3 schema/modules."""
from __future__ import annotations

from dataclasses import fields
import hashlib
import json
from pathlib import Path

from .free_agent_game import WorldAction
from .information_filter import AccessRule, InformationFilter
from .living_world import Capacity, LivingPoliticalWorld, Task
from .persona_v2 import ActionOption, FreeAgentDecisionEngine
from .political_state import PoliticalAction, PoliticalState, StateVariable
from .plugins.polling.tracker import PollSeriesSpec, RealtimePollingTracker
from .simulation_orchestrator import LayeredConfiguration, LayeredSimulationOrchestrator, SimulationNodeV3
from .world_clock import WorldClock, WorkCalendar
from .world_environment import WorldEnvironment, SchedulingRules, DEFAULT_ENVIRONMENT
from .party_interest import PartyInterestEngine
from .organizational_response import (
    OrganizationalBloc, PoliticalOrganization, OrganizationalRequest, OrganizationalResponseEngine,
)


PACKAGE = Path(__file__).resolve().parent


def load_living_world(path: Path, cards: str | Path | None = None,
                      environment_path: Path | None = None) -> tuple[LivingPoliticalWorld, str]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    if raw.get("schema_version") not in {"living-world-config-1.0","living-world-config-1.1"}:
        raise ValueError("Expected living-world-config-1.0 or 1.1")
    reference = raw.get("environment")
    environment = WorldEnvironment.load(environment_path or (path.parent/reference if reference else DEFAULT_ENVIRONMENT))
    if environment.rules.get("information_mode") == "DELIVERED_ONLY" and raw.get("information"):
        raise ValueError("AccessRule does not grant receipt: migrate information to knowledge.initial_beliefs/messages")
    clock = WorldClock(raw["start"], raw.get("timezone", environment.rules["clock"]["timezone"]))
    if clock.offset(raw["until"]) < 0:
        raise ValueError("Observation horizon precedes start")
    provenance = raw.get("variable_provenance", {})
    if set(provenance)-set(raw["variables"]):
        raise ValueError("Provenance refers to an unknown variable")
    for row in provenance.values():
        if environment.external is None:
            raise ValueError("Variable provenance requires an evidence-backed environment")
        environment.external.validate_provenance(row)
        if row["status"] == "UNKNOWN":
            raise ValueError("Unknown world values cannot be numeric placeholders; omit them from variables")
    state = PoliticalState({key: StateVariable(key, float(value), evidence=provenance.get(key, {}).get("status", "SIMULATION_ASSUMPTION"))
                            for key, value in raw["variables"].items()}, raw.get("capital", {}), raw.get("pressures", {}))
    personas = FreeAgentDecisionEngine.from_json(cards or PACKAGE/"data/personas/cards_pss.json")
    participants = {row["owner"] for row in raw.get("tasks", [])} | {row["owner"] for row in raw.get("nodes", [])}
    participants.update(actor for event in raw.get("events", []) for actor in event.get("affected", []))
    participants.update(row["route"]["owner"] for row in raw.get("history", {}).get("candidates", []))
    knowledge = raw.get("knowledge", {})
    participants.update(knowledge.get("initial_beliefs", {}))
    participants.update(actor for message in knowledge.get("messages", []) for actor in message["recipients"])
    participants.update(p['owner'] for p in raw.get('poll_feedback',{}).get('projects',()))
    for channel in raw.get('persona_communication',{}).get('channels',()):
        if not isinstance(channel,dict) or not all(isinstance(channel.get(k),str) and channel[k] for k in ('sender','recipient')):
            raise ValueError('Persona communication channel requires sender and recipient IDs')
        participants.update((channel['sender'],channel['recipient']))
    media = raw.get("media", {})
    participants.update(actor for name in ("event_routes", "decision_routes", "history_routes")
                        for route in media.get(name, {}).values() for actor in route["actors"])
    profiles = environment.capacities_for(list(participants), set(personas.cards), raw.get("capacities", {}))
    capacities = {key: Capacity(daily_minutes=row["daily_minutes"], slots=row["slots"],
                  calendar=WorkCalendar(**row["calendar"])) for key, row in profiles.items()}
    nodes = {}
    poll_vars = set(raw["poll_variables"])
    for node_raw in raw.get("nodes", []):
        key, owner = node_raw["key"], node_raw["owner"]
        if key in nodes:
            raise ValueError("Duplicate decision node key")
        actions = []
        for item in node_raw["actions"]:
            option_raw = dict(item["choice"])
            allowed = {f.name for f in fields(ActionOption)}
            if set(option_raw)-allowed:
                raise ValueError(f"Unknown action fields: {sorted(set(option_raw)-allowed)}")
            for name in ("control_domains", "identity_tags", "event_tags", "risk_tags",
                         "required_offices", "required_institutional_permissions"):
                if name in option_raw:
                    option_raw[name] = tuple(option_raw[name])
            option = ActionOption(**option_raw)
            effects = item.get("effects", {})
            if set(effects)-set(state.variables):
                raise ValueError("Action references unknown variable")
            if poll_vars & set(effects):
                raise ValueError("Direct party-support effects prohibited; connect narrative feedback")
            if option.required_offices or option.required_institutional_permissions:
                raise ValueError("This schedule loader accepts operational decisions only; configure legal intents via the Python v3 API")
            deferred=item.get("deferred_effects",{})
            if set(deferred)-{"medium","long"}:raise ValueError("Unknown deferred horizon")
            for changes in deferred.values():
                if set(changes)-set(state.variables) or poll_vars & set(changes):raise ValueError("Invalid deferred world variables; support must use voter response")
            if set(deferred)!=set(item.get("effect_timing",{})):raise ValueError("Every new deferred horizon needs explicit effect_timing")
            request = OrganizationalRequest(**item["organization_request"]) if "organization_request" in item else None
            conditional = item.get("organization_effects", {})
            if set(conditional)-set(state.variables) or poll_vars & set(conditional):
                raise ValueError("Invalid organizational operational effects; support must use voter response")
            if conditional and request is None:
                raise ValueError("Organizational effects need a request")
            actions.append(WorldAction(PoliticalAction(option.key, {"immediate": effects,**deferred},
                                       feasibility=option.objective_feasibility,effect_timing=item.get("effect_timing",{}),
                                       effect_status=item.get("effect_status", "DECLARED")), option,
                                       organization_request=request, organization_effects=conditional))
        if not actions or len({a.choice.key for a in actions}) != len(actions):
            raise ValueError("Node actions must be nonempty with unique keys")
        nodes[key] = SimulationNodeV3(key, owner, tuple(actions),
                       node_raw.get("goals", {}), tuple(node_raw.get("tags", ())),
                       system_feedback_context=node_raw.get("system_feedback_context"))
    actors = sorted(set(capacities) & set(personas.cards))
    information = InformationFilter({actor: {key: AccessRule(**rule)
                     for key, rule in raw.get("information", {}).get(actor, {}).items()}
                     for actor in actors}, seed=raw.get("seed", 0), stochastic=raw.get("stochastic_information", False),
                     delivery_only=environment.rules.get("information_mode") == "DELIVERED_ONLY")
    specs = tuple(PollSeriesSpec(key, key, "electorate", "vote_intention", "DE",
                               retention=.60) for key in raw["poll_variables"])
    if not specs or not poll_vars.issubset(state.variables):
        raise ValueError("At least one valid polling series is required")
    polling = raw.get("polling_plugin", {})
    if polling.get("enabled", False):
        from .plugins.polling.service import PollingPlugin
        if raw.get("media", {}).get("opinion_response"):
            raise ValueError("Do not combine legacy scalar opinion deltas with the electorate-response plugin")
        tracker = PollingPlugin(raw.get("run_id","living-world"),environment.facts["environment_id"],specs,raw["start"],
            bindings=polling["bindings"],response_request=polling.get("response_request"),
            response_by_event_id=polling.get("response_by_event_id"),window_minutes=polling.get("window_minutes",4320),
            publication_grid=polling.get("publication_grid",.5))
    else:
        tracker = RealtimePollingTracker(raw.get("run_id", "living-world"), environment.facts["environment_id"], specs, raw["start"],
            composition_groups=tuple(raw.get("polling_observation", {}).get("composition_groups", ())))
    organization_config = raw.get("organizations", {})
    organizations = None
    if organization_config:
        profiles = {}
        for key, item in organization_config["profiles"].items():
            data = dict(item)
            data["blocs"] = tuple(OrganizationalBloc(**row) for row in data["blocs"])
            profiles[key] = PoliticalOrganization(key, **data)
        organizations = OrganizationalResponseEngine(profiles, seed=organization_config.get("seed",raw.get("seed",0)),
            contingency_sigma=organization_config.get("contingency_sigma",0.0))
    if any(a.organization_request is not None for n in nodes.values() for a in n.actions) and organizations is None:
        raise ValueError("Organizational requests need recipient profiles")
    game = LayeredSimulationOrchestrator(state, nodes, personas, information, raw.get("resource_bindings", {}),
        environment.layered,
        event_observers=(tracker,), organizations=organizations)
    tasks = []
    for item in raw.get("tasks", []):
        if {"status", "started", "finished", "overdue","phase","work_status","action_outcome","institutional_outcome",
            "world_outcome","committed_at","committed_action","execution_duration","execution_started",
            "execution_attention","reservation_started","reserved_duration","reservation_day","revision"} & set(item):
            raise ValueError("Scenario tasks cannot prescribe runtime completion states")
        data = dict(item)
        if raw["schema_version"]=="living-world-config-1.1" and data.get("node"):
            data.setdefault("lifecycle","STAGED")
        data["release"] = clock.offset(data["release"])
        data["deadline"] = clock.offset(data["deadline"])
        data["dependencies"] = tuple(data.get("dependencies", ()))
        data["tags"] = tuple(data.get("tags", ()))
        data["requires_windows"] = tuple((clock.offset(start), clock.offset(end))
                                          for start, end in data.get("requires_windows", ()))
        data["followups"] = {key: tuple(value) for key, value in data.get("followups", {}).items()}
        tasks.append(Task(**data))
    scheduling = {**environment.rules["scheduling"], **raw.get("scheduling_overrides", {})}
    world = LivingPoliticalWorld(game, clock, capacities, tasks, tuple(raw.get("reactive_rules", ())), SchedulingRules(**scheduling))
    from .opportunity_windows import OpportunityWindow
    from .political_timing import TimingReport
    windows=[]
    for item in raw.get("opportunity_windows",()):
        if {"claims","resolved_claims"}&set(item):raise ValueError("Scenario cannot pre-fill opportunity claims")
        data=dict(item)
        for key in ("opens_at","closes_at"):
            if key in data:data[key]=clock.offset(data[key])
        data["opens_when"]=tuple(data.get("opens_when",()))
        data["closes_when"]=tuple(data.get("closes_when",()))
        windows.append(OpportunityWindow(**data))
    world.install_opportunities(windows)
    world.configure_waiting(raw.get("waiting_policies",{}))
    for item in raw.get("timing_reports",()):
        data=dict(item);actor=data.pop("actor");at=clock.offset(data.pop("received_at"))
        data["observed_at"]=clock.offset(data["observed_at"])
        report=TimingReport(**data)
        if actor not in world.used_personas:raise ValueError("Unknown timing report recipient")
        if "timing_report" not in world.event_handlers:
            def deliver_timing(w,event):
                w.deliver_timing_report(event.data["actor"],TimingReport(**event.data["report"]))
                return {"recipient":event.data["actor"],"message_id":event.data["report"]["message_id"]}
            world.register_event_handler("timing_report",deliver_timing)
        world.clock.schedule(at,"timing_report",{"actor":actor,"report":data})
    world.configuration = raw
    world.environment = environment.describe()
    world.environment["mode"] = "SHARED_ENVIRONMENT_WITH_SCENARIO_INPUTS"
    world.external_environment = environment.external
    world.variable_provenance = {key: {"status": "SIMULATION_ASSUMPTION", "sources": [], **provenance.get(key, {})}
                                 for key in state.variables}
    if information.delivery_only:
        from .world_information import KnowledgeClockService
        world.services["information"] = KnowledgeClockService(world, knowledge)
    from .world_services import HistoricalClockService, MediaClockService, ParliamentClockService
    def service_config(name):
        derived = int.from_bytes(hashlib.sha256(f"{raw.get('seed', 0)}:{name}".encode()).digest()[:8], "big")
        return {"seed": derived, **raw[name]}
    if "history" in raw:
        cadence = raw["history"].get("cadence_minutes", environment.rules["services"]["history"]["cadence_minutes"])
        world.services["history"] = HistoricalClockService(world, service_config("history"), cadence)
    if "media" in raw:
        parties = PartyInterestEngine.from_json(PACKAGE/"data/parties/party_interest_profiles.json")
        world.services["media"] = MediaClockService(world, service_config("media"), environment.rules["services"]["media"], parties)
    if "parliament" in raw:
        world.services["parliament"] = ParliamentClockService(world, service_config("parliament"))
    if 'poll_feedback' in raw:
        from .political_poll_feedback import PollFeedbackService
        world.services['poll_feedback']=PollFeedbackService(world,raw['poll_feedback'])
    if 'persona_communication' in raw:
        from .persona_communication import PersonaCommunicationService
        world.services['persona_communication']=PersonaCommunicationService(world,raw['persona_communication'])
    for task in world.tasks.values():
        if task.policy_project and task.policy_project not in world.policy_projects:
            raise ValueError('Task needs a registered policy project: '+task.key)
    world.environment['poll_decision_feedback']={'status':'ACTIVE' if world.policy_projects else 'NO_POLICY_PROJECT_BINDINGS',
        'note':'A chart does not imply actor knowledge or a policy review; configure poll_feedback projects/publications'}
    for event in raw.get("events", ()):
        world.add_event(clock.offset(event["at"]), event["key"], tuple(event.get("affected", ())),
                        event.get("severity", .4), tuple(event.get("tags", ())), event.get("effects", {}),
                        visibility=event.get("visibility", "PUBLIC"))
    return world, raw["until"]
