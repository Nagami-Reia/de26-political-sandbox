"""Explicit persona action -> channel -> delivered poll -> recipient's own review.

Opt-in world channels, no inferred access from employment or relationship scores.
Only actual completed communication work can trigger sending. This adapter never
chooses a stance for the recipient or creates additional voting/social effects.
"""
from copy import deepcopy
import math

from .world_clock import DELIVERY


class PersonaCommunicationService:
    def __init__(self, world, config):
        self.world = world
        self.channels = {}
        self.bindings = []
        self.history = []
        self.sent = set()
        if 'poll_feedback' not in world.services:
            raise ValueError('Persona poll communication requires poll_feedback')
        self.poll_feedback = world.services['poll_feedback']
        for raw in config.get('channels', ()):
            row = deepcopy(raw)
            if not {'id','sender','recipient','latency_minutes','reliability'} <= set(row):
                raise ValueError('Incomplete explicitly authorized persona channel')
            if row['id'] in self.channels or row['sender'] == row['recipient']:
                raise ValueError('Duplicate channel or self-relay')
            if any(a not in world.used_personas for a in (row['sender'],row['recipient'])):
                raise ValueError('Communication actors must be active personas')
            if type(row['latency_minutes']) is not int or row['latency_minutes'] < 1:
                raise ValueError('Channel latency must be at least one minute')
            r = row['reliability']
            if isinstance(r,bool) or not isinstance(r,(int,float)) or not math.isfinite(r) or not 0 <= r <= 1:
                raise ValueError('Channel reliability must be finite 0..1')
            if 'active' in row and type(row['active']) is not bool:
                raise ValueError('Channel active must be boolean')
            self.channels[row['id']] = row
        for raw in config.get('actions', ()):
            if not {'task','action','channel','release_id'} <= set(raw):
                raise ValueError('Forwarding requires task/action/channel/release bindings')
            row = deepcopy(raw)
            if row['task'] not in world.tasks or row['channel'] not in self.channels:
                raise ValueError('Unknown communication task/channel')
            task = world.tasks[row['task']]
            channel = self.channels[row['channel']]
            if task.owner != channel['sender'] or not task.node:
                raise ValueError('Communication action must belong to the sender')
            if row['action'] not in {a.world.key for a in world.game.nodes[task.node].actions}:
                raise ValueError('Unknown communication action')
            if row['release_id'] not in self.poll_feedback.releases:
                raise ValueError('Unknown original poll release')
            profile = world.game.personas.cards[task.owner].components.get('communication', {})
            if profile and (profile.get('auto_forward') is not False or
                            profile.get('forwarding_requires') != 'EXPLICIT_SELECTED_ACTION'):
                raise ValueError('Unsupported persona forwarding contract')
            self.bindings.append(row)
        world.register_event_handler('persona_poll_delivery', self.deliver)
        world.listeners.append(self.on_event)

    def on_event(self, world, event):
        if event['kind'] != 'task_completed' or not event.get('decision'):
            return
        task = world.tasks[event['task']]
        if task.action_outcome != 'SUCCEEDED':
            return
        for binding in self.bindings:
            if binding['task'] == task.key and binding['action'] == event['decision']['chosen_action']:
                self.send(binding)

    def send(self, binding):
        world = self.world
        task = world.tasks[binding['task']]
        if binding not in self.bindings or task.status not in {'COMPLETED','COMPLETED_LATE'} or task.action_outcome != 'SUCCEEDED':
            raise ValueError('Only completed explicitly bound communication work may send')
        settled = next((r for r in reversed(world.game.trace) if r['node']==f'living_task:{task.key}'),None)
        if not settled or settled['chosen_action'] != binding['action']:
            raise ValueError('Bound forwarding action was not actually selected')
        channel = self.channels[binding['channel']]
        identity = f"relay:{binding['task']}:{binding['release_id']}:{channel['id']}"
        if identity in self.sent:
            return
        self.sent.add(identity)
        sender, recipient = channel['sender'], channel['recipient']
        received = next((r for r in reversed(self.poll_feedback.history)
                         if r.get('release',{}).get('id') == binding['release_id']
                         and sender in r.get('delivered_beliefs',{})), None)
        if not received or not channel.get('active',True):
            self.history.append({'id':identity,'status':'BLOCKED',
                'reason':'SENDER_HAS_NOT_RECEIVED_OR_CHANNEL_CLOSED'})
            return
        original = received['release']
        key = f"poll:{original['channel']}:{original['region']}:{original['subject']}:{original['series']}"
        belief = received['delivered_beliefs'].get(sender)
        if belief is None:
            raise ValueError('Received poll has no sender belief')
        # Forward this received report, not the sender's later blended belief
        # under the same series key with an older publication date attached.
        row = {**deepcopy(original),'id':identity,'recipients':[recipient],'modeled':False,
            'value_percent':belief['estimate'],'confidence':belief['confidence']*channel['reliability'],
            'delivery_source':f'persona:{sender}','evidence_status':'FORWARDED_PERSONA_BELIEF',
            'origin_release_id':original.get('origin_release_id',original['id']),
            'forwarded_by':sender,'sender_belief_at_receipt':deepcopy(belief),
            'sending_task':binding['task'],'sending_action':binding['action']}
        if 'measurement' in row:
            row['origin_measurement'] = row.pop('measurement')
        row['is_new_poll_publication'] = False
        self.poll_feedback.releases[identity] = row
        at = world.clock.minute + channel['latency_minutes']
        world.clock.schedule(at,'persona_poll_delivery',{'id':identity,'channel':channel['id']},phase=DELIVERY)
        self.history.append({'id':identity,'status':'SENT_NOT_DELIVERED','sender':sender,
            'recipient':recipient,'sent_minute':world.clock.minute,'arrival_minute':at,
            'original_poll_source':original['source'],'content_source':'RECEIVED_SENDER_BELIEF'})

    def deliver(self, world, event):
        channel = self.channels[event.data['channel']]
        if not channel.get('active',True):
            row = {'id':event.data['id'],'status':'DELIVERY_FAILED_CHANNEL_CLOSED'}
        else:
            row = self.poll_feedback.publish(world,event)
        self.history.append(deepcopy(row))
        return row

    def payload(self):
        return {'schema_version':'persona-communication-1.0','channels':deepcopy(self.channels),
            'action_bindings':deepcopy(self.bindings),'history':deepcopy(self.history),
            'automatic_forwarding':False,'automatic_vote_or_relationship_changes':False}
