"""Published polls -> delivered beliefs -> persona review -> policy/task state.

All response coefficients are disclosed assumptions. This service never reads
latent support as actor knowledge and never changes support or vote counts.
"""
from copy import deepcopy
from dataclasses import dataclass, field, asdict
from datetime import datetime
import math

from .persona_v2 import ActionOption,WorldEvent
from .free_agent_game import WorldAction
from .political_state import PoliticalAction
from .simulation_orchestrator import SimulationNodeV3
from .living_world import Task
from .world_clock import DELIVERY, aware_datetime

CHANNEL_VALUES={
    'party_vote':('party_advantage','party_recovery','csu_relevance','political_authority'),
    'state_vote':('electoral_mandate','electoral_containment','regional_representation','bavarian_control','broad_acceptance'),
    'personal_approval':('political_authority','personal_option','public_opportunity_frame'),
    'party_base':('organizational_trust','party_inclusion','unity','union_unity','csu_and_home_base'),
    'policy_support':('social_legitimacy','broad_acceptance','democratic_responsibility','social_cohesion'),
}
REVIEW_EXPECTATIONS={'continue':(1.,1.,.10),'revise':(.65,.4,.30),
                     'pause':(.1,.15,.15),'withdraw':(-.4,-.2,.40)}


def unit(value,name):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not 0<=value<=1:
        raise ValueError(name+' must be finite in 0..1')
    return float(value)


def profile_for(card,override=None):
    values={v.key:v.weight for v in card.dna.value_hierarchy}
    derived={c:max((values[k] for k in keys if k in values),default=.5) for c,keys in CHANNEL_VALUES.items()}
    override=override or {}
    if set(override)-set(CHANNEL_VALUES):raise ValueError('Unknown poll decision channel')
    component=card.components.get('polling',{})
    configured=component.get('channel_weights',derived)
    if set(configured)!=set(CHANNEL_VALUES):raise ValueError('Incomplete persona polling component')
    weights={c:unit(override.get(c,v),c) for c,v in configured.items()}
    return {'channel_weights':weights,'status':'UNVALIDATED_MODEL_ASSUMPTION',
        'card_source_ids':list(card.source_ids),'parameter_source':('PERSONA_POLLING_COMPONENT_UNCALIBRATED' if component else 'MODEL_TRANSLATION_FROM_CARD_VALUES'),
        'derivation':{c:{k:values[k] for k in keys if k in values} for c,keys in CHANNEL_VALUES.items()},
        'fallback':.5,'overrides':dict(override),
        'component_source':'polling.json' if component else 'LEGACY_CARD_DERIVATION',
        'note':'Card-derived relevance prior, not measured poll sensitivity; fixed DNA is not rewritten'}


@dataclass
class PolicyProject:
    key: str
    owner: str
    party: str
    tasks: tuple[str,...]
    policy_value_keys: tuple[str,...]=()
    region: str='DE'
    scope: str='operational'
    review_minutes: int=15
    review_window_minutes: int=240
    minimum_change_pp: float=2.
    noise_multiplier: float=1.
    attribution: float=1.
    policy_merit: float|None=None
    revision_task: str|None=None
    withdrawal_task: str|None=None
    withdrawal_cleanup_tasks: tuple[str,...]=()
    task_action_roles: dict=field(default_factory=dict)
    status: str='ACTIVE'
    revision: int=0
    pending_review: str|None=None
    references: dict=field(default_factory=dict)
    latest: dict=field(default_factory=dict)


class PollFeedbackService:
    def __init__(self,world,config):
        self.world=world;self.history=[];self.releases={};self.review_nodes={};self.seen=set();self.series_sources={};self.delivered_at={}
        self.delivery_versions={}
        self.state_feedback_scale=unit(config.get('state_feedback_scale',.1),'state_feedback_scale')
        self.profiles={a:profile_for(world.game.personas.cards[a],config.get('actor_weights',{}).get(a))
                       for a in world.used_personas}
        if set(config.get('actor_weights',{}))-set(self.profiles):raise ValueError('Unknown actor poll profile')
        for raw in config.get('projects',()):
            if set(raw)&{'status','revision','pending_review','references','latest'}:raise ValueError('Project runtime state cannot be prefilled')
            p=PolicyProject(**{**raw,'tasks':tuple(raw['tasks']),'policy_value_keys':tuple(raw.get('policy_value_keys',())),
                'withdrawal_cleanup_tasks':tuple(raw.get('withdrawal_cleanup_tasks',()))})
            if not all(isinstance(v,str) and v for v in (p.key,p.owner,p.party,p.region)) or len(set(p.tasks))!=len(p.tasks):raise ValueError('Project identities and unique task list required')
            if p.key in world.policy_projects or p.owner not in world.used_personas or not p.tasks:raise ValueError('Invalid policy project identity/owner/tasks')
            if p.scope not in {'operational','legislative'}:raise ValueError('Unknown policy project scope')
            if type(p.review_minutes) is not int or p.review_minutes<=0 or p.review_minutes>world.capacities[p.owner].daily_minutes:raise ValueError('Invalid review attention cost')
            if type(p.review_window_minutes) is not int or p.review_window_minutes<p.review_minutes:raise ValueError('Invalid review window')
            for key in ('minimum_change_pp','noise_multiplier'):
                if isinstance(getattr(p,key),bool) or not math.isfinite(getattr(p,key)) or getattr(p,key)<=0:raise ValueError('Invalid materiality rule')
            unit(p.attribution,'attribution')
            if p.policy_merit is not None and (isinstance(p.policy_merit,bool) or not isinstance(p.policy_merit,(int,float)) or not math.isfinite(p.policy_merit) or not -1<=p.policy_merit<=1):raise ValueError('Policy merit must be an explicitly assumed signed value')
            for key in p.tasks:
                if key not in world.tasks or world.tasks[key].policy_project not in {None,p.key}:raise ValueError('Unknown or multiply owned project task')
                task=world.tasks[key]
                if p.scope=='operational' and (task.operation or (task.node and any(a.intent for a in world.game.nodes[task.node].actions))):raise ValueError('Institutional procedures require legislative scope and legal withdrawal routing')
                world.tasks[key].policy_project=p.key
            for key in (p.revision_task,p.withdrawal_task,*p.withdrawal_cleanup_tasks):
                if key and (key not in world.tasks or world.tasks[key].activation!='conditional'):raise ValueError('Revision/withdrawal requires an explicit conditional task')
                if key in p.tasks:raise ValueError('Procedure/cleanup tasks cannot also be held as project implementation work')
            for key,roles in p.task_action_roles.items():
                if key not in p.tasks or not world.tasks[key].node:raise ValueError('Action semantics require a registered personal project task')
                menu={a.world.key for a in world.game.nodes[world.tasks[key].node].actions}
                if not roles or set(roles)-menu or set(roles.values())-{'continue','pause','revise','withdraw'}:raise ValueError('Unknown task action role')
                if world.tasks[key].owner!=p.owner:raise ValueError('Project action semantics must be chosen by its owner')
                if 'revise' in roles.values() and not p.revision_task:raise ValueError('Revision needs real configured work')
                if 'withdraw' in roles.values() and p.scope=='legislative' and not p.withdrawal_task:raise ValueError('Formal withdrawal needs a procedure task')
            if p.scope=='legislative' and p.withdrawal_task:
                task=world.tasks[p.withdrawal_task]
                if not task.node or not any(a.intent for a in world.game.nodes[task.node].actions):raise ValueError('Formal withdrawal needs an institutional intent/check, not a polling shortcut')
                if not all(a.intent and a.intent.intent_type=='withdraw_bill' and a.intent.actor==p.owner and a.intent.target==p.key
                           for a in world.game.nodes[task.node].actions):raise ValueError('Formal withdrawal must check this actor and this bill, not an unrelated legal action')
                if world.game.objective_check_engine is None or world.game.check_context_provider is None:raise ValueError('Formal withdrawal needs a configured objective check environment')
            world.policy_projects[p.key]=p
        world.game.action_context_adapters.append(self.adapt)
        world.listeners.append(self.on_world_event)
        world.register_event_handler('poll_release',self.publish)
        for raw in config.get('releases',()):self.schedule(raw)
        for raw in config.get('publications',()):self.schedule(raw,modeled=True)

    def schedule(self,raw,modeled=False):
        row=deepcopy(raw)
        required={'id','published_at','series','source','channel','subject','region','standard_error_pp','confidence'}
        if not required<=set(row) or row['id'] in self.releases:raise ValueError('Incomplete or duplicate poll release')
        if row['channel'] not in CHANNEL_VALUES:raise ValueError('Unknown poll channel')
        if not all(isinstance(row[k],str) and row[k] for k in ('id','series','source','subject','region')):raise ValueError('Poll identities must be explicit')
        unit(row['confidence'],'poll confidence')
        if isinstance(row['standard_error_pp'],bool) or not isinstance(row['standard_error_pp'],(int,float)) or not math.isfinite(row['standard_error_pp']) or row['standard_error_pp']<0:raise ValueError('Invalid poll uncertainty')
        published=aware_datetime(row['published_at'])
        if modeled:
            if row['channel'] not in {'party_vote','state_vote'} or not row.get('variable'):raise ValueError('Model party publication requires an explicit party-support variable')
            if 'value_percent' in row:raise ValueError('Model publications cannot prescribe their own result')
            row['evidence_status']='SIMULATION_MEASUREMENT_ASSUMPTION'
        else:
            if row.get('evidence_status') not in {'SIMULATION_ASSUMPTION','OBSERVED'}:raise ValueError('Poll evidence status required')
            if row.get('evidence_status')=='OBSERVED' and (not row.get('source_ids') or published>aware_datetime(self.world.clock.at().isoformat())):raise ValueError('Observed initial evidence needs sources and cannot postdate current world time')
            if not {'value_percent','fieldwork_start','fieldwork_end'}<=set(row):raise ValueError('Explicit publication value and fieldwork interval required')
            if isinstance(row['value_percent'],bool) or not isinstance(row['value_percent'],(int,float)):raise ValueError('Invalid poll percent')
            unit(row['value_percent']/100.,'poll percent')
            start=aware_datetime(row['fieldwork_start']);end=aware_datetime(row['fieldwork_end'])
            if start>end or end>published:raise ValueError('Fieldwork must precede publication')
        signature=(row['series'],row['channel'],row['subject'],row['region'])
        if signature in self.series_sources and self.series_sources[signature]!=row['source']:raise ValueError('Do not mix pollsters inside one comparison series')
        self.series_sources[signature]=row['source']
        recipients=row.get('recipients',sorted({p.owner for p in self.world.policy_projects.values() if self.matches(p,row)}))
        if ('recipients' in row and not recipients) or len(set(recipients))!=len(recipients) or set(recipients)-set(self.profiles):raise ValueError('Unknown/duplicate polling recipients')
        row['recipients']=list(recipients);row['modeled']=modeled
        self.releases[row['id']]=row
        minute=max(self.world.clock.minute,self.world.clock.offset(row['published_at']))
        self.world.clock.schedule(minute,'poll_release',{'id':row['id']},phase=DELIVERY)

    @staticmethod
    def matches(p,row):
        if row['channel']=='personal_approval':return row['subject']==p.owner and row['region']==p.region
        if row['channel']=='policy_support':return row['subject']==p.key and row['region']==p.region
        return row['subject']==p.party and (row['region']==p.region if row['channel'] in {'state_vote','party_base'} else row['region']=='DE')

    def publish(self,world,event):
        row=deepcopy(self.releases[event.data['id']])
        if row['id'] in self.seen:return {'status':'DUPLICATE_IGNORED'}
        if row['modeled']:
            observers=[o for o in world.game.event_observers if hasattr(o,'publication_snapshot')]
            if len(observers)!=1:raise ValueError('Publication needs exactly one polling observer')
            snap=observers[0].publication_snapshot(world.game.state,world.clock.at().isoformat())
            if row['variable'] not in snap['published_percent']:raise ValueError('Unknown publication variable')
            row['value_percent']=snap['published_percent'][row['variable']]
            row['measurement']=snap
        key=f"poll:{row['channel']}:{row['region']}:{row['subject']}:{row['series']}"
        delivered={}
        corrections=[]
        for actor in row['recipients']:
            previous=self.delivered_at.get((actor,key))
            published=aware_datetime(row['published_at'])
            version=self.delivery_versions.get((actor,key,published))
            if previous is not None and published<previous:continue
            beliefs=world.game.information.states[actor].beliefs
            correcting=(previous==published and version is not None and version['forwarded'] and not row.get('forwarded_by'))
            if previous==published and not correcting:continue
            if correcting:
                # A relay and the original poll are the same evidence, not two
                # independent samples. Replace its indirect contribution from
                # the saved pre-report prior, rather than fuse it twice.
                before=version['belief_before']
                if before is None:beliefs.pop(key,None)
                else:beliefs[key]=deepcopy(before)
                corrections.append(actor)
            else:
                before=deepcopy(beliefs.get(key))
            world.game.information.deliver(actor,{key:{'estimate':row['value_percent'],'confidence':row['confidence'],'source':row.get('delivery_source',row['source'])}},message_id=row['id'])
            self.delivered_at[(actor,key)]=published
            self.delivery_versions[(actor,key,published)]={'forwarded':bool(row.get('forwarded_by')),'belief_before':before}
            delivered[actor]=asdict(world.game.information.states[actor].beliefs[key])
            world.notify_information(actor,row['id'])
        self.seen.add(row['id'])
        triggered=[];appraisals={}
        for p in world.policy_projects.values():
            if p.owner not in delivered or p.status not in {'ACTIVE','PAUSED','UNDER_REVIEW'} or not self.matches(p,row):continue
            old=p.latest.get(key)
            if p.owner in corrections and old is not None:
                old=old.get('previous_publication')
            # One independent earlier publication, not a recursive report log.
            previous_publication=({k:deepcopy(v) for k,v in old.items() if k!='previous_publication'} if old else None)
            item={**row,'belief':delivered[p.owner],'observation_key':key,
                  'previous_publication':previous_publication}
            p.latest[key]=item
            p.references.setdefault(key,deepcopy(item))
            if p.owner in corrections and p.references[key]['published_at']==row['published_at']:
                p.references[key]=deepcopy(item)
            if old is None:continue # Unknown prior is an anchor, not an invented collapse.
            change=item['belief']['estimate']-old['belief']['estimate']
            uncertainty=math.hypot(row['standard_error_pp'],old['standard_error_pp'])
            relevant=self.profiles[p.owner]['channel_weights'][row['channel']]*p.attribution*item['belief']['confidence']
            material=abs(change)>=max(p.minimum_change_pp,p.noise_multiplier*uncertainty)
            if material and relevant>0:
                severity=min(1.,abs(change)/max(p.minimum_change_pp,uncertainty))*relevant*self.state_feedback_scale
                candidate={'severity':severity,'delta_pp':change,'channel':row['channel']}
                if p.owner not in appraisals or severity>appraisals[p.owner]['severity']:appraisals[p.owner]=candidate
            if material and relevant>0 and p.pending_review is None:
                if self.request_review(p,row['id']):triggered.append(p.key)
        pss=[]
        for actor,item in appraisals.items():
            if item['severity']<=0:continue
            pss.append(world.game.personas.apply_event(actor,WorldEvent(
                f"poll_appraisal:{key}:{row['published_at']}:{actor}",'published_poll_appraisal',item['severity'],
                ('poll_decline' if item['delta_pp']<0 else 'poll_improvement',),
                valence=-1. if item['delta_pp']<0 else 1.,surprise=0.,
                impact_profile={'pressure':1.,'energy':0.,'confidence':0.,'control':0.,'identity_integrity':0.})))
        record={'release':row,'delivered_beliefs':delivered,'triggered_projects':triggered,
            'same_poll_direct_source_corrections':corrections,
            'status':'PUBLICATION_DELIVERED_NOT_LATENT_TRUTH','pss_updates':pss,
            'state_appraisal':{'scale':self.state_feedback_scale,'status':'UNVALIDATED_MODEL_ASSUMPTION',
                'aggregation':'MAX_RELEVANT_PROJECT_PER_ACTOR_RELEASE_NOT_SUM','only_pressure_directly_modified':True}}
        self.history.append(record)
        return record

    def request_review(self,p,message_id):
        world=self.world
        live=[world.tasks[k] for k in p.tasks if world.tasks[k].status not in {'COMPLETED','COMPLETED_LATE','EXPIRED','CANCELLED','FAILED','BLOCKED','MISSED'}]
        if not live:return False
        # Hold reversible work to make room for an attention-costed review.
        # Protected institutional operations are not mechanically interrupted.
        for task in live:world.suspend_task(task.key,'MATERIAL_POLL_REVIEW:'+message_id)
        p.status='UNDER_REVIEW';p.revision+=1
        key=f'policy_review:{p.key}:{p.revision}';p.pending_review=key
        self.review_nodes[key]=p.key
        actions=self.actions(p)
        world.game.nodes[key]=SimulationNodeV3(key,p.owner,actions,
            {'policy_delivery':1.,'public_mandate':1.,'information_quality':1.},('policy_review',))
        world.submit_task(Task(key,p.owner,world.clock.minute,world.clock.minute+p.review_window_minutes,
            p.review_minutes,node=key,importance=.8,tags=('policy_review',)))
        return True

    def appraisal(self,p):
        channels={}
        for key,item in p.latest.items():
            channel=item['channel']
            if channel not in channels or aware_datetime(item['published_at'])>aware_datetime(channels[channel]['published_at']):channels[channel]=item
        rows=[]
        for channel,item in channels.items():
            reference=p.references[item['observation_key']]
            delta=item['belief']['estimate']-reference['belief']['estimate']
            scale=max(p.minimum_change_pp,2*math.hypot(item['standard_error_pp'],reference['standard_error_pp']))
            weight=self.profiles[p.owner]['channel_weights'][channel]
            belief=self.world.game.information.states[p.owner].beliefs.get(item['observation_key'])
            if belief is not None:delta=belief.estimate-reference['belief']['estimate']
            confidence=belief.confidence if belief is not None else item['belief']['confidence']
            effect=max(-1.,min(1.,delta/scale))*weight*p.attribution*confidence
            rows.append({'channel':channel,'delta_pp':delta,'weight':weight,'effect':effect,'confidence':confidence})
        return {'signal':sum(r['effect'] for r in rows)/len(rows) if rows else 0.,'channels':rows,
            'interpretation':'Disclosed materiality/relevance heuristic, not a calibrated causal effect or real probability'}

    def actions(self,p):
        assessment=self.appraisal(p);signal=assessment['signal']
        merit=p.policy_merit if p.policy_merit is not None else 0.
        public_keys={k for row in assessment['channels'] for k in CHANNEL_VALUES[row['channel']]}
        # Expected effects, not settled public opinion. No poll gains are applied.
        actions=[]
        for role,(progress,public_factor,cost) in REVIEW_EXPECTATIONS.items():
            values={k:progress*merit for k in p.policy_value_keys}
            for k in public_keys:
                if k in values:continue # Do not quietly count the same value twice.
                values[k]=signal*public_factor
            legal=(role!='revise' or bool(p.revision_task)) and (role!='withdraw' or p.scope=='operational' or bool(p.withdrawal_task))
            choice=ActionOption(role,legal=legal,goal_impacts={'policy_delivery':progress*merit,
                'public_mandate':signal*public_factor,'information_quality':.2 if role=='pause' else 0.},
                value_impacts=values,effort=cost,downside=cost,
                conflict_strategy='negotiate' if role=='revise' else 'institutionalize',
                control_domains=('direction','organization','process'),
                identity_tags=('reform',) if role=='continue' else ('deliberation',),
                event_tags=('published_poll','policy_review'),information_confidence=min((r['confidence'] for r in assessment['channels']),default=0.))
            actions.append(WorldAction(PoliticalAction(role,{'immediate':{}}),choice))
        return tuple(actions)

    def adapt(self,node,beliefs,resources,actions):
        key=node.key.removeprefix('living_task:')
        return self.actions(self.world.policy_projects[self.review_nodes[key]]) if key in self.review_nodes else actions

    def on_world_event(self,world,row):
        if row['kind']=='poll_release' and 'release' in row.get('details',{}):
            from .decision_telemetry import SupportPoint
            release=row['details']['release']
            for observer in world.game.event_observers:
                if not hasattr(observer,'telemetry') or not observer.telemetry.events:continue
                observer.telemetry.record_support(SupportPoint(
                    observer.telemetry.events[-1].step,world.clock.at().isoformat(),row['node'],
                    release['subject'],'released_poll',release['channel']+'_published_release',release['region'],
                    release['value_percent'],'percent','OBSERVED' if release['evidence_status']=='OBSERVED' else 'MODEL_ESTIMATE',
                    source_id=(release.get('source_ids') or [release['source']+':'+release['id']])[0],
                    note='Published message delivered to actors; not latent support. '+release['evidence_status']))
        if row['kind'] in {'task_not_executed','deadline_missed'} and row.get('task') in self.review_nodes:
            task=world.tasks[row['task']]
            if task.status in {'EXPIRED','CANCELLED','MISSED','FAILED','BLOCKED'}:
                p=world.policy_projects[self.review_nodes[task.key]]
                if p.pending_review==task.key:
                    p.pending_review=None;p.status='PAUSED'
                    self.history.append({'project':p.key,'status':'PAUSED','reason':'REVIEW_NOT_COMPLETED_NO_PERSONA_DECISION'})
        if row['kind'] in {'task_not_executed','deadline_missed'}:
            task=world.tasks.get(row.get('task'))
            if task and task.status in {'EXPIRED','CANCELLED','MISSED','FAILED','BLOCKED'}:
                for p in world.policy_projects.values():
                    if (task.key==p.revision_task and p.status=='REVISING') or (task.key==p.withdrawal_task and p.status=='WITHDRAWAL_PENDING'):
                        p.status='PAUSED'
                        self.history.append({'project':p.key,'status':'PAUSED','reason':'CONFIGURED_PROCEDURE_NOT_COMPLETED'})
        if row['kind']!='task_completed':return
        task=world.tasks[row['task']]
        if task.key in self.review_nodes:
            p=world.policy_projects[self.review_nodes[task.key]]
            if p.pending_review!=task.key or p.status=='WITHDRAWN':return
            p.pending_review=None
            role=row['decision']['chosen_action']
            self.apply_choice(p,role)
            self.history.append({'project':p.key,'action':role,'status':p.status,'appraisal':self.appraisal(p),
                'profile':self.profiles[p.owner],'choice':'EXISTING_PERSONA_ENGINE','at':world.clock.at().isoformat()})
            world._record('policy_review_settled',details=self.history[-1])
        for p in world.policy_projects.values():
            if task.key in p.task_action_roles and row.get('decision') and task.action_outcome=='SUCCEEDED':
                role=p.task_action_roles[task.key].get(row['decision']['chosen_action'])
                if role:
                    self.apply_choice(p,role)
                    self.history.append({'project':p.key,'action':role,'status':p.status,'appraisal':self.appraisal(p),
                        'profile':self.profiles[p.owner],'choice':'EXPLICIT_PROJECT_ACTION_SEMANTICS',
                        'at':world.clock.at().isoformat()})
                    world._record('policy_action_settled',details=self.history[-1])
            if task.key==p.revision_task and p.status=='REVISING':
                p.status='ACTIVE' if task.action_outcome=='SUCCEEDED' else 'PAUSED'
                if p.status=='ACTIVE':
                    for key in p.tasks:world.restart_task_preparation(key,'REVISION_WORK_COMPLETED_NEW_COMMITMENT_REQUIRED')
            if task.key==p.withdrawal_task and p.status=='WITHDRAWAL_PENDING':
                if task.action_outcome=='SUCCEEDED' and task.institutional_outcome=='EXECUTABLE':self.withdraw(p)
                elif task.action_outcome!='PENDING_PROCEDURE':p.status='PAUSED'
            if p.status=='ACTIVE' and all(world.tasks[k].status in {'COMPLETED','COMPLETED_LATE'} for k in p.tasks):
                p.status='WORK_COMPLETED' # Operational work is not legal enactment.

    def apply_choice(self,p,role):
        world=self.world
        if role=='continue':
            p.status='ACTIVE'
            for key in p.tasks:world.resume_task(key,'PERSONA_CHOSE_CONTINUE')
        else:
            for key in p.tasks:world.suspend_task(key,'PERSONA_CHOSE_'+role.upper())
            if role=='pause':p.status='PAUSED'
            elif role=='revise':p.status='REVISING';self.activate(p.revision_task)
            elif role=='withdraw':
                if p.scope=='legislative':p.status='WITHDRAWAL_PENDING';self.activate(p.withdrawal_task)
                else:self.withdraw(p)

    def activate(self,key):
        task=self.world.tasks[key]
        if task.status!='UNRELEASED':raise ValueError('Configured procedure task already used; supply a new versioned task')
        self.world.clock.schedule(max(self.world.clock.minute+1,task.release),'release',{'task':key})

    def withdraw(self,p):
        pending=p.pending_review;p.pending_review=None
        if pending and pending in self.world.tasks:self.world.cancel_task(pending,'PROJECT_WITHDRAWN_BEFORE_REVIEW')
        p.status='WITHDRAWN'
        for key in p.tasks:self.world.cancel_task(key,'PERSONA_WITHDREW_PROJECT:'+p.key)
        for key in p.withdrawal_cleanup_tasks:self.activate(key)

    def payload(self):
        return {'schema_version':'political-poll-feedback-1.0','projects':{k:asdict(p) for k,p in self.world.policy_projects.items()},
            'profiles':self.profiles,'history':self.history,'polls_never_change_seat_counts':True,
            'default_review_expectations':{k:dict(zip(('policy_progress','expected_public_signal_multiplier','switch_cost'),v)) for k,v in REVIEW_EXPECTATIONS.items()},
            'state_feedback_scale':self.state_feedback_scale,
            'coefficient_status':'UNVALIDATED_MODEL_ASSUMPTIONS'}
