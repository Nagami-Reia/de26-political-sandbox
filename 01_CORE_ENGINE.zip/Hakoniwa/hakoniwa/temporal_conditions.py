"""Small objective predicates; unknown facts are never silently treated as zero."""
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class Condition:
    variable: str
    operator: str
    value: float

    def __post_init__(self):
        if self.operator not in {"ge","gt","le","lt","eq"} or not math.isfinite(self.value):
            raise ValueError("Invalid temporal predicate")

    def evaluate(self,state):
        if self.variable not in state.variables:return None
        actual=state.variables[self.variable].value
        return {"ge":actual>=self.value,"gt":actual>self.value,"le":actual<=self.value,
                "lt":actual<self.value,"eq":actual==self.value}[self.operator]


def conditions_hold(conditions,state):
    values=[(c if isinstance(c,Condition) else Condition(**c)).evaluate(state) for c in conditions]
    if False in values:return False
    return None if None in values else True
