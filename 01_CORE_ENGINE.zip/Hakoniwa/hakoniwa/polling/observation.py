"""Compatibility import; no duplicate observation implementation."""
from ..plugins.polling.observation import *
