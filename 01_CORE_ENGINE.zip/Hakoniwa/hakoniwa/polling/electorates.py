"""Compatibility import; data and implementation live in plugins.polling."""
from ..plugins.polling.electorates import *
if __name__ == "__main__":main()
