"""Compatibility import; no duplicate party functions."""
from ..plugins.polling.party_response import *
