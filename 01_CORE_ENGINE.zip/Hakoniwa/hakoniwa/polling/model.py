"""Compatibility import; no duplicate model implementation."""
from ..plugins.polling.model import *
