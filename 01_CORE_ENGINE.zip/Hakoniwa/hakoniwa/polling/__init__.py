"""Compatibility import only. Implementation lives in plugins.polling."""
from ..plugins.polling import *
