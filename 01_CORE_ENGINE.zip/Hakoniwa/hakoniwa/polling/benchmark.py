"""Compatibility command for the plugin research runner."""
from ..plugins.polling.benchmark import *
if __name__ == "__main__":main()
