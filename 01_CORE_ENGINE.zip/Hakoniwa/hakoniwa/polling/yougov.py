"""Compatibility command for the plugin PDF extractor."""
from ..plugins.polling.yougov import *
if __name__ == "__main__":main()
