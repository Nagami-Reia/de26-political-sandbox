"""Institutional rationality shared by an environment, not an actor trait.

The logic shapes perceived feasibility, deviation cost and expected responses.  It
must never select an action or be added to utility as an arbitrary bonus.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import math
from typing import Mapping


PRIORITY_FIELDS = {
    "governability": "governability_priority",
    "electoral_survival": "electoral_survival_priority",
    "fiscal_efficiency": "fiscal_efficiency_priority",
    "organizational_unity": "organizational_unity_priority",
}


def validate_pressure_exposure(raw: Mapping[str, float]) -> dict[str, float]:
    """Explicit perceived institutional resistance, never inferred from utility."""
    if not isinstance(raw, Mapping) or set(raw) - PRIORITY_FIELDS.keys():
        raise ValueError("institutional_pressure_exposure contains an unknown priority channel")
    result = {}
    for key, value in raw.items():
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= 1:
            raise ValueError("institutional pressure exposures must be finite numbers in 0..1")
        result[key] = float(value)
    return result


def clamp01(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


def q3(value: float) -> float:
    return round(clamp01(value), 3)


@dataclass(frozen=True)
class InstitutionalLogic:
    logic_id: str
    governability_priority: float = 0.000
    electoral_survival_priority: float = 0.000
    fiscal_efficiency_priority: float = 0.000
    organizational_unity_priority: float = 0.000
    necessity_claim_strength: float = 0.000
    alternative_legibility: float = 1.000
    metric_dominance: float = 0.000
    deviation_career_cost: float = 0.000
    legitimacy: float = 0.500
    control_concentration: float = 0.500
    epistemic_status: str = "MODEL_ASSUMPTION"

    def __post_init__(self) -> None:
        for key, value in asdict(self).items():
            if key in {"logic_id", "epistemic_status"}:
                continue
            if not 0.0 <= float(value) <= 1.0:
                raise ValueError(f"{key} must be in 0.000..1.000")

    @classmethod
    def neutral(cls, logic_id: str = "neutral_shadow_logic") -> "InstitutionalLogic":
        """A compatibility default that does not narrow an action repertoire."""
        return cls(logic_id=logic_id)

    @classmethod
    def from_mapping(cls, raw: Mapping[str, object]) -> "InstitutionalLogic":
        return cls(**raw)

    def evolve(
        self,
        *,
        legitimacy_delta: float = 0.0,
        control_concentration_delta: float = 0.0,
        logic_reinforcement: float = 0.0,
        alternative_legibility_delta: float = 0.0,
    ) -> "InstitutionalLogic":
        """Apply slow system feedback; fast political variables live elsewhere."""
        reinforcement = float(logic_reinforcement)
        return replace(
            self,
            legitimacy=clamp01(self.legitimacy + legitimacy_delta),
            control_concentration=clamp01(self.control_concentration + control_concentration_delta),
            necessity_claim_strength=clamp01(self.necessity_claim_strength + 0.100 * reinforcement),
            metric_dominance=clamp01(self.metric_dominance + 0.050 * reinforcement),
            alternative_legibility=clamp01(
                self.alternative_legibility
                + alternative_legibility_delta
                - 0.075 * max(0.0, reinforcement)
            ),
        )

    def payload(self) -> dict:
        return {key: round(value, 3) if isinstance(value, float) else value for key, value in asdict(self).items()}

    def pressure_components(self, exposures: Mapping[str, float]) -> dict[str, float]:
        """Priority salience times declared resistance exposure, not a bonus.

        The caller aggregates these as a dominant-pressure envelope. Missing
        exposure is unmodeled, not proof of zero actual institutional resistance.
        """
        return {key: float(getattr(self, PRIORITY_FIELDS[key])) * value
                for key, value in validate_pressure_exposure(exposures).items()}

