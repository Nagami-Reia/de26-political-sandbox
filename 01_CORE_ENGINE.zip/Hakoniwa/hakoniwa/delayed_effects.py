"""Realized causal obligations, not actors' hoped-for future rewards."""
from .political_state import PoliticalAction
from .temporal_conditions import conditions_hold
from .world_clock import EFFECT
from copy import copy
import math


class DelayedEffectExecutor:
    def __init__(self,world):
        self.world=world;self.scheduled=set();self.history=[]

    def refresh(self):
        w=self.world;now=w.clock.minute
        snapshot=copy(w.game.state);snapshot.variables=dict(w.game.state.variables)
        contributions=[]
        poll_vars={s.state_variable for o in w.game.event_observers for s in getattr(o,"specs",())}
        for row in w.game.state.pending_effects:
            if row.get("status") not in {"SCHEDULED","ACTIVE","PAUSED"}:continue
            if set(row["effects"]) & poll_vars:
                raise ValueError("Deferred facts cannot directly award party support; use narrative/voter response")
            for at in {row["starts_at"],row["ends_at"]}:
                key=(row["effect_id"],at)
                if key not in self.scheduled:
                    if at<now:raise ValueError("A timed effect was not registered with the running clock")
                    if at>now:
                        w.clock.schedule(at,"delayed_effect_boundary",{"effect_id":row["effect_id"]},phase=EFFECT)
                    self.scheduled.add(key)
            if now<row["starts_at"]:continue
            if row["mode"]=="LUMP" and row["starts_at"]==now and w.clock._active_phase is not None and w.clock._active_phase<EFFECT:continue
            condition=conditions_hold(row["conditions"],snapshot)
            if condition is not True:
                if row["on_condition_loss"]=="CANCEL":row["status"]="CANCELLED"
                else:row["status"]="PAUSED"
                row["reason"]="CONDITION_UNKNOWN" if condition is None else "CONDITION_LOST"
            elif row["mode"]=="LUMP":
                contributions.append((row,row["effects"],"lump"))
                row["status"]="REALIZED";row["realized_fraction"]=1.0
            else:row["status"]="ACTIVE"
            if row["mode"]=="ACCRUAL" and now>=row["ends_at"] and row["status"] not in {"CANCELLED","REALIZED"}:
                row["status"]="REALIZED" if row["realized_fraction"]>=1-1e-10 else "PARTIAL"
        self._apply_batch(contributions)

    def elapse(self,start,end):
        contributions=[]
        for row in self.world.game.state.pending_effects:
            if row.get("mode")!="ACCRUAL" or row.get("status")!="ACTIVE":continue
            duration=max(0,min(end,row["ends_at"])-max(start,row["starts_at"]))
            if duration and conditions_hold(row["conditions"],self.world.game.state) is True:
                fraction=duration/(row["ends_at"]-row["starts_at"])
                contributions.append((row,{k:v*fraction for k,v in row["effects"].items()},"accrual"))
                row["realized_fraction"]+=fraction
        self._apply_batch(contributions)

    def _apply_batch(self,contributions):
        if not contributions:return
        keys=sorted({k for _,effects,_ in contributions for k in effects})
        combined={k:math.fsum(effects.get(k,0) for _,effects,_ in contributions) for k in keys}
        state=self.world.game.state
        update=state.apply(PoliticalAction("delayed_batch:"+":".join(r["effect_id"] for r,_,_ in contributions),{"immediate":combined}))
        update["causes"]=[r["effect_id"] for r,_,_ in contributions]
        self.history.append({"contributions":[{"effect_id":r["effect_id"],"kind":kind,"requested_effects":dict(effects),"source_action":r["source_action"]} for r,effects,kind in contributions],
            "settled_at":state.now_minute,"combined_requested_effects":combined,
            "actual_delta":{k:update["after"][k]-update["before"][k] for k in keys}})

    def cancel(self,effect_id,reason):
        row=next(r for r in self.world.game.state.pending_effects if r.get("effect_id")==effect_id)
        if row.get("status") in {"REALIZED","PARTIAL","CANCELLED"}:return False
        row["status"]="CANCELLED";row["reason"]=reason;return True

    def payload(self):return {"history":list(self.history),"policy":"fixed accrual interval; pauses never backfill missed accrual"}
