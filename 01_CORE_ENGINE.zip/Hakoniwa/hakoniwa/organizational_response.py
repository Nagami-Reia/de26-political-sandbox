"""Recipient-side political endorsements, not legal votes or actor intentions.

Support indices, blocs and thresholds are explicit model assumptions, not counts
of members. This service never reads persona scores, beliefs, or a comparator.
"""
from __future__ import annotations

import copy
import hashlib
import math
import random
from dataclasses import asdict, dataclass, field
from typing import Callable, Mapping


def _unit(value: float) -> float:
    if not math.isfinite(value) or not 0 <= value <= 1:
        raise ValueError("Expected a finite value in 0..1")
    return float(value)


def _minute(value: int) -> int:
    if type(value) is not int or value < 0:
        raise ValueError("Expected a nonnegative whole minute")
    return value


@dataclass
class OrganizationalBloc:
    key: str
    weight: float
    support: dict[str, float]
    interests: Mapping[str, float]
    proposer_trust: Mapping[str, float] = field(default_factory=dict)
    response_rate: float = 0.500

    def __post_init__(self):
        _unit(self.weight); _unit(self.response_rate)
        if not self.support or abs(sum(self.support.values()) - 1.0) > 1e-6:
            raise ValueError("Bloc support must sum to one")
        for value in (*self.support.values(), *self.interests.values(), *self.proposer_trust.values()):
            _unit(value)


@dataclass
class PoliticalOrganization:
    key: str
    blocs: tuple[OrganizationalBloc, ...]
    adoption_threshold: float = 0.600
    minimum_margin: float = 0.050
    decision_capacity: float = 1.000
    alignment: str | None = None
    epistemic_status: str = "MODEL_ASSUMPTION_NOT_MEMBER_VOTES"

    def __post_init__(self):
        _unit(self.adoption_threshold); _unit(self.minimum_margin); _unit(self.decision_capacity)
        if not self.blocs or abs(sum(b.weight for b in self.blocs) - 1.0) > 1e-6:
            raise ValueError("Bloc weights must sum to one")
        candidates = set(self.blocs[0].support)
        if len(candidates) < 2 or any(set(b.support) != candidates for b in self.blocs):
            raise ValueError("Every bloc must describe the same candidate set")
        if self.alignment is not None and self.alignment not in candidates:
            raise ValueError("Unknown initial alignment")

    def support(self) -> dict[str, float]:
        return {candidate: sum(b.weight * b.support[candidate] for b in self.blocs)
                for candidate in self.blocs[0].support}


@dataclass(frozen=True)
class OrganizationalRequest:
    request_id: str
    organization: str
    proposer: str
    target: str
    effort: float
    delay_minutes: int
    features: Mapping[str, float] = field(default_factory=dict)

    def __post_init__(self):
        _unit(self.effort); _minute(self.delay_minutes)
        for value in self.features.values():
            if not math.isfinite(value) or not -1 <= value <= 1:
                raise ValueError("Proposal features must be in -1..1")


@dataclass(frozen=True)
class OrganizationalResponse:
    request_id: str
    organization: str
    proposer: str
    target: str
    submitted_at: int
    due_at: int
    resolved_at: int
    status: str
    support_before: Mapping[str, float]
    support_after: Mapping[str, float]
    alignment_before: str | None
    alignment_after: str | None
    realization_fraction: float
    bloc_responses: tuple[dict, ...] = ()
    reason: str = ""

    def payload(self) -> dict:
        return asdict(self)


class OrganizationalResponseEngine:
    """Queue requests; only a due recipient response can mutate its support.

    Randomness is local, seeded recipient-side contingency. A separate stream per
    request keeps unrelated logging/decision draws from changing this response.
    """
    def __init__(self, organizations: Mapping[str, PoliticalOrganization], *,
                 seed: int = 0, contingency_sigma: float = 0.0):
        if not math.isfinite(contingency_sigma) or contingency_sigma < 0:
            raise ValueError("Invalid contingency sigma")
        if any(key != org.key for key, org in organizations.items()):
            raise ValueError("Organization registry key mismatch")
        self.organizations = copy.deepcopy(dict(organizations))
        self.seed, self.contingency_sigma = seed, contingency_sigma
        self.requests: dict[str, dict] = {}
        self.responses: list[OrganizationalResponse] = []
        self.now_minute = 0

    def submit(self, request: OrganizationalRequest, now_minute: int) -> dict:
        _minute(now_minute)
        if now_minute < self.now_minute:
            raise ValueError("Cannot submit in the past")
        org = self.organizations[request.organization]
        if request.target not in org.support():
            raise ValueError("Unknown target")
        existing = self.requests.get(request.request_id)
        if existing is not None:
            if existing["request"] != request:
                raise ValueError("Request id reused for another intention")
            return {key: value for key, value in existing.items() if key != "request"}
        entry = {"request": copy.deepcopy(request), "submitted_at": now_minute,
                 "request_id": request.request_id,
                 "due_at": now_minute + request.delay_minutes, "status": "PENDING"}
        self.requests[request.request_id] = entry
        return {key: value for key, value in entry.items() if key != "request"}

    def advance_to(self, now_minute: int,
                   feature_provider: Callable[[OrganizationalRequest], Mapping[str, float]] | None = None
                   ) -> list[OrganizationalResponse]:
        _minute(now_minute)
        if now_minute < self.now_minute:
            raise ValueError("Time cannot run backwards")
        self.now_minute = now_minute
        due = [row for row in self.requests.values() if row["status"] == "PENDING" and row["due_at"] <= now_minute]
        batches: dict[tuple[int, str], list[dict]] = {}
        for row in due:
            batches.setdefault((row["due_at"], row["request"].organization), []).append(row)
        results = []
        for (_, org_key), rows in sorted(batches.items()):
            org = self.organizations[org_key]
            # No iteration-order winner for simultaneous contradictory requests.
            if len(rows) > 1:
                conflicting = len({row["request"].target for row in rows}) > 1
                status, reason = (("CONTESTED", "SIMULTANEOUS_CONFLICTING_REQUESTS") if conflicting
                                  else ("DEFERRED", "MULTIPLE_REQUESTS_REQUIRE_JOINT_DELIBERATION"))
                for row in rows:
                    result = self._unchanged(org, row, status, reason, now_minute)
                    row["status"] = status; results.append(result)
                continue
            row = rows[0]
            result = self._resolve(org, row, now_minute, feature_provider)
            row["status"] = result.status
            results.append(result)
        self.responses.extend(results)
        return results

    @staticmethod
    def _unchanged(org, row, status, reason, now):
        req = row["request"]
        support = org.support()
        return OrganizationalResponse(req.request_id, org.key, req.proposer, req.target,
            row["submitted_at"], row["due_at"], now, status, dict(support), dict(support),
            org.alignment, org.alignment, 0.0, reason=reason)

    def _resolve(self, org, row, now, feature_provider):
        req = row["request"]
        if org.decision_capacity == 0:
            return self._unchanged(org, row, "DEFERRED", "NO_RECIPIENT_DECISION_CAPACITY", now)
        features = dict(feature_provider(req) if feature_provider else req.features)
        for value in features.values():
            if not math.isfinite(value) or not -1 <= value <= 1:
                raise ValueError("Invalid recipient context")
        seed = int.from_bytes(hashlib.sha256(f"{self.seed}:{req.request_id}".encode()).digest()[:8], "big")
        rng = random.Random(seed)
        before, alignment_before = org.support(), org.alignment
        details = []
        for bloc in org.blocs:
            total = sum(bloc.interests.values())
            fit = sum(weight * features.get(key, 0.0) for key, weight in bloc.interests.items()) / total if total else 0.0
            trust = bloc.proposer_trust.get(req.proposer, 0.500)
            shock = rng.gauss(0, self.contingency_sigma) if self.contingency_sigma else 0.0
            influence = max(-1.0, min(1.0,
                bloc.response_rate * org.decision_capacity * req.effort * trust * fit + shock))
            old = bloc.support[req.target]
            new = old + influence * (1.0 - old) if influence >= 0 else old * (1.0 + influence)
            other_total = 1.0 - old
            for candidate in bloc.support:
                if candidate == req.target:
                    continue
                bloc.support[candidate] = ((bloc.support[candidate] / other_total) * (1.0 - new)
                    if other_total > 1e-12 else (1.0 - new) / (len(bloc.support) - 1))
            bloc.support[req.target] = new
            details.append({"bloc": bloc.key, "fit": fit, "trust": trust,
                            "contingency": shock, "influence": influence,
                            "target_before": old, "target_after": new})
        after = org.support()
        ranking = sorted(after, key=lambda key: (-after[key], key))
        leader, second = ranking[:2]
        adopted = (after[leader] >= org.adoption_threshold and
                   after[leader] - after[second] >= org.minimum_margin)
        if adopted:
            org.alignment = leader
        gain = max(0.0, after[req.target] - before[req.target])
        if adopted and leader == req.target:
            status = "ACCEPTED"
            fraction = (gain / max(1e-12, 1.0 - before[req.target])
                        if alignment_before == req.target else 1.0)
        elif adopted:
            status, fraction = "REJECTED", 0.0
        elif gain > 1e-12:
            status = "PARTIAL"
            fraction = gain / max(1e-12, 1.0 - before[req.target])
        else:
            status, fraction = "REJECTED", 0.0
        return OrganizationalResponse(req.request_id, org.key, req.proposer, req.target,
            row["submitted_at"], row["due_at"], now, status, before, after,
            alignment_before, org.alignment, max(0.0, min(1.0, fraction)), tuple(details))

    def payload(self) -> dict:
        return {"schema_version": "organizational-response-1.0", "now_minute": self.now_minute,
                "organizations": {key: {**asdict(org), "aggregate_support": org.support()}
                                  for key, org in self.organizations.items()},
                "requests": {key: {**{k: v for k, v in row.items() if k != "request"},
                                   "request": asdict(row["request"])} for key, row in self.requests.items()},
                "responses": [row.payload() for row in self.responses]}
