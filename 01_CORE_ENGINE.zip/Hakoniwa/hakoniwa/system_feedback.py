"""Second feedback channel: reproduction, erosion or transformation of a system."""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from copy import deepcopy
import math
from enum import Enum
from statistics import fmean
from typing import Mapping

from .institutional_logic import InstitutionalLogic, clamp01
from .persona_v2 import ActionOption
from .political_agency import AgencyHorizon
from .rationality_evaluation import RationalityEvaluation


class ReproductionType(str, Enum):
    REINFORCEMENT = "REINFORCEMENT"
    ADAPTIVE_REPRODUCTION = "ADAPTIVE_REPRODUCTION"
    EROSION = "EROSION"
    TRANSFORMATION = "TRANSFORMATION"
    MIXED = "MIXED"


@dataclass(frozen=True)
class SystemFeedback:
    operational_success: float
    legitimacy_delta: float
    agency_delta: float
    control_concentration_delta: float
    autonomy_distribution_delta: Mapping[str, float]
    logic_reinforcement: float
    alternative_legibility_delta: float
    reproduction_type: str
    diagnostics: Mapping[str, float]

    def payload(self) -> dict:
        return asdict(self)

    def scaled(self, scale: float) -> "SystemFeedback":
        """Scale changes, not observed success or qualitative classification."""
        values = {name: getattr(self, name)*scale for name in (
            "legitimacy_delta", "agency_delta", "control_concentration_delta",
            "logic_reinforcement", "alternative_legibility_delta")}
        return replace(self, **values,
            autonomy_distribution_delta={k: v*scale for k, v in self.autonomy_distribution_delta.items()},
            diagnostics={**self.diagnostics, "institutional_scale": scale})


@dataclass(frozen=True)
class SystemFeedbackContext:
    causal_event_id: str
    institutional_scale: float
    phase: str = "SETTLED"
    occurred_at_minute: int | None = None

    def __post_init__(self):
        if not isinstance(self.causal_event_id, str) or not self.causal_event_id.strip():
            raise ValueError("causal_event_id must be a nonempty string, not an automatic node counter")
        value = self.institutional_scale
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= 1:
            raise ValueError("institutional_scale must be explicitly declared in 0..1")
        if self.phase not in {"DIAGNOSTIC", "SETTLED"}:
            raise ValueError("feedback phase must be DIAGNOSTIC or SETTLED")
        if self.occurred_at_minute is not None and (type(self.occurred_at_minute) is not int or self.occurred_at_minute < 0):
            raise ValueError("occurred_at_minute must be a nonnegative integer or None")


class SystemFeedbackLedger:
    """Commit discrete causal feedback once; evaluation alone never commits.

    This is not a continuous-time institutional drift model. Context and scale
    are scenario assumptions requiring provenance, not inferred from node count.
    """
    def __init__(self):
        self.events: dict[str, dict] = {}

    def apply(self, feedback: SystemFeedback, context: SystemFeedbackContext | None,
              logic: InstitutionalLogic, agency: AgencyHorizon, *, actor: str,
              enabled: bool, now_minute: int | None = None):
        record = {"applied": False, "context": asdict(context) if context else None,
                  "status": "DISABLED", "model": "DISCRETE_CAUSAL_OUTCOME_V1_UNCALIBRATED"}
        if not enabled:
            return logic, agency, record
        if context is None:
            record["status"] = "MISSING_CAUSAL_CONTEXT"
            return logic, agency, record
        if context.phase != "SETTLED":
            record["status"] = "DIAGNOSTIC_ONLY"
            return logic, agency, record
        if now_minute is not None and (type(now_minute) is not int or now_minute < 0):
            raise ValueError("now_minute must be a nonnegative integer or None")
        if context.occurred_at_minute is not None and now_minute is not None and context.occurred_at_minute > now_minute:
            raise ValueError("Cannot commit future institutional feedback")
        previous = self.events.get(context.causal_event_id)
        if previous is not None:
            if previous["actor"] != actor or previous["context"] != asdict(context):
                raise ValueError("Conflicting actor, scale or timing for an already settled causal event")
            record.update(status="ALREADY_SETTLED", original_applied_at_minute=previous["applied_at_minute"],
                          replay_feedback_changed=previous["raw_feedback"] != feedback.payload())
            return logic, agency, record
        scaled = feedback.scaled(context.institutional_scale)
        # Calculate both new states before consuming the event identifier.
        new_logic = logic.evolve(legitimacy_delta=scaled.legitimacy_delta,
            control_concentration_delta=scaled.control_concentration_delta,
            logic_reinforcement=scaled.logic_reinforcement,
            alternative_legibility_delta=scaled.alternative_legibility_delta)
        new_agency = agency.evolve(agency_delta=scaled.agency_delta)
        record.update(status="APPLIED" if context.institutional_scale > 0 else "ZERO_SCOPE",
                      applied=context.institutional_scale > 0, actor=actor,
                      applied_at_minute=now_minute, raw_feedback=feedback.payload(),
                      scaled_feedback=scaled.payload(),
                      timing_status="DATED" if context.occurred_at_minute is not None else "UNTIMED_DISCRETE")
        self.events[context.causal_event_id] = deepcopy(record)
        return (new_logic, new_agency, record) if record["applied"] else (logic, agency, record)

    def payload(self):
        return {"schema_version": "system-feedback-ledger-1.0", "events": deepcopy(self.events)}

    @classmethod
    def from_payload(cls, payload):
        if not isinstance(payload, dict) or set(payload) != {"schema_version", "events"} or payload["schema_version"] != "system-feedback-ledger-1.0" or not isinstance(payload["events"], dict):
            raise ValueError("Invalid system feedback ledger")
        ledger = cls()
        for key, row in payload["events"].items():
            if not isinstance(row, dict):
                raise ValueError("Invalid feedback ledger entry")
            context = SystemFeedbackContext(**row["context"])
            if context.causal_event_id != key or context.phase != "SETTLED" or row.get("status") not in {"APPLIED", "ZERO_SCOPE"}:
                raise ValueError("Invalid settled causal event")
            if type(row.get("applied")) is not bool or row["applied"] != (context.institutional_scale > 0):
                raise ValueError("Invalid feedback application status")
            ledger.events[key] = deepcopy(row)
        return ledger


class SystemFeedbackAssessor:
    """Generic rule model; scenario files supply action features, not outcomes."""

    def assess(
        self,
        action: ActionOption,
        evaluation: RationalityEvaluation,
        logic: InstitutionalLogic,
        operational_success: float,
    ) -> SystemFeedback:
        success = clamp01(operational_success)
        autonomy_mean = fmean(action.autonomy_impacts.values()) if action.autonomy_impacts else 0.0
        alignment = clamp01(action.necessity_frame_alignment)
        deviation = clamp01(action.institutional_deviation)
        substantive = evaluation.substantive_score

        reinforcement = success * alignment - success * deviation * (0.5 + 0.5 * substantive)
        agency_delta = 0.120 * success * deviation + 0.080 * autonomy_mean - 0.080 * success * alignment
        control_delta = -0.100 * autonomy_mean + 0.060 * success * alignment * logic.metric_dominance
        legitimacy_delta = 0.080 * (success - 0.5) + 0.080 * (substantive - 0.5)
        legibility_delta = 0.100 * success * deviation - 0.075 * success * alignment

        if deviation >= 0.600 and success >= 0.650 and agency_delta > 0.0:
            kind = ReproductionType.TRANSFORMATION
        elif reinforcement >= 0.250 and evaluation.rationality_conflict >= 0.250:
            kind = ReproductionType.ADAPTIVE_REPRODUCTION
        elif reinforcement >= 0.200:
            kind = ReproductionType.REINFORCEMENT
        elif reinforcement <= -0.200:
            kind = ReproductionType.EROSION
        else:
            kind = ReproductionType.MIXED

        return SystemFeedback(
            operational_success=round(success, 3),
            legitimacy_delta=round(legitimacy_delta, 3),
            agency_delta=round(agency_delta, 3),
            control_concentration_delta=round(control_delta, 3),
            autonomy_distribution_delta={key: round(float(value), 3) for key, value in action.autonomy_impacts.items()},
            logic_reinforcement=round(reinforcement, 3),
            alternative_legibility_delta=round(legibility_delta, 3),
            reproduction_type=kind.value,
            diagnostics={
                "necessity_frame_alignment": round(alignment, 3),
                "institutional_deviation": round(deviation, 3),
                "autonomy_mean": round(autonomy_mean, 3),
            },
        )

