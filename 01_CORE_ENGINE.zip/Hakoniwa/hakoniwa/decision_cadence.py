"""Materiality gate between continuous evidence and political decision nodes.

Messages are observations, not decisions.  The gate batches routine reports and
opens a node only when the feasible action set, institutional state, evidential
classification, resource position, or an actual decision deadline changes.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Mapping


@dataclass(frozen=True)
class EvidenceUpdate:
    update_id: str
    at: str
    source: str
    topic: str
    confidence: float
    payload: Mapping[str, Any] = field(default_factory=dict)
    action_menu_changed: bool = False
    institutional_state_changed: bool = False
    decision_required: bool = False
    resource_delta: float = 0.0


@dataclass(frozen=True)
class DecisionBatch:
    node_id: str
    opened_at: str
    trigger_reasons: tuple[str, ...]
    evidence: tuple[EvidenceUpdate, ...]
    prior_evidence_band: str
    current_evidence_band: str

    def payload(self) -> dict[str, Any]:
        return {
            "node_id": self.node_id,
            "opened_at": self.opened_at,
            "trigger_reasons": list(self.trigger_reasons),
            "prior_evidence_band": self.prior_evidence_band,
            "current_evidence_band": self.current_evidence_band,
            "evidence": [asdict(row) for row in self.evidence],
        }


class MaterialDecisionGate:
    """Batch evidence while retaining a complete audit trail."""

    def __init__(self, *, resource_threshold: float = .120) -> None:
        self.resource_threshold = max(0.0, float(resource_threshold))
        self.buffer: list[EvidenceUpdate] = []
        self.audit: list[EvidenceUpdate] = []
        self.last_evidence_band = "UNASSESSED"
        self.node_count = 0

    @staticmethod
    def evidence_band(confidence: float) -> str:
        value = max(0.0, min(1.0, float(confidence)))
        if value < .300:
            return "RUMOUR"
        if value < .600:
            return "PARTIAL"
        if value < .800:
            return "SUBSTANTIAL"
        return "CORROBORATED"

    def ingest(self, update: EvidenceUpdate) -> DecisionBatch | None:
        self.buffer.append(update)
        self.audit.append(update)
        current_band = self.evidence_band(update.confidence)
        reasons: list[str] = []
        consequential_bands = {"SUBSTANTIAL", "CORROBORATED"}
        if (self.last_evidence_band != "UNASSESSED" and current_band != self.last_evidence_band
                and (current_band in consequential_bands or self.last_evidence_band in consequential_bands)):
            reasons.append("EVIDENCE_CLASSIFICATION_CHANGED")
        if update.action_menu_changed:
            reasons.append("ACTION_MENU_CHANGED")
        if update.institutional_state_changed:
            reasons.append("INSTITUTIONAL_STATE_CHANGED")
        if abs(update.resource_delta) >= self.resource_threshold:
            reasons.append("MATERIAL_RESOURCE_CHANGE")
        if update.decision_required:
            reasons.append("DECISION_DEADLINE")
        self.last_evidence_band = current_band
        if not reasons:
            return None
        self.node_count += 1
        batch = DecisionBatch(
            node_id=f"material_node_{self.node_count:02d}",
            opened_at=update.at,
            trigger_reasons=tuple(dict.fromkeys(reasons)),
            evidence=tuple(self.buffer),
            prior_evidence_band=(
                self.evidence_band(self.buffer[0].confidence)
                if len(self.buffer) > 1 else "UNASSESSED"
            ),
            current_evidence_band=current_band,
        )
        self.buffer.clear()
        return batch

    def pending_payload(self) -> list[dict[str, Any]]:
        return [asdict(row) for row in self.buffer]
