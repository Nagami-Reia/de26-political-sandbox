"""Explicit knowledge acquisition on the existing world clock."""
from __future__ import annotations

from copy import deepcopy


class KnowledgeClockService:
    def __init__(self, world, config: dict):
        self.history, self.messages = [], {}
        self.information = world.game.information
        actors = self.information.states
        observable_keys = set(world.game.state.variables) | {f"capital:{key}" for key in world.game.state.capital}
        for actor, observations in config.get("initial_beliefs", {}).items():
            if set(observations)-observable_keys:
                raise ValueError("Unknown initial-belief variable")
            self.information.deliver(actor, observations, message_id=f"prior:{actor}")
        for message in config.get("messages", []):
            key = message["key"]
            if key in self.messages:
                raise ValueError("Duplicate knowledge message")
            if message.get("visibility", "PRIVATE") not in {"PUBLIC", "PRIVATE"}:
                raise ValueError("Invalid knowledge visibility")
            if not message.get("recipients") or set(message["recipients"])-actors.keys():
                raise ValueError("Message needs participating recipients")
            if set(message["observations"])-observable_keys:
                raise ValueError("Unknown reported variable")
            probe = deepcopy(self.information)
            for actor in message["recipients"]:
                probe.deliver(actor, message["observations"], message_id=key)
            self.messages[key] = deepcopy(message)
            world.clock.schedule(world.clock.offset(message["at"]), "knowledge_message", {"key": key})
        world.register_event_handler("knowledge_message", self.deliver)

    def deliver(self, world, event):
        message = self.messages[event.data["key"]]
        received = [self.information.deliver(actor, message["observations"], message_id=message["key"])
                    for actor in message["recipients"]]
        for actor in message["recipients"]:
            world.notify_information(actor,message["key"])
        row = {"key": message["key"], "at": world.clock.at().isoformat(),
               "visibility": message.get("visibility", "PRIVATE"), "recipients": message["recipients"],
               "observations": message["observations"], "beliefs_after": received,
               "status": "SCENARIO_GENERATED", "note": "delivery does not prove the report true"}
        self.history.append(row)
        return row

    def payload(self):
        return {"mode": "DELIVERED_ONLY", "history": self.history,
                "beliefs": {actor: self.information.payload(bs)
                            for actor, bs in self.information.states.items()}}
