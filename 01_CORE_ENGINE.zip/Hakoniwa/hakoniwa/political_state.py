"""Reality, time, political capital, pressure tracks and irreversible route locks."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from copy import deepcopy
from typing import Mapping
import math

HORIZONS=("immediate","medium","long")

@dataclass(frozen=True)
class StateVariable:
    key: str
    value: float
    scale: float=10.0
    uncertainty: float=0.0
    evidence: str="MODEL_STATE"

@dataclass(frozen=True)
class PoliticalAction:
    key: str
    effects: Mapping[str,Mapping[str,float]]
    uncertainty: Mapping[str,Mapping[str,float]]=field(default_factory=dict)
    capital_delta: Mapping[str,float]=field(default_factory=dict)
    pressure_delta: Mapping[str,float]=field(default_factory=dict)
    locks_add: tuple[str,...]=()
    locks_remove: tuple[str,...]=()
    closes_actions: tuple[str,...]=()
    opens_actions: tuple[str,...]=()
    irreversibility: float=0.0
    feasibility: float=1.0
    next_node: str|None=None
    tags: tuple[str,...]=()
    effect_timing: Mapping[str,Mapping]=field(default_factory=dict)
    effect_status: str = "DECLARED"

    def __post_init__(self):
        if not isinstance(self.effect_status, str) or self.effect_status not in {"DECLARED", "REALIZED", "DETERMINISTIC_ASSUMPTION"}:
            raise ValueError("Unknown effect_status")
        if isinstance(self.feasibility, bool) or not isinstance(self.feasibility, (int, float)) or not math.isfinite(self.feasibility) or not 0 <= self.feasibility <= 1:
            raise ValueError("feasibility must be a finite number in 0..1")

    def settlement_basis(self):
        if self.effect_status != "DECLARED":
            return self.effect_status
        if self.feasibility != 1:
            raise ValueError(f"Unresolved effects for {self.key}: feasibility is not an outcome; use a resolver, "
                             "REALIZED evidence, or an explicit DETERMINISTIC_ASSUMPTION")
        return "DETERMINISTIC_DEFAULT"

@dataclass(frozen=True)
class PressureRule:
    track: str
    threshold: float
    event: str
    effects: Mapping[str,float]=field(default_factory=dict)
    locks_add: tuple[str,...]=()

@dataclass
class PoliticalState:
    variables: dict[str,StateVariable]
    capital: dict[str,float]
    pressures: dict[str,float]
    locks: set[str]=field(default_factory=set)
    closed_actions: set[str]=field(default_factory=set)
    pending_effects: list[dict]=field(default_factory=list)
    triggered_events: set[str]=field(default_factory=set)
    history: list[dict]=field(default_factory=list)
    now_minute: int|None=None
    effect_sequence: int=0

    def clone(self): return deepcopy(self)

    def legal(self,action:PoliticalAction):
        return action.key not in self.closed_actions and not any(tag.startswith("requires_lock:") and tag.split(":",1)[1] not in self.locks for tag in action.tags)

    def apply(self,action:PoliticalAction,pressure_rules:tuple[PressureRule,...]=()):
        # Ledger effects must already be settled or explicitly deterministic.
        # This does not turn a feasibility estimate into a success draw.
        basis = action.settlement_basis()
        if set(action.effect_timing)-{h for h in ("medium","long") if action.effects.get(h)}:
            raise ValueError("Timing must reference a nonempty deferred horizon")
        timed=[]
        for horizon in ("medium","long"):
            if not action.effects.get(horizon):continue
            timing=action.effect_timing.get(horizon)
            if timing is None:
                timed.append({"horizon":horizon,"source_action":action.key,"effects":dict(action.effects[horizon]),"status":"UNSCHEDULED"})
                continue
            from .temporal_conditions import Condition
            if self.now_minute is None:raise ValueError("Timed effects require a bound simulation clock")
            delay=timing.get("delay_minutes");duration=timing.get("duration_minutes",0)
            if type(delay) is not int or type(duration) is not int or delay<0 or duration<0 or delay+duration<=0:
                raise ValueError("Explicit positive delay or accrual duration required")
            if timing.get("on_condition_loss","CANCEL") not in {"CANCEL","PAUSE"}:raise ValueError("Unknown condition loss policy")
            if set(action.effects[horizon])-set(self.variables) or any(not math.isfinite(v) for v in action.effects[horizon].values()):raise ValueError("Invalid delayed effect variable/value")
            for c in timing.get("conditions",()):Condition(**c)
            timed.append({"effect_id":f"effect:{self.effect_sequence+len(timed)}","horizon":horizon,
                "source_action":action.key,"registered_at":self.now_minute,"starts_at":self.now_minute+delay,
                "ends_at":self.now_minute+delay+duration,"mode":"ACCRUAL" if duration else "LUMP",
                "effects":dict(action.effects[horizon]),"conditions":list(timing.get("conditions",())),
                "on_condition_loss":timing.get("on_condition_loss","CANCEL"),"status":"SCHEDULED","realized_fraction":0.0})
        before={k:v.value for k,v in self.variables.items()}
        for key,delta in action.effects.get("immediate",{}).items():
            v=self.variables[key]; self.variables[key]=StateVariable(key,max(0,min(100,v.value+delta)),v.scale,v.uncertainty,v.evidence)
        self.pending_effects.extend(timed);self.effect_sequence+=len(timed)
        for key,delta in action.capital_delta.items(): self.capital[key]=max(0,min(100,self.capital.get(key,50)+delta))
        for key,delta in action.pressure_delta.items(): self.pressures[key]=max(0,min(100,self.pressures.get(key,0)+delta))
        self.locks.update(action.locks_add); self.locks.difference_update(action.locks_remove)
        self.closed_actions.update(action.closes_actions); self.closed_actions.difference_update(action.opens_actions)
        fired=[]
        for rule in pressure_rules:
            if self.pressures.get(rule.track,0)>=rule.threshold and rule.event not in self.triggered_events:
                self.triggered_events.add(rule.event); self.locks.update(rule.locks_add); fired.append(rule.event)
                for key,delta in rule.effects.items():
                    v=self.variables[key]; self.variables[key]=StateVariable(key,max(0,min(100,v.value+delta)),v.scale,v.uncertainty,v.evidence)
        event={"action":action.key,"settlement_basis":basis,"declared_feasibility":action.feasibility,"before":before,"after":{k:v.value for k,v in self.variables.items()},"capital":dict(self.capital),"pressures":dict(self.pressures),"locks":sorted(self.locks),"triggered_events":fired}
        self.history.append(event); return event

    def payload(self):
        return {"variables":{k:asdict(v) for k,v in self.variables.items()},"capital":self.capital,"pressures":self.pressures,"locks":sorted(self.locks),"closed_actions":sorted(self.closed_actions),"pending_effects":self.pending_effects,"triggered_events":sorted(self.triggered_events),"history":self.history,"now_minute":self.now_minute,"effect_sequence":self.effect_sequence}
