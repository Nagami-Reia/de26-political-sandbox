"""One actor directory, shared engines. No duplicated actor-specific Python AI.

The registry is the authored source; cards_pss.json remains a generated
compatibility view. Arbitrary old decks/explicit overlays stay independent.
"""
from copy import deepcopy
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent / "data" / "personas"
COMPONENTS = ("behavior", "pss", "resources", "memory", "relationships",
              "voting", "polling", "communication", "rationality", "influence", "evidence")


def _read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _inside(root, relative):
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Persona registry path escapes its root")
    return path


def load_bundle(actor, root=ROOT):
    root = Path(root)
    registry = _read(root / "registry.json")
    if registry.get("schema_version") != "persona-registry-1.0":
        raise ValueError("Unsupported persona registry")
    if actor not in registry["actors"]:
        raise KeyError(f"Unknown registered persona: {actor}")
    folder = _inside(root, registry["actors"][actor])
    manifest = _read(folder / "manifest.json")
    if manifest.get("schema_version") != 'persona-package-1.0' or manifest.get("actor") != actor or set(manifest["components"]) != set(COMPONENTS):
        raise ValueError("Incomplete/mismatched actor manifest")
    components = {}
    for name in COMPONENTS:
        row = _read(_inside(folder, manifest["components"][name]))
        if row.get("actor") != actor or row.get("component") != name:
            raise ValueError(f"Mismatched persona component: {actor}/{name}")
        components[name] = row
    behavior = components["behavior"]
    card = {"name": manifest["name"],
        "fixed_personality": behavior["fixed_personality"],
        "decision_parameters": behavior["decision_parameters"],
        "evidence_confidence": behavior["evidence_confidence"],
        "source_ids": behavior["source_ids"],
        "political_state_system": components["pss"]["profile"],
        "initial_current_state": components["pss"]["initial_state"],
        "initial_resources": components["resources"]["initial_resources"],
        "event_memory": components["memory"]["event_memory"],
        "relationship_memory": components["relationships"]["relationship_memory"]}
    return {"actor": actor, "folder": str(folder), "manifest": manifest,
            "card": card, "components": components}


def assemble_deck(root=ROOT, *, include_components=False):
    root = Path(root)
    registry = _read(root / "registry.json")
    payload = deepcopy(registry["deck_metadata"])
    payload["actors"] = {}
    for actor in registry["actors"]:
        bundle = load_bundle(actor, root)
        payload["actors"][actor] = bundle["card"]
        if include_components:
            payload["actors"][actor]["_components"] = bundle["components"]
    return payload


def load_persona_payload(path):
    path = Path(path)
    if path.is_dir():
        return assemble_deck(path, include_components=True)
    if path.name == "registry.json":
        return assemble_deck(path.parent, include_components=True)
    if path.resolve() == (ROOT / "cards_pss.json").resolve() and (ROOT / "registry.json").exists():
        # Direct legacy JSON readers see the same data as the directory loader.
        # Fail visibly if somebody edits the generated view instead of its source.
        assembled = assemble_deck()
        if assembled != _read(path):
            raise ValueError("Generated cards_pss.json is stale; run python -m hakoniwa.persona_repository export")
        return assemble_deck(include_components=True)
    return _read(path)


def load_rationality_payload(path):
    path = Path(path)
    if path.resolve().parent == ROOT and path.name in {
        "rationality_profiles_v3.json", "rationality_profiles_expansion_2026_09.json"
    } and (ROOT / "registry.json").exists():
        legacy = _read(path)
        result = deepcopy(legacy)
        result["actors"] = {actor: load_bundle(actor)["components"]["rationality"]["profiles"][path.name]
                            for actor in legacy["actors"]}
        if result != legacy:
            raise ValueError("Generated rationality snapshot is stale; export persona repository")
        return result
    return _read(path)


def export(root=ROOT):
    root = Path(root)
    payload = assemble_deck(root)
    (root / "cards_pss.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    for name in ("rationality_profiles_v3.json", "rationality_profiles_expansion_2026_09.json"):
        path = root / name
        payload = _read(path)
        payload["actors"] = {a: load_bundle(a, root)["components"]["rationality"]["profiles"][name]
                             for a in payload["actors"]}
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Inspect or export the modular persona repository")
    parser.add_argument("command", choices=("list", "inspect", "export", "validate"))
    parser.add_argument("actor", nargs="?")
    args = parser.parse_args()
    if args.command == "export":
        export()
        print("Exported compatibility snapshots from the actor directories")
    elif args.command == "inspect":
        if not args.actor:
            parser.error("inspect requires an existing actor ID")
        print(json.dumps(load_bundle(args.actor), ensure_ascii=False, indent=2))
    elif args.command == "validate":
        payload = load_persona_payload(ROOT / "cards_pss.json")
        for name in ("rationality_profiles_v3.json", "rationality_profiles_expansion_2026_09.json"):
            load_rationality_payload(ROOT / name)
        print(json.dumps({"actors": len(payload["actors"]), "status": "CONSISTENT", "behavior_changed": False}))
    else:
        print(json.dumps(_read(ROOT / "registry.json")["actors"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
