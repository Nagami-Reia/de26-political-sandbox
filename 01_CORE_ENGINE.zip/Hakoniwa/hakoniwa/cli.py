"""Dependency-free CLI and JSON protocol for the political sandbox."""
from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
from dataclasses import asdict, fields
from pathlib import Path
from typing import Any, Mapping, Sequence

from .persona_v2 import ActionOption, ActionOutcome, FreeAgentDecisionEngine, WorldEvent
from .plugins.arcana import ArcanaConfig, ArcanaService
from .plugins.arcana.hakoniwa import ArcanaDecisionAdapter
from .political_state_system import quantize3


PACKAGE = Path(__file__).resolve().parent
DEFAULT_CARDS = PACKAGE / "data/personas" / "cards_pss.json"
SCENARIOS = {
    "afd-scandal-event-driven": {
        "module": "hakoniwa.scenarios.afd_scandal_event_driven.run_scenario",
        "description": "Fictional evidence-batched scandal and party-survival stress test",
        "parameters": False,
        "seeded_single": True,
        "output_option": True,
    },
    "berlin-blackout-12h": {
        "module": "hakoniwa.scenarios.berlin_blackout.run_scenario",
        "description": "Fictional three-site Berlin crisis, existing personas, 12-hour seeded single path",
        "parameters": False,
        "seeded_single": True,
    },
    "germany-russia-risk-2026": {
        "module": "hakoniwa.scenarios.germany_russia_risk_2026.run_scenario",
        "description": "Reversible Germany–Russia escalation-risk sandbox",
        "parameters": True,
    },
    "kfrage-2024-blind-replay": {
        "module": "hakoniwa.scenarios.kfrage_2024_blind_replay.run_scenario",
        "description": "Outcome-sanitized replay of the 2024 CDU/CSU candidate-selection process",
        "parameters": True,
        "supports_arcana": False,
        "output_option": True,
    },
    "germany-russia-defence-case": {
        "module": "hakoniwa.scenarios.germany_russia_defence_case.run_scenario",
        "description": "Legacy constitutional defence-case stress scenario",
        "parameters": False,
    },
    "mv-cdu-amthor-aftermath": {
        "module": "hakoniwa.scenarios.mv_cdu_amthor_aftermath.run_scenario",
        "description": "Mecklenburg-Vorpommern CDU succession aftermath",
        "parameters": False,
    },
    "october-2026-three-state": {
        "module": "hakoniwa.scenarios.october_2026_three_state.run_scenario",
        "description": "October 2026 three-state and federal-policy sequence",
        "parameters": False,
    },
}
TUPLE_ACTION_FIELDS = {
    "control_domains", "identity_tags", "event_tags", "risk_tags",
    "required_offices", "required_institutional_permissions",
}
TUPLE_EVENT_FIELDS = {"tags"}
TUPLE_OUTCOME_FIELDS = {"tags"}


def _emit(value: Any, pretty: bool = False) -> None:
    print(json.dumps(quantize3(value), ensure_ascii=False, indent=2 if pretty else None))


def _load_engine(cards: str | Path) -> FreeAgentDecisionEngine:
    return FreeAgentDecisionEngine.from_json(cards)


def _dataclass_from_dict(cls, raw: Mapping[str, Any], tuple_fields: set[str]):
    allowed = {item.name for item in fields(cls)}
    unknown = sorted(set(raw) - allowed)
    if unknown:
        raise ValueError(f"Unknown {cls.__name__} fields: {', '.join(unknown)}")
    values = dict(raw)
    for key in tuple_fields:
        if key in values:
            values[key] = tuple(values[key])
    return cls(**values)


def _action(raw: Mapping[str, Any]) -> ActionOption:
    return _dataclass_from_dict(ActionOption, raw, TUPLE_ACTION_FIELDS)


def _event(raw: Mapping[str, Any]) -> WorldEvent:
    return _dataclass_from_dict(WorldEvent, raw, TUPLE_EVENT_FIELDS)


def _outcome(raw: Mapping[str, Any]) -> ActionOutcome:
    return _dataclass_from_dict(ActionOutcome, raw, TUPLE_OUTCOME_FIELDS)


def _read_json(path: str) -> Any:
    if path == "-":
        return json.load(sys.stdin)
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _apply_history(engine: FreeAgentDecisionEngine, actor: str, history: Sequence[Mapping[str, Any]]) -> list[dict]:
    trace = []
    for index, item in enumerate(history, start=1):
        kind = item.get("type")
        if kind == "event":
            result = engine.apply_event(actor, _event(item["data"]))
        elif kind == "outcome":
            result = engine.apply_outcome(actor, _outcome(item["data"]))
        elif kind == "advance_time":
            result = engine.advance_time(actor, int(item["days"]), float(item.get("workload", 0.0)))
        else:
            raise ValueError(f"history[{index}] has unsupported type: {kind!r}")
        trace.append({"index": index, "type": kind, "result": result})
    return trace


def _decision_payload(
    engine: FreeAgentDecisionEngine,
    actor: str,
    request: Mapping[str, Any],
    arcana: ArcanaService | None = None,
) -> dict:
    if actor not in engine.cards:
        raise ValueError(f"Unknown actor {actor!r}; run `actors` to list valid keys")
    history = _apply_history(engine, actor, request.get("history", ()))
    actions = tuple(_action(item) for item in request.get("actions", ()))
    if not actions:
        raise ValueError("request.actions must contain at least one action")
    decision = engine.decide(
        actor,
        actions,
        request.get("resources", engine.cards[actor].initial_resources),
        current_goals=request.get("goals", {}),
        scene_tags=tuple(request.get("scene_tags", ())),
        soft_resource_constraints=bool(request.get("soft_resource_constraints", False)),
    )
    arcana_payload = {"enabled": False, "status": "DISABLED"}
    selected_action = decision.chosen_action
    if arcana is not None and arcana.config.enabled:
        node_id = str(request.get("node_id", f"cli:{actor}:{engine.runtime[actor].turn}"))
        node_uncertainty = float(request.get(
            "node_uncertainty",
            sum(action.uncertainty for action in actions) / len(actions),
        ))
        counterparty = request.get("conflict_actor")
        interaction_modifier = 0.000
        if counterparty is not None:
            if counterparty not in engine.cards:
                raise ValueError(f"Unknown conflict_actor {counterparty!r}")
            conflict = arcana.run_conflict(
                node_id, actor, str(counterparty),
                engine.cards[actor], engine.runtime[actor],
                engine.cards[str(counterparty)], engine.runtime[str(counterparty)],
            )
            run = arcana.repository.get(conflict["primary_reading"]["run_id"])
            interaction_modifier = conflict["interaction"]["primary_pss_mediation"]["decision_threshold_modifier"]
            reading = conflict["primary_reading"]
        else:
            run = arcana.run_reading(node_id, actor)
            conflict = None
            reading = run.payload()
        normalized_scores = {
            key: 1.000 / (1.000 + math.exp(-max(-60.0, min(60.0, row.total)) / 18.000))
            for key, row in decision.scores.items()
        }
        selected_action, adoption = ArcanaDecisionAdapter().adapt(
            decision.chosen_action, normalized_scores, actions, run.advice,
            engine.cards[actor], engine.runtime[actor], node_uncertainty,
            interaction_modifier,
            arcana.config.influence_cap,
        )
        arcana_payload = {
            "enabled": True,
            "status": "RUN",
            "reading": reading,
            "adoption": adoption,
            "conflict_interaction": conflict,
        }
    return {
        "protocol_version": "hakoniwa-cli-1.0",
        "actor": actor,
        "history_trace": history,
        "decision": asdict(decision),
        "selected_action_after_arcana": selected_action,
        "arcana": arcana_payload,
        "state_after_history": asdict(engine.runtime[actor].state),
        "relationships_after_history": {
            key: asdict(value) for key, value in engine.runtime[actor].relationships.items()
        },
    }


def cmd_actors(args) -> int:
    engine = _load_engine(args.cards)
    rows = [
        {
            "actor": key,
            "name": card.name,
            "archetype": card.dna.archetype,
            "evidence_confidence": card.evidence_confidence,
        }
        for key, card in engine.cards.items()
    ]
    if args.json:
        _emit({"count": len(rows), "actors": rows}, args.pretty)
    else:
        for row in rows:
            print(f'{row["actor"]:12} {row["name"]:24} {row["archetype"]}')
    return 0


def cmd_card(args) -> int:
    engine = _load_engine(args.cards)
    if args.actor not in engine.cards:
        raise ValueError(f"Unknown actor {args.actor!r}")
    card = engine.cards[args.actor]
    payload = {
        "actor": args.actor,
        "name": card.name,
        "fixed_card": {
            "dna": asdict(card.dna),
            "pss_profile": asdict(card.pss_profile),
            "initial_resources": dict(card.initial_resources),
            "evidence_confidence": card.evidence_confidence,
            "source_ids": card.source_ids,
        },
        "initial_runtime": asdict(engine.runtime[args.actor]),
        "component_modules": dict(card.components),
    }
    _emit(payload, args.pretty or not args.json)
    return 0


def cmd_validate(args) -> int:
    engine = _load_engine(args.cards)
    errors = []
    for actor, card in engine.cards.items():
        if len(card.dna.value_hierarchy) < 4:
            errors.append(f"{actor}: fewer than four ranked values")
        if not card.source_ids:
            errors.append(f"{actor}: no source_ids")
        for counterpart, relation in engine.runtime[actor].relationships.items():
            if set(relation.dependency) != {"organizational", "informational", "electoral", "personal_trust"}:
                errors.append(f"{actor}->{counterpart}: incomplete dependency dimensions")
            if set(relation.alternative_capacity) != {"organizational", "informational", "electoral"}:
                errors.append(f"{actor}->{counterpart}: incomplete alternative_capacity dimensions")
    payload = {
        "valid": not errors,
        "actor_count": len(engine.cards),
        "actors": sorted(engine.cards),
        "errors": errors,
    }
    _emit(payload, args.pretty or not args.json)
    return 0 if not errors else 2


def cmd_personas(args) -> int:
    from .persona_repository import ROOT, assemble_deck, export, load_bundle, load_rationality_payload
    if args.operation == 'export':
        export()
        _emit({'status':'EXPORTED_COMPATIBILITY_VIEWS','source':str(ROOT/'actors')},args.pretty)
    elif args.operation == 'inspect':
        if not args.actor:raise ValueError('personas inspect requires --actor')
        bundle=load_bundle(args.actor)
        _emit(bundle['components'][args.component] if args.component else bundle,args.pretty)
    else:
        payload=assemble_deck()
        if args.operation == 'validate':
            from .persona_repository import load_persona_payload
            load_persona_payload(ROOT/'cards_pss.json')
            for name in ('rationality_profiles_v3.json','rationality_profiles_expansion_2026_09.json'):
                load_rationality_payload(ROOT/name)
        _emit({'actors':list(payload['actors']),'count':len(payload['actors']),
            'source':str(ROOT/'actors'),'status':'CONSISTENT' if args.operation=='validate' else 'REGISTERED'},args.pretty)
    return 0


def cmd_decide(args) -> int:
    engine = _load_engine(args.cards)
    arcana = ArcanaService(ArcanaConfig(enabled=args.arcana, master_seed=args.arcana_seed))
    payload = _decision_payload(engine, args.actor, _read_json(args.request), arcana)
    _emit(payload, args.pretty)
    return 0


def cmd_protocol(args) -> int:
    example = {
        "node_id": "example_merz_frei_node",
        "node_uncertainty": 0.650,
        "conflict_actor": "Frei",
        "resources": {"formal_power": 0.900, "organization_base": 0.750},
        "scene_tags": ["authority_challenge"],
        "history": [{
            "type": "event",
            "data": {
                "event_id": "example_shock",
                "event_type": "example_pattern",
                "severity": 0.700,
                "tags": ["authority_challenge"],
                "relationship_deltas": {"Frei": {"trust": -0.150}},
            },
        }],
        "actions": [
            {
                "key": "repair",
                "value_impacts": {"unity": 0.700},
                "upside": 0.500,
                "downside": 0.200,
                "conflict_strategy": "negotiate",
                "target_actor": "Frei",
                "relationship_posture": "repair",
            },
            {
                "key": "set_boundary",
                "value_impacts": {"political_authority": 0.800},
                "upside": 0.650,
                "downside": 0.450,
                "conflict_strategy": "institutionalize",
                "target_actor": "Frei",
                "relationship_posture": "boundary",
            },
        ],
    }
    _emit({
        "protocol_version": "hakoniwa-cli-1.0",
        "usage": "python -m hakoniwa [--arcana --arcana-seed 1773] decide Merz --request request.json --pretty",
        "stdin_usage": "cat request.json | python -m hakoniwa [--arcana] decide Merz --request -",
        "arcana_contract": {
            "default": "disabled",
            "request_fields": ["node_id", "node_uncertainty", "conflict_actor"],
            "conflict_semantics": "independent readings; PSS mediates posture collision; cards never directly mutate PSS",
            "output": "full reading, historical rules, advice derivation, adoption trace, and optional interaction",
        },
        "relationship_postures": ["neutral", "repair", "boundary", "rupture", "comply", "exit"],
        "request_example": example,
    }, True)
    return 0


def cmd_scenarios(args) -> int:
    rows = [{"scenario": key, **value} for key, value in SCENARIOS.items()]
    if args.json:
        _emit({"count": len(rows), "scenarios": rows}, args.pretty)
    else:
        for row in rows:
            print(f'{row["scenario"]:34} {row["description"]}')
    return 0


def cmd_run_scenario(args) -> int:
    spec = SCENARIOS[args.scenario]
    command = [sys.executable, "-m", spec["module"]]
    if spec.get("seeded_single"):
        if args.arcana or args.runs != 10000:
            raise ValueError("This fictional single-path adapter supports --seed, not --runs or ARCANA")
        if args.seed is not None:
            command.extend(["--seed", str(args.seed)])
        if spec.get("output_option"):
            command.extend(["--output", args.output or f"outputs/{args.scenario}"])
    elif spec["parameters"]:
        if args.arcana and not spec.get("supports_arcana", True):
            raise ValueError(f"{args.scenario} deliberately disables ARCANA")
        command.extend(["--runs", str(args.runs)])
        if args.seed is not None:
            command.extend(["--seed", str(args.seed)])
        if args.arcana:
            command.append("--arcana")
        if spec.get("output_option"):
            command.extend(["--output", args.output or f"outputs/{args.scenario}"])
    elif args.seed is not None or args.runs != 10000 or args.arcana:
        raise ValueError(f"{args.scenario} is a legacy fixed scenario and accepts no seed/runs/arcana options")
    return subprocess.run(command, check=False).returncode


def cmd_world(args) -> int:
    from .living_world import LivingPoliticalWorld
    from .living_world_config import load_living_world
    from .world_environment import WorldEnvironment, DEFAULT_ENVIRONMENT
    environment_path = Path(args.environment) if args.environment else None
    if args.config is None or args.inspect_environment:
        _emit(WorldEnvironment.load(environment_path or DEFAULT_ENVIRONMENT).describe(), True)
        return 0
    world, horizon = load_living_world(Path(args.config), args.cards, environment_path)
    if args.arcana:
        world.game.arcana = ArcanaService(ArcanaConfig(enabled=True, master_seed=args.arcana_seed))
    payload = world.run_until(args.until or horizon)
    LivingPoliticalWorld.save(payload, Path(args.output))
    _emit({"timestamp": payload["clock"]["timestamp"],
           "decisions": len(payload["political_decisions"]), "events": len(payload["trace"]),
           "tasks": {key: row["status"] for key, row in payload["tasks"].items()},
           "report": str(Path(args.output).resolve()/"report.html")}, True)
    return 0


def cmd_play(args) -> int:
    """Persistent JSONL mode intended for another AI or orchestration process."""
    engine = _load_engine(args.cards)
    arcana = ArcanaService(ArcanaConfig(enabled=args.arcana, master_seed=args.arcana_seed))
    if args.actor not in engine.cards:
        raise ValueError(f"Unknown actor {args.actor!r}")
    _emit({
        "type": "ready",
        "protocol_version": "hakoniwa-jsonl-1.0",
        "actor": args.actor,
        "commands": ["event", "decide", "outcome", "advance_time", "state", "quit"],
    })
    for line_number, line in enumerate(sys.stdin, start=1):
        if not line.strip():
            continue
        try:
            request = json.loads(line)
            command = request.get("command")
            if command == "event":
                response = engine.apply_event(args.actor, _event(request["data"]))
            elif command == "outcome":
                response = engine.apply_outcome(args.actor, _outcome(request["data"]))
            elif command == "advance_time":
                response = engine.advance_time(args.actor, int(request["days"]), float(request.get("workload", 0.0)))
            elif command == "decide":
                response = _decision_payload(engine, args.actor, request, arcana)
            elif command == "state":
                response = {
                    "state": asdict(engine.runtime[args.actor].state),
                    "relationships": {key: asdict(value) for key, value in engine.runtime[args.actor].relationships.items()},
                    "turn": engine.runtime[args.actor].turn,
                }
            elif command == "quit":
                _emit({"type": "bye", "actor": args.actor})
                return 0
            else:
                raise ValueError(f"Unsupported command: {command!r}")
            _emit({"type": "result", "command": command, "data": response})
        except Exception as exc:  # JSONL keeps the session alive after a bad command.
            _emit({"type": "error", "line": line_number, "error": str(exc)})
    return 0


def cmd_polling(args) -> int:
    from datetime import date
    from .plugins.polling.model import PollingModel, BlendedPublicationModel, BUNDLE
    from .plugins.polling.electorates import ElectorateAtlas, ROOT
    if args.operation == "verify":
        result=PollingModel().verify()
    elif args.operation == "summary":
        result={"integrated_into_original_hakoniwa":True,"reference_bundle_is_frozen":True,
                "party_response_functions":"hakoniwa.polling.party_response",
                "reference_results":json.loads((BUNDLE/"results_index.json").read_text())}
    elif args.operation == "predict":
        if not args.request: raise ValueError("predict requires --request JSON context")
        context=json.loads(Path(args.request).read_text())
        model=BlendedPublicationModel(args.experimental_parameters) if args.experimental_parameters else PollingModel()
        result=model.predict(context)
    elif args.operation == "response":
        from .plugins.polling.party_response import PartyResponseModel
        if not args.request: raise ValueError("response requires --request JSON")
        request=json.loads(Path(args.request).read_text())
        model=PartyResponseModel()
        result=model.functions()[args.party](request) if args.party else model.predict(request)
    elif args.operation == "electorate":
        if not args.state or not args.as_of: raise ValueError("electorate requires --state and --as-of")
        result=ElectorateAtlas().state(args.state,as_of=args.as_of)
    else:
        if not args.as_of: raise ValueError("crosstabs requires --as-of; cannot silently leak future observations")
        result=json.loads((ROOT/"yougov_2026_10.json").read_text())
        if date.fromisoformat(args.as_of) < date.fromisoformat(result["available_from"]):
            raise ValueError("This YouGov source was not established available at the requested cutoff")
    _emit(result,pretty=args.pretty)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="hakoniwa",
        description="Hakoniwa political sandbox: auditable decisions and reproducible scenarios.",
    )
    parser.add_argument("--cards", default=str(DEFAULT_CARDS), help="persona registry, directory or explicit frozen card JSON")
    parser.add_argument("--arcana", action="store_true", help="enable ARCANA Petit Etteilla advisory readings")
    parser.add_argument("--arcana-seed", type=int, default=0, help="master seed for reproducible ARCANA readings")
    sub = parser.add_subparsers(dest="command", required=True)

    personas = sub.add_parser('personas',help='per-person components, evidence and compatibility exports')
    personas.add_argument('operation',choices=('list','inspect','validate','export'))
    personas.add_argument('--actor')
    from .persona_repository import COMPONENTS
    personas.add_argument('--component',choices=COMPONENTS,help='read just one functional module')
    personas.add_argument('--pretty',action='store_true')
    personas.set_defaults(func=cmd_personas)

    majorities = sub.add_parser("majorities", help="member-level organizational votes and pivotal-vote diagnostics")
    majorities.add_argument("operation", choices=("run", "verify", "power", "count"))
    majorities.add_argument("--request", required=True, help="JSON file or - for stdin")
    majorities.add_argument("--output", help="write full-precision result JSON")
    majorities.add_argument("--pretty", action="store_true")
    majorities.set_defaults(func=cmd_majorities)

    polling = sub.add_parser("polling", help="audited poll publication models and electorate evidence")
    polling.add_argument("operation", choices=("verify","summary","predict","response","electorate","crosstabs"))
    polling.add_argument("--request", help="explicit next-release JSON context")
    polling.add_argument("--state", help="two-letter state code, e.g. NW / BY / ST")
    polling.add_argument("--as-of", help="evidence cutoff ISO date; prevents historical information leakage")
    polling.add_argument("--experimental-parameters", help="opt-in validation-selected research blend parameter file")
    polling.add_argument("--party", choices=("Union","SPD","Grüne","FDP","Linke","AfD","BSW","Other"), help="one party's coupled response, with its state breakdown")
    polling.add_argument("--pretty", action="store_true")
    polling.set_defaults(func=cmd_polling)

    actors = sub.add_parser("actors", help="list runnable actors")
    actors.add_argument("--json", action="store_true")
    actors.add_argument("--pretty", action="store_true")
    actors.set_defaults(func=cmd_actors)

    card = sub.add_parser("card", help="show one full card and initial runtime")
    card.add_argument("actor")
    card.add_argument("--json", action="store_true")
    card.add_argument("--pretty", action="store_true")
    card.set_defaults(func=cmd_card)

    validate = sub.add_parser("validate", help="validate the canonical card deck")
    validate.add_argument("--json", action="store_true")
    validate.add_argument("--pretty", action="store_true")
    validate.set_defaults(func=cmd_validate)

    decide = sub.add_parser("decide", help="run one AI-supplied JSON decision request")
    decide.add_argument("actor")
    decide.add_argument("--request", required=True, help="JSON file or - for stdin")
    decide.add_argument("--pretty", action="store_true")
    decide.set_defaults(func=cmd_decide)

    protocol = sub.add_parser("protocol", help="print the AI JSON request contract and example")
    protocol.set_defaults(func=cmd_protocol)

    scenarios = sub.add_parser("scenarios", help="list bundled runnable scenarios")
    scenarios.add_argument("--json", action="store_true")
    scenarios.add_argument("--pretty", action="store_true")
    scenarios.set_defaults(func=cmd_scenarios)

    run_scenario = sub.add_parser("run-scenario", help="run a bundled scenario")
    run_scenario.add_argument("scenario", choices=sorted(SCENARIOS))
    run_scenario.add_argument("--seed", type=int)
    run_scenario.add_argument("--runs", type=int, default=10000)
    run_scenario.add_argument("--output", help="scenario output directory when supported")
    run_scenario.set_defaults(func=cmd_run_scenario)

    world = sub.add_parser("world", help="advance the existing engine through a timed persistent-world schedule")
    world.add_argument("--config", help="scenario inputs layered onto the shared environment")
    world.add_argument("--environment", help="existing political-simulation environment JSON")
    world.add_argument("--inspect-environment", action="store_true", help="inspect shared rules without running a scenario")
    world.add_argument("--until", help="override horizon with an ISO timestamp including UTC offset")
    world.add_argument("--output", default="outputs/living_world")
    world.set_defaults(func=cmd_world)

    play = sub.add_parser("play", help="persistent JSONL session for an AI client")
    play.add_argument("actor")
    play.set_defaults(func=cmd_play)
    return parser


def cmd_majorities(args) -> int:
    from .plugins.majorities.__main__ import execute
    try:
        result = execute(args.operation, _read_json(args.request))
    except (TypeError, OSError) as exc:
        raise ValueError(str(exc)) from exc
    if args.output:
        target = Path(args.output)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
        _emit({"saved": str(target)})
    else:
        _emit(result, pretty=args.pretty)
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except (ValueError, KeyError, json.JSONDecodeError) as exc:
        _emit({"type": "error", "error": str(exc)})
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
