"""Translate a role repertoire into an actor-specific consideration set."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, replace
from typing import Mapping, Sequence

from .action_repertoire import RepertoireAssessment
from .institutional_logic import InstitutionalLogic, clamp01
from .persona_v2 import ActionOption
from .political_agency import AgencyHorizon


@dataclass(frozen=True)
class PerceivedAction:
    action: str
    objective_status: str
    role_status: str
    perceived_status: str
    perceived_feasibility: float
    information_confidence: float
    alternative_legibility_factor: float
    carrier_access: float
    deviation_survivability: float
    reasons: tuple[str, ...]
    execution_feasibility: float = 1.000
    political_success_expectation: float = 1.000
    consideration_strength: float = 1.000
    expectation_source: str = "LEGACY_OBJECTIVE_FEASIBILITY"
    execution_source: str = "ROLE_AND_RESOURCE_ONLY_DEFAULT"
    priority_pressure: float = 0.000
    priority_pressure_components: Mapping[str, float] = field(default_factory=dict)
    priority_pressure_status: str = "UNMODELED_NO_EXPOSURE"
    institutional_support_survivability: float = 1.000
    priority_pressure_exposure: Mapping[str, float] = field(default_factory=dict)
    priority_pressure_model: str = "DOMINANT_ENVELOPE_V1_UNCALIBRATED"

    def payload(self) -> dict:
        return asdict(self)

    def for_scoring(self, action: ActionOption) -> ActionOption:
        """Bind subjective channels once, without converting beliefs to truth."""
        return replace(
            action,
            # Resource coverage is applied once by persona.score, not folded
            # into this parameter and then applied again there.
            execution_feasibility=action.execution_estimate,
            political_success_expectation=self.political_success_expectation,
            information_confidence=self.information_confidence,
        )


class ActionPerceptionFilter:
    def __init__(self, serious_consideration_threshold: float = 0.250):
        self.threshold = clamp01(serious_consideration_threshold)

    def apply(
        self,
        actions: Sequence[ActionOption],
        repertoire: Mapping[str, RepertoireAssessment],
        logic: InstitutionalLogic,
        agency: AgencyHorizon,
        resources: Mapping[str, float],
        information_confidence: float = 1.000,
    ) -> dict[str, PerceivedAction]:
        result: dict[str, PerceivedAction] = {}
        for action in actions:
            role = repertoire[action.key]
            deviation = clamp01(action.institutional_deviation)
            info = min(clamp01(information_confidence), clamp01(action.information_confidence))
            # Overlapping resource requirements belong to the execution layer;
            # do not deduct the identical shortage again as political support.
            carrier_rows = []
            for key, need in action.organizational_carrier_requirements.items():
                have = max(0.0, float(resources.get(key, 0.0)))
                coverage = min(1.0, have / need) if need > 0.0 else 1.0
                execution_need = action.required_resources.get(key, 0.0)
                if execution_need > 0.0:
                    execution_coverage = min(1.0, have / execution_need)
                    coverage = (min(1.0, coverage / execution_coverage)
                                if execution_coverage > 0.0 else 1.0)
                carrier_rows.append(coverage)
            action_carrier = sum(carrier_rows) / len(carrier_rows) if carrier_rows else 1.0
            carrier_access = (
                min(action_carrier, agency.access_to_organizational_carrier)
                if action.organizational_carrier_requirements else 1.0
            )
            alternative_factor = 1.0 - deviation * (1.0 - logic.alternative_legibility)
            deviation_survivability = 1.0 - (
                deviation
                * logic.necessity_claim_strength
                * logic.deviation_career_cost
                * (1.0 - 0.5 * agency.confidence_in_deviation)
            )
            components = logic.pressure_components(action.institutional_pressure_exposure)
            priority_pressure = max(components.values(), default=0.0)
            # Conservative envelope: the four channels are not assumed to be
            # independent shocks. Nor count a possibly overlapping career cost
            # twice. This is a declared, uncalibrated perception-model closure.
            support_survivability = min(deviation_survivability, 1.0-priority_pressure)
            agency_factor = 1.0 - deviation * (
                1.0
                - (
                    agency.perceived_alternatives
                    + agency.collective_change_expectation
                )
                / 2.0
            )
            execution = clamp01(action.execution_estimate * role.resource_coverage)
            political_success = clamp01(
                action.political_success_estimate * carrier_access * support_survivability
            )
            # Legibility and perceived alternatives can narrow consideration;
            # poor evidence or weak odds of winning cannot make a speech,
            # request, investigation, or negotiation cease to be an option.
            consideration = clamp01(alternative_factor * agency_factor)
            if role.role_status != "AVAILABLE":
                execution = 0.0
            # Compatibility alias now means execution only, never a confidence
            # times success times feasibility product.
            perceived = execution
            reasons = list(role.reasons)
            if alternative_factor < 0.650:
                reasons.append("low_alternative_legibility")
            if carrier_access < 0.650:
                reasons.append("low_organizational_carrier")
            if deviation_survivability < 0.650:
                reasons.append("high_deviation_cost")
            if priority_pressure > 0:
                reasons.append("declared_institutional_priority_pressure")
            if agency.collective_change_expectation < 0.350 and deviation > 0.0:
                reasons.append("low_collective_change_expectation")
            if info < 0.650:
                reasons.append("low_information_confidence")
            if political_success < 0.250:
                reasons.append("low_expected_political_success")
            if action.required_resources.keys() & action.organizational_carrier_requirements.keys():
                reasons.append("overlapping_resource_requirements_counted_once")
            status = (
                "UNAVAILABLE"
                if role.role_status != "AVAILABLE"
                else "NOT_EXECUTABLE"
                if execution <= 0.0
                else "CONSIDERED"
                if consideration >= self.threshold
                else "NOT_SERIOUSLY_CONSIDERED"
            )
            if status == "NOT_SERIOUSLY_CONSIDERED":
                reasons.append("low_alternative_legibility_or_agency")
            if status == "NOT_EXECUTABLE":
                reasons.append("no_execution_capacity")
            result[action.key] = PerceivedAction(
                action=action.key,
                objective_status=role.objective_status,
                role_status=role.role_status,
                perceived_status=status,
                perceived_feasibility=round(perceived, 3),
                information_confidence=round(info, 3),
                alternative_legibility_factor=round(alternative_factor, 3),
                carrier_access=round(carrier_access, 3),
                deviation_survivability=round(deviation_survivability, 3),
                reasons=tuple(dict.fromkeys(reasons)),
                execution_feasibility=round(execution, 3),
                political_success_expectation=round(political_success, 3),
                consideration_strength=round(consideration, 3),
                expectation_source=("EXPLICIT_POLITICAL_SUCCESS_EXPECTATION"
                                    if action.political_success_expectation is not None
                                    else "LEGACY_OBJECTIVE_FEASIBILITY"),
                execution_source=("EXPLICIT_EXECUTION_FEASIBILITY"
                                  if action.execution_feasibility is not None
                                  else "ROLE_AND_RESOURCE_ONLY_DEFAULT"),
                priority_pressure=round(priority_pressure, 3),
                priority_pressure_components={key: round(value, 3) for key, value in components.items()},
                priority_pressure_status=("MODELED_EXPOSURE" if components else "UNMODELED_NO_EXPOSURE"),
                institutional_support_survivability=round(support_survivability, 3),
                priority_pressure_exposure=dict(action.institutional_pressure_exposure),
            )
        return result
