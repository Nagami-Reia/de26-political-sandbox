"""CLI for modular personas (kept separate from the eagerly imported loader)."""
from .persona_repository import main

if __name__ == '__main__':
    main()
