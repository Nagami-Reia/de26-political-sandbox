"""Fog-of-war: transform one reality into actor-specific belief states."""
from __future__ import annotations
import random
import math
from copy import deepcopy
from dataclasses import dataclass,field,asdict
from typing import Mapping
from .political_state import PoliticalState

@dataclass(frozen=True)
class AccessRule:
    access: float
    bias: float=0.0
    noise: float=0.0
    source: str="public"

@dataclass
class Belief:
    estimate: float
    confidence: float
    source: str
    last_truth: float|None=None

@dataclass
class BeliefState:
    actor: str
    beliefs: dict[str,Belief]=field(default_factory=dict)
    source_trust: dict[str,float]=field(default_factory=dict)

class InformationFilter:
    def __init__(self,rules:Mapping[str,Mapping[str,AccessRule]],seed:int=0,stochastic:bool=False, *, delivery_only:bool=False):
        self.rules={a:dict(v) for a,v in rules.items()}; self.rng=random.Random(seed); self.stochastic=stochastic
        self.states={a:BeliefState(a) for a in rules}
        self.delivery_only = delivery_only
        self.deliveries = []

    def observe(self,actor:str,state:PoliticalState,commit:bool=False):
        """Preview on private belief/RNG copies; advance both only on commit.

        A preview is not a new independent information sample. Identical state
        and RNG checkpoints produce identical views, regardless of how many
        counterfactual actions are inspected. Gaussian cache is copied too.
        """
        # Counterfactual branches must never leak back into an actor's real beliefs.
        bs=self.states[actor] if commit else deepcopy(self.states[actor]); rules=self.rules.get(actor,{})
        if self.delivery_only:
            # World changes and hypothetical branches cannot grant fresh knowledge.
            return bs
        rng = self.rng
        if self.stochastic and not commit:
            rng = random.Random(0)
            rng.setstate(self.rng.getstate())
        for key,var in state.variables.items():
            r=rules.get(key,AccessRule(.35,0,var.uncertainty,"public")); trust=bs.source_trust.get(r.source,.75)
            # No observation is not a low-confidence observation of the truth.
            # Do this before drawing noise, reading value, or touching priors.
            effective_access = r.access * trust * (1-var.uncertainty)
            if r.access <= 0 or effective_access <= 0:
                continue
            noise=rng.gauss(0,r.noise) if self.stochastic else 0.0
            estimate=max(0,min(100,var.value+r.bias+noise))
            confidence=max(.05,min(.99,effective_access))
            prior=bs.beliefs.get(key)
            if prior:
                alpha=confidence/(confidence+prior.confidence)
                estimate=alpha*estimate+(1-alpha)*prior.estimate
                confidence=max(prior.confidence*.85,confidence)
            # Objective truth belongs to world/audit state, never actor memory.
            bs.beliefs[key]=Belief(round(estimate,4),round(confidence,4),r.source)
        return bs

    def deliver(self, actor:str, observations:Mapping[str,dict], *, message_id:str):
        """Receive reported estimates, not objective state. Rumours may be false."""
        if actor not in self.states:
            raise ValueError("Unknown information recipient")
        validated = {}
        for key, item in observations.items():
            estimate, confidence = float(item["estimate"]), float(item["confidence"])
            if not math.isfinite(estimate) or not 0 <= estimate <= 100 or not math.isfinite(confidence) or not 0 <= confidence <= 1:
                raise ValueError("Invalid observation estimate/confidence")
            validated[key] = (estimate, confidence, str(item["source"]))
        bs = self.states[actor]
        for key, (estimate, confidence, source) in validated.items():
            confidence *= bs.source_trust.get(source, .75)
            prior = bs.beliefs.get(key)
            if prior and confidence+prior.confidence > 0:
                alpha = confidence/(confidence+prior.confidence)
                estimate = alpha*estimate+(1-alpha)*prior.estimate
                confidence = max(prior.confidence*.85, confidence)
            # last_truth deliberately absent: only the objective audit knows it.
            bs.beliefs[key] = Belief(round(estimate, 4), round(confidence, 4), source)
        self.deliveries.append({"message_id": message_id, "actor": actor,
                                "observations": deepcopy(dict(observations))})
        return self.payload(bs)

    def reveal(self,actor:str,key:str,truth:float):
        bs=self.states[actor]; b=bs.beliefs.get(key)
        if not b:return
        error=abs(b.estimate-truth); old=bs.source_trust.get(b.source,.75)
        bs.source_trust[b.source]=max(.1,min(.99,.8*old+.2*max(0,1-error/20)))

    @staticmethod
    def payload(bs:BeliefState): return {"actor":bs.actor,"beliefs":{k:asdict(v) for k,v in bs.beliefs.items()},"source_trust":bs.source_trust}
