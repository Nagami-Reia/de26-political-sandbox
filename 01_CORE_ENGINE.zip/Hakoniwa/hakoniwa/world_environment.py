"""Reusable environment policy. Scenario incidents live in separate inputs."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import json
import math
from pathlib import Path

from .simulation_orchestrator import LayeredConfiguration
from .external_environment import ExternalEnvironment

PACKAGE = Path(__file__).resolve().parent
DEFAULT_ENVIRONMENT = PACKAGE / "data/environments/2026-07-31/environment.json"


@dataclass(frozen=True)
class SchedulingRules:
    persona_weight: float = .600
    urgency_weight: float = .250
    importance_weight: float = .150
    energy_cost_per_daily_budget: float = .080
    deadline_severity_base: float = .200
    deadline_severity_importance: float = .400

    def __post_init__(self):
        if any(not math.isfinite(v) or not 0 <= v <= 1 for v in self.__dict__.values()):
            raise ValueError("Scheduling parameters must be finite numbers in 0..1")
        if not math.isclose(self.persona_weight+self.urgency_weight+self.importance_weight, 1):
            raise ValueError("Agenda weights must sum to 1")
        if self.deadline_severity_base+self.deadline_severity_importance > 1:
            raise ValueError("Deadline severity cannot exceed 1")


@dataclass
class WorldEnvironment:
    path: Path
    facts: dict
    rules: dict
    layered: LayeredConfiguration
    external: ExternalEnvironment | None = None

    @classmethod
    def load(cls, path: Path = DEFAULT_ENVIRONMENT) -> "WorldEnvironment":
        path = path.resolve()
        facts = json.loads(path.read_text(encoding="utf-8"))
        reference = facts.get("living_world_rules")
        rules_path = path.parent/reference if reference else PACKAGE/"data/environments/shared/living_world_rules.json"
        rules = json.loads(rules_path.read_text(encoding="utf-8"))
        if rules.get("schema_version") != "living-world-rules-1.0":
            raise ValueError("Expected living-world-rules-1.0")
        SchedulingRules(**rules.get("scheduling", {}))
        external = ExternalEnvironment(rules_path.parent/rules["external_environment"]) if rules.get("external_environment") else None
        return cls(path, facts, rules, LayeredConfiguration.from_environment_json(path), external)

    def capacities_for(self, participants: list[str], persona_keys: set[str], overrides: dict) -> dict:
        result = {}
        for key in sorted(set(participants) | set(overrides)):
            kind = "person" if key in persona_keys else "organization"
            row = deepcopy(self.rules["capacity_defaults"][kind])
            row["calendar"] = deepcopy(self.rules["calendar"])
            if kind == "organization":
                profile = self.rules.get("organization_profiles", {}).get(key, {})
                row.update({k: v for k, v in profile.items() if k != "calendar"})
                row["calendar"].update(profile.get("calendar", {}))
            override = overrides.get(key, {})
            row.update({k: v for k, v in override.items() if k != "calendar"})
            row["calendar"].update(override.get("calendar", {}))
            result[key] = row
        return result

    def describe(self) -> dict:
        return {"environment_id": self.facts["environment_id"],
                "historical_cutoff": self.facts.get("cutoff"),
                "runtime_profile": self.rules, "institutional_matrix": self.layered.matrix.payload(),
                "external_environment": self.external.payload() if self.external else None,
                "mode": "SHARED_ENVIRONMENT_NO_SCENARIO_LOADED",
                "interfaces": ["history_to_generated_decision_space", "media_to_audience_to_polling", "parliament_to_vote_feedback",
                    "prepare_commit_execute_realize","conditional_opportunity_and_delivered_timing_beliefs"],
                "scenario_required_fields": ["start", "until", "variables", "poll_variables"],
                "scenario_optional_inputs": ["tasks", "nodes", "events", "history", "media", "parliament",
                    "opportunity_windows","timing_reports","waiting_policies","polling_plugin","poll_feedback","persona_communication"]}
