@echo off
py -3 -m hakoniwa %*
