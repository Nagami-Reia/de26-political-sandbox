"""Independently verify SHA-256, manifests, coverage and optional portable tests."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tempfile
import zipfile


def digest(content):return hashlib.sha256(content).hexdigest()


def verify(shelf, *, smoke=False):
    shelf=Path(shelf)
    expected={}
    for line in (shelf/'SHA256SUMS.txt').read_text().splitlines():
        sha,name=line.split('  ',1)
        if not re.fullmatch('[0-9a-f]{64}',sha) or Path(name).name!=name or name in expected:
            raise ValueError('Malformed or duplicate checksum entry')
        expected[name]=sha
    actual={p.name for p in shelf.glob('*.zip')}
    if set(expected)!=actual:raise ValueError('Archive list differs from SHA256SUMS')
    release=json.loads((shelf/'RELEASE_MANIFEST.json').read_text())
    if {r['file']:r['sha256'] for r in release['archives']}!=expected:
        raise ValueError('Release manifest disagrees with independent checksum file')
    inventories={};rows=[]
    for name,sha in expected.items():
        path=shelf/name
        if digest(path.read_bytes())!=sha:raise ValueError('Archive SHA-256 mismatch: '+name)
        with zipfile.ZipFile(path) as z:
            if z.testzip() is not None:raise ValueError('ZIP CRC error: '+name)
            names=z.namelist()
            if len(names)!=len(set(names)):raise ValueError('Duplicate ZIP entries')
            for member in names:
                p=PurePosixPath(member)
                if p.is_absolute() or '..' in p.parts or not member.startswith('Hakoniwa/'):
                    raise ValueError('Unsafe/nonportable archive path')
                if any(part in {'__pycache__','.git','.DS_Store','outputs','output'} for part in p.parts) or p.suffix in {'.pyc','.pyo'}:
                    raise ValueError('Generated output/cache included: '+member)
            manifest=json.loads(z.read('Hakoniwa/BUNDLE_MANIFEST.json'))
            if manifest['version']!=release['version']:raise ValueError('Mixed archive versions')
            declared={'Hakoniwa/'+r['path']:r for r in manifest['files']}
            if len(declared)!=len(manifest['files']) or set(names)!=set(declared)|{'Hakoniwa/BUNDLE_MANIFEST.json'}:
                raise ValueError('ZIP contents differ from per-file manifest')
            for member,record in declared.items():
                content=z.read(member)
                if len(content)!=record['bytes'] or digest(content)!=record['sha256']:
                    raise ValueError('Inner file SHA-256 mismatch: '+member)
            inventories[name]={k:v['sha256'] for k,v in declared.items()}
            rows.append({'archive':name,'bytes':path.stat().st_size,'files':len(declared),
                         'sha256':sha,'crc':'PASS','inner_sha256':'PASS'})
    full=inventories['00_FULL_PORTABLE_APP.zip']
    category={}
    for name,files in inventories.items():
        if name=='00_FULL_PORTABLE_APP.zip':continue
        for member,sha in files.items():
            if full.get(member)!=sha:raise ValueError('Category/full content conflict: '+member)
            category[member]=sha
    if set(category)!=set(full):raise ValueError('Some full-package sources have no category')
    report={'version':release['version'],'status':'PASS','archives':rows,
        'complete_category_coverage':True,'source_files':len(full),
        'max_archive_below_github_browser_25_mib':max(r['bytes'] for r in rows)<25*1024*1024}
    if smoke:
        with tempfile.TemporaryDirectory(prefix='hakoniwa-release-',dir='/private/tmp' if Path('/private/tmp').exists() else None) as temp:
            with zipfile.ZipFile(shelf/'00_FULL_PORTABLE_APP.zip') as z:z.extractall(temp)
            root=Path(temp)/'Hakoniwa'
            env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(root)}
            commands=[['-m','hakoniwa','validate','--pretty'],
                ['-m','hakoniwa','personas','validate','--pretty'],
                ['-m','unittest','discover','-s','hakoniwa/tests','-q']]
            results=[]
            for cmd in commands:
                result=subprocess.run([sys.executable,*cmd],cwd=root,env=env,capture_output=True,text=True,timeout=180)
                item={'command':'python '+ ' '.join(cmd),'exit_code':result.returncode,
                      'stdout':result.stdout,'stderr':result.stderr}
                results.append(item)
                if result.returncode:
                    raise RuntimeError('Extracted portable check failed: '+json.dumps(item,ensure_ascii=False))
            report['extracted_portable_checks']=results
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--shelf',type=Path,default=Path(__file__).resolve().parent/'github_shelf')
    parser.add_argument('--smoke',action='store_true',help='extract and run CLI checks and the full test suite')
    args=parser.parse_args()
    result=verify(args.shelf,smoke=args.smoke)
    (args.shelf/'VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
