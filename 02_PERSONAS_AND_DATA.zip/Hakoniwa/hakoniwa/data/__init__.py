"""Versioned personas, party profiles, environments, calibration and research data."""
