# 公共政治环境与情景输入

公共环境直接接入原来的 `hakoniwa`，入口为 `python3 -m hakoniwa world`。

2026-10-15新增外部环境研究层：36份一手资料、27条证据记录，详见 [现实考据与边界](../research/external_environment/SOURCE_NOTES_CN.md)。`shared/external_environment.json`声明六层职责、官方日程参考和未实现项，不保存人格或未来结局。

## 环境保存什么

现有历史环境继续保存职位、组织结构、制度矩阵、制度逻辑和资料截止时间。它通过 `living_world_rules` 引用 `shared/living_world_rules.json`，增加所有情景共用的运行规则：

- 时区、工作日历和程序窗口约束；
- 个人注意力和组织执行容量默认值；
- 待办排序、能量消耗和逾期压力系数；
- 历史压力检查节奏；
- 媒体收集窗口、传播选择所需时间；意见响应不再有默认支持率换算系数；
- 议会必须具备明确席位和表决窗口的要求。

规则文件不保存某次会议、战争、人物选项或未来结果。容量与时间系数均标记为模型假设；默认工作日历不是官方Bundestag日程。`world_environment.py` 提供同一份规则与制度配置，人物和政党继续使用原有模型。

## 一次运行另外提供什么

情景输入说明起点、观察期限、初始变量与民调锚点，再按需要提供事件、历史因素、策略效果假设、叙事候选、议会席位和程序窗口。它可覆盖个别容量，覆盖项写入输出。

`examples/living_world.json` 是原并发调度测试。`examples/shared_world_inputs.json` 是新的集成验证输入，采用缩小的10席议会；所有数值均为合成假设。它没有手写的人物决策节点，人物待办由历史压力与媒体回应生成。

## 历史压力 → 生成事务 → 人物决策

`HistoricalClockService` 按配置间隔调用原 `HistoricalWorldEngine`。长期、中期、短期因素按该间隔推进，不会每记录一条新闻就推进一轮。

每轮先从世界读取显式绑定的系统变量与风险基线，评估既有机制与触发器。未跨阈值就不生成事务。符合条件的事件按职责路由进入人物待办，并竞争有限注意力。

具体行动菜单由原 `DecisionSpaceGenerator` 在处理时生成，再交给原v3人物选择与结果结算。输入声明各策略可能的影响与不确定性，不能指定人物选哪项或结果必然成功。

同类事件使用显式冷却时间。外部事件通过 `trigger_routes` 变成一次性触发器，在下一轮历史检查中消费，不会被复制为未来每轮的“新证据”。行动和投票改变世界变量后，下一轮检查会读取新状态。

## 事件/决定 → 叙事选择 → 受众 → 民调

`MediaClockService` 通过明确的 `event_routes / history_routes / decision_routes` 判断哪些事实进入媒体议程，不假定每项内部工作立即公开。

人物收到媒体待办，与原议程竞争时间。菜单由原 `NarrativeMoveGenerator` 提供，包括沉默；人物按原v3逻辑选择。AFD等外部政党通过 `PartyInterestEngine` 选择，使用候选叙事声明的共同利益与策略影响，不添加虚构人物PSS。

窗口关闭后，原 `NarrativeArena` 统一结算实际完成的传播动作，考虑证据、来源信任、渠道、受众身份和认知惯性。只有受众反馈能通过绑定改变党派支持。迟到的传播不能进入已结束的反应轮次。现在未给定`media.opinion_response`时只保存认知结果；试验响应必须逐目标给出假设增益、变化上限、延迟和理由。该桥接器尚未实证拟合。

## 知识获取与世界自主性

共享链默认只使用已送达知识。旧`information` access规则不再代表已读过事实，须迁移到`knowledge.initial_beliefs`或`knowledge.messages`。旧引擎构造器保持兼容，不自动迁移旧场景。

```json
{
  "knowledge": {
    "initial_beliefs": {"Frei": {}},
    "messages": [{
      "key": "staff_report_1",
      "at": "2026-10-19T09:30:00+02:00",
      "visibility": "PRIVATE",
      "recipients": ["Frei"],
      "observations": {"coalition_alignment": {
        "estimate": 55, "confidence": 0.700, "source": "synthetic_staff_report"
      }}
    }]
  }
}
```

报告不必正确；未收信的人不会知道。PRIVATE事实不自动进入公共媒体；HIDDEN事实可先改变世界且不通知人物，后来另排消息。PUBLIC是可公开，不是全员阅读。完整轨迹是审计数据，不能作为人物的上帝视角输入。

可以不载入主要人物任务，仅运行组织和外部事件。仍保留民调观察；没有使用人物卡时PSS标为不适用，不能伪造人物满足报告。

`variable_provenance`逐值标注五类证据地位，默认SIMULATION_ASSUMPTION；现实观察须引用账本ID。UNKNOWN不允许用零等数值占位。被模拟改变的变量会在轨迹和当前值中标为SCENARIO_GENERATED。

同一事实可以无效，也可以引发分化反应。事实、工作量、法案通过本身均不能直接给政党加减民调。

## 议会窗口 → 表决 → 反馈 → 下一轮环境

`ParliamentClockService` 将表决接为需要明确程序窗口的机构任务，通过`MemberVoteService`统一调用`plugins.majorities.MajorityModel`。旧投票器已删除。

表决读取当时的席位、出席与投票倾向。只有集团比例时，将其明确标为匿名成员的低精度投票先验；不会伪装成已研究的个人政策或忠诚。倾向可绑定世界变量，但这些绑定是场景假设，不是新增人格关系。确定性模式使用逐人众数代表票，不再取整期望票数；随机模式由同一插件抽样出席和共同信息扰动。

输入必须提供四类结果的反馈：明确通过、险过、险败、明确失败。实际结果更新权威、政治资本、压力或锁，也可发布不同后续任务。公共支持仍经过媒体链。

这是表决接口。涉及《基本法》授权、联邦参议院同意等法律条件的动作，仍须配置原有Intent/CheckContext检查。普通表决不能替代所有法律程序。

## 事实、参数与复现

原始历史环境仍截止于2026-07-31。增加持续运行能力不会自动把资料更新成2026-10-15的真实现状；人物卡和政党资料也保留各自来源说明。

运行保存环境ID、历史截止、规则、情景输入、覆盖项、子系统种子、逐节点轨迹，以及PSS与民调曲线。历史、媒体、投票使用主种子派生的各自随机流，人物人格不随机化。

## 使用

只查看公共环境，不启动测试故事：

```bash
python3 -m hakoniwa world
```

选择另一个已有环境：

```bash
python3 -m hakoniwa world --environment path/to/environment.json
```

注入运行输入：

```bash
python3 -m hakoniwa world \
  --config examples/shared_world_inputs.json \
  --output outputs/shared_environment_check
```

输入的 `environment` 路径相对于输入文件所在目录。旧情景入口保留，未迁移的旧情景仍走原有执行路径。

## 实现范围

公共环境已接通时间、容量、动态待办、历史事件、生成式行动空间、媒体竞争与投票反馈。具体问题仍来自定义好的因素、机制与事件语法；环境不凭空补齐资料或自动创造新制度。

部门目前使用执行队列。内部派别、任务抢占、通用政策实施评估和JSON快照直接恢复尚未实现。同一Python世界对象可以持续 `run_until()`；新进程根据配置和种子重放。
