"""Party collective profiles and validation fixtures."""
