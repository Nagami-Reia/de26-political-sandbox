"""Legacy CLI/import adapter; implementation and calibration now in polling plugin."""
from ...plugins.polling.legacy_projection import project, round_grid, main, DEFAULT_MODEL
if __name__ == "__main__":main()
