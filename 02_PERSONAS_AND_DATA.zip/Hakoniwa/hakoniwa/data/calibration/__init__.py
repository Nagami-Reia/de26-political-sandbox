"""Calibration datasets and observation models."""
