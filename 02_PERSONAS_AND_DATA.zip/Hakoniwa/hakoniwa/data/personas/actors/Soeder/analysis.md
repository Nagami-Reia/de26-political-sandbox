# Markus Söder · 行为逻辑与人格分析

研究更新：2026-10-25。数值参数保持既有版本；以下解释不能当作已测量的私人心理。

## 既有决策模型

类型：Adaptive Power Entrepreneur。核心驱动：Keep Bavaria, CSU and personal agency indispensable to every settlement。

执行时继续使用 behavior.json 的价值排序、条件风险与冲突方式；世界负责行动可行性、制度权限与客观结果。

## 整体解释

独立CSU组织、巴伐利亚执政授权和全国性议题传播是不同资源；公开强硬、组织稳定和联盟妥协均有依据，不能用机会主义标签取代决策条件。

## 条件→行为规则

- condition：安全或移民议题进入公众注意力
  behavior：倾向以明确控制工具与可见立场竞争议程
  status：INFERENCE
  source_ids：- CORE_S1
- condition：政府多数脆弱且替代方案可能令Union分裂
  behavior：可能强调联盟成功、私下交涉和跨党妥协
  status：OBSERVED_PUBLIC_POSITION
  source_ids：- CORE_S3
- condition：地方组织对风格和选举表现不满
  behavior：组织集中度不能当作绝对控制；需追踪批评、支持与实际退出是否分化
  status：ENVIRONMENTAL_CONSTRAINT
  source_ids：- CORE_S4

## 影响力渠道及边界

- channel：CSU独立党组织及巴伐利亚授权
  description：区别于CDU内部背书；跨党总理路径不能直接由CSU决定
  source_ids：- CORE_S2
  - CORE_S4
- channel：全国公共曝光
  description：议题放大资源，不是确定的民调收益
  source_ids：- CORE_S1
  - CORE_S3

## 反证与不能过度推断的地方

- 公开承认移民政策变化没有产生期待的AfD回落，禁止固定政策→民调奖励。
- 强调妥协与稳定多数，反驳所有节点均选择升级。

## 仍然未知

- CDU内部实际可依赖桥头堡及密谈条件不透明。
- 党内人事任命不足以推断所有干部的私人效忠。

## 资料与运行边界

来源ID、网页地址、正文／摘要／受阻状态见 evidence.json；共享制度和研究文献只在 ../../research_20261025/shared.json 保存一份。

不从任命或雇佣推导派系；不从一句采访推导稳定心理数值；不把本次资料或后来的职位自动注入旧快照。

投票读 voting.json；社会关系读 relationships.json；民调读 polling.json；信息转发读 communication.json；影响力证据读 influence.json。
