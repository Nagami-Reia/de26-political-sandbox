# Nina Warken · 行为逻辑与人格分析

研究更新：2026-10-25。数值参数保持既有版本；以下解释不能当作已测量的私人心理。

## 既有决策模型

类型：Resilient Reform Integrator。核心驱动：Turn contested reform into an administratively passable and politically supportable government result。

执行时继续使用 behavior.json 的价值排序、条件风险与冲突方式；世界负责行动可行性、制度权限与客观结果。

## 条件→行为规则

- condition：改革面临财政缺口与多个利益集团抵制
  behavior：倾向维持结构性目标，要求各方分担；用可实施的调整与联邦—州合作换取推进空间
  status：INFERENCE_FROM_PUBLIC_CONDUCT
  source_ids：- PR26-NW01
  - PR26-NW02
  - PR26-NW03
- condition：竞争者试图用组织安排阻断提名或女性进入关键职位
  behavior：强调持续建网、明确约定并及时争取机会；不宜建模成只等待被动任命
  status：SELF_REPORTED_STRATEGY
  source_ids：- PR26-NW04
- condition：改革建议超出自身法律职权
  behavior：先区分管辖边界，再说明其他层级可采取的行动
  status：OBSERVED_PUBLIC_ARGUMENT
  source_ids：- PR26-NW01

## 影响力渠道及边界

observed：- 律师及议会/党务经验有助于处理程序和利益冲突；妇女联盟及选区提供不同组织渠道
inferred：- 更可能通过协商和组织网络获取支持，不能把这些网络视作天然固定票仓
source_ids：- PR26-NW02
- PR26-NW04

## 反证与不能过度推断的地方

- 她对讨论开放并不表示所有政策都可退让；护理与医保融资中公开维护节约底线。
- 公开承认女性进入关键委员会的建议尚未实现，不能把人脉等同控制权。

## 仍然未知

- 没有可测量的私人忠诚阈值、真实疲劳恢复率或与Merz个人信任分数。
- 卫生部长阶段的行为不自动等同总理府协调角色；职位按世界快照读取。

## 资料与运行边界

来源ID、网页地址、正文／摘要／受阻状态见 evidence.json；共享制度和研究文献只在 ../../research_20261025/shared.json 保存一份。

不从任命或雇佣推导派系；不从一句采访推导稳定心理数值；不把本次资料或后来的职位自动注入旧快照。

投票读 voting.json；社会关系读 relationships.json；民调读 polling.json；信息转发读 communication.json；影响力证据读 influence.json。
