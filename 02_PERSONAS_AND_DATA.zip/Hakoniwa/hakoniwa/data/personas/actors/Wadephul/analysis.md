# Johann Wadephul · 行为逻辑与人格分析

研究更新：2026-10-25。数值参数保持既有版本；以下解释不能当作已测量的私人心理。

## 既有决策模型

类型：Diplomatic Intersection Builder。核心驱动：Preserve alliance and legal legitimacy by finding workable intersections between conflicting interests。

执行时继续使用 behavior.json 的价值排序、条件风险与冲突方式；世界负责行动可行性、制度权限与客观结果。

## 可核实的公开行为

- 多个本人访谈把利益、伙伴、沟通与防务能力同时列入外交工具
- 个人站具体描述议会、选区及外交专业交流渠道

## 条件→行为规则

- if：对方立场不完全相容但存在共同安全或经济利益
  then：把条件性合作和保持渠道作为可考虑选项，不因价值差异自动排除
  status：MODEL_INFERENCE
  source_ids：- GVR_WA1
  - GVR_WA2
- if：盟友要求跨越原定任务边界
  then：分别评估联盟维护、具体参与范围及需要澄清的表达，不把盟友支持等同任意参战
  status：MODEL_INFERENCE
  source_ids：- GVR_WA3

## 影响力渠道及边界

supported_channels：- 外交部门和对外谈判渠道
- 外交防务专业议会网络
- 石荷州与选区基础设施联系
limits：- 部长职位不自动控制外交政策总方向或党团票数
- 公开接触不是私人依赖强度

## 反证与不能过度推断的地方

- 威慑与国防投入主张反驳把其设为无条件降级或迁就者
- 本人承认沟通可能不够清楚，不能设为所有受众都准确理解

## 仍然未知

- 危机中各渠道实际可传递信息的速度与可靠性
- 与其他人物的私下信任、权力交换及不可接受让步阈值

## 资料与运行边界

来源ID、网页地址、正文／摘要／受阻状态见 evidence.json；共享制度和研究文献只在 ../../research_20261025/shared.json 保存一份。

不从任命或雇佣推导派系；不从一句采访推导稳定心理数值；不把本次资料或后来的职位自动注入旧快照。

投票读 voting.json；社会关系读 relationships.json；民调读 polling.json；信息转发读 communication.json；影响力证据读 influence.json。
