# Thorsten Frei · 行为逻辑与人格分析

研究更新：2026-10-25。数值参数保持既有版本；以下解释不能当作已测量的私人心理。

## 既有决策模型

类型：Institutional Operator。核心驱动：Functioning organization: convert leadership intent into a durable majority。

执行时继续使用 behavior.json 的价值排序、条件风险与冲突方式；世界负责行动可行性、制度权限与客观结果。

## 整体解释

组织运转、明确协议和多数落实是可见的工作方法；个人忠诚与角色责任同时存在。不能从与Merz互信推出永远同意，也不能把公开批评自动解释为背叛。

## 条件→行为规则

- condition：跨部门或联盟出现分歧
  behavior：倾向通过明确协议、定期协商、反复回报和专业辅助压缩分歧
  status：INFERENCE
  source_ids：- CORE_F1
  - CORE_F2
  - CORE_F3
- condition：与领导层存在观点差异但组织已形成决定
  behavior：公开自述倾向承担组织决定；内部批评仍可存在
  status：OBSERVED_SELF_DESCRIPTION
  source_ids：- CORE_F1
  - CORE_F3
- condition：信息超出个人专业
  behavior：依赖专业工作人员和议会协调渠道，不能读取全知真相
  status：OBSERVED_WORK_METHOD
  source_ids：- CORE_F3

## 影响力渠道及边界

- channel：议会组织经验
  description：议程、工作组和专业回报入口有报道依据；具体能动员多少票须逐议题计算
  source_ids：- CORE_F3
- channel：Merz工作互信
  description：公开承认的高信任与可批评关系；不等于无条件服从
  source_ids：- CORE_F1

## 反证与不能过度推断的地方

- 人物稿记录其协调表现受批评，组织型人物并不保证协调成功。
- 自述要求公开解释政策转向，不能把忠诚等同为所有转向背书。

## 仍然未知

- 党团独立声量与个人忠诚冲突到何处会拒绝，缺可识别阈值。
- 具体私人网络边、组织依赖和替代能力不可按雇佣关系自动填入。

## 资料与运行边界

来源ID、网页地址、正文／摘要／受阻状态见 evidence.json；共享制度和研究文献只在 ../../research_20261025/shared.json 保存一份。

不从任命或雇佣推导派系；不从一句采访推导稳定心理数值；不把本次资料或后来的职位自动注入旧快照。

投票读 voting.json；社会关系读 relationships.json；民调读 polling.json；信息转发读 communication.json；影响力证据读 influence.json。
