# Carsten Linnemann · 行为逻辑与人格分析

研究更新：2026-10-25。数值参数保持既有版本；以下解释不能当作已测量的私人心理。

## 既有决策模型

类型：Reform Executor。核心驱动：Wirksamkeit: turn diagnosed dysfunction into a rule that changes behavior。

执行时继续使用 behavior.json 的价值排序、条件风险与冲突方式；世界负责行动可行性、制度权限与客观结果。

## 整体解释

把可见的改革实施当作政治效果，同时会用保住联盟和后续议程来解释局部妥协。专业能力、学习和执行偏好不能混成一个参数。

## 条件→行为规则

- condition：人事争论挤占生活成本与改革议程
  behavior：倾向把讨论转回税负、能源和行政障碍等可落实政策
  status：INFERENCE
  source_ids：- CORE_L3
- condition：单项法案不理想但失败会损害联盟和其他改革
  behavior：可能接受局部妥协，保留后续改革路径
  status：OBSERVED_JUSTIFICATION
  source_ids：- CORE_L4
- condition：新任务缺乏长期专业积累
  behavior：需要学习和专家支持；改革意愿不能抵消专业与执行约束
  status：OBSERVED_ADMISSION_AND_CRITICISM
  source_ids：- CORE_L1
  - CORE_L2

## 影响力渠道及边界

- channel：政策概念推动与党内议程
  description：自述活动养老金从党纲到联盟协商的路径，显示议题持续性；实际归功仍需独立程序核对
  source_ids：- CORE_L4
- channel：党内与公众传播
  description：能把内部人事问题重框为实施问题，不保证受众接受
  source_ids：- CORE_L3

## 反证与不能过度推断的地方

- 岗位转换经历及不同阶段的说法表明能力判断受情境变化，不能写成恒定万能执行者。
- 接受养老金方案的妥协理由反驳永不妥协的纯改革执行机器。

## 仍然未知

- 卫生复杂利益协商的私人红线和可替代专家网络未充分可见。
- 长期思考等心理形容词不足以给恢复速度定量。

## 资料与运行边界

来源ID、网页地址、正文／摘要／受阻状态见 evidence.json；共享制度和研究文献只在 ../../research_20261025/shared.json 保存一份。

不从任命或雇佣推导派系；不从一句采访推导稳定心理数值；不把本次资料或后来的职位自动注入旧快照。

投票读 voting.json；社会关系读 relationships.json；民调读 polling.json；信息转发读 communication.json；影响力证据读 influence.json。
