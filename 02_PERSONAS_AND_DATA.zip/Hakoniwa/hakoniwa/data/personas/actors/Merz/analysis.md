# Friedrich Merz · 行为逻辑与人格分析

研究更新：2026-10-25。数值参数保持既有版本；以下解释不能当作已测量的私人心理。

## 既有决策模型

类型：Strategic Reform Leader。核心驱动：Gestaltung: impose a strategic direction on political reality。

执行时继续使用 behavior.json 的价值排序、条件风险与冲突方式；世界负责行动可行性、制度权限与客观结果。

## 整体解释

将改革方向、政府行动能力与政治权威相连；明确表达能创造议程，也可能增加说服和联盟协调成本。不能把宏观理性、忠诚敏感度直接当已经测量的心理事实。

## 条件→行为规则

- condition：认为结构性问题持续恶化且仍存在议会与联盟路径
  behavior：倾向要求推进改革、解释必要性并争取多数
  status：INFERENCE_FROM_PUBLIC_CONDUCT
  source_ids：- CORE_M1
  - CORE_M2
  - CORE_M4
- condition：路线方向仍获本人认可但公众沟通明显失效
  behavior：可能调整表达、接触对象和解释方式，而非必然撤回政策
  status：INFERENCE
  source_ids：- CORE_M3
- condition：单方面推动受议会程序或联盟伙伴约束
  behavior：仍需讨论与谈判；不能用强领导标签跳过制度
  status：OBSERVED_SELF_DESCRIPTION
  source_ids：- CORE_M1

## 影响力渠道及边界

- channel：正式政府/党内方向设置
  description：职位所带来的提议、协调与传播入口须由当前场景办公室状态确认
  source_ids：- CORE_M1
  - CORE_M2
- channel：与Frei的工作互信
  description：Frei本人描述直接互信与开放批评；这是特定方向的公开证据，不证明所有被任命者组成Merz派系
  source_ids：- CORE_F1

## 反证与不能过度推断的地方

- 公开承认沟通不足并尝试调整，反驳永远不调整、只赌不谈的单一剧本。
- IHK讲话明确承认改革无法简单自上而下命令，反驳无限行政权力模型。

## 仍然未知

- 真正的失败承受阈值、忠诚破裂阈值与民调权重没有直接测量。
- 私人决策过程和未公开的信息状态不可由记者形容词补全。

## 资料与运行边界

来源ID、网页地址、正文／摘要／受阻状态见 evidence.json；共享制度和研究文献只在 ../../research_20261025/shared.json 保存一份。

不从任命或雇佣推导派系；不从一句采访推导稳定心理数值；不把本次资料或后来的职位自动注入旧快照。

投票读 voting.json；社会关系读 relationships.json；民调读 polling.json；信息转发读 communication.json；影响力证据读 influence.json。
