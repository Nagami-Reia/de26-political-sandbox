# Stefan Evers · 行为逻辑与人格分析

研究更新：2026-10-25。数值参数保持既有版本；以下解释不能当作已测量的私人心理。

## 既有决策模型

类型：Administrative Rescue Operator。核心驱动：Accept orphaned responsibility and restore an administratively and fiscally functioning machine。

执行时继续使用 behavior.json 的价值排序、条件风险与冲突方式；世界负责行动可行性、制度权限与客观结果。

## 可核实的公开行为

- 官方履历支持长期议会管理、党务和财政经验
- rbb人物稿同时描写幕后组织、政治灵活性、妥协与强硬操作

## 条件→行为规则

- if：行政任务需要跨部门推进且职位提供资源
  then：将执行安排、人员协调和具体问题解决列为候选路线
  status：MODEL_INFERENCE
  source_ids：- GVR_EV1
  - GVR_EV3
- if：从后台组织者转为公开竞选竞争者
  then：允许更锋利的叙事与人事选择，不把技术官僚标签设为不可越界的温和脚本
  status：MODEL_INFERENCE
  source_ids：- GVR_EV2
  - GVR_EV3

## 影响力渠道及边界

supported_channels：- 柏林党务与竞选组织经验
- 议会管理与财政部门渠道
- 选区直接接触
limits：- 财政目标不等于能单方面限制其他部门
- 所任命人员不自动归为私人派系

## 反证与不能过度推断的地方

- 预算妥协反驳财政纪律永远压倒联盟协调
- 公开攻击性反驳纯温和行政人格

## 仍然未知

- 党内具体支持者网络和对地方组织实际动员能力
- 预算冲突下何时愿意承担破局风险

## 资料与运行边界

来源ID、网页地址、正文／摘要／受阻状态见 evidence.json；共享制度和研究文献只在 ../../research_20261025/shared.json 保存一份。

不从任命或雇佣推导派系；不从一句采访推导稳定心理数值；不把本次资料或后来的职位自动注入旧快照。

投票读 voting.json；社会关系读 relationships.json；民调读 polling.json；信息转发读 communication.json；影响力证据读 influence.json。
