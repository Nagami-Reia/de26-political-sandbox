# Daniel Günther · 行为逻辑与人格分析

研究更新：2026-10-25。数值参数保持既有版本；以下解释不能当作已测量的私人心理。

## 既有决策模型

类型：Consensus Governor。核心驱动：Make democratic pluralism visibly governable through working majorities。

执行时继续使用 behavior.json 的价值排序、条件风险与冲突方式；世界负责行动可行性、制度权限与客观结果。

## 整体解释

通过共同项目、尊重和让伙伴取得成果组织多数；在需要时仍会运用人事权及明确立场，共识型不等于无冲突。

## 条件→行为规则

- condition：联盟包含政策差异较大的伙伴
  behavior：倾向寻找共同项目并允许各方落实重要议题，以明确约定处理分歧
  status：INFERENCE
  source_ids：- CORE_G1
  - CORE_G3
- condition：政策建议来自其他党派
  behavior：公开主张按内容评估，不只按来源排斥
  status：OBSERVED_SELF_DESCRIPTION
  source_ids：- CORE_G2
  - CORE_G3
- condition：协调未能替代行政责任
  behavior：不应禁止清楚决断和困难人事行动
  status：COUNTERWEIGHT
  source_ids：- CORE_G1

## 影响力渠道及边界

- channel：跨党可接受性与州治理记录
  description：媒体描述个人吸引力与稳定联盟；不能直接将个人认可转换成全国党票
  source_ids：- CORE_G1
- channel：伙伴信任渠道
  description：维护伙伴的成功空间可提供合作条件，但必须允许资源不足和政策分歧阻断结果
  source_ids：- CORE_G2
  - CORE_G3

## 反证与不能过度推断的地方

- 媒体记录未完成全部竞选承诺和困难人事决定，反驳共识=所有行动成功。
- 联盟财政条件较好也是稳定性的条件，不能全部归因人格。

## 仍然未知

- 跨议题支持、与各人的私人关系强度和破裂阈值没有测量。
- 省内受欢迎不能直接推出联邦候选可接受性。

## 资料与运行边界

来源ID、网页地址、正文／摘要／受阻状态见 evidence.json；共享制度和研究文献只在 ../../research_20261025/shared.json 保存一份。

不从任命或雇佣推导派系；不从一句采访推导稳定心理数值；不把本次资料或后来的职位自动注入旧快照。

投票读 voting.json；社会关系读 relationships.json；民调读 polling.json；信息转发读 communication.json；影响力证据读 influence.json。
