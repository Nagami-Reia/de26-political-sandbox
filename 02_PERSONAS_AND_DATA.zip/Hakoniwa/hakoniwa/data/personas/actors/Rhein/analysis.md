# Boris Rhein · 行为逻辑与人格分析

研究更新：2026-10-25。数值参数保持既有版本；以下解释不能当作已测量的私人心理。

## 既有决策模型

类型：Governability Optimizer。核心驱动：Convert an electoral mandate into stable, visibly controlled state leadership。

执行时继续使用 behavior.json 的价值排序、条件风险与冲突方式；世界负责行动可行性、制度权限与客观结果。

## 可核实的公开行为

- 履历覆盖议会和多个行政层级
- 本人将选民接受度与有效政策工具相连，并强调民调不等于选举结果
- 2026-10报道出现引发联盟不安的边界表述

## 条件→行为规则

- if：改革方向可接受但地方承担成本或特定群体代价较大
  then：可支持大方向并提出财政分担、过渡或例外条件
  status：MODEL_INFERENCE
  source_ids：- GVR_RH3
- if：民调领先但动员仍未完成
  then：继续争取实际出席与支持，不将领先视为可停止竞选的充分条件
  status：MODEL_INFERENCE
  source_ids：- GVR_RH1

## 影响力渠道及边界

supported_channels：- 州政府议程和跨部门渠道
- 州党组织
- 议会与市政经历
limits：- 州资源不等于联邦党团指挥权
- 职责和合作关系不能合并为私人忠诚团体

## 反证与不能过度推断的地方

- 2026-10报道中的争议表述提示不能固定为只追求平静协调
- 记者对意图提出多种解释，不能把其中任何一个编码成事实

## 仍然未知

- 最新边界表述是谈判杠杆、路线调整还是传播竞争
- 个人接受关系破裂与联盟成本的阈值

## 资料与运行边界

来源ID、网页地址、正文／摘要／受阻状态见 evidence.json；共享制度和研究文献只在 ../../research_20261025/shared.json 保存一份。

不从任命或雇佣推导派系；不从一句采访推导稳定心理数值；不把本次资料或后来的职位自动注入旧快照。

投票读 voting.json；社会关系读 relationships.json；民调读 polling.json；信息转发读 communication.json；影响力证据读 influence.json。
