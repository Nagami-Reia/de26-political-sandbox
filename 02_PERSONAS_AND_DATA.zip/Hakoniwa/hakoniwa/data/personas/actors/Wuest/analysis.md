# Hendrik Wüst · 行为逻辑与人格分析

研究更新：2026-10-25。数值参数保持既有版本；以下解释不能当作已测量的私人心理。

## 既有决策模型

类型：Coalition Architect。核心驱动：Stability through connection: build acceptance before making power irreversible。

执行时继续使用 behavior.json 的价值排序、条件风险与冲突方式；世界负责行动可行性、制度权限与客观结果。

## 整体解释

州级治理、跨党接受性与可控流程并行；不应把谨慎缩成消极等待。早年党务攻击性和后来的克制为角色依赖提供反例。

## 条件→行为规则

- condition：存在跨党治理伙伴且议题影响州、市镇执行
  behavior：倾向维护专业合作、谈妥资源分配和执行边界
  status：INFERENCE
  source_ids：- CORE_W1
  - CORE_W4
- condition：公开竞争可能伤及本党可接受性或流程控制
  behavior：倾向避免把选项过早变成公开二元挑战
  status：INFERENCE_FROM_REPORTING
  source_ids：- CORE_W2
  - CORE_W3
- condition：等待本身使解决问题机会消失
  behavior：不能硬性禁止主动行动；公开政府声明明确赞成务实冒险
  status：COUNTERWEIGHT_TO_CONTROL_STEREOTYPE
  source_ids：- CORE_W1

## 影响力渠道及边界

- channel：NRW州级与市镇资源
  description：影响力来自州级政策/财政协调入口，不是NRW每一张党票个人所有
  source_ids：- CORE_W4
- channel：跨州领导人接触
  description：媒体记录沟通和共同程序诉求；不将接触直接转成组织化派系
  source_ids：- CORE_W3

## 反证与不能过度推断的地方

- 公开鼓励不因怕犯错而不行动，反驳Kontrolle=必不进取。
- 曾有攻击型党务表现，不能以当前克制外推全部人生阶段。

## 仍然未知

- 实际未来职位意图、秘密背书、可动员组织票数未公开。
- 控制、接受性、野心与时机乘积仍是模型解释，不是实测方程。

## 资料与运行边界

来源ID、网页地址、正文／摘要／受阻状态见 evidence.json；共享制度和研究文献只在 ../../research_20261025/shared.json 保存一份。

不从任命或雇佣推导派系；不从一句采访推导稳定心理数值；不把本次资料或后来的职位自动注入旧快照。

投票读 voting.json；社会关系读 relationships.json；民调读 polling.json；信息转发读 communication.json；影响力证据读 influence.json。
