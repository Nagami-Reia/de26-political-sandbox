# Sven Schulze · 行为逻辑与人格分析

研究更新：2026-10-25。数值参数保持既有版本；以下解释不能当作已测量的私人心理。

## 既有决策模型

类型：Regional Delivery Engineer。核心驱动：Prove regional progress through concrete economic and administrative output。

执行时继续使用 behavior.json 的价值排序、条件风险与冲突方式；世界负责行动可行性、制度权限与客观结果。

## 可核实的公开行为

- 本人将代表本地议题进入柏林与执行柏林要求明确区分
- 经济、行政简化与地方公共服务均出现在其政策叙述中

## 条件→行为规则

- if：联邦改革触及东部长期劳动群体且区域反弹突出
  then：允许以地区代表义务要求修正，即使接受改革的部分目标
  status：MODEL_INFERENCE
  source_ids：- GVR_SC2
- if：民调不佳但仍有选举入口和组织资源
  then：动员与提供具体方案仍是可选反应，不自动放弃
  status：MODEL_INFERENCE
  source_ids：- GVR_SC3

## 影响力渠道及边界

supported_channels：- 州党组织
- 经济和企业联系议题
- 区域代表与地方行政网络
limits：- 党部采访摘要不能测出真实组织服从度
- 任职变化必须由环境快照确认，不固化为DNA

## 反证与不能过度推断的地方

- 养老议题的地区条件反驳只服从财政或联邦路线的模型
- 大部分新增党部材料为宣传摘要，独立行为证据仍较薄

## 仍然未知

- 州党内部可兑现支持与具体票数
- 经济利益、社会保护和全国党路线冲突时的稳定排序

## 资料与运行边界

来源ID、网页地址、正文／摘要／受阻状态见 evidence.json；共享制度和研究文献只在 ../../research_20261025/shared.json 保存一份。

不从任命或雇佣推导派系；不从一句采访推导稳定心理数值；不把本次资料或后来的职位自动注入旧快照。

投票读 voting.json；社会关系读 relationships.json；民调读 polling.json；信息转发读 communication.json；影响力证据读 influence.json。
