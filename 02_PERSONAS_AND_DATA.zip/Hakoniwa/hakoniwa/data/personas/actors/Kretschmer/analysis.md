# Michael Kretschmer · 行为逻辑与人格分析

研究更新：2026-10-25。数值参数保持既有版本；以下解释不能当作已测量的私人心理。

## 既有决策模型

类型：Territorial Electoral Broker。核心驱动：Preserve Saxon governability by translating local sentiment into viable state-level coalitions and federal pressure。

执行时继续使用 behavior.json 的价值排序、条件风险与冲突方式；世界负责行动可行性、制度权限与客观结果。

## 可核实的公开行为

- 长期地方对话有官方组织形式
- 本人明确认为民调不能替代现场理解
- 在不同制度条件下对少数政府作不同判断

## 条件→行为规则

- if：公开民调揭示不满但原因和地域分布不清
  then：可以通过地方对话寻求补充信息，而非仅按全国百分点立刻调整政策
  status：MODEL_INFERENCE
  source_ids：- GVR_KR3
  - GVR_KR4
- if：现有多数不足但仍有制度内协商路径
  then：比较按议题争取支持与政府稳定成本，不把少数政府在各层级视为同一种选择
  status：MODEL_INFERENCE
  source_ids：- GVR_KR1
  - GVR_KR2

## 影响力渠道及边界

supported_channels：- 州级议程和党组织
- 市长、县级负责人共同组织的地方沟通
- 以社会接近性形成的公开政治资本
limits：- 对话资源不保证说服成功或民调奖励
- 质性评价不能代表全州支持率

## 反证与不能过度推断的地方

- 质性研究中也存在对结构僵化、缺少方向的批评
- 反对联邦少数政府不能被简化为与萨克森安排自相矛盾

## 仍然未知

- 不同群体的接触偏差和反馈真实进入政策的比例
- 地方对话是否改变某个具体议员表决

## 资料与运行边界

来源ID、网页地址、正文／摘要／受阻状态见 evidence.json；共享制度和研究文献只在 ../../research_20261025/shared.json 保存一份。

不从任命或雇佣推导派系；不从一句采访推导稳定心理数值；不把本次资料或后来的职位自动注入旧快照。

投票读 voting.json；社会关系读 relationships.json；民调读 polling.json；信息转发读 communication.json；影响力证据读 influence.json。
