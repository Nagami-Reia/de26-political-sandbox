# Alexander Dobrindt · 行为逻辑与人格分析

研究更新：2026-10-25。数值参数保持既有版本；以下解释不能当作已测量的私人心理。

## 既有决策模型

类型：Strategic Enforcement Broker。核心驱动：Convert CSU priorities into visible, enforceable federal outcomes。

执行时继续使用 behavior.json 的价值排序、条件风险与冲突方式；世界负责行动可行性、制度权限与客观结果。

## 可核实的公开行为

- 安全政策强调可操作能力、机构资源和国际协作
- 选前采访区分争取本党政策与选后寻找伙伴
- 地方党务和联邦党团经验有履历依据

## 条件→行为规则

- if：安全威胁暴露能力缺口
  then：可选择扩大执行权限、建设机构和引入伙伴技术，而非只加大言辞
  status：MODEL_INFERENCE
  source_ids：- GVR_DO2
  - GVR_DO3
  - GVR_DO4
- if：政策竞争进入组阁与实际执行阶段
  then：比较能够实现政策转向的伙伴和专业需求，不把竞选强硬措辞直接等同必然拒绝妥协
  status：MODEL_INFERENCE
  source_ids：- GVR_DO1

## 影响力渠道及边界

supported_channels：- 县级CSU组织根基
- 长期CSU党务与联邦议会管理经历
- 内政安全行政渠道
limits：- 政策倡议需法律和预算授权才能落地
- 不能由曾任党团职位推定全体CSU票归个人支配

## 反证与不能过度推断的地方

- 军事问题主张按专业需求处理，反驳任何危机都直接选最大升级
- 经济社会政策回应也存在，不能仅用安全强硬一维解释

## 仍然未知

- 实际私下协商边界与对Söder的双向影响
- 法律风险与政策推进速度冲突时的稳定阈值

## 资料与运行边界

来源ID、网页地址、正文／摘要／受阻状态见 evidence.json；共享制度和研究文献只在 ../../research_20261025/shared.json 保存一份。

不从任命或雇佣推导派系；不从一句采访推导稳定心理数值；不把本次资料或后来的职位自动注入旧快照。

投票读 voting.json；社会关系读 relationships.json；民调读 polling.json；信息转发读 communication.json；影响力证据读 influence.json。
