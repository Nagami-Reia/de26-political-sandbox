# Alexander Dobrindt · Dobrindt

本目录是该人物的权威配置；共享引擎执行它，不复制一套个人 AI。

| 文件 | 负责什么 |
| --- | --- |
| analysis.md | 有来源的行为分析、影响力、反例与未知 |
| behavior.json | 固定人格、价值排序、条件风险和冲突方式 |
| voting.json | 既有投票器接口及逐议题价值映射；不授予议席 |
| relationships.json | 有方向的人际关系、依赖与历史初始状态 |
| polling.json | 各种已送达民调的接收权重与复审接口 |
| communication.json | 向别人转达信息的边界；默认不自动转发 |
| pss.json | 压力—恢复参数及有日期的初始状态 |
| resources.json | 有日期的初始资源；须由世界更新 |
| memory.json | 历史记忆；回溯冻结时须过滤 |
| rationality.json | 工具、实质、人格、战略的既有权重 |
| influence.json | 有来源的影响力渠道与控制边界 |
| evidence.json | 来源、观察、推断、未知与参数更新状态 |

修改目录后运行 `python -m hakoniwa.persona_repository export` 更新兼容视图。
