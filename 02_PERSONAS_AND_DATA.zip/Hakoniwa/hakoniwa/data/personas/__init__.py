"""Canonical persona-card datasets and their provenance."""
