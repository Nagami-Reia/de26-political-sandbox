# 人物系统：一人一目录

现有 **17 人**，没有新增人物。入口是 `registry.json`；权威配置在 `actors/<actor>/`。

```text
personas/
├── registry.json
├── actors/
│   ├── Merz/
│   │   ├── manifest.json
│   │   ├── analysis.md          人格分析、条件行为、反例、未知
│   │   ├── behavior.json        固定人格与决策参数
│   │   ├── voting.json          投票接口与逐议题价值映射
│   │   ├── relationships.json   有方向的社会关系和依赖
│   │   ├── polling.json         不同民调口径的接收和反馈权重
│   │   ├── communication.json   对他人转达信息的边界
│   │   ├── influence.json       有来源的影响力渠道及其限制
│   │   ├── pss.json             压力恢复、动态状态初值
│   │   ├── resources.json       有日期的资源初值
│   │   ├── memory.json          历史记忆
│   │   ├── rationality.json     既有四类理性权重
│   │   ├── evidence.json        逐条来源、事实/解释/未知
│   │   └── README.md
│   └── 其余16人，同样结构
├── research_20261025/           本轮考据与共享研究文献
└── cards_pss.json               自动导出的旧接口兼容视图
```

每人的文件夹少于100个文件；同一层只有17个人物目录，便于浏览和上传。

## 运行与修改

```bash
python -m hakoniwa personas list --pretty
python -m hakoniwa personas inspect --actor Frei --pretty
python -m hakoniwa personas inspect --actor Frei --component voting --pretty
python -m hakoniwa personas validate --pretty
python -m hakoniwa personas export
```

现有 `actors`、`card`、`decide`、`play` 和场景入口继续使用原来的公共引擎。
`FreeAgentDecisionEngine.from_json()` 也可直接接收本目录或 `registry.json`。

改人物请改个人目录，再 export。不要手工改生成的 cards_pss.json 或两个
rationality_profiles 兼容视图；启动时发现分歧会报错，而不是悄悄选一份。
早期 cards.json、cards_v2.json 保持历史格式，不作为当前模块目录的另一个权威来源。
传入其他位置的冻结旧卡/显式overlay仍按原文件读，不强制套用本次最新考据。

## 模块如何连接

| 人物模块 | 实际运行连接 |
| --- | --- |
| behavior / pss / resources / memory / relationships | `persona_repository` 组装，原 `persona_v2` 执行 |
| voting | 原 `plugins.majorities.integration`；Zustrom回溯读取该人的逐议题映射 |
| polling | 原 `political_poll_feedback.profile_for`，场景可显式覆盖 |
| communication | `persona_communication`，只有场景授权通道和实际发送动作才转发 |
| rationality | 原 `LayeredConfiguration` 加载个人权重 |
| analysis / evidence / influence | 研究与诊断；不会成为人物的全知信息或自动票数 |

共享代码负责数学和制度，人格文件负责个人参数。不会为17人复制17套引擎。

## 考据边界

本轮新增73个可读独立网页，含明确标注的摘要、付费导语和PDF局部阅读；80条
来源记录中也保留了失败、返回首页等情况，不能把这些算成全文已读。
治理组另外保留7次失败/未采用访问。逐页见 research_20261025 各组JSON与summary.json。

新资料提供了条件行为、公开立场、影响力渠道、反例和未知；**没有把文字直接
换算成新的心理数值**。旧数值完整保留，仍有未实证校准部分。雇佣、任命、同州、
同党、公开赞成，都不自动证明派系归属、个人忠诚或固定投票支持。

研究更新日是2026-10-25；原卡、资源、状态和记忆保留各自冻结日期。
研究材料不会自动进入历史回放中的人物认知。行为注释也不是强制剧情脚本。

完整接线和信息转发配置见 `../../docs/MODULAR_PERSONAS.md`。
